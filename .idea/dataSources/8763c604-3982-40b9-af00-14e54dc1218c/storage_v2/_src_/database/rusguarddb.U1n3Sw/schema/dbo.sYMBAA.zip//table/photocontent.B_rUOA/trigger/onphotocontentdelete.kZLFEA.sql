-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[OnPhotoContentDelete]
   ON  [dbo].[PhotoContent]
   INSTEAD OF DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


    update [dbo].AcsConfigurator
	set PassportPhotoNumber = NULL
	where PassportPhotoNumber in (select _id from deleted)
	
	    
	update [dbo].AcsConfigurator
	set DriverLicensePhotoNumber = NULL
	where DriverLicensePhotoNumber in (select _id from deleted)
	
	update [dbo].AcsConfigurator
	set ForeignPassportPhotoNumber = NULL
	where ForeignPassportPhotoNumber in (select _id from deleted)
	
	delete [dbo].[PhotoContent] where _id in (select _id from deleted)
    -- Insert statements for trigger here

END
go

