-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[udf_CreateIntegerTable]
(
	@IDs as xml
)
RETURNS 
@temp TABLE 
(
	_id int not null primary key
)
AS
BEGIN
		INSERT INTO @temp(_id)
		SELECT
			list.Id.value('.', 'int')
		FROM
			@ids.nodes('/*/int') as list(id)
		RETURN
END
go

