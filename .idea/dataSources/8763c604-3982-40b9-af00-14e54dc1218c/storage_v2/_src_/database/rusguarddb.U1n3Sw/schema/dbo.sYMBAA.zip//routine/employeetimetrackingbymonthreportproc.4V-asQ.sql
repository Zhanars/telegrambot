-- =============================================
-- Учет рабочего времени за месяц
-- =============================================
CREATE PROCEDURE [dbo].[EmployeeTimeTrackingByMonthReportProc]
	@Month	   int,				 -- Месяц
	@Year	   int,				 -- Год
	@Employees nvarchar(max)     -- Идентификаторы сотрудников, разделенные запятыми
AS
BEGIN
	SET NOCOUNT ON;

	if (@Month < 1 and @Month > 12)
		raiserror('@Month can''t be less then 1 or greater then 12 ', 0, 0);

	if (@Year < 2010)
		raiserror('@Year can''t be less then 2010', 0,0);

	declare @StartDate date = DATEFROMPARTS(@Year, @Month, 1)
	declare @EndDate   date = EOMONTH(@StartDate)

	exec EmployeeTimeTrackingReportProc @StartDate, @EndDate, @Employees
END
go

