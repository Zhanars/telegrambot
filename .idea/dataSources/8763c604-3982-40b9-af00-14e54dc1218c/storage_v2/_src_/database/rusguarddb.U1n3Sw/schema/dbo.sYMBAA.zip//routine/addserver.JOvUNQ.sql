-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[AddServer] 
	@idNet uniqueidentifier,
	@Url NVARCHAR(50),
	@Type NVARCHAR(50),
	@id uniqueidentifier OUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SET @id = NEWID()
    INSERT INTO Resource (_id, ResourceType) VALUES (@id, 1)
    INSERT INTO Server (_idResource, _idNet) VALUES (@id, @idNet)
    INSERT INTO Property (_idResource, PropertyName, Value) VALUES (@id, 'Type', @Type)
    INSERT INTO Property (_idResource, PropertyName, Value) VALUES (@id, 'Url', @Url)
    INSERT INTO State (_idResource, Name, Value) VALUES (@id, 'IsAttached', 'False')
END
go

