-- =============================================
-- Создает временную группу и добавляет туда заданное количество сотрудников
-- =============================================
CREATE PROCEDURE [dbo].[test_CreateNumberOfEmployees]
	@Count	int -- Количество добавляемых сотрудников
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	declare @groupId    as table (id uniqueidentifier)
	declare @positionId as table (id uniqueidentifier)


	insert into EmployeeGroup   (Name) output inserted._id into @groupId    values ('TestGroupName ' + CAST(GETDATE() as nvarchar))
	insert into EmployeePosition(Name) output inserted._id into @positionId values ('Слесарь ' + CAST(GETDATE() as nvarchar))


	declare @idx int = 0

	while(@idx < @Count)
	begin
		set @idx = @idx + 1;
		insert into Employee(LastName, TableNumber, EmployeeGroupID, EmployeePositionID) values 
																								('Иванов' + CAST(@idx as nvarchar(100)), CAST(@idx as nvarchar(100)), 
																								(select top 1 id from @groupId), 
																								(select top 1 id from @positionId))
	end
END
go

