-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[DeleteDriver_UpdateParentDriverDatabaseChangeVersion]
   ON  [dbo].[Driver]
   AFTER INSERT, UPDATE, DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

update State
set Value = Value + 1
from inserted as ins
join DriverLinkProperty as parentLinkProperty on ins._idParentProperty = parentLinkProperty._id
join Driver as parentDriver on parentLinkProperty._idParent = parentDriver._idResource
join Resource as parentResource on parentDriver._idResource = parentResource._id
join State as parentState on parentResource._id = parentState._idResource
where parentState.Name = 'DatabaseChangeVersion'


update State
set Value = Value + 1
from deleted as del
join DriverLinkProperty as parentLinkProperty on del._idParentProperty = parentLinkProperty._id
join Driver as parentDriver on parentLinkProperty._idParent = parentDriver._idResource
join Resource as parentResource on parentDriver._idResource = parentResource._id
join State as parentState on parentResource._id = parentState._idResource
where parentState.Name = 'DatabaseChangeVersion'


    -- Insert statements for trigger here

END
go

