CREATE TRIGGER [dbo].[ServerAfterDeleted]
   ON  [dbo].[Server]
   AFTER DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @cnt int
	SELECT @cnt = COUNT(*) FROM DELETED
	
	IF(@cnt > 0)
	BEGIN
		DELETE FROM Resource WHERE _id IN (SELECT _idResource FROM DELETED)
    END

END
go

