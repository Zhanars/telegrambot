-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[UpdateDriverDatabaseChangeVersion]
   ON  [dbo].[Property]
   AFTER INSERT, UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


update Property
set UpdateTime = SYSUTCDATETIME()
where _id in (select _id from inserted)

update State
set Value = st.Value + 1
from State st
join Resource as res on st._idResource = res._id
join inserted as ins on res._id = ins._idResource
where Name = 'DatabaseChangeVersion' and ins.PropertyName != 'EnableOperatorDecisionEntry' and ins.PropertyName != 'EnableOperatorDecisionExit'
    -- Insert statements for trigger here

END
go

