-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[ResourceDeleted]
   ON  [dbo].[Resource]
   INSTEAD OF DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @cnt int
	SELECT @cnt = COUNT(*) FROM DELETED
	
	IF(@cnt > 0)
	BEGIN
		DELETE FROM Link WHERE _idChild IN (SELECT _id FROM DELETED)
		DELETE FROM LinkMonitoringInfo WHERE _idChildResource IN (SELECT _id FROM DELETED)
		DELETE FROM Net WHERE _idResource IN (SELECT _id FROM DELETED WHERE ResourceType = 2)
		DELETE FROM Server WHERE _idResource IN (SELECT _id FROM DELETED WHERE ResourceType = 1)
		DELETE FROM Driver WHERE _idResource IN (SELECT _id FROM DELETED WHERE ResourceType = 0)
		DELETE FROM Resource WHERE _id IN (SELECT _id FROM DELETED)
    END

END
go

