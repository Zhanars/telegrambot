-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[AcsKeys_After_Insert_Update_Delete]
   ON  [dbo].[AcsKeys]
   AFTER INSERT,UPDATE, DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	update Employee
	set ModificationDateTime = GetDate()
	where Employee._id in (select Employee._id from inserted
						   inner join AcsKey2EmployeeAssignment on AcsKey2EmployeeAssignment.AcsKeyId = inserted.KeyNumber
						   inner join Employee on Employee._id = AcsKey2EmployeeAssignment.EmployeeId)


	update Employee
	set ModificationDateTime = GetDate()
	where Employee._id in (select Employee._id from deleted
						   inner join AcsKey2EmployeeAssignment on AcsKey2EmployeeAssignment.AcsKeyId = deleted.KeyNumber
						   inner join Employee on Employee._id = AcsKey2EmployeeAssignment.EmployeeId)

    -- Insert statements for trigger here
END
go

