CREATE VIEW dbo.EmployeesView
AS
SELECT        empl._id, empl.FirstName, empl.SecondName, empl.LastName, empl.TableNumber, empl.RegistrationAddress, empl.ResidentialAddress, 
                         empl.Comment AS EmployeeDetails, emplGroup.Name AS EmployeeGroup, position.Name AS Position, photo.Photo, key1.KeyNumber AS Key1Number, 
                         key1.StartDate AS Key1StartDate, key1.EndDate AS Key1EndDate, key1.Description AS Key1Details, key2.KeyNumber AS Key2Number, 
                         key2.StartDate AS Key2StartDate, key2.EndDate AS Key2EndDate, key2.Description AS Key2Details
FROM            dbo.Employee AS empl LEFT OUTER JOIN
                         dbo.EmployeePosition AS position ON empl.EmployeePositionID = position._id AND position.IsRemoved = 0 LEFT OUTER JOIN
                         dbo.EmployeePhoto AS photo ON empl._id = photo.EmployeeID AND photo.PhotoNumber = 1 LEFT OUTER JOIN
                         dbo.EmployeeGroup AS emplGroup ON empl.EmployeeGroupID = emplGroup._id LEFT OUTER JOIN
                         dbo.AcsKey2EmployeeAssignment AS key1Assignment ON empl._id = key1Assignment.EmployeeId AND 
                         key1Assignment.AssignmentModificationType = 0 AND key1Assignment.IndexNumberOfAssignedKey = 1 LEFT OUTER JOIN
                         dbo.AcsKey2EmployeeAssignment AS key2Assignment ON empl._id = key2Assignment.EmployeeId AND 
                         key2Assignment.AssignmentModificationType = 0 AND key2Assignment.IndexNumberOfAssignedKey = 2 LEFT OUTER JOIN
                         dbo.AcsKeys AS key1 ON key1Assignment.AcsKeyId = key1.KeyNumber LEFT OUTER JOIN
                         dbo.AcsKeys AS key2 ON key2Assignment.AcsKeyId = key2.KeyNumber
WHERE        (empl.IsRemoved = 0)
go

