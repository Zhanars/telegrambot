-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER OnAcsKey2EmployeeAssignmentUpdated
   ON  dbo.AcsKey2EmployeeAssignment
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    update [AcsKey2EmployeeAssignment] set AssignmentModificationDateTime = GetDate()
    where _id in (select _id from inserted)
    
END
go

