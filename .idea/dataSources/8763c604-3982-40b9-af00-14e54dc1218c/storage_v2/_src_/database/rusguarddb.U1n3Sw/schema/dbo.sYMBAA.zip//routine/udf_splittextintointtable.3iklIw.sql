-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[udf_SplitTextIntoIntTable]
(
	@Text nvarchar(max),
	@Delim char(1) = ','
)
RETURNS 
@temp TABLE
(
	_id int not null primary key
)
AS
BEGIN
    DECLARE @XML XML 
    SELECT @XML = CONVERT(XML, SQL_TEXT) 
    FROM ( 
        SELECT '<root><item>' 
            + REPLACE(@Text, @Delim, '</item><item>') 
            + '</item></root>' AS SQL_TEXT 
        ) dt 

    INSERT INTO @temp(_id) 
    SELECT t.col.query('.').value('.', 'int') AS _id 
    FROM @XML.nodes('root/item') t(col) 
    RETURN 
END
go

