-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[udf_CreateGuidTable]
(
	@IDs as xml
)
RETURNS 
@temp TABLE 
(
	_id uniqueidentifier not null primary key
)
AS
BEGIN
		INSERT INTO @temp(_id)
		SELECT
			list.Id.value('.', 'uniqueidentifier')
		FROM
			@ids.nodes('/*/guid') as list(id)
		RETURN
END
go

