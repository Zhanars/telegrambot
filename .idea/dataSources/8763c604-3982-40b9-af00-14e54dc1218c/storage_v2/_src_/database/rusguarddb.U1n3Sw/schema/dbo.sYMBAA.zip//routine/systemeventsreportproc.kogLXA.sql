-- Batch submitted through debugger: SQLQuery12.sql|7|0|C:\Users\Karaya1\AppData\Local\Temp\~vsFC5A.sql
-- Batch submitted through debugger: SQLQuery11.sql|7|0|C:\Users\Karaya1\AppData\Local\Temp\~vs49E6.sql
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SystemEventsReportProc]
	-- Add the parameters for the stored procedure here
	@StartDate					   datetime,          --От какой даты
	@EndDate					   datetime,          --По какую дату
	@MessageSubTypes			   nvarchar(max),     --Подтипы событий в виде строки с идентификаторами, разделенными запятой
	@Employees					   nvarchar(max),	  --Сотрудники. Идентификаторы сотрудников, разделенные запятыми
	@Groups				  		   nvarchar(max),	  --Группы сотрудников. Идентификаторы групп сотрудников, разделенные запятыми
	@Drivers					   nvarchar(max),	  --Устройства. Идентификаторы устройств, разделенные запятыми
	@IsAllEmployees                bit,               --Всех сотрудников
	@IsAllEvents                   bit,
	@IsAllDevices                  bit
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

		select  log.DateTime,
				log.LogMessageType,
				prop.Value as DeviceName,
				isnull(empl.LastName, '') + ' ' + isnull(empl.FirstName, '') + ' ' + isnull(empl.SecondName, '') as EmployeeFullName,
				log.Message,
				log.Details,
				log.LogMessageSubType,
				emplPos.Name as Position,
				emplGroup.Name as [Group]
			from Log log
			left outer join Employee empl on empl._id=log.EmployeeID
			left outer join Property prop on prop._idResource=log.DriverID and prop.PropertyName='Name'
			left outer join EmployeePosition emplPos on emplPos._id=empl.EmployeePositionID
			left outer join EmployeeGroup emplGroup on emplGroup._id=empl.EmployeeGroupID
			where
				(CAST(log.DateTime as datetime2) between @StartDate and @EndDate) and 
				(@IsAllEvents = 1 or log.LogMessageSubType in (select _id from udf_SplitTextIntoIntTable(@MessageSubTypes, ','))) and
				(@IsAllDevices = 1 or log.DriverID in (select _id from udf_SplitTextIntoGuidTable(@Drivers, ',')))	and 
				(@IsAllEmployees = 1 or log.EmployeeID IS NULL 
				or (log.EmployeeID IS NOT NULL and 
				(empl.EmployeeGroupID in (select _id from udf_SplitTextIntoGuidTable(@Groups, ','))
				or empl._id in (select _id from udf_SplitTextIntoGuidTable(@Employees, ',')))
				))



	SET NOCOUNT OFF;
END
go

