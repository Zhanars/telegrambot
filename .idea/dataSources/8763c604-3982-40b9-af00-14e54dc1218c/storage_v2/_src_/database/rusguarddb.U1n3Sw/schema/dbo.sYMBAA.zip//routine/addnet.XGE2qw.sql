-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[AddNet]
	@GatewayUrl NVARCHAR(50),
	@id uniqueidentifier OUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SET @id = NEWID()
    INSERT INTO Resource (_id, ResourceType) VALUES (@id, 2)
    INSERT INTO Net (_idResource) VALUES (@id)
    INSERT INTO Property (_idResource, PropertyName, Value) VALUES (@id, 'GatewayUrl', @GatewayUrl)
    INSERT INTO State (_idResource, Name, Value) VALUES (@id, 'IsAttached', 'False')
END
go

