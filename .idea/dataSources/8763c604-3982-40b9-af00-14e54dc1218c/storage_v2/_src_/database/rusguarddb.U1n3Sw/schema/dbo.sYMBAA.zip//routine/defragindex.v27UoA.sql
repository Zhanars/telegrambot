CREATE PROCEDURE [dbo].[DefragIndex] 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
DBCC INDEXDEFRAG (RusGuard, 'PropertyChanged_ClientNotified', PK_PropertyChanged_ClientNotified)

DBCC INDEXDEFRAG (RusGuard, 'StateChanged_ClientNotified', PK_StateChanged_ClientNotified)

DBCC INDEXDEFRAG (RusGuard, 'State', PK_State)

DBCC INDEXDEFRAG (RusGuard, 'Property', PK_Property)

DBCC INDEXDEFRAG (RusGuard, 'Driver', PK_Driver)

DBCC INDEXDEFRAG (RusGuard, 'Resource', PK_Object)

DBCC INDEXDEFRAG (RusGuard, 'ResourceAdded_ClientNotified', PK_ResourceRemoved_ClientToNotify)

DBCC INDEXDEFRAG (RusGuard, 'Link', PK_Link)

DBCC INDEXDEFRAG (RusGuard, 'LinkAdded_ClientNotified', PK_LinkRemoved_ClientToNotify)

DBCC INDEXDEFRAG (RusGuard, 'LinkMonitoringInfo', PK_LinkRemoved)

DBCC INDEXDEFRAG (RusGuard, 'AccessLevel', PK_AccessLevel)

DBCC INDEXDEFRAG (RusGuard, 'Driver2AccessLevel', PK_Driver2AccessLevel)

DBCC INDEXDEFRAG (RusGuard, 'AccessLevel2Employee', PK_AccessLevel2Employee)

DBCC INDEXDEFRAG (RusGuard, 'AccessLevel2EmployeeGroup', PK_AccessLevel2EmployeeGroup)

DBCC INDEXDEFRAG (RusGuard, 'Employee', PK_Employee)

DBCC INDEXDEFRAG (RusGuard, 'EmployeeGroup', PK_EmployeeGroup)
DBCC INDEXDEFRAG (RusGuard, 'EmployeeGroup', IX_EmployeeGroup)

DBCC INDEXDEFRAG (RusGuard, 'OperationResult', PK_OperationResult)

--EXEC sp_updatestats 
	
END
go

