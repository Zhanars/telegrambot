CREATE TRIGGER [dbo].[NetAfterDeleted] 
   ON  [dbo].[Net]
   AFTER DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DELETE FROM Resource WHERE _id IN (SELECT _idResource FROM DELETED)

END
go

