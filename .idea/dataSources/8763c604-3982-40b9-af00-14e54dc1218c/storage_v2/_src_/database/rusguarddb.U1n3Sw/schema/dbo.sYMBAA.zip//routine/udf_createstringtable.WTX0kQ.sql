-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[udf_CreateStringTable]
(	
	@IDs as xml
)
RETURNS
@temp TABLE 
(
	_id nvarchar(250) not null primary key
)
AS
BEGIN
		INSERT INTO @temp(_id)
		SELECT
			list.Id.value('.', 'nvarchar(250)')
		FROM
			@ids.nodes('/*/string') as list(id)
		RETURN
END
go

