-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[EmployeeTimeTrackingReportProc]
	-- Add the parameters for the stored procedure here
	@FromDate  date,			 -- От какой даты
	@ToDate    date,			 -- По какую дату
	@Employees nvarchar(max)     -- Идентификаторы сотрудников, разделенные запятыми
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	if (@ToDate < @FromDate)
		raiserror('ToDate can not be less then FromDate', 0, 0);

	if (@Employees is null or @Employees = '')
		raiserror('Employees can not be empty', 0, 0);

	declare @DateRangeTable table (Date date primary key)

	START:
		insert  into    @DateRangeTable 
        values          (@FromDate)
		if  @FromDate < @ToDate 
		begin            
			set @FromDate = DATEADD(day, 1, @FromDate);
			goto START;
		end

	declare @EnterMsgSubTypes table (MsgSubType int primary key)

	insert  into    @EnterMsgSubTypes 
    values          (26), (30), (34), (66), (81), (85), (88), (92);

	declare @ExitMsgSubTypes table (MsgSubType int primary key)

	insert  into    @ExitMsgSubTypes 
    values          (27), (28), (31), (32), (35), (36), (67), (82), (83), (86), (89), (90), (93), (94)

	select              DENSE_RANK() over (order by isnull(e.LastName, '') + ' ' + isnull(e.FirstName, '') + ' ' + isnull(e.SecondName, '')) EmployeePositionNumber,
		                isnull(e.LastName, '') + ' ' + isnull(e.FirstName, '') + ' ' + isnull(e.SecondName, '') as EmployeeFullName,
		                e.TableNumber as TableNumber,
		                p.Name as Position,
		                d.Date as Date,
		                schedule.*,
		                enterEvent.*,
		                exitEvent.*,
                        CAST(DateAdd(second,totalAbsence.Absence, 0) as Time) as TotalAbsence
	from                Employee as e
	cross join          @DateRangeTable as d
	left outer join     EmployeePosition as p on e.EmployeePositionID = p._id
	outer apply     	(select         ett.DayType, 
                                        dmc.DayMode as TypeOfCalculate, 
                                        dmc.Convention as DayModeConvention, 
                                        dmc.DigitalConvention as DayModeDigitalConvention,
                                        ett.EntryTime,
                                        ett.ExitTime,
                                        ett.BreakBeginTime,
                                        ett.BreakEndTime,
                                        ett.WorkBreak,
                                        ett.WorkTime,
                                        ett.EarlyArrival,
                                        ett.LateArrival,
                                        ett.EarlyDeparture,
                                        ett.LateDeparture,
                                        ett.Absence,
                                        ett.MaxAbsence,
                                        ett.IsMoningOvertime,
                                        ett.IsEveningOvertime,
                                        ett.IsNightShift
		                 from           EmployeeTimetable as ett 
		                 inner join     DayModeCatalog dmc on ett.DayModeCatalogID = dmc._id
		                 where          ett.EmployeeID = e._id and ett.Date = d.Date
		                 union all
		                 select         wtt.DayType,
                                        dmc.DayMode as TypeOfCalculate,
                                        dmc.Convention as DayModeConvention,
                                        dmc.DigitalConvention as DayModeDigitalConvention,
                                        wtt.EntryTime,
                                        wtt.ExitTime,
                                        wtt.BreakBeginTime,
                                        wtt.BreakEndTime,
                                        wtt.WorkBreak,
                                        wtt.WorkTime,
                                        wtt.EarlyArrival,
                                        wtt.LateArrival,
                                        wtt.EarlyDeparture,
                                        wtt.LateDeparture,
                                        wtt.Absence,
                                        wtt.MaxAbsence,
                                        wtt.IsMoningOvertime,
                                        wtt.IsEveningOvertime,
                                        wtt.IsNightShift
		                 from           EmployeeWorkSchedule ews
		                 inner join     WorkSchedules ws on ews.WorkSchedulesID = ws._id
		                 inner join     WorkTimetable wtt on ws._id = wtt.WorkScheduleID
		                 inner join     DayModeCatalog dmc on wtt.DayModeCatalogID = dmc._id
		                 where          e.IsWorkSchedulesInherited = 0 
                                        and ews.EmployeeID = e._id 
                                        and wtt.Date = d.Date 
                                        and not exists (select  top 1 * 
                                                        from    EmployeeTimetable 
                                                        where   EmployeeTimetable.EmployeeID = e._id 
                                                                and EmployeeTimetable.Date = d.Date)
		                 union all
		                 select         wtt.DayType, 
                                        dmc.DayMode as TypeOfCalculate, 
                                        dmc.Convention as DayModeConvention, 
                                        dmc.DigitalConvention as DayModeDigitalConvention,
                                        wtt.EntryTime, 
                                        wtt.ExitTime, 
                                        wtt.BreakBeginTime, 
                                        wtt.BreakEndTime, 
                                        wtt.WorkBreak, 
                                        wtt.WorkTime, 
                                        wtt.EarlyArrival, 
                                        wtt.LateArrival,
                                        wtt.EarlyDeparture, 
                                        wtt.LateDeparture, 
                                        wtt.Absence, 
                                        wtt.MaxAbsence, 
                                        wtt.IsMoningOvertime, 
                                        wtt.IsEveningOvertime, 
                                        wtt.IsNightShift
		                 from           EmployeeGroupWorkSchedule egws
		                 inner join     WorkSchedules ws on egws.WorkSchedulesID = ws._id
		                 inner join     WorkTimetable wtt on ws._id = wtt.WorkScheduleID
		                 inner join     DayModeCatalog dmc on wtt.DayModeCatalogID = dmc._id
		                 where          e.IsWorkSchedulesInherited = 1 
                                        and egws.EmployeeGroupID in (select ID 
                                                                     from   udf_GetGroupInheritancePathForWorkSchedules(e.EmployeeGroupID) 
                                                                     where  IsInherited = 0 ) 
                                        and wtt.Date = d.Date 
                                        and not exists (select  top 1 * 
                                                        from    EmployeeTimetable 
                                                        where   EmployeeTimetable.EmployeeID = e._id 
                                                                and EmployeeTimetable.Date = d.Date)) as schedule
	outer apply         (select         MIN(l.DateTime) PassageIn 
                         from           (select         wzap.*
                                         from           EmployeeWorkZone ewz
		                                 inner join     WorkZones wz on ewz.WorkZoneID = wz._id
		                                 inner join     WorkZonesAccessPoint wzap on wz._id = wzap.WorkZoneID
		                                 where          e.IsWorkZonesInherited = 0 
                                                        and ewz.EmployeeID = e._id
                                         union all
                                         select         wzap.*
                                         from           EmployeeGroupWorkZone egwz
                                         inner join     WorkZones wz on egwz.WorkZoneID = wz._id
		                                 inner join     WorkZonesAccessPoint wzap on wz._id = wzap.WorkZoneID
		                                 where          e.IsWorkZonesInherited = 1 
                                                        and egwz.EmployeeGroupID in (select     ID 
                                                                                     from       udf_GetGroupInheritancePathForWorkZones(e.EmployeeGroupID) 
                                                                                     where      IsInherited = 0 )) as accessPoints
		                 inner join     Log l on accessPoints.DriverID = l.DriverID 
                                                 and l.EmployeeID is not null 
                                                 and l.EmployeeID = e._id 
                                                 and (      (accessPoints.EventType = 0 and l.LogMessageSubType in (select * from @EnterMsgSubTypes)) 
                                                       or   (accessPoints.EventType = 1 and l.LogMessageSubType in (select * from @ExitMsgSubTypes))
                                                     )
		                 where          CAST(l.DateTime as DATE) = d.Date 
                                        and accessPoints.AccessPointType = 1) as enterEvent
	outer apply         (select         MAX(l.DateTime) PassageOut 
                         from           (select         wzap.*
		                                 from           EmployeeWorkZone ewz
		                                 inner join     WorkZones wz on ewz.WorkZoneID = wz._id
		                                 inner join     WorkZonesAccessPoint wzap on wz._id = wzap.WorkZoneID
		                                 where          e.IsWorkZonesInherited = 0 
                                                        and ewz.EmployeeID = e._id
		                                 union all
		                                 select         wzap.*
		                                 from           EmployeeGroupWorkZone egwz
		                                 inner join     WorkZones wz on egwz.WorkZoneID = wz._id
		                                 inner join     WorkZonesAccessPoint wzap on wz._id = wzap.WorkZoneID
		                                 where          e.IsWorkZonesInherited = 1 
                                                        and egwz.EmployeeGroupID in (select     ID 
                                                                                     from       udf_GetGroupInheritancePathForWorkZones(e.EmployeeGroupID) 
                                                                                     where      IsInherited = 0 )) as accessPoints
		                 inner join     Log l on accessPoints.DriverID = l.DriverID 
                                                 and l.EmployeeID is not null 
                                                 and l.EmployeeID = e._id 
                                                 and (     ((accessPoints.EventType = 0 or accessPoints.EventType = 2) and l.LogMessageSubType in (select * from @EnterMsgSubTypes)) 
                                                        or (accessPoints.EventType = 1 and l.LogMessageSubType in (select * from @ExitMsgSubTypes)))
		                 where          CAST(l.DateTime as DATE) = d.Date 
                                        and accessPoints.AccessPointType = 0) as exitEvent
    outer apply         (select         SUM(Absence) as Absence 
                         from           (select     case when schedule.BreakBeginTime is not null
                                                              and schedule.BreakBeginTime <> '00:00:00'
                                                              and schedule.BreakEndTime is not null
                                                              and schedule.BreakEndTime <> '00:00:00'
                                                              and schedule.BreakEndTime > schedule.BreakBeginTime
                                                         then case when CAST(MIN(exitEvents.DateTime) as Time) < schedule.BreakBeginTime --  Ушел раньше начала обеда и пришел после его окончания
                                                                        and CAST(enterEvents.DateTime as Time) > schedule.BreakEndTime
                                                                   then DATEDIFF(second, MIN(exitEvents.DateTime), enterEvents.DateTime) - DATEDIFF(second, schedule.BreakBeginTime, schedule.BreakEndTime)                                                                        
                                                                   when CAST(MIN(exitEvents.DateTime) as Time) < schedule.BreakBeginTime -- Ушел раньше обеда и пришел во время обеда
                                                                        and CAST(enterEvents.DateTime as Time) >= schedule.BreakBeginTime 
                                                                        and CAST(enterEvents.DateTime as Time) <= schedule.BreakEndTime
                                                                   then DATEDIFF(second, CAST(MIN(exitEvents.DateTime) as Time), schedule.BreakBeginTime)                                                                            
                                                                   when CAST(MIN(exitEvents.DateTime) as Time) >= schedule.BreakBeginTime --    Ушел во время обеда и пришел после обеда
                                                                        and CAST(MIN(exitEvents.DateTime) as Time) <= schedule.BreakEndTime
                                                                        and CAST(enterEvents.DateTime as Time) > schedule.BreakEndTime
                                                                   then DATEDIFF(second, schedule.BreakEndTime, CAST(enterEvents.DateTime as Time))                                                                            
                                                                   when CAST(MIN(exitEvents.DateTime) as Time) >= schedule.BreakBeginTime --    Ушел во время обеда и пришел во время обеда обеда
                                                                        and CAST(MIN(exitEvents.DateTime) as Time) <= schedule.BreakEndTime
                                                                        and CAST(enterEvents.DateTime as Time) >= schedule.BreakBeginTime 
                                                                        and CAST(enterEvents.DateTime as Time) <= schedule.BreakEndTime
                                                                   then 0
                                                                    --  Уходил и приходил за рамками обеда
                                                                   else 
                                                                        DATEDIFF(second, min(exitEvents.DateTime), enterEvents.DateTime)
                                                              end
                                                         else 
                                                                   DATEDIFF(second, min(exitEvents.DateTime), enterEvents.DateTime)
                                                    end as Absence
                                         from           (select         l.DateTime as DateTime
                                                         from           (select         wzap.*
		                                                                 from           EmployeeWorkZone ewz
		                                                                 inner join     WorkZones wz on ewz.WorkZoneID = wz._id
		                                                                 inner join     WorkZonesAccessPoint wzap on wz._id = wzap.WorkZoneID
		                                                                 where          e.IsWorkZonesInherited = 0 
                                                                                        and ewz.EmployeeID = e._id
		                                                                 union all
		                                                                 select         wzap.*
		                                                                 from           EmployeeGroupWorkZone egwz
		                                                                 inner join     WorkZones wz on egwz.WorkZoneID = wz._id
		                                                                 inner join     WorkZonesAccessPoint wzap on wz._id = wzap.WorkZoneID
		                                                                 where          e.IsWorkZonesInherited = 1 
                                                                                        and egwz.EmployeeGroupID in (select     ID 
                                                                                                                     from       udf_GetGroupInheritancePathForWorkZones(e.EmployeeGroupID) 
                                                                                                                     where      IsInherited = 0 )) as accessPoints
		                                                 inner join     Log l on accessPoints.DriverID = l.DriverID 
                                                                                 and l.EmployeeID is not null 
                                                                                 and l.EmployeeID = e._id 
                                                                                 and (     ((accessPoints.EventType = 0 or accessPoints.EventType = 2) and l.LogMessageSubType in (select * from @EnterMsgSubTypes)) 
                                                                                         or (accessPoints.EventType = 1 and l.LogMessageSubType in (select * from @ExitMsgSubTypes)))
  		                                                 where          CAST(l.DateTime as DATE) = d.Date 
                                                                        and enterEvent.PassageIn is not null
                                                                        and l.DateTime >= enterEvent.PassageIn
                                                                        and accessPoints.AccessPointType = 0) as exitEvents
                                         cross apply    (select         top 1 l.DateTime as DateTime 
                                                         from           (select         wzap.*
                                                                         from           EmployeeWorkZone ewz
		                                                                 inner join     WorkZones wz on ewz.WorkZoneID = wz._id
		                                                                 inner join     WorkZonesAccessPoint wzap on wz._id = wzap.WorkZoneID
		                                                                 where          e.IsWorkZonesInherited = 0 
                                                                                        and ewz.EmployeeID = e._id
                                                                         union all
                                                                         select         wzap.*
                                                                         from           EmployeeGroupWorkZone egwz
                                                                         inner join     WorkZones wz on egwz.WorkZoneID = wz._id
		                                                                 inner join     WorkZonesAccessPoint wzap on wz._id = wzap.WorkZoneID
		                                                                 where          e.IsWorkZonesInherited = 1 
                                                                                        and egwz.EmployeeGroupID in (select     ID 
                                                                                                                     from       udf_GetGroupInheritancePathForWorkZones(e.EmployeeGroupID) 
                                                                                                                     where      IsInherited = 0 )) as accessPoints
		                                                 inner join     Log l on accessPoints.DriverID = l.DriverID 
                                                                                 and l.EmployeeID is not null 
                                                                                 and l.EmployeeID = e._id 
                                                                                 and (      (accessPoints.EventType = 0 and l.LogMessageSubType in (select * from @EnterMsgSubTypes)) 
                                                                                     or   (accessPoints.EventType = 1 and l.LogMessageSubType in (select * from @ExitMsgSubTypes))
                                                                                     )
  	  	                                                 where          CAST(l.DateTime as DATE) = d.Date 
                                                                        and exitEvent.PassageOut is not null
                                                                        and l.DateTime <= exitEvent.PassageOut
                                                                        and l.DateTime > exitEvents.DateTime
                                                                        and accessPoints.AccessPointType = 1
                                                         order          by l.DateTime) as enterEvents
                                         where           schedule.Absence is not null
                                                         and schedule.Absence <> '00:00:00'
                                         group           by enterEvents.DateTime
                                         having          CAST(DateAdd(second, DATEDIFF(second, MIN(exitEvents.DateTime), enterEvents.DateTime), 0) as Time) >= schedule.Absence
                                        ) as absences
                         where          absences.Absence >=DATEDIFF(second, 0, schedule.Absence)) as totalAbsence
	where               e._id in (select    _id 
                                  from      udf_SplitTextIntoGuidTable(@Employees, ','))                        
	order               by EmployeeFullName, Date
END
go

