CREATE TRIGGER [dbo].[OnEmployeeGroupUpdated]
   ON  [dbo].[EmployeeGroup]
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
    -- Insert statements for trigger here
    
    update EmployeeGroup set ModificationDateTime = GetDate()
    where _id in (select _id from inserted)

END
go

