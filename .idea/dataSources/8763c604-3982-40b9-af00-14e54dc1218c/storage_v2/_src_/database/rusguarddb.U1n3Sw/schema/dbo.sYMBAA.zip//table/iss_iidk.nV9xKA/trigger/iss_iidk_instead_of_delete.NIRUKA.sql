-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[ISS_IIDK_Instead_Of_Delete]
   ON  [dbo].[ISS_IIDK]
   INSTEAD OF DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	delete from ISS_Slave where ISS_IIDK_ID in (select _id from deleted)
	delete from ISS_IIDK where _id in (select _id from deleted)

    -- Insert statements for trigger here

END
go

