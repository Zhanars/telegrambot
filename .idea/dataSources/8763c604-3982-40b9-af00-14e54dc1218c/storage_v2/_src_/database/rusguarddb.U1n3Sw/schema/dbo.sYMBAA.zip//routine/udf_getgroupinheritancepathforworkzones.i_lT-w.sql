-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[udf_GetGroupInheritancePathForWorkZones]
(
	-- Add the parameters for the function here
	@GroupID uniqueidentifier	
)
RETURNS 
@temp TABLE 
(	
	ID			uniqueidentifier not null primary key,
	ParentID	uniqueidentifier,
	IsInherited bit				 not null
)
AS
BEGIN

	;with GetGroupInheritancePathForIsWorkZonesCTE
	  as 
	(
		select _id,ParentID, IsWorkZonesInherited as IsInherited from EmployeeGroup
		where _id = @GroupID

		union all

		select gr._id, gr.ParentID, gr.IsWorkZonesInherited as IsInherited from EmployeeGroup gr
		inner join GetGroupInheritancePathForIsWorkZonesCTE child on gr._id = child.ParentID
		and child.IsInherited = 1
	)

	insert into @temp select * from GetGroupInheritancePathForIsWorkZonesCTE

	RETURN 
END
go

