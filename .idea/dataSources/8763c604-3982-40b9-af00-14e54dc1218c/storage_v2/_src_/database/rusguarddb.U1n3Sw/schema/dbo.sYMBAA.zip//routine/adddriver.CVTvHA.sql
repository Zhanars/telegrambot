-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[AddDriver]
	@idServer uniqueidentifier,
	@Type NVARCHAR(50),
	@id uniqueidentifier OUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    SET @id = NEWID()
    INSERT INTO Resource (_id, ResourceType) VALUES (@id, 0)
    INSERT INTO Driver (_idResource, _idServer, ObjectTypeName) VALUES (@id, @idServer, @Type)
END
go

