-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[OnState_Insert_Update]
   ON  [dbo].[State]
   AFTER INSERT, UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


update State
set UpdateTime = SYSUTCDATETIME()
where _id in (select _id from inserted)
    -- Insert statements for trigger here

END
go

