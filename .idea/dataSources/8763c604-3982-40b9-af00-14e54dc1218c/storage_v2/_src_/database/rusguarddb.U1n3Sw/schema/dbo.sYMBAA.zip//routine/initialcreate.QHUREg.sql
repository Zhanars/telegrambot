-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE  PROCEDURE [dbo].[InitialCreate]

AS
BEGIN

	DECLARE @servName NVarchar(255)
	SET @servName = 'PROG3'
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DELETE FROM Resource
	
	DECLARE @id uniqueidentifier
	
    DECLARE @idNet uniqueidentifier
	EXECUTE dbo.AddNet @GatewayUrl = @servName, @id = @idNet OUT

	DECLARE @idServer uniqueidentifier
	EXECUTE dbo.AddServer @idNet = @idNet, @Url = @servName, @Type = '0', @id = @idServer OUT

	EXECUTE dbo.AddServer @idNet = @idNet, @Url = @servName, @Type = '2', @id = @id OUT

	EXECUTE dbo.AddServer @idNet = @idNet, @Url = @servName, @Type = '3', @id = @id OUT

	EXECUTE dbo.AddServer @idNet = @idNet, @Url = @servName, @Type = '4', @id = @id OUT

    DECLARE @idSomeDriver uniqueidentifier
    EXECUTE dbo.AddDriver @idServer = @idServer, @Type = 'some', @id = @idSomeDriver OUT

    DECLARE @idParentDriver uniqueidentifier
    EXECUTE dbo.AddDriver @idServer = @idServer, @Type = 'parent', @id = @idParentDriver OUT

	SET @id = NEWID()
    INSERT INTO DriverLinkProperty (_id, _idParent, Name) VALUES (@id, @idParentDriver, 'parent2child')
    DECLARE @idProp uniqueidentifier = @id

    DECLARE @idChildDriver uniqueidentifier
    EXECUTE dbo.AddDriver @idServer = @idServer, @Type = 'child', @id = @idChildDriver OUT
    UPDATE Driver SET _idParentProperty = @idProp WHERE _idResource = @idChildDriver

END
go

