
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[InsertOrUpdateState]
	@IdResource uniqueidentifier,
	@Name		nvarchar(50),
	@Value		nvarchar(50)


AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
merge State as target
using (select @IdResource, @Name, @Value) as source (ResourceId, Name, Value)
on (target._idResource = source.ResourceId and target.Name = source.Name)
when matched and (target.Value is null or target.Value <> source.Value)
then update set target.Value = source.Value
when not matched then insert (_idResource, Name, Value) values (source.ResourceId, source.Name, source.Value);

END
go

