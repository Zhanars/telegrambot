-- Batch submitted through debugger: SQLQuery64.sql|7|0|C:\Users\Karaya1\AppData\Local\Temp\~vs9229.sql
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[Delete_UpdateParentDriverDatabaseChangeVersion]
   ON  [dbo].[Resource]
   AFTER DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

update State
set Value = Value + 1
from deleted as ins
join Driver as currentDrv on ins._id = currentDrv._idResource
join DriverLinkProperty as parentLinkProperty on currentDrv._idParentProperty = parentLinkProperty._id
join Driver as parentDriver on parentLinkProperty._idParent = parentDriver._idResource
join Resource as parentResource on parentDriver._idResource = parentResource._id
join State as parentState on parentResource._id = parentState._idResource
where parentState.Name = 'DatabaseChangeVersion'
    
    
    -- Insert statements for trigger here

END
go

