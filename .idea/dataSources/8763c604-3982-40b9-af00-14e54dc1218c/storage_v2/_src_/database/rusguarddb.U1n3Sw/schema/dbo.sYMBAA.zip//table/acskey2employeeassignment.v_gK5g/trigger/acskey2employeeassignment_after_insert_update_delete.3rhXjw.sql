-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER AcsKey2EmployeeAssignment_After_Insert_Update_Delete
   ON  AcsKey2EmployeeAssignment
   AFTER INSERT,DELETE,UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	update Employee
	set ModificationDateTime = GETDATE()
	where Employee._id in (select inserted.EmployeeId from inserted)

	update Employee
	set ModificationDateTime = GETDATE()
	where Employee._id in (select deleted.EmployeeId from deleted)

    -- Insert statements for trigger here

END
go

