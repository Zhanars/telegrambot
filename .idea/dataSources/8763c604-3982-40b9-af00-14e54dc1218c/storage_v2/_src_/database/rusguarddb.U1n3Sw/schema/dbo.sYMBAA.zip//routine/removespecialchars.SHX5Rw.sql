-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[RemoveSpecialChars] 
(
@s nvarchar(max)
)
RETURNS nvarchar(max)
AS
BEGIN
if @s is null
      return null
   declare @s2 nvarchar(max)
   set @s2 = ''
   declare @l int
   set @l = len(@s)
   declare @p int
   set @p = 1
   while @p <= @l begin
      declare @c int
      set @c = ascii(substring(@s, @p, 1))
      if @c != 08 --AND @c != 64 -- пока проверка только на 0x08(bs)
         set @s2 = @s2 + char(@c)
      set @p = @p + 1
      end
   if len(@s2) = 0
      return null
   return @s2

END
go

