-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[LinkAdded_ClientNotifiedDeleted]
   ON  [dbo].[LinkAdded_ClientNotified]
   AFTER DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DELETE FROM LinkMonitoringInfo WHERE isDeleted = 1 AND
        _id IN (SELECT d._idLinkMonitoringInfo FROM DELETED AS d WHERE
			NOT EXISTS(SELECT * FROM LinkAdded_ClientNotified AS cn WHERE
				cn._idLinkMonitoringInfo = d._idLinkMonitoringInfo))

END
go

