CREATE TRIGGER [dbo].[OnEmployeeUpdated]
   ON  [dbo].[Employee]
   AFTER INSERT,UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;



    UPDATE empl SET
    FirstName = dbo.RemoveSpecialChars(empl.FirstName),
    SecondName = dbo.RemoveSpecialChars(empl.SecondName),
    LastName = dbo.RemoveSpecialChars(empl.LastName),
    PassportIssue = dbo.RemoveSpecialChars(empl.PassportIssue),
    PassportNumber = dbo.RemoveSpecialChars(empl.PassportNumber),
    Authority = dbo.RemoveSpecialChars(empl.Authority),
    RegistrationAddress = dbo.RemoveSpecialChars(empl.RegistrationAddress),
    ResidentialAddress = dbo.RemoveSpecialChars(empl.ResidentialAddress),
    Comment = dbo.RemoveSpecialChars(empl.Comment),
    PinCodeDescription = dbo.RemoveSpecialChars(empl.PinCodeDescription),
    PinCodeUnderPressureDescription = dbo.RemoveSpecialChars(empl.PinCodeUnderPressureDescription),
    PassportLastName = dbo.RemoveSpecialChars(empl.PassportLastName),
    PassportFirstName = dbo.RemoveSpecialChars(empl.PassportFirstName),
    PassportMiddleName = dbo.RemoveSpecialChars(empl.PassportMiddleName),
    PassportPlaceOfBirth = dbo.RemoveSpecialChars(empl.PassportPlaceOfBirth),
    PassportDepartmentCode = dbo.RemoveSpecialChars(empl.PassportDepartmentCode),
    DriverLastName = dbo.RemoveSpecialChars(empl.DriverLastName),
    DriverFirstName = dbo.RemoveSpecialChars(empl.DriverFirstName),
    DriverMiddleName = dbo.RemoveSpecialChars(empl.DriverMiddleName),
    DriverPlaceOfBirth = dbo.RemoveSpecialChars(empl.DriverPlaceOfBirth),
    DriverNumber = dbo.RemoveSpecialChars(empl.DriverNumber),
    DriverSeries = dbo.RemoveSpecialChars(empl.DriverSeries),
    ForeignPassportMRZ = dbo.RemoveSpecialChars(empl.ForeignPassportMRZ),
    ForeignPassportCodeOfIssuingState = dbo.RemoveSpecialChars(empl.ForeignPassportCodeOfIssuingState),
    ForeignPassportLastName = dbo.RemoveSpecialChars(empl.ForeignPassportLastName),
    ForeignPassportFirstName = dbo.RemoveSpecialChars(empl.ForeignPassportFirstName),
    ForeignPassportMiddleName = dbo.RemoveSpecialChars(empl.ForeignPassportMiddleName),
    ForeignPassportNumber = dbo.RemoveSpecialChars(empl.ForeignPassportNumber),
    ForeignPassportNationality = dbo.RemoveSpecialChars(empl.ForeignPassportNationality),  
    ForeignPassportSex = dbo.RemoveSpecialChars(empl.ForeignPassportSex),  
    ForeignPassportPersonalCode = dbo.RemoveSpecialChars(empl.ForeignPassportPersonalCode)    
    FROM Employee empl 
    WHERE empl._id in (SELECT _id FROM inserted)

    -- Insert statements for trigger here
    IF EXISTS (SELECT * FROM DELETED)
    BEGIN
		update Employee set ModificationDateTime = GetDate()
		where _id in (select _id from inserted)
    END

END
go

