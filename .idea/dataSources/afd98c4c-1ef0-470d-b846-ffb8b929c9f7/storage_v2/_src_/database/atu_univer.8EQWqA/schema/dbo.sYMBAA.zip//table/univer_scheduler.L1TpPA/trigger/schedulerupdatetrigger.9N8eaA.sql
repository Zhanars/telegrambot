-- =============================================
-- Author:		@LFER
-- Create date: 2009-11-13
-- Description:	Удаление или добавлении права доступа при изменении статуса сотрудника
-- =============================================
CREATE TRIGGER [dbo].[schedulerUpdateTrigger]
   ON  [dbo].[univer_scheduler]
   FOR UPDATE
AS 
BEGIN	
	SET NOCOUNT ON;
	
	DECLARE @pi int
	DECLARE @st int
	
	DECLARE insCursor cursor 
		FOR SELECT personal_id, status FROM inserted
	
	IF UPDATE(status)
	BEGIN
		OPEN insCursor
		FETCH NEXT FROM insCursor INTO @pi, @st
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF(@st=1)
				EXEC dbo.personalSetAccess @pi, 'SCHEDULER'
			ELSE
				EXEC dbo.personalDeleteAccess @pi, 'SCHEDULER'
				
			FETCH NEXT FROM insCursor INTO @pi, @st
		END
		CLOSE insCursor
	END

END
go

