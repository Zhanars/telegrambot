
-- =============================================
-- Author:		Yerlan
-- Create date: 09.02.2016
-- Description: Получить Количество учебно-методических статей через Доклады в материалах в научно-методических конференциях
-- (@indicatorConst=1 - Количество учебно-методических статей через Доклады в материалах в научно-методических конференциях)
-- (@indicatorConst=2 - 2.10.1 - Proceedings indexed by Thomson Reuters)
-- (@indicatorConst=3 - 2.10.2 - Доклад в сборнике Scopus (Proceedings indexed by Scopus))
-- =============================================
CREATE FUNCTION [dbo].[IP_NIR_getSciThesises_Count_By]
(
	@categoryId int,
	@personalId int=0,
	@chairId int=0,
	@facultyId int=0,
	@year int=0,
	@publisherTypeId int=null,
	@indicatorConst int=0
)
RETURNS int
AS
BEGIN
	DECLARE @Result int=0;
	declare @Result2 int =0;
-- ==================================== если учебно-методических статей 
	IF (@indicatorConst=1)
	BEGIN
		SELECT @Result =  COUNT(*)
		FROM
			DBScience.dbo.Thesises th,
			DBScience.dbo.L_Person_Thesis_Authors a,
			DBScience.dbo.SciEvents se
		WHERE
			-- тезис не архивирован
			th.status != 2 AND
			-- тезис этого года (по мероприятию)
			th.sciEvent_id = se.sciEvent_id AND
			-- тезис этого года
			YEAR(se.eventStart) in (@year, @year+1) and
			-- не дублированная и подтвержденная
			th.is_overlap IS NULL AND
			th.is_approve=1 AND
			--Доклад в материалах в научно-методических конференциях
			th.thesisType_id=13 and
			-- тезис этого автора (ППС, потому personType = 1)
			th.thesis_id = a.thesis_id AND
			a.personType = 1 AND 
			(
			-- на уровне ппс
			(@categoryId=3 AND a.person_id = @personalId)
			OR
			-- на уровне кафедры
			(@categoryId=2 AND a.person_id IN 
				(SELECT
					DISTINCT p.personal_id
				FROM
					univer_personal p,
					univer_structure_division_1c sd,
					univer_personal_struct_pos_link_1c spl
				WHERE
					p.personal_id = spl.personal_id AND
					sd.structure_division_id = spl.structure_division_id AND
					sd.structure_division_id = @chairId AND
					spl.status != 2  AND p.status != 2
					AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
				))
			OR
			-- на уровне факультета
			(@categoryId=1 AND a.person_id IN 
				(SELECT
					DISTINCT p.personal_id
				FROM
					univer_personal p,
					univer_structure_division_1c sd,
					univer_personal_struct_pos_link_1c spl
				WHERE
					p.personal_id = spl.personal_id AND
					sd.structure_division_id = spl.structure_division_id AND
					sd.structure_division_ext = @facultyId AND
					spl.status != 2  AND p.status != 2
					AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
				))
			);
			
		SELECT @Result2 = COUNT(*)
		FROM 
			DBScience.dbo.ImagePapers p,
			DBScience.dbo.L_Person_ImagePaper_Authors a,
			DBScience.dbo.OtherPeriodicEditions op
		WHERE
			-- статья не архивирована
			p.status != 2 AND
			-- статья должна иметь другое пер. издание с типом "Сборник учебно-методических статей"
			op.otherPeriodicEdition_id = p.periodicEdition_id AND
			op.otherPeriodicEditionType_id = 10 AND
			-- статья этого года
			p.yearPublication in (@year, @year + 1) AND
			-- не дублированная и подтвержденная
			p.is_overlap IS NULL AND
			p.is_approve=1 AND
			-- статья этого автора (ППС, потому personType = 1)
			p.imagePaper_id = a.imagePaper_id AND
			a.personType = 1 AND 
			(
			-- на уровне ппс
			(@categoryId=3 AND a.person_id = @personalId)
			OR
			-- на уровне кафедры
			(@categoryId=2 AND a.person_id IN 
				(SELECT
					DISTINCT p.personal_id
				FROM
					univer_personal p,
					univer_structure_division_1c sd,
					univer_personal_struct_pos_link_1c spl
				WHERE
					p.personal_id = spl.personal_id AND
					sd.structure_division_id = spl.structure_division_id AND
					sd.structure_division_id = @chairId AND
					spl.status != 2  AND p.status != 2
					AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
				))
			OR
			-- на уровне факультета
			(@categoryId=1 AND a.person_id IN 
				(SELECT
					DISTINCT p.personal_id
				FROM
					univer_personal p,
					univer_structure_division_1c sd,
					univer_personal_struct_pos_link_1c spl
				WHERE
					p.personal_id = spl.personal_id AND
					sd.structure_division_id = spl.structure_division_id AND
					sd.structure_division_ext = @facultyId AND
					spl.status != 2  AND p.status != 2
					AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
				))
			)
			
	END;
	/********************2.10.1 - Proceedings indexed by Thomson Reuters***********************************************************/
	IF (@indicatorConst=2)
	BEGIN
		SELECT @Result =  COUNT(*)
		FROM
			DBScience.dbo.Thesises th,
			DBScience.dbo.L_Person_Thesis_Authors a,
			DBScience.dbo.SciEvents se
		WHERE
			-- тезис не архивирован
			th.status != 2 AND
			-- тезис этого года (по мероприятию)
			th.sciEvent_id = se.sciEvent_id AND
			-- тезис этого года
			YEAR(se.eventStart) in (@year, @year+1) and
			-- не дублированная и подтвержденная
			th.is_overlap IS NULL AND
			th.is_approve=1 AND
			--Доклад в сборнике Thomson Reuters (Proceedings indexed by Thomson Reuters)
			th.thesisType_id=11 and
			-- тезис этого автора (ППС, потому personType = 1)
			th.thesis_id = a.thesis_id AND
			a.personType = 1 AND 
			(
			-- на уровне ппс
			(@categoryId=3 AND a.person_id = @personalId)
			OR
			-- на уровне кафедры
			(@categoryId=2 AND a.person_id IN 
				(SELECT
					DISTINCT p.personal_id
				FROM
					univer_personal p,
					univer_structure_division_1c sd,
					univer_personal_struct_pos_link_1c spl
				WHERE
					p.personal_id = spl.personal_id AND
					sd.structure_division_id = spl.structure_division_id AND
					sd.structure_division_id = @chairId AND
					spl.status != 2  AND p.status != 2
					AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
				))
			OR
			-- на уровне факультета
			(@categoryId=1 AND a.person_id IN 
				(SELECT
					DISTINCT p.personal_id
				FROM
					univer_personal p,
					univer_structure_division_1c sd,
					univer_personal_struct_pos_link_1c spl
				WHERE
					p.personal_id = spl.personal_id AND
					sd.structure_division_id = spl.structure_division_id AND
					sd.structure_division_ext = @facultyId AND
					spl.status != 2  AND p.status != 2
					AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
				))
			);
	END;
	
	/********************2.10.2 Proceedings indexed by Scopus***********************************************************/
	IF (@indicatorConst=3)
	BEGIN
		SELECT @Result =  COUNT(*)
		FROM
			DBScience.dbo.Thesises th,
			DBScience.dbo.L_Person_Thesis_Authors a,
			DBScience.dbo.SciEvents se
		WHERE
			-- тезис не архивирован
			th.status != 2 AND
			-- тезис этого года (по мероприятию)
			th.sciEvent_id = se.sciEvent_id AND
			-- тезис этого года
			YEAR(se.eventStart) in (@year, @year+1) and
			-- не дублированная и подтвержденная
			th.is_overlap IS NULL AND
			th.is_approve=1 AND
			--Доклад в сборнике Scopus (Proceedings indexed by Scopus)
			th.thesisType_id=12 and
			-- тезис этого автора (ППС, потому personType = 1)
			th.thesis_id = a.thesis_id AND
			a.personType = 1 AND 
			(
			-- на уровне ппс
			(@categoryId=3 AND a.person_id = @personalId)
			OR
			-- на уровне кафедры
			(@categoryId=2 AND a.person_id IN 
				(SELECT
					DISTINCT p.personal_id
				FROM
					univer_personal p,
					univer_structure_division_1c sd,
					univer_personal_struct_pos_link_1c spl
				WHERE
					p.personal_id = spl.personal_id AND
					sd.structure_division_id = spl.structure_division_id AND
					sd.structure_division_id = @chairId AND
					spl.status != 2  AND p.status != 2
					AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
				))
			OR
			-- на уровне факультета
			(@categoryId=1 AND a.person_id IN 
				(SELECT
					DISTINCT p.personal_id
				FROM
					univer_personal p,
					univer_structure_division_1c sd,
					univer_personal_struct_pos_link_1c spl
				WHERE
					p.personal_id = spl.personal_id AND
					sd.structure_division_id = spl.structure_division_id AND
					sd.structure_division_ext = @facultyId AND
					spl.status != 2  AND p.status != 2
					AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
				))
			);
	END;
	
	RETURN @Result+@Result2;

END

go

