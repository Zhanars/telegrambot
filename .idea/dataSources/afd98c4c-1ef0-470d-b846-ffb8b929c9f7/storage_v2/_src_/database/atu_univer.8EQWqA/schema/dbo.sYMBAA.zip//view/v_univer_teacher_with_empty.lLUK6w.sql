CREATE VIEW dbo.v_univer_teacher_with_empty
AS
SELECT     teacher_id, personal_id, teacher_spec_id, teacher_count_doctor_degree, status
FROM         dbo.univer_teacher
union select  0, 0, 0,0,1

go

