-- =============================================
-- Author:		@LFER
-- Create date: 2009-06-17 13:43:24.297
-- Description:	Изменение прав доступа соответствуеющего персонала при редактировании
-- =============================================
CREATE TRIGGER [dbo].[personalUpdateTrigger]
   ON  [dbo].[univer_personal]
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @ui int
	DECLARE @pi int
	DECLARE @st int
	
	DECLARE insCursor1 cursor 
		FOR SELECT user_id, status, personal_id FROM inserted
	
	IF UPDATE(status)
	BEGIN
		OPEN insCursor1
		FETCH NEXT FROM insCursor1 INTO @ui, @st, @pi
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF(@st=1)
				begin EXEC dbo.usersSetAccess @ui, 'PERSONAL';
				      Exec dbo.personalStatusAfterUpdate @pi
				 end 
			ELSE
			BEGIN
				update univer_users set user_access=0 WHERE user_id=@ui;
				update univer_advicer set status=@st where personal_id=@pi;
				update univer_teacher set status=@st where personal_id=@pi;
				--UPDATE univer_personal SET user_id=0 WHERE personal_id=@pi
			END
				
			FETCH NEXT FROM insCursor1 INTO @ui, @st, @pi
		END
		CLOSE insCursor1
	END

END
go

