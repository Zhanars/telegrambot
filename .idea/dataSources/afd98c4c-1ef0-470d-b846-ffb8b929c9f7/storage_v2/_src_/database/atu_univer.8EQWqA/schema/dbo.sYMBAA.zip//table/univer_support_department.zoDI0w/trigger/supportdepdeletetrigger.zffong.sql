-- =============================================
-- Author:		@LFER
-- Create date: 2009-07-13 11:32:47.090
-- Description:	Триггер на удаление сотрудника отдела сопровождения
-- =============================================
CREATE TRIGGER [dbo].[supportDepDeleteTrigger]
   ON  [dbo].[univer_support_department] 
   AFTER DELETE
AS 
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    DECLARE @pi int
	DECLARE @st int
    DECLARE insCursor cursor 
		FOR SELECT personal_id FROM deleted
	
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @pi
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC dbo.personalDeleteAccess @pi, 'SUPPORT_DEPART'
			
		FETCH NEXT FROM insCursor INTO @pi
	END
	CLOSE insCursor
END
go

