
-- =============================================
-- Author:		Yerlan
-- Create date: 21.06.2012
-- Description: Получить КОЛИЧЕСТВО кафедр по факультету
-- =============================================
CREATE FUNCTION [dbo].[IP_ALL_getChairsCount_ByFacultyId]
(
	@facultyId int
)
RETURNS real
AS
BEGIN
DECLARE @Result real

SELECT @Result = COUNT(DISTINCT chair_id)
	FROM 
		univer_chair c, univer_faculty f
	WHERE 
	c.faculty_id = f.faculty_id AND f.structure_division_id=@facultyId AND c.status=1 AND f.status=1
IF (@Result=0)
	BEGIN
	SET @Result = 1;
	END
RETURN ISNULL(@Result,1)
END

go

