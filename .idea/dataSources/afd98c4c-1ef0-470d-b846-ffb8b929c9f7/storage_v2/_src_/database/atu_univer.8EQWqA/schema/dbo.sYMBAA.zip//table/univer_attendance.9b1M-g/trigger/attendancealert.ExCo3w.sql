-- =============================================
-- Author:		sasha
-- Create date: 30.10.2017 
-- Description:	Добавление студентам сообщения об обновлении журнала
-- =============================================
CREATE TRIGGER [dbo].[attendanceAlert]
   ON  [dbo].[univer_attendance]
   After UPDATE,INSERT 
AS 
BEGIN	
	SET NOCOUNT ON;
	
	IF EXISTS(SELECT * FROM inserted)
	BEGIN
	INSERT INTO univer_alert (alert_code, user_id, alert_date) 
	select 3,st.user_id,getdate() from univer_students st, inserted a where a.student_id=st.students_id
	and not exists(select * from univer_alert a where a.user_id=st.user_id and a.alert_code=3);	
	END	
END
go

