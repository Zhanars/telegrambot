-- =============================================
-- Author:		@LFER
-- Create date: 2009-11-30
-- Description:	Добавление права пользователю
-- =============================================
CREATE TRIGGER [dbo].[parentRoleCreate] ON  [dbo].[univer_parent] FOR INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	-- Insert statements for trigger here
	-- Цифра доступа для данной сущности
	DECLARE @userId int
	
	DECLARE insCursor cursor 
		FOR SELECT user_id FROM inserted		
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @userId
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC dbo.usersSetAccess @userId, 'PARENTS'
		FETCH NEXT FROM insCursor INTO @userId;
	END
	CLOSE insCursor
END
go

