-- =============================================
-- Author:		Twice
-- Create date: 31.01.2012
-- Description: Получить количество ППС, награжденных за выдающийся вклад в развитие науки и техники (1 - Государственные награды РК, 2 - Международные награды, 3 - Лауреаты государственной премии РК, 4 - Именные премии РК, 5 - Государственные научные стипендии для ученых и специалистов, внесших выдающийся вклад, 6 - Грант Лучший преподаватель вуза - в разрезе кафедр
-- =============================================
CREATE FUNCTION IP_NIR_getAwardedPPS_Count_ByChairId_DESC
(
	@chairId int,
	@year int,
	@awardTypeId int
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @Result NVARCHAR(MAX)

SELECT @Result = N''

-- Return the result of the function
RETURN @Result

END
go

