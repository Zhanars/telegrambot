CREATE VIEW dbo.site_personal_publications_papers
AS
SELECT     TOP (100) PERCENT p.personal_id, pspl.structure_division_id AS chair_id, p.personal_sname + ' ' + LEFT(p.personal_name, 1) + '.' + LEFT(p.personal_father_name, 1)
                       + '.' AS author, DBScience.dbo.support_getCoauthorsOfPublication(pp.paper_id, 2, p.personal_id) AS coauthors, pp.paper_id, pp.name_kz, pp.name_ru, pp.name_en, 
                      (CASE WHEN pp.periodicEditionType_id = 1 THEN sj.name WHEN pp.periodicEditionType_id = 2 THEN op.name END) AS journalName, pp.yearPublication, pp.volume, 
                      pp.issueNumber, pp.startPage, pp.endPage, pp.pageCount, pp.annotationFile_id, fi.serverFileName AS annotationFile, pp.paperFile_id, 
                      fi2.showName AS paperFile
FROM         dbo.univer_personal AS p LEFT OUTER JOIN
                      DBScience.dbo.L_Person_Paper_Authors AS lpa ON lpa.personType = 1 AND lpa.person_id = p.personal_id INNER JOIN
                      DBScience.dbo.Papers AS pp ON pp.paper_id = lpa.paper_id AND pp.status <> 2 LEFT OUTER JOIN
                      DBScience.dbo.SciJournals AS sj ON sj.sciJournal_id = pp.periodicEdition_id AND pp.periodicEditionType_id = 1 LEFT OUTER JOIN
                      DBScience.dbo.OtherPeriodicEditions AS op ON op.otherPeriodicEdition_id = pp.periodicEdition_id AND pp.periodicEditionType_id = 2 LEFT OUTER JOIN
                      DBScience.dbo.Publishers AS pub ON pub.publisher_id = sj.publisher_id LEFT OUTER JOIN
                      DBScience.dbo.Countries AS c ON c.country_id = pub.country_id LEFT OUTER JOIN
                      DBScience.dbo.FileInfos AS fi ON pp.annotationFile_id = fi.fileInfo_id LEFT OUTER JOIN
                      DBScience.dbo.FileInfos AS fi2 ON pp.paperFile_id = fi2.fileInfo_id LEFT OUTER JOIN
                      dbo.univer_personal_struct_pos_link_1c AS pspl ON pspl.personal_id = p.personal_id AND pspl.status = 1 AND pspl.type_id IN (1, 2)
ORDER BY p.personal_id
go

