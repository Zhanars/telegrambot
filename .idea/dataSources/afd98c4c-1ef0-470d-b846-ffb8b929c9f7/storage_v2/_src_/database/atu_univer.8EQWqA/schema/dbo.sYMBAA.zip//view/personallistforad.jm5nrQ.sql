






CREATE view [dbo].[personalListForAD]
as
select p.personal_id
, null as ad_login
, u.user_login as univer_login
, case
	when /*p.status=1 and*/ (select COUNT(*) cnt from univer_personal_struct_pos_link_1c l where l.personal_id=p.personal_id and l.status=1)>0 then 1
	WHEN p.status=1 AND p.status_personal_id=3/*Vremenniy*/ THEN 1 
	else 2
	end as status	
, GETDATE() as date_change_univer
, null as date_change_ad
, p.personal_sname sname
, p.personal_name name
--, p.card_id as card_id --старый код
, CAST((select TOP 1 idf.identifier 
	from perco_univer_identifier idf, perco_univer_staff sf 
	where idf.staff_id_internal=sf.staff_id_internal and sf.staff_tabel_id='p_'+CAST(p.personal_id as varchar)
	ORDER BY idf.prohibit) AS NVARCHAR(20)) as card_id
, null as email
, substring(
	(select ', ' + structure_division_name_ru from
		(select distinct sd.structure_division_name_ru, MAX(l.personal_rate) rate
		from univer_structure_division_1c sd
		, univer_personal_struct_pos_link_1c l
		where p.personal_id=l.personal_id
		and sd.structure_division_id=l.structure_division_id
		and l.status=1
		group by sd.structure_division_name_ru) as temp3
	order by rate desc, structure_division_name_ru
	For XML PATH ('')),3, 255) as structure_division
, SUBSTRING(
	(select '| ' + name from 
		(select distinct psd.structure_division_name_ru as name, max(l.personal_rate) rate
		from univer_structure_division_1c psd
		, univer_structure_division_1c sd
		, univer_personal_struct_pos_link_1c l
		where psd.structure_division_id=sd.structure_division_ext
		and p.personal_id=l.personal_id
		and sd.structure_division_id=l.structure_division_id
		and l.status=1
		group by psd.structure_division_name_ru) as temp2
	order by rate desc, name
	For XML PATH ('')), 3, 255) as parent_structure_division
, ISNULL(SUBSTRING(
	(select '| ' + name from 
		(select distinct pos.personal_position_name_ru as name, MAX(l.personal_rate) rate
		from univer_personal_struct_pos_link_1c l 
		, univer_personal_position_1c pos
		where pos.personal_position_id=l.personal_position_id
		and p.personal_id=l.personal_id
		and l.status=1
		group by pos.personal_position_name_ru) as temp
	order by rate desc, name
	For XML PATH ('')), 3, 255), case when p.status=1 AND p.status_personal_id=3 THEN N'Временный' ELSE NULL END) as position
, null room
, null telephone
, N'КазНУ' as company
, null temp_password
, 0 change_password
--, dbo.Ad_sortGroups(
--	SUBSTRING(
--		(select ';' + sd.memberof
--		from univer_structure_division_1c sd
--		, univer_personal_struct_pos_link_1c l
--		where p.personal_id=l.personal_id
--		and sd.structure_division_id=l.structure_division_id
--		and l.status=1
--		For XML PATH ('')), 2, 512)
--	) as memberof
, null as memberof
, 0 memberof_changed
, p.personal_id_1c
, SUBSTRING(
	(select ', ' + l.pers_struct_pos_link_id_1c from 
	univer_personal_struct_pos_link_1c l
	where l.personal_id=p.personal_id
	and l.status=1
	and l.personal_went_date>getdate()
	order by l.personal_rate desc, l.personal_emp_date, l.pers_struct_pos_link_id_1c
	For XML PATH ('')), 3, 250) as staff_ids_1c
from univer_personal p
left join univer_users u on p.user_id=u.user_id


go

