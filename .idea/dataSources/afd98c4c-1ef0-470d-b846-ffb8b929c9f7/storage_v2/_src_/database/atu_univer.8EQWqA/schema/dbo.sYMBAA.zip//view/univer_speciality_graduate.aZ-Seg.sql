
CREATE VIEW [dbo].[univer_speciality_graduate]
AS
SELECT     sp.speciality_id, year(o.order_date) grad_year, count(DISTINCT osl.student_id) AS student_count
FROM          univer_speciality sp,  univer_students st,  univer_order_student_link osl,  univer_order o
WHERE     o.order_id = osl.order_id AND st.students_id = osl.student_id AND st.speciality_id = sp.speciality_id AND o.order_type_id = 80 AND year(o.order_date) >= YEAR(getdate())-4  AND o.status IN (22, 21)
GROUP BY sp.speciality_id, year(o.order_date)
UNION
SELECT     sp.speciality_id, year(o.order_date) grad_year, count(DISTINCT osl.student_id) AS student_count
FROM          univer_speciality sp,  _arc_univer_students st,  _arc_univer_order_student_link osl,  univer_order o
WHERE     o.order_id = osl.order_id AND st.students_id = osl.student_id AND st.speciality_id = sp.speciality_id AND o.order_type_id = 80 AND year(o.order_date) >= YEAR(getdate())-4  AND o.status IN (22, 21)
GROUP BY sp.speciality_id, year(o.order_date)

go

