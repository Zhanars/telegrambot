-- =============================================
-- Author:		Sasha
-- Create date: 20.04.2011
-- Description:	Удаление права на доступ к летнему семестру при удалении строки
-- =============================================
CREATE TRIGGER [dbo].[studentSummerDeleteTrigger]
   ON  [dbo].[univer_additsem_student]
   AFTER DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @userId int
	DECLARE @st int
	
	DECLARE insCursor cursor 
		FOR SELECT user_id, status FROM deleted
	
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @userId, @st
	WHILE @@FETCH_STATUS = 0
	BEGIN
	EXEC dbo.usersDeleteAccess @userId, 'ADDIT_STUDENT'
	FETCH NEXT FROM insCursor INTO @userId, @st
	END
	CLOSE insCursor
END
go

