-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER CertPointDeleteForPlatonus
   ON  univer_certificate_points
   AFTER delete
AS 
BEGIN
	SET NOCOUNT ON;
	if (ISNULL((select COUNT(*) from deleted d),0)>0)
	begin
		insert into platonus_univer_certificate_points(point_id, operation)
		select d.point_id, 2 from deleted d
	end;
END
go

