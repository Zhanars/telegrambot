CREATE VIEW dbo.crystal_education_student
AS
SELECT     students_zachetka AS id, students_sname AS surname, students_name AS firstname, students_father_name AS middlename, CONVERT(nvarchar, 
                      students_birth_date, 103) AS birthdate, students_adress AS address, students_contact_town_phone AS phone, students_document_identity_number AS id_no, 
                      CONVERT(nvarchar, students_document_identity_date, 103) AS id_date, students_document_identity_issued AS id_issuer, N'' AS nationality, 
                      CASE students_marital_status WHEN 0 THEN N'SINGLE' ELSE N'MARRIED' END AS marital_status, N'' AS notes, 0 AS school, N'ONLINE' AS student_status
FROM         dbo.univer_students
WHERE     (status = 1) AND (education_form_id = 1)
go

