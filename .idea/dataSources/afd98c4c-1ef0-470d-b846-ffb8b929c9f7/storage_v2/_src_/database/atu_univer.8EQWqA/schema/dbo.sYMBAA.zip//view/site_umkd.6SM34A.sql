CREATE VIEW dbo.site_umkd
AS
SELECT     TOP (100) PERCENT tf.teacher_file_id AS file_id, t.personal_id, 
                      CASE WHEN tf.umkd_access & 4 > 0 THEN '\\BLDEK_2\uni.kaznu.kz\Content\files\umkd\' + CONVERT(nvarchar, tf.teacher_id) 
                      + '\' + tf.teacher_file_name ELSE '' END AS file_path, tf.teacher_file_description AS file_desc, tf.teacher_file_size AS file_size, 
                      tf.teacher_file_download_count AS download_count, tf.teacher_file_ext AS file_ext, tf.teacher_file_title AS file_title, tf.teacher_file_upload_date AS upload_date, 
                      tf.umkd_type_id AS type_id, tp.umkd_type_name_ru AS type_name_ru, tp.umkd_type_name_kz AS type_name_kz, tp.umkd_type_name_en AS type_name_en, 
                      tf.educ_lang_id AS lang_id, ISNULL(el.educ_lang_name_ru, '-') AS lang_name_ru, ISNULL(el.educ_lang_name_kz, '-') AS lang_name_kz, 
                      ISNULL(el.educ_lang_name_en, '-') AS lang_name_en, tf.subject_id, ISNULL(sb.subject_name_ru, '-') AS subject_name_ru, ISNULL(sb.subject_name_kz, '-') 
                      AS subject_name_kz, ISNULL(sb.subject_name_en, '-') AS subject_name_en
FROM         dbo.univer_teacher_file AS tf LEFT OUTER JOIN
                      dbo.univer_educ_lang AS el ON el.educ_lang_id = tf.educ_lang_id LEFT OUTER JOIN
                      dbo.univer_subject AS sb ON tf.subject_id = sb.subject_id INNER JOIN
                      dbo.univer_teacher AS t ON tf.teacher_id = t.teacher_id INNER JOIN
                      dbo.univer_umkd_type AS tp ON tf.umkd_type_id = tp.umkd_type_id
WHERE     (tf.umkd_access & 2 > 0) OR
                      (tf.umkd_access & 4 > 0) AND (tf.status = 1)
ORDER BY tf.subject_id, type_id, file_title
go

