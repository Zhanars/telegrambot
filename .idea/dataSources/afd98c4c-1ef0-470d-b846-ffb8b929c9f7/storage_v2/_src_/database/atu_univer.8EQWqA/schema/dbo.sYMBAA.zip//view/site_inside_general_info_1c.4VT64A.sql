
CREATE VIEW [dbo].[site_inside_general_info_1c]
AS
SELECT     dbo.univer_personal.personal_id, dbo.univer_personal.personal_sname, dbo.univer_personal.personal_name, dbo.univer_personal.personal_father_name, researcher_id, 
                      CASE WHEN dbo.univer_personal.personal_birthday_date < '3086-10-21 00:00:00.000' THEN NULL ELSE DATEADD(YYYY, - 2000, 
                      dbo.univer_personal.personal_birthday_date) END AS personal_birthday_date, dbo.univer_personal.personal_photo, 
                      univer_structure_division_1c_1.structure_division_ext AS faculty_id,
                          (SELECT     structure_division_name_kz
                            FROM          dbo.univer_structure_division_1c AS sd
                            WHERE      (univer_structure_division_1c_1.structure_division_ext = structure_division_id)) AS faculty_name_kz,
                          (SELECT     structure_division_name_ru
                            FROM          dbo.univer_structure_division_1c AS sd
                            WHERE      (univer_structure_division_1c_1.structure_division_ext = structure_division_id)) AS faculty_name_ru,
                          (SELECT     structure_division_name_en
                            FROM          dbo.univer_structure_division_1c AS sd
                            WHERE      (univer_structure_division_1c_1.structure_division_ext = structure_division_id)) AS faculty_name_en, 
                      univer_structure_division_1c_1.structure_division_id AS chair_id, univer_structure_division_1c_1.structure_division_name_kz AS chair_name_kz, 
                      univer_structure_division_1c_1.structure_division_name_ru AS chair_name_ru, univer_structure_division_1c_1.structure_division_name_en AS chair_name_en, 
                      dbo.univer_personal_position_1c.personal_position_name_kz, dbo.univer_personal_position_1c.personal_position_name_ru, 
                      dbo.univer_personal_position_1c.personal_position_name_en, dbo.univer_academic_degree_1c.academic_degree_name_kz, 
                      dbo.univer_academic_degree_1c.academic_degree_name_ru, dbo.univer_academic_degree_1c.academic_degree_name_en, 
                      dbo.univer_degree_area_1c.degree_area_name_kz AS academic_degree_area_name_kz, 
                      dbo.univer_degree_area_1c.degree_area_name_ru AS academic_degree_area_name_ru, 
                      dbo.univer_degree_area_1c.degree_area_name_en AS academic_degree_area_name_en, 
                      dbo.univer_degree_area_1c.degree_area_short_name_kz AS academic_degree_area_short_name_kz, 
                      dbo.univer_degree_area_1c.degree_area_short_name_ru AS academic_degree_area_short_name_ru, 
                      dbo.univer_degree_area_1c.degree_area_short_name_en AS academic_degree_area_short_name_en, dbo.univer_degree_area_1c.degree_area_translit_name_kz, 
                      dbo.univer_degree_area_1c.degree_area_translit_name_ru, dbo.univer_degree_area_1c.degree_area_translit_name_en, 
                      dbo.univer_personal_academic_degree_1c.personal_academic_degree_number, 
                      CASE WHEN dbo.univer_personal_academic_degree_1c.personal_academic_degree_date < '3086-10-21 00:00:00.000' THEN NULL ELSE DATEADD(YYYY, - 2000, 
                      dbo.univer_personal_academic_degree_1c.personal_academic_degree_date) END AS personal_academic_degree_date, 
                      dbo.univer_scientific_degree_1c.scientific_degree_name_kz, dbo.univer_scientific_degree_1c.scientific_degree_name_ru, 
                      dbo.univer_scientific_degree_1c.scientific_degree_name_en, univer_degree_area_1.degree_area_name_kz AS scientific_degree_area_name_kz, 
                      univer_degree_area_1.degree_area_name_ru AS scientific_degree_area_name_ru, 
                      univer_degree_area_1.degree_area_name_en AS scientific_degree_area_name_en, 
                      univer_degree_area_1.degree_area_short_name_kz AS scientific_degree_area_short_name_kz, 
                      univer_degree_area_1.degree_area_short_name_ru AS scientific_degree_area_short_name_ru, 
                      univer_degree_area_1.degree_area_short_name_en AS scientific_degree_area_short_name_en, 
                      univer_degree_area_1.degree_area_translit_name_kz AS sdegree_area_translit_name_kz, 
                      univer_degree_area_1.degree_area_translit_name_ru AS sdegree_area_translit_name_ru, 
                      univer_degree_area_1.degree_area_translit_name_en AS sdegree_area_translit_name_en, 
                      dbo.univer_personal_scientific_degree_1c.personal_scientific_degree_number, 
                      CASE WHEN dbo.univer_personal_scientific_degree_1c.personal_scientific_degree_date < '3086-10-21 00:00:00.000' THEN NULL ELSE DATEADD(YYYY, - 2000, 
                      dbo.univer_personal_scientific_degree_1c.personal_scientific_degree_date) END AS personal_scientific_degree_date, 
                      dbo.univer_scientific_rank_1c.scientific_rank_name_kz, dbo.univer_scientific_rank_1c.scientific_rank_name_ru, 
                      dbo.univer_scientific_rank_1c.scientific_rank_name_en, dbo.univer_personal_scientific_rank_1c.personal_scientific_rank_number, 
                      CASE WHEN dbo.univer_personal_scientific_rank_1c.personal_scientific_rank_date < '3086-10-21 00:00:00.000' THEN NULL ELSE DATEADD(YYYY, - 2000, 
                      dbo.univer_personal_scientific_rank_1c.personal_scientific_rank_date) END AS personal_scientific_rank_date, 
                      dbo.univer_scientific_degree_1c.scientific_degree_short_name_kz, dbo.univer_scientific_degree_1c.scientific_degree_short_name_ru, 
                      dbo.univer_scientific_degree_1c.scientific_degree_short_name_en, dbo.univer_personal_position_1c.personal_position_id, 
                      dbo.univer_personal_biografy.personal_biografy_kz, dbo.univer_personal_biografy.personal_biografy_ru, dbo.univer_personal_biografy.personal_biografy_en, 
                      '0' AS mainer, dbo.univer_site_link.site_faculty_id, dbo.univer_personal_position_1c.personal_position_rate, dbo.univer_personal.personal_site_photo
FROM         dbo.univer_personal_biografy RIGHT OUTER JOIN
                      dbo.univer_degree_area_1c RIGHT OUTER JOIN
                      dbo.univer_personal_struct_pos_link_1c INNER JOIN
                      dbo.univer_personal ON dbo.univer_personal_struct_pos_link_1c.personal_id = dbo.univer_personal.personal_id LEFT OUTER JOIN
                      dbo.univer_personal_academic_degree_1c ON dbo.univer_personal.personal_id = dbo.univer_personal_academic_degree_1c.personal_id AND 
                      dbo.univer_personal_academic_degree_1c.personal_academic_degree_id =
                          (SELECT     TOP (1) personal_academic_degree_id
                            FROM          dbo.univer_personal_academic_degree_1c AS ad
                            WHERE      (personal_id = dbo.univer_personal.personal_id)
                            ORDER BY personal_academic_degree_date DESC) LEFT OUTER JOIN
                      dbo.univer_personal_scientific_rank_1c ON dbo.univer_personal.personal_id = dbo.univer_personal_scientific_rank_1c.personal_id AND 
                      dbo.univer_personal_scientific_rank_1c.personal_scientific_rank_id =
                          (SELECT     TOP (1) personal_scientific_rank_id
                            FROM          dbo.univer_personal_scientific_rank_1c AS sd
                            WHERE      (personal_id = dbo.univer_personal.personal_id)
                            ORDER BY personal_scientific_rank_date DESC) LEFT OUTER JOIN
                      dbo.univer_personal_scientific_degree_1c ON dbo.univer_personal.personal_id = dbo.univer_personal_scientific_degree_1c.personal_id AND 
                      dbo.univer_personal_scientific_degree_1c.personal_scientific_degree_id =
                          (SELECT     TOP (1) personal_scientific_degree_id
                            FROM          dbo.univer_personal_scientific_degree_1c AS sd
                            WHERE      (personal_id = dbo.univer_personal.personal_id) AND (scientific_degree_id NOT IN (2, 4))
                            ORDER BY personal_scientific_degree_date DESC) LEFT OUTER JOIN
                      dbo.univer_personal_position_1c ON 
                      dbo.univer_personal_struct_pos_link_1c.personal_position_id = dbo.univer_personal_position_1c.personal_position_id LEFT OUTER JOIN
                      dbo.univer_structure_division_1c AS univer_structure_division_1c_1 ON 
                      dbo.univer_personal_struct_pos_link_1c.structure_division_id = univer_structure_division_1c_1.structure_division_id LEFT OUTER JOIN
                      dbo.univer_academic_degree_1c ON 
                      dbo.univer_personal_academic_degree_1c.academic_degree_id = dbo.univer_academic_degree_1c.academic_degree_id LEFT OUTER JOIN
                      dbo.univer_scientific_degree_1c ON 
                      dbo.univer_personal_scientific_degree_1c.scientific_degree_id = dbo.univer_scientific_degree_1c.scientific_degree_id LEFT OUTER JOIN
                      dbo.univer_scientific_rank_1c ON dbo.univer_personal_scientific_rank_1c.scientific_rank_id = dbo.univer_scientific_rank_1c.scientific_rank_id ON 
                      dbo.univer_degree_area_1c.degree_area_id = dbo.univer_personal_academic_degree_1c.degree_area_id LEFT OUTER JOIN
                      dbo.univer_degree_area_1c AS univer_degree_area_1 ON dbo.univer_personal_scientific_degree_1c.degree_area_id = univer_degree_area_1.degree_area_id ON 
                      dbo.univer_personal_biografy.personal_id = dbo.univer_personal.personal_id LEFT OUTER JOIN
                      dbo.univer_site_link ON dbo.univer_site_link.uni_faculty_id = univer_structure_division_1c_1.structure_division_ext
WHERE     (dbo.univer_personal.status = 1) AND (univer_structure_division_1c_1.status = 1) AND (dbo.univer_personal_struct_pos_link_1c.status = 1) AND 
                      (univer_structure_division_1c_1.structure_division_ext IN (9, 15, 29, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50, 52)) AND 
                      (univer_structure_division_1c_1.structure_division_id IN (28, 72, 76, 77, 103, 121, 132, 107, 30, 85, 83, 89, 90, 97, 33, 102, 127, 118, 35, 74, 95, 96, 79, 37, 131, 94, 
                      101, 109, 133, 39, 84, 92, 41, 78, 75, 43, 98, 99, 82, 86, 87, 88, 93, 91, 45, 80, 111, 116, 112, 110, 108, 105, 106, 125, 47, 49, 73, 128, 129, 124, 104, 117, 114, 122, 
                      123, 51, 53, 81, 119, 115, 113, 12, 227, 31, 100, 120, 126, 130)) AND (dbo.univer_personal_position_1c.category_id = 3) AND 
                      (dbo.univer_personal_struct_pos_link_1c.type_id = 3)

go

