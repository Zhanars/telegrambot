-- =============================================
-- Author:		Yerlan
-- Create date: 2016-05-10 
-- Description:	Добавление соответствующего права для сотрудника при добалений строки
-- =============================================
create TRIGGER [dbo].[KMOUpdateTrigger]
   ON  [dbo].[univer_stud_rating_admin]
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
    DECLARE @pi int
	DECLARE @st int
	
	DECLARE insCursor cursor 
		FOR SELECT user_id, status FROM inserted
		
	IF UPDATE(status)
	BEGIN
		OPEN insCursor
		FETCH NEXT FROM insCursor INTO @pi, @st
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF(@st=1)
				EXEC dbo.usersSetAccess @pi, 'KMO'
			ELSE
				EXEC dbo.usersDeleteAccess @pi, 'KMO'
				
			FETCH NEXT FROM insCursor INTO @pi, @st
		END
		CLOSE insCursor
	END
END
go

