-- =============================================
-- Author:		@LFER
-- Create date: 
-- Description:	Преобразование старых казахских символов в новые
-- =============================================
CREATE FUNCTION [dbo].[translateFromOldKZ]
(
	@str NVARCHAR(4000)
)
RETURNS NVARCHAR(4000)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ret NVARCHAR(4000)

	-- Add the T-SQL statements to compute the return value here
	SELECT @ret = REPLACE(@str, N'ќ', N'қ' collate Cyrillic_General_CS_AS) 
	SELECT @ret = REPLACE(@ret, N'Ќ', N'Қ' collate Cyrillic_General_CS_AS) 
	
	SELECT @ret = REPLACE(@ret, N'њ', N'ң' collate Cyrillic_General_CS_AS) 
	SELECT @ret = REPLACE(@ret, N'Њ', N'Ң' collate Cyrillic_General_CS_AS)
	
	SELECT @ret = REPLACE(@ret, N'є', N'ә' collate Cyrillic_General_CS_AS)
	SELECT @ret = REPLACE(@ret, N'Є', N'Ә' collate Cyrillic_General_CS_AS)
	
	SELECT @ret = REPLACE(@ret, N'ѓ', N'ғ' collate Cyrillic_General_CS_AS)
	SELECT @ret = REPLACE(@ret, N'Ѓ', N'Ғ' collate Cyrillic_General_CS_AS)
	
	SELECT @ret = REPLACE(@ret, N'±', N'ұ' collate Cyrillic_General_CS_AS)
	SELECT @ret = REPLACE(@ret, N'¦', N'Ұ' collate Cyrillic_General_CS_AS)
	
	SELECT @ret = REPLACE(@ret, N'µ', N'ө' collate Cyrillic_General_CS_AS)
	SELECT @ret = REPLACE(@ret, N'¤', N'Ө' collate Cyrillic_General_CS_AS)
	
	SELECT @ret = REPLACE(@ret, N'‰', N'ү' collate Cyrillic_General_CS_AS)
	SELECT @ret = REPLACE(@ret, N'‡', N'Ү' collate Cyrillic_General_CS_AS)
	
	RETURN @ret

END
go

