-- =============================================
-- Author:		@LFER
-- Create date: 2009-03-31 10:37:41.997
-- Description:	Функция, которая возвращает численное значение доступа по роли
-- =============================================
CREATE FUNCTION [dbo].[accessGetByRole]
(
	@role nvarchar(50)
)
RETURNS bigint
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ret bigint
	SET @ret = 
	CASE @role
		-- <summary>Студент бакалавриата</summary>
		WHEN 'STUDENT_BAKALAVR' THEN 1
		-- <summary>Студент магистратуры</summary>
		WHEN 'STUDENT_MAGISTRANT' THEN 2
		-- <summary>Студент докторантуры</summary>
		WHEN 'STUDENT_PHD' THEN 4
		-- <summary>Студент, обучающийся по программе довузовского образования</summary>
		WHEN 'STUDENT_PREUNIVER' THEN 8

		-- <summary>Преподаватель</summary>
		WHEN 'TEACHER' THEN 16
		-- <summary>Эдвайзер</summary>
		WHEN 'ADVICER' THEN 32
		-- <summary>Офис-регистратор</summary>
		WHEN 'OFICE_REGISTRATOR' THEN 64
		-- <summary>Заведующий кафедрой</summary>
		WHEN 'CHAIR_HEAD' THEN 128
		-- <summary>Декан</summary>
		WHEN 'DEAN' THEN 256
		-- <summary>Ректор</summary>
		WHEN 'RECTOR' THEN 512
		-- <summary>Проректор</summary>
		WHEN 'PRORECTOR' THEN 1024
		-- <summary>Метод отдел</summary>
		WHEN 'METHOD_DEPART' THEN 2048
		-- <summary>Учебный отдел</summary>
		WHEN 'LEARN_DEPART' THEN 4096
		-- <summary>Сотрудники приемной комиссии (занимаются зачислением абитуриентов и студентами, переведенных с других вузов)</summary>
		WHEN 'ADMITING_COMMISSION' THEN 8192
		-- <summary>Сотрудники студенческого отдела</summary>
		WHEN 'STUD_DEPART' THEN 16384
		-- <summary>Сотрудники, контролирующие деятельность пользователей (например загружены ли УМКД, и т.д., у нас это ДАВ)</summary>
		WHEN 'CONTROLLER' THEN 32768
		-- <summary>Сотрудники отдела сопровождения</summary>
		WHEN 'SUPPORT_DEPART' THEN 65536

		-- <summary>Родители</summary>
		WHEN 'PARENTS' THEN 131072

		-- <summary>Абитуриенты</summary>
		WHEN 'ABITURIENT' THEN 262144

		-- <summary>Библиотека</summary>
		WHEN 'LIBRARY' THEN 524288

		-- <summary>Бухгалтерия<summary>
		WHEN 'ACCOUNTING_DEPART' THEN 1048576
		-- <summary>Тестирование</summary>
		WHEN 'TEST_DEPART' THEN 2097152

		-- <summary>Студент</summary>
		WHEN 'STUDENT' THEN 4194304
		-- <summary>Персонал</summary>
		WHEN 'PERSONAL' THEN 8388608
		
		-- <summary>Сотрудники отдела кадров</summary>
		WHEN 'PERSONNEL_DEPART' THEN 16777216
		
		-- <summary>Отдел послевузовского образования</summary>
		WHEN 'POSTGRADUATE_DEPART' THEN 33554432
		
		-- <summary>Зам. декана</summary>
		WHEN 'VICE_DEKAN' THEN 67108864
		
		-- <summary>Руководство (то руководство, что не ректор, не проректор и для всех факультетов)</summary>
		WHEN 'LEADER_OTHER' THEN 134217728
		
		-- <summary>Диспетчер по расписанию</summary>
		WHEN 'SCHEDULER' THEN CAST (268435456 as BIGINT)
		
		-- <summary>Методист факультета/summary>
		WHEN 'METODIST' THEN CAST (536870912 as BIGINT)
		
		-- <summary>АДМИНИСТРАТОР</summary>
		WHEN 'ADMINISTRATOR' THEN CAST (2147483648 as BIGINT)
		
		-- <summary> Рейтинг ППС </summary>
		WHEN 'RATING_PPS' THEN CAST (4294967296 as BIGINT)
		
		-- <summary>Студенты летнего семестра из других ВУЗов</summary>
        WHEN 'ADDIT_STUDENT' THEN CAST (8589934592 AS BIGINT)
        
        -- <summary>Департамент языка и воспитательной работы
        WHEN 'Dl_EW' THEN CAST (17179869184 AS BIGINT)
        
        -- <summary>Зам. заведующего кафедрой
        WHEN 'VICE_CHAIR_HEAD' THEN CAST (34359738368 AS BIGINT)     
        
        -- <summary>Метод бюро
        WHEN 'METHOD_BYURO' THEN CAST (68719476736 AS BIGINT)       
        
        -- <summary>Индикативный план
        WHEN 'INDICATIVE_PLAN' THEN CAST (137438953472 AS BIGINT)
        
        -- <summary>Дистанционное обучение
        WHEN 'DISTANCE_LEARNING' THEN CAST (274877906944 AS BIGINT)
        
		-- <summary>электронные услуги
		WHEN 'ICD' THEN CAST (549755813888 AS BIGINT)
		
		-- <summary>комитет молодежных организации
		WHEN 'KMO' THEN CAST (524288 AS BIGINT)
		
		-- <summary>бухгалтерия ДДПУ (зк)
		WHEN 'ACCOUNTING_DEPART_ABROAD' THEN CAST (2199023255552 AS BIGINT)
		
		-- <summary>бухгалтерия ОТС
		WHEN 'ACCOUNTING_DEPART_STUD' THEN CAST (1099511627776 AS BIGINT)

		-- <summary>Комендант</summary>
		WHEN 'COMMANDANT' THEN CAST (4398046511104 AS BIGINT)

		-- <summary>Комендант</summary>
		WHEN 'ESUVO' THEN CAST (8796093022208 AS BIGINT)
	END

	-- Return the result of the function
	RETURN @ret

END

go

