-- =============================================
-- Author:		sasha
-- Create date: 2014-07-11 
-- Description:	Расчет ECTS-кредитов для прогресса
-- =============================================
CREATE TRIGGER [dbo].[_arc_progressECTSupd]
   ON  [dbo].[_arc_univer_progress]
   After UPDATE,INSERT 
AS 
BEGIN	
	--IF @@ROWCOUNT =0
    --RETURN	
	SET NOCOUNT ON;
	
	IF EXISTS(SELECT * FROM inserted) and (UPDATE(progress_credit) or UPDATE(controll_type_id) or UPDATE(academ_year) or UPDATE(subject_type) or UPDATE(subject_id) or UPDATE(educ_plan_pos_addit))
	BEGIN
	UPDATE p
    SET p.progress_credit_ects = isnull((
select top 1 case when ects_const_value>0 then 
			ects_const_value 
		else 
			case when ects_calc_type=1 then
				case when ects_max_value>0 and p.progress_credit*ects_ratio>ects_max_value then ects_max_value else p.progress_credit*ects_ratio end
			else
				cast(isnull(ects_case_value.value('(/ArrayOfEntry/Entry[Key=sql:column("p.progress_credit")]/Value)[1]', 'float'),0) as real)
				
			end
		end
		from univer_ects_ratio r, _arc_univer_students st where p.student_id=st.students_id and r.status=1  and (r.controll_type_id=p.controll_type_id or r.controll_type_id =0) and  
		 isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="educFormId"]/Value)[1]', 'int'),0) in (0,st.education_form_id) and 
		 isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="stageId"]/Value)[1]', 'int'),0) in( 0,st.stage_id) and
		 isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="eduLevelId"]/Value)[1]', 'int'),0) in (0,st.edu_levels_id) and
		 isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="academYear"]/Value)[1]', 'int'),0) in(0,p.academ_year) and
		 isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="subjType"]/Value)[1]', 'int'),0) in(0,p.subject_type) and
		 isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="specId"]/Value)[1]', 'int'),0) in(0,st.speciality_id) and
		 isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="subjectId"]/Value)[1]', 'int'),0) in(0,p.subject_id) and
		 isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="practiceType"]/Value)[1]', 'int'),0)  in(0,p.educ_plan_pos_addit)
		order by p.controll_type_id, (len(cast(ects_compare_filter as nvarchar(MAX)))- len(replace(cast(ects_compare_filter as nvarchar(MAX)),'<Key>','')))/LEN('<Key>') desc),0) 
    FROM [dbo].[_arc_univer_progress] p
    where p.progress_id in (select progress_id from inserted)
		
		
	END	
END
go

