-- =============================================
-- Author:		Sasha
-- Create date: 19.10.2017
-- Description:	Создать группу по дипломной работе или удалить студента из группы, если такой группы нет
-- для триггера на таблицу univer_student_supervisor
-- =============================================
CREATE PROCEDURE updDiplomGroup
	@studentId int,
	@teacherId int,
	@action bit
AS
BEGIN    

begin transaction	    	
if (@action=1)--Назначен руководитель и надо добавить группу
begin
		declare @posId int;
		declare @langDivId int;
		declare @year int;
		declare @sem int;
		declare @mod int;
		--выбираем все позиции учебного плана, которые являются выпускными работами и по которым еще нет групп
		declare @tbl table(educ_plan_pos_id int, students_id int, teacher_id int, lang_division_id int, group_semestr int, group_year int,acpos_module int)
		insert into @tbl(educ_plan_pos_id, students_id, teacher_id,lang_division_id, group_semestr, group_year,acpos_module )
		select pp.educ_plan_pos_id, s.students_id, @teacherId, s.lang_division_id, 2-pp.educ_plan_pos_semestr%2 sem, s.educ_plan_adm_year+(pp.educ_plan_pos_semestr-1)/2 y, pp.acpos_module  from univer_students s, univer_educ_plan p, univer_educ_plan_pos pp where p.edu_level_id=s.edu_levels_id and p.educ_plan_adm_year=s.educ_plan_adm_year and p.education_form_id=s.education_form_id and p.speciality_id=s.speciality_id and p.status=1 and pp.educ_plan_id=p.educ_plan_id and pp.status=1 and pp.controll_type_id in (select controll_type_id from univer_controll_type where controll_type_section=4 and status=1 union select 32) and s.status=1 and s.student_edu_status_id=1
		and not exists(select g.group_id from univer_group g, univer_group_student gs where g.group_id=gs.group_id and gs.student_id=s.students_id and g.educ_plan_pos_id=pp.educ_plan_pos_id and g.teacher_id=@teacherId and g.group_semestr=2-pp.educ_plan_pos_semestr%2 and g.group_year=s.educ_plan_adm_year+(pp.educ_plan_pos_semestr-1)/2 and g.acpos_module=pp.acpos_module) and s.students_id=@studentId
		--если такие позиции есть, то для каждой создаем группу или прикрепляем студента к имеющейся
		if (exists (select * from @tbl))
		begin
			    DECLARE addGroup cursor 
					FOR SELECT educ_plan_pos_id, lang_division_id,group_semestr, group_year,acpos_module FROM @tbl		
				OPEN addGroup
				FETCH NEXT FROM addGroup INTO @posId, @langDivId,@sem,@year,@mod
				WHILE @@FETCH_STATUS = 0
				BEGIN	
					declare @groupId int=0;
					declare @create bit=0;
					--ищем уже существующую группу преподавателя
					select @groupId=g.group_id from univer_group g where g.educ_plan_pos_id=@posId and g.teacher_id=@teacherId and group_retake_semestr=0 and group_semestr=@sem and group_year=@year and lang_division_id=@langDivId and acpos_module=@mod
					if (isnull(@groupId,0)=0)
					--если групп нет, то создаем
					begin   	    
						declare @chairId int=null;
						--ищем кафедру преподавателя
						select top 1 @chairId=c.chair_id from univer_chair c, univer_teacher t, univer_teacher_chair_link tcl, univer_personal_struct_pos_link_1c sp where tcl.chair_id=c.chair_id and tcl.teacher_id=t.teacher_id and sp.structure_division_id=c.structure_division_id  and t.personal_id=sp.personal_id and t.status=1 and sp.status=1 and c.status=1 and t.teacher_id=@teacherId order by t.teacher_id, sp.personal_rate desc
						--добавляем группу
						insert into univer_group(educ_plan_pos_id, group_students_max,group_students_min, educ_lang_id, educ_type_id, group_isdo, teacher_id, group_retake_semestr, group_semestr, group_year, lang_division_id, acpos_module, chair_id)
						values (@posId,0,0,case @langDivId when 1 then 1 else 2 end,  0, null, @teacherId, 0, @sem, @year,@langDivId, @mod, @chairId)
						set @groupId=@@identity;
						set @create=1;
					end;
					--привязываем студента к группе
					if (isnull(@groupId,0)>0)
					begin
						insert into univer_group_student(student_id,group_id,student_choice_date,student_reg)
						values (@studentId, @groupId, getdate(),0);
						insert into _tmp_group_gen_for_diplom (group_id,student_id,actionStud,actionGroup)
						values (@groupId,@studentId,1,@create)

					end
					FETCH NEXT FROM addGroup INTO @posId, @langDivId,@sem,@year,@mod;
				END
				CLOSE addGroup
		end
end 
else --если надо удалить студента из группы (когда открепили от руководителя)
begin
		declare @groups table(group_id int,subject_id int, n_seme int, academ_year int, semestr int, acpos_module int)
		--ищем группы с таким преподавателем по выпускной работе, в которых сидит этот студент
		insert into @groups (group_id,subject_id, n_seme, academ_year, semestr, acpos_module)
		select g.group_id,subject_id, pp.educ_plan_pos_semestr, g.group_year, g.group_semestr, g.acpos_module from univer_group g, univer_group_student gs, univer_educ_plan_pos pp where g.group_id=gs.group_id and gs.student_id=@studentId 
		and pp.educ_plan_pos_id=g.educ_plan_pos_id and pp.controll_type_id in (select controll_type_id from univer_controll_type where controll_type_section=4 and status=1 union select 32) and g.teacher_id=@teacherId
		--проверяем есть ли ведомости
		declare @sheetCnt int=0;
		select @sheetCnt=count(*) from univer_sheet_result sr, @groups g, univer_sheet s where s.sheet_id=sr.sheet_id and sr.student_id=@studentId and sr.academ_year=g.academ_year and sr.n_seme=g.n_seme and sr.semestr=g.semestr and sr.subject_id=g.subject_id and s.acpos_module=g.acpos_module and s.sheet_kind_id in (1,2)
		--если ведомостей нет, то удаляем из групп студента
		if (@sheetCnt<=0)
		begin
		delete from univer_group_student where student_id=@studentId and group_id in (select group_id from @groups)
		insert into _tmp_group_gen_for_diplom (group_id,student_id,actionStud,actionGroup)
		select group_id,@studentId,0,0 from @groups;		
		end
end
commit    

END
go

