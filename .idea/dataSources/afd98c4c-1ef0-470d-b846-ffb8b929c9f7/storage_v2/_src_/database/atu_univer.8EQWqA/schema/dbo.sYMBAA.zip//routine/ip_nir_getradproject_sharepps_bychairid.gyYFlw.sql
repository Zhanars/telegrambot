-- =============================================
-- Author:		Twice
-- Create date: 31.01.2012
-- Description: Получить долю ППС в научных проектах по фундаментальным, прикладным и хоздоговорным исследованиям (1 - фунд. и прикл., 2 - хоздоговорные) - в разрезе кафедр
-- =============================================
CREATE FUNCTION IP_NIR_getRADProject_SharePPS_ByChairId
(
	@chairId int,
	@year int,
	@radProjectTypeId int
)
RETURNS real
AS
BEGIN
DECLARE @Result real

SELECT @Result = 0

-- Return the result of the function
RETURN @Result

END
go

