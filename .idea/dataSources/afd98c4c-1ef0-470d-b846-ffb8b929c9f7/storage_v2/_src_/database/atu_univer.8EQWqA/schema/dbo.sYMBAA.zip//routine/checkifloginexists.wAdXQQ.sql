
-- =============================================
-- Author:		Twice
-- Create date: 11.12.2011
-- Description:	Проверка, нет ли в Univer_users пользователя с таким логином
-- =============================================
CREATE FUNCTION [dbo].[CheckIfLoginExists] 
(
	-- Add the parameters for the function here
	@login NVARCHAR(50)
)
RETURNS int
AS
BEGIN
-- Declare the return variable here
	DECLARE @Result bit

	-- Add the T-SQL statements to compute the return value here
	SELECT @Result =
	CASE WHEN kol > 0 THEN 1 ELSE 0 END 
	FROM 
	(
		SELECT 
			COUNT(*) as kol 
		FROM 
			univer_users u
		WHERE 
			u.user_login = @login
	) as [found]

	-- Return the result of the function
	RETURN @Result
END

go

