-- =============================================
-- Author:		@LFER
-- Create date: 2009-05-22 12:58:56.740
-- Description:	Удаление или добавлении права доступа при изменении статуса сотрудника
-- =============================================
CREATE TRIGGER [dbo].[teacherUpdateTrigger]
   ON  [dbo].[univer_teacher]
   FOR UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @pi int
	DECLARE @st int
	
	DECLARE insCursor cursor 
		FOR SELECT personal_id, status FROM inserted
	
	IF UPDATE(status)
	BEGIN
		OPEN insCursor
		FETCH NEXT FROM insCursor INTO @pi, @st
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF(@st=1)
			BEGIN
				EXEC dbo.personalSetAccess @pi, 'TEACHER'
				-- восстанавливаем пользователя в Науке, если у него роль ППС
				EXEC dbo.SCI_PPS_SetStatus @pi, 1
			END
			ELSE
			BEGIN
				EXEC dbo.personalDeleteAccess @pi, 'TEACHER'
				-- архивируем пользователя в Науке, если у него роль ППС
				EXEC dbo.SCI_PPS_SetStatus @pi, 2
			END	
			FETCH NEXT FROM insCursor INTO @pi, @st
		END
		CLOSE insCursor
	END

END
go

