-- =============================================
-- Author:		Yerlan
-- Create date: 12.04.2016
-- Description: 
-- =============================================
CREATE FUNCTION [dbo].[GetStudentCertificatesInfoDesc]
(
	@studentId int,
	@langId int
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @Result NVARCHAR(MAX)

SELECT @Result = COALESCE(@Result + '\n\n', N'') + 
		(case when @langId=1 then ct.certificate_type_name_kz when @langId=2 then ct.certificate_type_name_ru else ct.certificate_type_name_en end) collate SQL_Latin1_General_CP1_CI_AS 
		+N', №'+CAST(c.certificate_number as nvarchar(20))
		+N', ' +convert(nvarchar(20),c.certificate_resive_date,111)
FROM 
	univer_certificates c, univer_certificate_type ct
where 
	c.certificate_type_id=ct.certificate_type_id  
	AND c.students_id=@studentId;
	
RETURN @Result

END
go

