-- =============================================
-- Author:		Sasha
-- Create date: 18.12.2014
-- Description:	Функция для получения стоимости обучения в год для студента
-- =============================================
CREATE FUNCTION [dbo].[getEduCostForStudent] 
(
	@studentId int
)
RETURNS real
AS
BEGIN
	DECLARE @yearAdm int, @category int, @planId int, @citId int, @natId int, @college bit, @cost real, @sp int;
	set @category=1;--ОБЫЧНЫЕ
	select top 1 @sp=spec from (
select o.order_date,
case o.order_type_id 
when 21 then convert(int,replace(replace(convert(nvarchar(MAX),osl_data.query('(/CourseUpgradeStudentModel/specialityIdOld)')),'<specialityIdOld>',''),'</specialityIdOld>',''))
when 32 then convert(int,replace(replace(convert(nvarchar(MAX),osl_data.query('(/AcademReturnStudentModel/specialityIdWas)')),'<specialityIdWas>',''),'</specialityIdWas>',''))
when 42 then convert(int,replace(replace(convert(nvarchar(MAX),osl_data.query('(/AbroadReturnStudentModel/specialityIdWas)')),'<specialityIdWas>',''),'</specialityIdWas>',''))
else 0 end as spec from univer_order_student_link osl, univer_order o where o.order_id=osl.order_id and order_type_id in (21,32,42) and o.status in (21,22) and osl.student_id =@studentId and not exists (select * from univer_order o1, univer_order_student_link osl1 where osl1.order_id=o1.order_id and o1.status in (21,22) and osl1.student_id =osl.student_id and o1.order_date>o.order_date and o1.order_type_id in (20,10,200))
) t where t.spec>0  order by order_date;

set @sp=(select sp.speciality_id from univer_speciality sp, univer_faculty f, univer_students st where sp.faculty_id=f.faculty_id and st.faculty_id=f.faculty_id and st.students_id=@studentId and sp.status=1 and sp.speciality_id=@sp)

	select @yearAdm=max(o.order_year) from univer_order o, univer_order_student_link osl where osl.order_id=o.order_id and osl.student_id=@studentId and o.status in (21,22) and o.order_type_id in (1,8,10/*,20*/) and o.order_id not in (22249);
	select @yearAdm=isnull(@yearAdm,st.educ_plan_adm_year), @planId=p.educ_plan_id,@college=st.student_after_college, @citId=st.citizenship_id,@natId=st.nationality_id  from univer_students st, univer_educ_plan p where p.edu_level_id=st.edu_levels_id and p.educ_plan_adm_year=isnull(@yearAdm,st.educ_plan_adm_year) and p.education_form_id=st.education_form_id and p.speciality_id=isnull(@sp,st.speciality_id) and p.status=1 and st.students_id=@studentId;
     --if (@college=1) set @category=3;--После колледжа
     if (@citId<>(select top 1 country_id from univer_country where country_current=1 and status=1) and @natId<>(select top 1 nationality_id from univer_nationality where nationality_current=1 and status=1)) set @category=2;--Иностранцы
     select @cost=s.sum_cost from univer_educ_plan_sum s where category=@category and educ_plan_id=@planId
	-- Return the result of the function
	RETURN isnull(@cost,0);

END
go

