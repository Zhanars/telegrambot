-- =============================================
-- Author:		sasha
-- Create date: 05.06.2015
-- Description:	Для автоматического обновления статуса заявок по доп. семестру
-- =============================================
CREATE TRIGGER [dbo].[FailOrderUpdStatus]
   ON  [dbo].[_1c_univer_student_contract_debt]
   AFTER INSERT,DELETE,UPDATE
AS 
BEGIN
	
	SET NOCOUNT ON;
    begin transaction
    insert into univer_fail_order_history(fail_order_id,date_change,status,user_id,comments)
    select fo.fail_order_id, GETDATE(),7,0,N'Изменен статус на оплаченный через синхронизацию с 1С' from univer_fail_order fo where exists(select * from _1c_univer_student_contract_debt d, _1c_univer_student_contract c,
_1c_univer_student s where d._1c_student_contract_id=c._1c_student_contract_id and c._1c_student_id=s._1c_student_id and s._1c_univer_student_id=fo.student_id 
and d._1c_student_contract_datenumber like '%'+fo.fail_order_number +'%' and _1c_student_contract_debt>=0) and fo.status=6
    update univer_fail_order set status=7 where fail_order_id in (
    select fo.fail_order_id from univer_fail_order fo where exists(select * from _1c_univer_student_contract_debt d, _1c_univer_student_contract c,
_1c_univer_student s where d._1c_student_contract_id=c._1c_student_contract_id and c._1c_student_id=s._1c_student_id and s._1c_univer_student_id=fo.student_id 
and d._1c_student_contract_datenumber like '%'+fo.fail_order_number +'%' and _1c_student_contract_debt>=0) and fo.status=6
    )
    commit

END
go

