CREATE VIEW dbo.site_personal_interests
AS
SELECT     dbo.univer_personal.personal_id, dbo.univer_interest_types.interest_type_id, dbo.univer_interest_types.interest_type_name_kz, 
                      dbo.univer_interest_types.interest_type_name_ru, dbo.univer_interest_types.interest_type_name_en, dbo.univer_interests.description, 
                      dbo.univer_personal.personal_sname, dbo.univer_personal.personal_name, dbo.univer_personal.personal_father_name, dbo.univer_personal.personal_photo, 
                      dbo.univer_structure_division_1c.structure_division_ext AS faculty_id,
                          (SELECT     structure_division_name_kz
                            FROM          dbo.univer_structure_division_1c AS sd
                            WHERE      (dbo.univer_structure_division_1c.structure_division_ext = structure_division_id)) AS faculty_name_kz,
                          (SELECT     structure_division_name_ru
                            FROM          dbo.univer_structure_division_1c AS sd
                            WHERE      (dbo.univer_structure_division_1c.structure_division_ext = structure_division_id)) AS faculty_name_ru,
                          (SELECT     structure_division_name_en
                            FROM          dbo.univer_structure_division_1c AS sd
                            WHERE      (dbo.univer_structure_division_1c.structure_division_ext = structure_division_id)) AS faculty_name_en, 
                      dbo.univer_structure_division_1c.structure_division_id AS chair_id, dbo.univer_structure_division_1c.structure_division_name_kz AS chair_name_kz, 
                      dbo.univer_structure_division_1c.structure_division_name_ru AS chair_name_ru, dbo.univer_structure_division_1c.structure_division_name_en AS chair_name_en, 
                      dbo.univer_personal_position_1c.personal_position_id, dbo.univer_personal_position_1c.personal_position_name_kz, 
                      dbo.univer_personal_position_1c.personal_position_name_ru, dbo.univer_personal_position_1c.personal_position_name_en, 
                      dbo.univer_personal.personal_site_photo
FROM         dbo.univer_personal INNER JOIN
                      dbo.univer_interests ON dbo.univer_personal.personal_id = dbo.univer_interests.personal_id INNER JOIN
                      dbo.univer_interest_types ON dbo.univer_interests.interest_type_id = dbo.univer_interest_types.interest_type_id INNER JOIN
                      dbo.univer_personal_struct_pos_link_1c ON dbo.univer_personal.personal_id = dbo.univer_personal_struct_pos_link_1c.personal_id INNER JOIN
                      dbo.univer_personal_position_1c ON 
                      dbo.univer_personal_struct_pos_link_1c.personal_position_id = dbo.univer_personal_position_1c.personal_position_id INNER JOIN
                      dbo.univer_structure_division_1c ON dbo.univer_personal_struct_pos_link_1c.structure_division_id = dbo.univer_structure_division_1c.structure_division_id
WHERE     (dbo.univer_personal.status = 1) AND (dbo.univer_personal_struct_pos_link_1c.status = 1) AND (dbo.univer_structure_division_1c.structure_division_ext IN (9, 11, 15, 
                      29, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50, 52, 340, 456))
go

