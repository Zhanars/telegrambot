-- =============================================
-- Author:		<Baton>
-- Create date: <27.04.2009>
-- Description:	<Тригер на присвоения "права" абитуриента при создании записи>
-- =============================================
CREATE TRIGGER [dbo].[studentRoleCreate] ON  dbo.univer_students AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	-- Insert statements for trigger here
	-- Цифра доступа для данной сущности
	DECLARE @userId int
	DECLARE @st int
	
	DECLARE insCursor cursor
		FOR SELECT user_id, status FROM inserted
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @userId, @st
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF(@st=1)
			exec dbo.usersSetAccess @userId, 'STUDENT'
		ELSE IF(@st=10)
			exec dbo.usersSetAccess @userId, 'ABITURIENT'
		ELSE IF(@st=11)
			exec dbo.usersSetAccess @userId, 'ABITURIENT'
			
		FETCH NEXT FROM insCursor INTO @userId, @st;
	END
	CLOSE insCursor
END
go

