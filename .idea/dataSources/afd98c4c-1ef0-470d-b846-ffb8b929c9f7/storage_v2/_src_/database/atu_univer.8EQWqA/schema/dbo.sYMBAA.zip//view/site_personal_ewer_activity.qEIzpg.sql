CREATE VIEW dbo.site_personal_ewer_activity
AS
SELECT     admin_personal_id AS personal_id, chair_id, dl_ewer_activity_name_kz, dl_ewer_activity_name_ru, dl_ewer_activity_name_en, dl_ewer_activity_desc_kz, 
                      dl_ewer_activity_desc_ru, dl_ewer_activity_desc_en, dl_ewer_activity_begin
FROM         dbo.univer_dl_ewer_activity
WHERE     (status = 1)
go

