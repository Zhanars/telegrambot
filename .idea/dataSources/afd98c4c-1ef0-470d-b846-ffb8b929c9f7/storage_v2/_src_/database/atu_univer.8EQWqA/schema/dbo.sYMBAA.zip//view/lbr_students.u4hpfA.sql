CREATE VIEW dbo.lbr_students
AS
SELECT     TOP (100) PERCENT st.students_id AS ID, st.students_sname AS SURNAME, st.students_name AS NAME, st.students_father_name AS PATRONYMIC, 
                      st.student_edu_status_id AS STATUS_ID, es.student_edu_status_name_ru AS STATUS_NAME, st.students_birth_date AS DATE_BIRTH, 
                      st.students_document_identity_type AS DOC_TYPE, st.students_document_identity_number AS DOC_NUMBER, st.students_document_identity_date AS DOC_DATE, 
                      st.students_document_identity_issued AS DOC_ISSUED, n.nationality_id AS NATION_ID, n.nationality_name_ru AS NATION_NAME, 
                      CASE st.students_sex WHEN 1 THEN N'М' ELSE N'Ж' END AS GENDER, st.students_adress AS ADDRESS, st.students_contact_town_phone AS PHONE, 
                      st.students_email AS EMAIL, f.faculty_id AS FACULTY_ID, f.faculty_name_ru AS FACULTY_NAME, sp.speciality_id AS SPEC_ID, sp.speciality_okpd AS SPEC_CODE, 
                      sp.speciality_name_ru AS SPEC_NAME, st.students_curce_number AS COURSE, s.stage_id AS STAGE_ID, s.stage_name_ru AS STAGE_NAME, 
                      el.edu_level_id AS LEVEL_ID, el.edu_level_name_ru AS LEVEL_NAME, ef.education_form_id AS FORM_ID, ef.education_form_name_ru AS FORM_NAME, 
                      ld.lang_division_id AS LANGD_ID, ld.lang_division_name_ru AS LANGD_NAME, 
                      N'http://univer.kaznu.kz/new/photostudent/' + st.student_photo_file_name AS PHOTO
FROM         dbo.univer_students AS st LEFT OUTER JOIN
                      dbo.univer_nationality AS n ON st.nationality_id = n.nationality_id INNER JOIN
                      dbo.univer_speciality AS sp ON st.speciality_id = sp.speciality_id INNER JOIN
                      dbo.univer_faculty AS f ON st.faculty_id = f.faculty_id INNER JOIN
                      dbo.univer_stage AS s ON st.stage_id = s.stage_id INNER JOIN
                      dbo.univer_edu_levels AS el ON st.edu_levels_id = el.edu_level_id INNER JOIN
                      dbo.univer_education_form AS ef ON st.education_form_id = ef.education_form_id INNER JOIN
                      dbo.univer_student_edu_statuses AS es ON st.student_edu_status_id = es.student_edu_status_id INNER JOIN
                      dbo.univer_lang_division AS ld ON st.lang_division_id = ld.lang_division_id
WHERE     (st.status IN (1, 2))
ORDER BY SURNAME, NAME, PATRONYMIC
go

