-- =============================================
-- Author:		
-- Create date: 
-- Description:	
-- =============================================
CREATE FUNCTION [dbo].[IP_GetRatingIHBall]
(
 @value real
)
RETURNS float
AS
BEGIN
	DECLARE @ret float

    if (@value <= 0) begin set @ret = 0; end
    else if (@value = 1) begin set @ret = 300; end
    else if (@value >= 2  and @value <= 3) begin set @ret = 500; end
    else if (@value >= 4  and @value <= 5) begin set @ret = 1000; end
    else if (@value >= 6  and @value <= 8) begin set @ret = 1500; end
    else if (@value >= 9  and @value <= 10) begin set @ret = 2000; end
    else if (@value > 10  and @value <= 15) begin set @ret = 3000; end
    else if (@value > 15  and @value <= 20) begin set @ret = 4000; end
    else if (@value > 20  and @value <= 25) begin set @ret = 5000; end
    else if (@value > 25  and @value <= 30) begin set @ret = 6000; end
    else if (@value > 30  and @value <= 40) begin set @ret = 7000; end
    else if (@value > 40  and @value <= 50) begin set @ret = 8000; end
    else if (@value > 50  and @value <= 60) begin set @ret = 9000; end
    else if (@value > 60  and @value <= 70) begin set @ret = 10000; end
    else if (@value > 70  and @value <= 80) begin set @ret = 11000; end
    else if (@value > 80  and @value <= 90) begin set @ret = 12000; end
    else if (@value > 90  and @value <= 100) begin set @ret = 13000; end
    else if (@value > 100  and @value <= 150) begin set @ret = 14000; end
    else if (@value > 150  and @value <= 200) begin set @ret = 16000; end
    else if (@value > 200  and @value <= 250) begin set @ret = 18000; end
    else if (@value > 250) begin set @ret = 20000; end

	RETURN isnull(@ret,0)

END
go

