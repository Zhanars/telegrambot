
CREATE VIEW [dbo].[_server_stat_parametrs]
AS
SELECT DISTINCT TOP (100) PERCENT record_parametr_name
FROM         dbo._server_stat_record
group by record_parametr_name
having count(*)>5
ORDER BY record_parametr_name

go

