-- =============================================
-- Author:		Yerlan
-- Create date: 26.12.2016
-- Description: Получить количество учебных пособий 
-- (@indicatorConst=1 - Количество учебников с грифом МОН РК
-- @indicatorConst=2 - Количество учебников и учебных пособий рекомендованных УМО РУМС (Издательство "Қазақ Университеті")
-- @indicatorConst=3 - Количество учебников и учебных пособий рекомендованных РИСО (Издательство «Қазақ Университеті»)
-- @indicatorConst=4 - Количество научных монографий/глав в коллективной монографии на английском языке индексируемых в Scopus
-- @indicatorConst=5 - Количество научных монографий изданных в Казахстане и странах ближнего зарубежья
-- =============================================
CREATE FUNCTION [dbo].[IP_NIR_NEW_getSciTreatises_Count_By]
(
	@categoryId int,
	@personalId int=0,
	@chairId int=0,
	@facultyId int=0,
	@year int=0,
	@indicatorCode varchar(10)
)
RETURNS real
AS
BEGIN
DECLARE @Result real

-- ==================================== Учебники с грифом МОН РК
IF (@indicatorCode = '1.1')
BEGIN
SELECT @Result = COUNT(*)
		FROM 
			DBScience.dbo.Treatises t,
			DBScience.dbo.L_Person_Treatise_Authors a
			,DBScience.dbo.Publishers p
			,DBScience.dbo.Countries c
		WHERE
		-- не архивированная
		t.status != 2 AND
		-- издательство 
		p.publisher_id = t.publisher_id AND
		c.country_id = p.country_id AND
		EXISTS(select * from DBScience.dbo.IndPlanIndicator ind WHERE ind.code=@indicatorCode AND ind.ipIndicator_id=t.ipIndicator_id) AND
		-- книга этого года или следующего
		t.yearPublication in (@year, @year+1) AND
		-- не дублированная и подтвержденная
		t.is_overlap IS NULL AND
		t.is_approve=1 AND
		-- книга этого автора (ППС, потому personType = 1)
		t.treatise_id = a.treatise_id AND
		a.personType = 1 AND 
		(
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		)
END
-- ==================================== рекомендованных УМО РУМС 
IF (@indicatorCode = '1.2')
BEGIN
SELECT @Result = COUNT(*)
		FROM 
			DBScience.dbo.Treatises t,
			DBScience.dbo.L_Person_Treatise_Authors a
			,DBScience.dbo.Publishers p
			,DBScience.dbo.Countries c
		WHERE
		-- не архивированная
		t.status != 2 AND
		p.publisher_id = t.publisher_id AND
		c.country_id = p.country_id AND
		EXISTS(select * from DBScience.dbo.IndPlanIndicator ind WHERE ind.code=@indicatorCode AND ind.ipIndicator_id=t.ipIndicator_id) AND
		-- книга этого года или следующего
		t.yearPublication in (@year, @year+1) AND
		-- не дублированная и подтвержденная
		t.is_overlap IS NULL AND
		t.is_approve=1 AND
		-- книга этого автора (ППС, потому personType = 1)
		t.treatise_id = a.treatise_id AND
		a.personType = 1 AND 
		(
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		)
END
-- ==================================== рекомендованных РИСО 
IF (@indicatorCode = '1.3')
BEGIN
SELECT @Result = COUNT(*)
		FROM 
			DBScience.dbo.Treatises t,
			DBScience.dbo.L_Person_Treatise_Authors a
			,DBScience.dbo.Publishers p
			,DBScience.dbo.Countries c
		WHERE
		-- не архивированная
		t.status != 2 AND
		p.publisher_id = t.publisher_id AND
		c.country_id = p.country_id AND
		EXISTS(select * from DBScience.dbo.IndPlanIndicator ind WHERE ind.code=@indicatorCode AND ind.ipIndicator_id=t.ipIndicator_id) AND
		-- книга этого года или следующего
		t.yearPublication in (@year, @year+1) AND
		-- не дублированная и подтвержденная
		t.is_overlap IS NULL AND
		t.is_approve=1 AND
		-- книга этого автора (ППС, потому personType = 1)
		t.treatise_id = a.treatise_id AND
		a.personType = 1 AND 
		(
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		)
END
-- ==================================== Количество научных монографий/глав в коллективной монографии на английском языке индексируемых в Scopus
IF (@indicatorCode = '2.6')
BEGIN
SELECT @Result = COUNT(*)
		FROM 
			DBScience.dbo.Treatises t,
			DBScience.dbo.L_Person_Treatise_Authors a
			,DBScience.dbo.Publishers p
			,DBScience.dbo.Countries c
		WHERE
		-- не архивированная
		t.status != 2 AND
		p.publisher_id = t.publisher_id AND
		c.country_id = p.country_id AND
		EXISTS(select * from DBScience.dbo.IndPlanIndicator ind WHERE ind.code=@indicatorCode AND ind.ipIndicator_id=t.ipIndicator_id) AND
		-- книга этого года или следующего
		t.yearPublication in (@year, @year+1) AND
		-- не дублированная и подтвержденная
		t.is_overlap IS NULL AND
		t.is_approve=1 AND
		-- книга этого автора (ППС, потому personType = 1)
		t.treatise_id = a.treatise_id AND
		a.personType = 1 AND 
		(
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		)
END

-- ==================================== Количество научных монографий изданных в Казахстане и странах ближнего зарубежья
IF (@indicatorCode = '2.7')
BEGIN
SELECT @Result = COUNT(*)
		FROM 
			DBScience.dbo.Treatises t,
			DBScience.dbo.L_Person_Treatise_Authors a
			,DBScience.dbo.Publishers p
			,DBScience.dbo.Countries c
		WHERE
		-- не архивированная
		t.status != 2 AND
		p.publisher_id = t.publisher_id AND
		c.country_id = p.country_id AND
		EXISTS(select * from DBScience.dbo.IndPlanIndicator ind WHERE ind.code=@indicatorCode AND ind.ipIndicator_id=t.ipIndicator_id) AND
		-- книга этого года или следующего
		t.yearPublication in (@year, @year+1) AND
		-- не дублированная и подтвержденная
		t.is_overlap IS NULL AND
		t.is_approve=1 AND
		-- книга этого автора (ППС, потому personType = 1)
		t.treatise_id = a.treatise_id AND
		a.personType = 1 AND 
		(
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		)
END

-- Return the result of the function
RETURN ISNULL(@Result, 0)

END
go

