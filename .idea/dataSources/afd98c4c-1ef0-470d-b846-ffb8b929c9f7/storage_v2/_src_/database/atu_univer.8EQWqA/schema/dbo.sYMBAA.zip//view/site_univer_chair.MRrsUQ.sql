CREATE VIEW dbo.site_univer_chair
AS
SELECT     chair_id, faculty_id, chair_name_kz, chair_name_ru, chair_name_en, structure_division_id, status
FROM         dbo.univer_chair
WHERE     (status = 1)
go

