-- =============================================
-- Author:		sasha
-- Create date: 23.01.2017
-- Description: автообновление ролей
-- =============================================
CREATE TRIGGER [dbo].[univerRoleUpd]
   ON [dbo].[univer_personal_struct_pos_link_1c]
   AFTER UPDATE,INSERT
AS 
BEGIN	
    IF @@ROWCOUNT =0
    RETURN	
	SET NOCOUNT ON;
	
	DECLARE @p int	
	DECLARE pCur cursor 
		FOR SELECT personal_id FROM inserted WHERE status=1
		
	OPEN pCur
	FETCH NEXT FROM pCur INTO @p
	WHILE @@FETCH_STATUS = 0
	BEGIN
	    exec dbo.updAccessByStructPos @p
		FETCH NEXT FROM pCur INTO @p;
	END
	CLOSE pCur
END
go

