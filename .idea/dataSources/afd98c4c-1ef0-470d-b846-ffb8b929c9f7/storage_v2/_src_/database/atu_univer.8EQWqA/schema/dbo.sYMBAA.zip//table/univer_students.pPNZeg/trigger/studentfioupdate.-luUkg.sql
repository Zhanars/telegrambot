-- =============================================
-- Author:		Sasha
-- Create date: 23/06/2011
-- Description:	При изменении ФИО менять и в падежах
-- =============================================
CREATE TRIGGER [dbo].[studentFIOUpdate]
   ON   dbo.univer_students
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @id int
	DECLARE @val nvarchar(50)
	IF UPDATE(students_name) 
	BEGIN
		DECLARE insCursor cursor 
			FOR SELECT students_id, students_name FROM inserted		
		OPEN insCursor
		FETCH NEXT FROM insCursor INTO @id,@val
		WHILE @@FETCH_STATUS = 0
		BEGIN
		if @val<>(select students_name from deleted where students_id=@id)
			 update univer_students set students_accusative_name_en=@val,
					students_accusative_name_kz=@val, 
					students_accusative_name_ru=@val,
					students_dative_name_en=@val, 
					students_genitive_name_en=@val, 
					students_dative_name_kz=@val,  
					students_genitive_name_kz=@val,
					students_dative_name_ru=@val, 
					students_genitive_name_ru=@val, 
					students_name_intern=@val  where students_id=@id 
			FETCH NEXT FROM insCursor INTO @id,@val
		END
		CLOSE insCursor
		DEALLOCATE insCursor
	END
	IF UPDATE(students_sname)
	BEGIN
		DECLARE insCursor cursor 
			FOR SELECT students_id, students_sname FROM inserted		
		OPEN insCursor
		FETCH NEXT FROM insCursor INTO @id,@val
		WHILE @@FETCH_STATUS = 0
		BEGIN			
		if @val<>(select students_sname from deleted where students_id=@id)
			update univer_students set students_accusative_sname_en=@val, 
					students_accusative_sname_kz=@val, 
					students_accusative_sname_ru=@val,
					students_dative_sname_en=@val,  
					students_genitive_sname_en=@val, 
					students_dative_sname_kz=@val, 
					students_genitive_sname_kz=@val,
					students_dative_sname_ru=@val, 
					students_genitive_sname_ru=@val, 
					students_sname_intern=@val   where students_id=@id 
			FETCH NEXT FROM insCursor INTO @id,@val
		END
		CLOSE insCursor
		DEALLOCATE insCursor
	END
	IF UPDATE(students_father_name)
	BEGIN
		DECLARE insCursor cursor 
			FOR SELECT students_id, students_father_name FROM inserted		
		OPEN insCursor
		FETCH NEXT FROM insCursor INTO @id,@val
		WHILE @@FETCH_STATUS = 0
		BEGIN			
		if @val<>(select students_father_name from deleted where students_id=@id)		
			update univer_students set students_accusative_father_name_en=@val, 
					students_accusative_father_name_kz=@val,
					students_accusative_father_name_ru=@val, 
					students_dative_father_name_en=@val,  
					students_genitive_father_name_en=@val,
					students_dative_father_name_kz=@val, 
					students_genitive_father_name_kz=@val, 
					students_dative_father_name_ru=@val, 
					students_genitive_father_name_ru=@val  where students_id=@id 
			FETCH NEXT FROM insCursor INTO @id,@val
		END
		CLOSE insCursor
		DEALLOCATE insCursor
	END

END
go

