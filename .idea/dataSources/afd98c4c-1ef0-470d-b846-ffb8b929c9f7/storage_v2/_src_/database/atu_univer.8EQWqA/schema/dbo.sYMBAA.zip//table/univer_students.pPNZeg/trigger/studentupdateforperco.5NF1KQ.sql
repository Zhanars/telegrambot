-- =============================================
-- Author:		Yerlan
-- Create date: 05.12.2016
-- Description:	for perco
-- =============================================
CREATE TRIGGER [dbo].[studentUpdateForPerco]
   ON  dbo.univer_students
   AFTER update
AS 
BEGIN

	IF @@ROWCOUNT =0
    RETURN
    
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	--Update block.
	DELETE FROM perco_univer_student WHERE student_id in (select DISTINCT i.students_id FROM inserted i INNER JOIN deleted d ON i.students_id=d.students_id AND i.status=1 AND d.status=1 AND i.faculty_id<>d.faculty_id);
	
	insert into perco_univer_student(student_id, operation)
	select DISTINCT i.students_id, 2/*UPDATE*/
	FROM inserted i INNER JOIN deleted d ON i.students_id=d.students_id AND i.status=1 AND d.status=1 AND i.faculty_id<>d.faculty_id
	
	DELETE FROM perco_univer_student WHERE student_id IN (select DISTINCT i.students_id from inserted i INNER JOIN deleted d ON i.students_id=d.students_id AND i.status=1 AND d.status<>1);
	insert into perco_univer_student(student_id, operation)
	select DISTINCT i.students_id, 4/*RESTORE*/ 
	from inserted i INNER JOIN deleted d ON i.students_id=d.students_id AND i.status=1 AND d.status<>1
	
	DELETE FROM perco_univer_student WHERE student_id IN (select DISTINCT i.students_id from inserted i INNER JOIN deleted d ON i.students_id=d.students_id AND i.status<>1 AND d.status=1);
	insert into perco_univer_student(student_id, operation)
	select DISTINCT i.students_id, 3/*DISMISS*/ 
	from inserted i INNER JOIN deleted d ON i.students_id=d.students_id AND i.status<>1 AND d.status=1
    
END
go

