-- =============================================
-- Author:		@LFER
-- Create date: 2009-06-17 13:41:35.477
-- Description:	Действия, которые необходимо выполнить при добавлении сотрудника
-- =============================================
CREATE TRIGGER [dbo].[personalInsertTrigger] ON  [dbo].[univer_personal] AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	-- Insert statements for trigger here
	-- Цифра доступа для данной сущности
	DECLARE @ui int
	
	DECLARE insCursor cursor 
		FOR SELECT user_id FROM inserted WHERE status=1
		
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @ui
	WHILE @@FETCH_STATUS = 0
	BEGIN
		exec dbo.usersSetAccess @ui, 'PERSONAL'
		FETCH NEXT FROM insCursor INTO @ui;
	END
	CLOSE insCursor
END
go

