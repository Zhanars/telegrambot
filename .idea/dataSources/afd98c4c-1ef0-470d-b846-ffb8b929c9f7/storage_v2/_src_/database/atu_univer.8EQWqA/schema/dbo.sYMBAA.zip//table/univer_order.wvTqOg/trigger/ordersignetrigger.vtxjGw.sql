-- =============================================
-- Author:		@LFER
-- Create date: 2009-07-08 10:36:15.940
-- Description:	Установка даты подписания приказа в случае, если его подписали все, кто должен был
-- =============================================
CREATE TRIGGER [dbo].[orderSigneTrigger]
   ON  [dbo].[univer_order]
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
    DECLARE @oi int;
    DECLARE @os bigint;
    DECLARE @ons bigint;
    DECLARE @approved bit;
	IF ( ( SELECT TRIGGER_NESTLEVEL ( ( SELECT object_id FROM sys.triggers WHERE name = 'orderSigneTrigger' ), 'AFTER' , 'DML' ) ) <= 1 )
	BEGIN --В тек. базе установлено рекурсивный запуск триггеров, поэтому эта проверка останавливает после первого запуска рек. запуск этого триггера
		BEGIN TRANSACTION
			DECLARE signeCursor1 cursor 
				FOR SELECT order_id, order_signed, order_type_need_signed, order_approved FROM inserted i, univer_order_type ot WHERE i.order_type_id=ot.order_type_id
			
				IF UPDATE(order_signed)
				BEGIN
					OPEN signeCursor1
					FETCH NEXT FROM signeCursor1 INTO @oi, @os, @ons, @approved
					WHILE @@FETCH_STATUS = 0
					BEGIN
						IF @os=@ons
						BEGIN
							UPDATE univer_order SET order_date_approve=getdate(), order_approved=1 WHERE order_id=@oi
						END
						ELSE IF @approved=1
						BEGIN
							UPDATE univer_order SET order_date_approve=NULL, order_approved=0 WHERE order_id=@oi
						END
						FETCH NEXT FROM signeCursor1 INTO @oi, @os, @ons, @approved
					END
					CLOSE signeCursor1
					DEALLOCATE signeCursor1
				END
		COMMIT
	END
END
go

