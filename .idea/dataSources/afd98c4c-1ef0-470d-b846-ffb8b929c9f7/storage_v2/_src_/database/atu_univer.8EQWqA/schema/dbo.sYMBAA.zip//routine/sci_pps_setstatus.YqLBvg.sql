-- =============================================
-- Author:		Twice
-- Create date: 30.05.2012
-- Description:	Изменить статус пользователя, если у него роль ППС
-- =============================================
CREATE PROCEDURE [dbo].[SCI_PPS_SetStatus] 
	@personal_id int = 0,
	@status int
AS
BEGIN
	SET NOCOUNT ON;

	--DECLARE @user_id INT
	--SELECT @user_id = p.user_id FROM univer_personal p WHERE p.personal_id = @personal_id
	
	---- если есть такой пользователь в таблице пользователей Науки
	--IF ((SELECT COUNT(*) FROM DBScience.dbo.univer_userAccounts ua WHERE ua.univer_user_id = @user_id) > 0)
	--BEGIN
	--	-- ставим статус 2 только если роль у пользователя стоит ППС(id=8)
	--	UPDATE DBScience.dbo.univer_userAccounts
	--	SET status = @status
	--	WHERE univer_user_id = @user_id AND role_id = 8 
	--END
END
go

