
-- =============================================
-- Author:		Yerlan
-- Create date: 26.12.2016
-- Description: Получить описания публикаций (имеется ввиду статьи) 
--@indicatorCode=1.4 - Учебно-методические статьи
--@indicatorCode=2.5- Количество научных статей (ППС, студентов, магистрантов и докторантов), опубликованных в журналах, индексируемых в Scopus
--@indicatorCode=2.8- Количество статей, опубликованных в материалах международных научных конференций (Proceedings), индексируемых в международной базе данных Scopus
--@indicatorCode=2.9-Количество статей на английском языке, опубликованных в научных периодических изданиях дальнего зарубежья, неиндексируемых в базе данных Scopus
--@indicatorCode=2.10- Количество статей, опубликованных в научных изданиях, рекомендованных ККСОН
--@indicatorCode=2.11- Количество статей, опубликованных в англоязычных научных журналах КазНУ совместно с авторами из дальнего зарубежья с высокой цитируемостью публикаций
--@indicatorCode=2.12- Количество статей, опубликованных на английском языке в неанглоязычных журналах КазНУ
-- =============================================
CREATE FUNCTION [dbo].[IP_NIR_NEW_getSciPapers_Count_By_DESC]
(
	@categoryId int,
	@personalId int,
	@chairId int,
	@facultyId int,
	@year int,
	@indicatorCode varchar(10)
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @Result NVARCHAR(MAX)
DECLARE @PaperStr NVARCHAR(MAX)
DECLARE @ThesisStr NVARCHAR(MAX)
-- ==================================== если учебно-методические статьи
IF (@indicatorCode='1.4')
BEGIN
	SELECT @Result = COALESCE(@Result + ';\n\n', '') + 
			CASE WHEN @categoryId=3 THEN
				ISNULL(N'Статья\nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en +
				N'\nИздание:' + op.name, '')
			ELSE ISNULL(
				CONVERT(NVARCHAR(MAX), ROW_NUMBER() OVER (ORDER BY dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.paper_id, 2))) +N') '
				+ N'Автор(ы): ' + dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.paper_id, 2) 
				+ N'Научная статья:\nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en
				+ N'\nИздание:' + op.name, '')
			END
		FROM 
			DBScience.dbo.Papers p,
			DBScience.dbo.L_Person_Paper_Authors a,
			DBScience.dbo.OtherPeriodicEditions op
		WHERE
		-- статья не архивирована
		p.status != 2 AND
		op.otherPeriodicEdition_id = p.periodicEdition_id AND
		EXISTS(select * from DBScience.dbo.IndPlanIndicator ind WHERE ind.code=@indicatorCode AND ind.ipIndicator_id=p.ipIndicator_id) AND
		-- статья этого года
		p.yearPublication in (@year, @year + 1) AND
		-- не дублированная и подтвержденная
		p.is_overlap IS NULL AND
		p.is_approve=1 AND
		-- статья этого автора (ППС, потому personType = 1)
		p.paper_id = a.paper_id AND
		a.personType = 1 AND 
		(
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		)
END

-- ==================================== Количество научных статей (ППС, студентов, магистрантов и докторантов), опубликованных в журналах, индексируемых в Scopus
IF (@indicatorCode='2.5')
BEGIN
	SELECT @PaperStr = COALESCE(@PaperStr + '\n\n', '') + 
			CASE WHEN @categoryId=3 THEN
					ISNULL(N'Статья\nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en +
					N'\nИздание:' + sj.name + N'\nСтрана журнала:' + c.name_ru, '')
			ELSE 
				ISNULL(
				CONVERT(NVARCHAR(MAX), ROW_NUMBER() OVER (ORDER BY dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.paper_id, 2))) +N') '
				+ N'Научная статья\n' +
				+ N'Автор(ы): ' + dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.paper_id, 2) 
				+ N'\nНазвание: \nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en 
				+ N'\nЖурнал:' + sj.name + N'\nСтрана журнала:' + c.name_ru, '')
			END
		FROM 
			DBScience.dbo.Papers p,
			DBScience.dbo.L_Person_Paper_Authors a,
			DBScience.dbo.SciJournals sj, 
			DBScience.dbo.Countries c
		WHERE
		-- статья не архивирована
		p.status != 2 AND
		sj.sciJournal_id = p.periodicEdition_id AND
		sj.journalCountry_id = c.country_id AND
		EXISTS(select * from DBScience.dbo.IndPlanIndicator ind WHERE ind.code=@indicatorCode AND ind.ipIndicator_id=p.ipIndicator_id) AND
		-- статья этого года
		p.yearPublication in (@year, @year + 1) AND	
		-- не дублированная и подтвержденная
		p.is_overlap IS NULL AND
		p.is_approve=1 AND
		-- статья этого автора (ППС, потому personType = 1)
		p.paper_id = a.paper_id AND
		a.personType = 1  AND (
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		) 		
SELECT @Result = N'------------- Научные статьи -----------\n' + ISNULL(@PaperStr,'') ;
END
-- ==================================== Количество статей, опубликованных в материалах международных научных конференций (Proceedings), индексируемых в международной базе данных Scopus
IF (@indicatorCode='2.8')
BEGIN
		SELECT @Result = COALESCE(@Result + ';\n\n', '') + 
			CASE WHEN @categoryId=3 THEN
				ISNULL(N'Статья\nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en +
				N'\nЖурнал:' + sj.name, '')
			ELSE ISNULL(
				CONVERT(NVARCHAR(MAX), ROW_NUMBER() OVER (ORDER BY dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.paper_id, 2))) +N') '
				+ N'Автор(ы): ' + dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.paper_id, 2) 
				+ N'Научная статья:\nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en
				+ N'\nЖурнал:' + sj.name, '')
			END
		FROM 
			DBScience.dbo.Papers p,
			DBScience.dbo.L_Person_Paper_Authors a,
			DBScience.dbo.SciJournals sj
		WHERE
		-- статья не архивирована
		p.status != 2 AND
		sj.sciJournal_id = p.periodicEdition_id AND
		EXISTS(select * from DBScience.dbo.IndPlanIndicator ind WHERE ind.code=@indicatorCode AND ind.ipIndicator_id=p.ipIndicator_id) AND
		-- статья этого года
		p.yearPublication in (@year, @year+1) AND
		-- не дублированная и подтвержденная
		p.is_overlap IS NULL AND
		p.is_approve=1 AND
		-- статья этого автора (ППС, потому personType = 1)
		p.paper_id = a.paper_id AND
		a.personType = 1 AND  (
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		) 
END

-- ==================================== Количество статей на английском языке, опубликованных в научных периодических изданиях дальнего зарубежья, неиндексируемых в базе данных Scopus
IF (@indicatorCode='2.9')
BEGIN
		SELECT @Result = COALESCE(@Result + ';\n\n', '') + 
			CASE WHEN @categoryId=3 THEN
				ISNULL(N'Статья\nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en +
				N'\nЖурнал:' + sj.name, '')
			ELSE ISNULL(
				CONVERT(NVARCHAR(MAX), ROW_NUMBER() OVER (ORDER BY dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.paper_id, 2))) +N') '
				+ N'Автор(ы): ' + dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.paper_id, 2) 
				+ N'Научная статья:\nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en
				+ N'\nЖурнал:' + sj.name + N'\nСтрана журнала:' + c.name_ru, '')
			END
		FROM 
			DBScience.dbo.Papers p,
			DBScience.dbo.L_Person_Paper_Authors a,
			DBScience.dbo.SciJournals sj,
			DBScience.dbo.Countries c,
			DBScience.dbo.Publishers pb
		WHERE
		-- статья не архивирована
		p.status != 2 AND
		sj.sciJournal_id = p.periodicEdition_id AND
		sj.journalCountry_id = c.country_id AND
		pb.publisher_id = sj.publisher_id AND
		EXISTS(select * from DBScience.dbo.IndPlanIndicator ind WHERE ind.code=@indicatorCode AND ind.ipIndicator_id=p.ipIndicator_id) AND
		-- статья этого года
		p.yearPublication in (@year, @year+1) AND
		-- не дублированная и подтвержденная
		p.is_overlap IS NULL AND
		p.is_approve=1 AND
		-- статья этого автора (ППС, потому personType = 1)
		p.paper_id = a.paper_id AND
		a.personType = 1 AND  (
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		) 
END

-- ==================================== Количество статей, опубликованных в научных изданиях, рекомендованных ККСОН
IF (@indicatorCode='2.10')
BEGIN
		SELECT @Result = COALESCE(@Result + ';\n\n', '') + 
			CASE WHEN @categoryId=3 THEN
				ISNULL(N'Статья\nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en +
				N'\nЖурнал:' + sj.name, '')
			ELSE ISNULL(
				CONVERT(NVARCHAR(MAX), ROW_NUMBER() OVER (ORDER BY dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.paper_id, 2))) +N') '
				+ N'Автор(ы): ' + dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.paper_id, 2) 
				+ N'Научная статья:\nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en
				+ N'\nЖурнал:' + sj.name, '')
			END
		FROM 
			DBScience.dbo.Papers p,
			DBScience.dbo.L_Person_Paper_Authors a,
			DBScience.dbo.SciJournals sj,
			DBScience.dbo.Countries c,
			DBScience.dbo.Publishers pb
		WHERE
		-- статья не архивирована
		p.status != 2 AND
		sj.sciJournal_id = p.periodicEdition_id AND
		sj.journalCountry_id = c.country_id AND
		pb.publisher_id = sj.publisher_id AND
		EXISTS(select * from DBScience.dbo.IndPlanIndicator ind WHERE ind.code=@indicatorCode AND ind.ipIndicator_id=p.ipIndicator_id) AND
		-- статья этого года
		p.yearPublication in (@year, @year+1) AND
		-- не дублированная и подтвержденная
		p.is_overlap IS NULL AND
		p.is_approve=1 AND
		-- статья этого автора (ППС, потому personType = 1)
		p.paper_id = a.paper_id AND
		a.personType = 1 AND  (
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		) 
END

-- ==================================== Количество статей, опубликованных в англоязычных научных журналах КазНУ совместно с авторами из дальнего зарубежья с высокой цитируемостью публикаций
IF (@indicatorCode='2.11')
BEGIN
		SELECT @Result = COALESCE(@Result + ';\n\n', '') + 
			CASE WHEN @categoryId=3 THEN
				ISNULL(N'Статья\nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en +
				N'\nЖурнал:' + sj.name+ N'\nСтрана журнала:' + c.name_ru, '')
			ELSE ISNULL(
				CONVERT(NVARCHAR(MAX), ROW_NUMBER() OVER (ORDER BY dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.paper_id, 2))) +N') '
				+ N'Автор(ы): ' + dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.paper_id, 2) 
				+ N'Научная статья:\nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en
				+ N'\nЖурнал:' + sj.name + N'\nСтрана журнала:' + c.name_ru, '')
			END
		FROM 
			DBScience.dbo.Papers p,
			DBScience.dbo.L_Person_Paper_Authors a,
			DBScience.dbo.SciJournals sj,
			DBScience.dbo.Countries c
		WHERE
		-- статья не архивирована
		p.status != 2 AND
		sj.sciJournal_id = p.periodicEdition_id AND
		sj.journalCountry_id = c.country_id AND
		EXISTS(select * from DBScience.dbo.IndPlanIndicator ind WHERE ind.code=@indicatorCode AND ind.ipIndicator_id=p.ipIndicator_id) AND
		-- статья этого года
		p.yearPublication in (@year, @year+1) AND
		-- не дублированная и подтвержденная
		p.is_overlap IS NULL AND
		p.is_approve=1 AND
		-- статья этого автора (ППС, потому personType = 1)
		p.paper_id = a.paper_id AND
		a.personType = 1 AND  (
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		) 
END

-- ==================================== Количество статей, опубликованных на английском языке в неанглоязычных журналах КазНУ
IF (@indicatorCode='2.12')
BEGIN
		SELECT @Result = COALESCE(@Result + ';\n\n', '') + 
			CASE WHEN @categoryId=3 THEN
				ISNULL(N'Статья\nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en +
				N'\nЖурнал:' + sj.name+ N'\nСтрана журнала:' + c.name_ru, '')
			ELSE ISNULL(
				CONVERT(NVARCHAR(MAX), ROW_NUMBER() OVER (ORDER BY dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.paper_id, 2))) +N') '
				+ N'Автор(ы): ' + dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.paper_id, 2) 
				+ N'Научная статья:\nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en
				+ N'\nЖурнал:' + sj.name + N'\nСтрана журнала:' + c.name_ru, '')
			END
		FROM 
			DBScience.dbo.Papers p,
			DBScience.dbo.L_Person_Paper_Authors a,
			DBScience.dbo.SciJournals sj,
			DBScience.dbo.Countries c
		WHERE
		-- статья не архивирована
		p.status != 2 AND
		sj.sciJournal_id = p.periodicEdition_id AND
		sj.journalCountry_id = c.country_id AND
		EXISTS(select * from DBScience.dbo.IndPlanIndicator ind WHERE ind.code=@indicatorCode AND ind.ipIndicator_id=p.ipIndicator_id) AND
		-- статья этого года
		p.yearPublication in (@year, @year+1) AND
		-- не дублированная и подтвержденная
		p.is_overlap IS NULL AND
		p.is_approve=1 AND
		-- статья этого автора (ППС, потому personType = 1)
		p.paper_id = a.paper_id AND
		a.personType = 1 AND  (
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		) 
END
RETURN ISNULL(@Result, '')

END

go

