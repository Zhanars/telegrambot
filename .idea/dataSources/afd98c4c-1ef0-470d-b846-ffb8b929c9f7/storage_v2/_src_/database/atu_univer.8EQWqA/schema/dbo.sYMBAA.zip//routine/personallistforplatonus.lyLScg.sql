-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[personalListForPlatonus]
	-- Add the parameters for the stored procedure here
	@operation int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

select 
per.personal_id as tutorid 
, per.personal_name as firstname
, per.personal_sname as lastname
, per.personal_father_name as patronymic
, case
	when YEAR(per.personal_birthday_date) > 3900 then DATEADD(YEAR, -2000, per.personal_birthday_date) 
	else per.personal_birthday_date
	end as birthdate
, case
	when YEAR(isnull(per.personal_employment_date,GETDATE())) > 3900 then DATEADD(YEAR, -2000, isnull(per.personal_employment_date,GETDATE())) 
	else per.personal_employment_date
	end as startdate
, case
	when YEAR(isnull(per.personal_finish_date,GETDATE())) > 3900 then DATEADD(YEAR, -2000, isnull(per.personal_finish_date,GETDATE())) 
	else per.personal_finish_date
	end as finishdate
, ISNULL(per.personal_mobile_phone, per.personal_home_phone) as phone
, per.personal_adress as adress
, per.personal_sex + 1 as sexid
, per.nationality_id as nationid
, per.personal_photo as photo
, per.personal_rnn as rnn
, substring((Select ', ' + r.scientific_rank_name_ru
        From  univer_personal_scientific_rank_1c rl
        , univer_scientific_rank_1c r
        Where rl.personal_id=per.personal_id
        and rl.scientific_rank_id=r.scientific_rank_id
        ORDER BY r.scientific_rank_id
        For XML PATH ('')),2, 1000) rang
,  isnull(
	(select top 1 temp.platonus_value from(
		select l.platonus_value, sd.personal_scientific_degree_date as given_date
		from univer_personal_scientific_degree_1c sd, atu_platonus_univer.dbo.scientificdegree_academicdegree_link l
		where per.personal_id=sd.personal_id and l.univer_value=sd.scientific_degree_id and l.plat_table_name='scientificdegree' and l.uni_table_name='univer_scientific_degree_1c'
		union all 
		select l.platonus_value, ad.personal_academic_degree_date as given_date
		from univer_personal_academic_degree_1c ad, atu_platonus_univer.dbo.scientificdegree_academicdegree_link l
		where per.personal_id=ad.personal_id and l.univer_value=ad.academic_degree_id  and l.plat_table_name='scientificdegree' and l.uni_table_name='univer_academic_degree_1c'
		) as temp
	order by temp.given_date desc

	), 1) scientificdegreeid
, isnull(
	(	select top 1 temp.platonus_value from(
		select l.platonus_value, sd.personal_scientific_rank_date as given_date
		from univer_personal_scientific_rank_1c sd, atu_platonus_univer.dbo.scientificdegree_academicdegree_link l
		where per.personal_id=sd.personal_id and l.univer_value=sd.scientific_rank_id and l.plat_table_name='academicstatus' and l.uni_table_name='univer_scientific_rank_1c' 
		) as temp
	order by temp.given_date desc 
	), 1) as academicstatusid
, (select top 1 l.personal_rate from univer_personal_struct_pos_link_1c l	
	where l.personal_id=per.personal_id and l.status=1
	order by l.personal_rate desc, l.personal_change_date desc) as rate
, null as roleid
, isnull( isnull((select top 1 ch.chair_id from univer_personal_struct_pos_link_1c l, univer_chair ch 
	where l.personal_id=per.personal_id and l.status=1 and ch.structure_division_id=l.structure_division_id and ch.status=1 
	order by l.personal_rate desc, l.personal_change_date desc), (
select top 1 tcl.chair_id from univer_teacher t, univer_teacher_chair_link tcl , univer_chair ch
	where t.personal_id=per.personal_id and t.teacher_id=tcl.teacher_id and t.status=1 and ch.status=1 and ch.chair_id=tcl.chair_id)),0) as cafedraid
--, (select top 1 chl.chair_id from univer_teacher t, univer_teacher_chair_link chl
--	where t.personal_id=per.personal_id
--	and chl.teacher_id=t.teacher_id 
--	and t.status=1
--	order by chl.stavka desc) as cafedraid
, case 
	when ((select COUNT(*) from univer_personal_struct_pos_link_1c l where l.personal_id=per.personal_id and l.status=1)>0) then 0
	else 1 end as deleted
, per.personal_document_number as icnumber
, case 
	when YEAR(ISNULL(per.personal_document_issue_date,getdate())) > 3900 then DATEADD(YEAR, -2000, ISNULL(per.personal_document_issue_date,getdate()))
	else per.personal_document_issue_date
	end as icdate
, per.personal_document_issued as icdepartment
, case 
	when per.family_status_id=1 or per.family_status_id=7 then 1
	when per.family_status_id>1 then 2
	else 0 
	end as ismarried
, YEAR(GETDATE()) - YEAR(per.personal_work_experience) as length_workall
, YEAR(GETDATE()) - YEAR(per.personal_employment_date) as length_work
, (select top 1 pos.personal_position_name_ru from univer_personal_struct_pos_link_1c l 
	, univer_personal_position_1c pos where per.personal_id=l.personal_id
	and pos.personal_position_id=l.personal_position_id and l.status=1
	order by l.personal_rate desc, l.personal_change_date desc) as job_title
, per.ftutor as ftutor
, per.funiversity as funiversity
, per.ftitle as ftitle
, per.fdates as fdates
, per.personal_identification_number as iinplt
, per.fcountryid as fcountryid
, per.funiversityid as funiversityid
, per.fuplaceworldrankings as fuplaceworldrankings
, per.fnumberhoursrk as fnumberhoursrk
, per.fnumberhoursects as fnumberhoursects
, per.fsourceoffinance as fsourceoffinance
, per.fofallcosts as fofallcosts
, 0 as maternity_leave
, 0 as on_foreign_trip
from univer_personal per, platonus_univer_personals pper
where 
per.personal_id=pper.personal_id
and pper.operation=@operation

END
go

