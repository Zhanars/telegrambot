-- =============================================
-- Author:		Twice
-- Create date: 31.01.2012
-- Description: Получить количество научных трудов, опубликованных в  международных научных изданиях, имеющих по данным информационных баз компаний Томсон Рейтер и Scopus (ISI Web of Knowledge, Thomson Reuters) ненулевой импакт-фактор - в разрезе сотрудника
-- =============================================
CREATE FUNCTION [dbo].[IP_NIR_getNotNullImpactFactor_Count_ByPersonalId]
(
	@personalId int,
	@year int
)
RETURNS real
AS
BEGIN
DECLARE @Result real

SELECT @Result = COUNT(*)
	FROM 
		DBScience.dbo.Papers p,
		DBScience.dbo.L_Person_Paper_Authors a,
		DBScience.dbo.SciJournals sj,
		DBScience.dbo.L_SciJournal_IFRatingAgencies sip
	WHERE
	-- статья не архивирована
	p.status != 2 AND
	-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
	sj.sciJournal_id = p.periodicEdition_id AND
	p.periodicEditionType_id = 1 AND
	-- импакт факторы, принадлежащие этой статье должны относиться к Томсон Ройтерс (id = 1) 
	-- и быть > 0
	sip.sciJournal_id = sj.sciJournal_id AND
	sip.IFRatingAgency_id = 1 AND sip.factorValue > 0 AND
	-- статья этого года
	p.yearPublication in (@year, @year+1)  AND
	-- статья этого автора (ППС, потому personType = 1)
	p.paper_id = a.paper_id AND
	a.personType = 1 AND 
	a.person_id = @personalId
	
-- Return the result of the function
RETURN ISNULL(@Result, 0)

END
go

