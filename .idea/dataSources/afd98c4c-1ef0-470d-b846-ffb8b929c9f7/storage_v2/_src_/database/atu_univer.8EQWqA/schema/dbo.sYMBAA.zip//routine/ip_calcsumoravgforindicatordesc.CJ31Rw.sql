
-- =============================================
-- Author:		Yerlan
-- Create date: 18.01.2013
-- Description:	Получить описание на сумму или ср. значение конкретного показателя по анкетным данным ППС(для кафедры) или Кафедры(для факультета)
-- =============================================
CREATE FUNCTION [dbo].[IP_CalcSumOrAVGForIndicatorDESC] 
(
	-- Add the parameters for the function here
	@indPlanIndicatorId		INT,
	@categoryId				INT,
	@strucDivId				INT,
	@year					INT,
	/*@semester				INT,*/
	@whichValue				INT -- Если равно 1, то нужно получить плановые значения, если 2 то фактические.
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result NVARCHAR(MAX);
	-- ================================================= ЕСЛИ КАТЕГОРИЯ КАФЕДРАЛЬНАЯ
	IF (@categoryId=2)
	BEGIN
		SELECT @Result = COALESCE(@Result + '\n\n', '') + 
			ISNULL(CONVERT(NVARCHAR(MAX), ROW_NUMBER() OVER (ORDER BY p.personal_sname)) +N') '
			+ N'Сотрудник: ' + p.personal_sname + ' '+ SUBSTRING(p.personal_name,1,1)+'.'+ SUBSTRING(p.personal_father_name,1,1)
			+ N'\nЗначение: ' + CONVERT(nvarchar(max),(CASE WHEN @whichValue=1 THEN 
			(case when ipp.ind_plan_personal_p_approve_value is not null then ipp.ind_plan_personal_p_approve_value else ipp.ind_plan_personal_p_value end) 
			ELSE 
			(case when ipp.ind_plan_personal_f_approve_value is not null then ipp.ind_plan_personal_f_approve_value else ipp.ind_plan_personal_f_value end)  END)) +
			N'\nОписание: ' + CONVERT(nvarchar(max),(CASE WHEN @whichValue=1 
			THEN 
			(case when ipp.ind_plan_personal_p_approve_desc IS NOT NULL THEN ipp.ind_plan_personal_p_approve_desc ELSE 
			ipp.ind_plan_personal_p_value_desc END)
			ELSE 
			(case when ipp.ind_plan_personal_f_approve_desc IS NOT NULL THEN ipp.ind_plan_personal_f_approve_desc ELSE 
			ipp.ind_plan_personal_f_value_desc END)
			END)), '')
		FROM 
			(
				SELECT DISTINCT p.personal_id, p.personal_sname,  p.personal_name, p.personal_father_name, spl.structure_division_id 
				FROM univer_personal p, univer_personal_struct_pos_link_1c spl 
				WHERE p.personal_id=spl.personal_id AND p.status=1 AND spl.status=1 AND spl.structure_division_id=@strucDivId
			) p
			,univer_ind_plan_personal ipp
		WHERE 
			-- сравнение с персоналом
			p.personal_id=ipp.personal_id
			-- по ИД кода показателя
			AND ipp.ind_plan_indicator_id=@indPlanIndicatorId
			-- за академ. год и за тек. семестр
			AND ipp.year = @year
			/*AND ipp.semester = @semester */
			AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,p.structure_division_id,1)=1	
			AND (CASE WHEN @whichValue=1 THEN ipp.ind_plan_personal_p_value+ISNULL(ipp.ind_plan_personal_p_approve_value,0) ELSE ipp.ind_plan_personal_f_value+ISNULL(ipp.ind_plan_personal_f_approve_value,0) END)>0
	END
	-- ================================================= ЕСЛИ КАТЕГОРИЯ ФАКУЛЬТЕТСКАЯ
	ELSE IF (@categoryId=1)
	BEGIN
		SELECT @Result = COALESCE(@Result + '\n\n', '') + 
			ISNULL(CONVERT(NVARCHAR(MAX), ROW_NUMBER() OVER (ORDER BY p.personal_sname)) +N') '
			+ N'Кафедра: ' + c.chair_name_ru
			+ N'\nЗначение: ' + CONVERT(nvarchar(max),(CASE WHEN @whichValue=1 THEN 
			(case when ipp.ind_plan_personal_p_approve_value is not null then ipp.ind_plan_personal_p_approve_value else ipp.ind_plan_personal_p_value end) 
			 ELSE (case when ipp.ind_plan_personal_f_approve_value is not null then ipp.ind_plan_personal_f_approve_value else ipp.ind_plan_personal_f_value end) END)) +
			N'\nОписание: {' + (CASE WHEN @whichValue=1 THEN 
			(case when ipp.ind_plan_personal_p_approve_desc IS NOT NULL THEN ipp.ind_plan_personal_p_approve_desc ELSE 
			ipp.ind_plan_personal_p_value_desc END)
			ELSE 
			(case when ipp.ind_plan_personal_f_approve_desc IS NOT NULL THEN ipp.ind_plan_personal_f_approve_desc ELSE 
			ipp.ind_plan_personal_f_value_desc END) END)+'}', '')
		FROM 
			(
				SELECT DISTINCT p.personal_id, p.personal_sname,  p.personal_name, p.personal_father_name, hc.chair_id 
				FROM univer_personal p, univer_head_chair hc 
				WHERE p.personal_id=hc.personal_id AND p.status=1 AND hc.status=1
			) p
			,univer_ind_plan_personal ipp
			, univer_faculty f, univer_chair c
		WHERE 
		-- по факультету
		f.structure_division_id = @strucDivId AND f.faculty_id=c.faculty_id AND f.status=1
		AND f.faculty_id=c.faculty_id
		-- по кафедре
		AND c.chair_id = p.chair_id AND c.status=1 
		-- сравнение с персоналом
		AND p.personal_id=ipp.personal_id
		-- по ИД кода показателя
		AND ipp.ind_plan_indicator_id=@indPlanIndicatorId
		-- за академ. год и за тек. семестр
		AND ipp.year= @year 
        /*AND ipp.semester = @semester */
        AND (CASE WHEN @whichValue=1 THEN ipp.ind_plan_personal_p_value+ISNULL(ipp.ind_plan_personal_p_approve_value,0) ELSE ipp.ind_plan_personal_f_value+ISNULL(ipp.ind_plan_personal_f_approve_value,0) END)>0
	END
	RETURN @Result
END


go

