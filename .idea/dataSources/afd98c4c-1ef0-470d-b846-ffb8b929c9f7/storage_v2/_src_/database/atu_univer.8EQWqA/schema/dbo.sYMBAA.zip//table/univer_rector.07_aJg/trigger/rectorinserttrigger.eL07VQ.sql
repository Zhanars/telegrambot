-- =============================================
-- Author:		@LFER
-- Create date: 2009-03-30 13:23:08.447
-- Description:	Действия, которые необходимо выполнить при добавлении нового ректора
-- =============================================
CREATE TRIGGER [dbo].[rectorInsertTrigger] ON  [dbo].[univer_rector] AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	-- Insert statements for trigger here
	-- Цифра доступа для данной сущности
	DECLARE @pi int
	
	DECLARE insCursor cursor 
		FOR SELECT personal_id FROM inserted WHERE status=1
		
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @pi
	WHILE @@FETCH_STATUS = 0
	BEGIN
		exec dbo.personalSetAccess @pi, 'RECTOR'
		FETCH NEXT FROM insCursor INTO @pi;
	END
	CLOSE insCursor
END
go

