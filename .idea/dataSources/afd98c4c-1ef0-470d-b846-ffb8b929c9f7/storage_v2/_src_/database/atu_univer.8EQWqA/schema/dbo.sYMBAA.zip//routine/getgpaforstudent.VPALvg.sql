-- =============================================
-- Author:		Sasha
-- Create date: 13.05.2010
-- Description:	Подсчет GPA для студента (@maxSem-семестр, до которого нужно считать GPA, если 0, то считается за все семестры; @course-курс, за который считать GPA, если 0 - то считается общее GPA)
-- =============================================
CREATE FUNCTION [dbo].[getGPAForStudent]
(
 @studentId int,
 @maxSem int,
 @course int
)
RETURNS float
AS
BEGIN
	DECLARE @ret float

      if (exists(select * from univer_students where students_id=@studentId)) 
      begin
	SELECT @ret=sum(isnull(mt.mark_type_gpa,0)*pr.progress_credit)/case when SUM(pr.progress_credit)>0 then SUM(pr.progress_credit) else 1 end  
	from univer_progress pr left join univer_mark_type mt on mt.mark_type_id=pr.mark_type_id, univer_students st with (nolock) where st.students_id=pr.student_id and pr.status=1 and student_id=@studentId 
and ((@course>0 and pr.n_seme in (@course*2,@course*2-1) ) or @course=0) and ((@maxSem>0 and pr.n_seme<@maxSem) or @maxSem=0)
and pr.controll_type_id in (select gg.controll_type_id from univer_controll_type_gpa gg where gg.stage_id=st.stage_id and gg.gpa=1) and pr.controll_type_id>0
end
else
begin
SELECT @ret=sum(isnull(mt.mark_type_gpa,0)*pr.progress_credit)/case when SUM(pr.progress_credit)>0 then SUM(pr.progress_credit) else 1 end  
	from  _arc_univer_progress pr left join univer_mark_type mt on mt.mark_type_id=pr.mark_type_id, _arc_univer_students st  with (nolock) where st.students_id=pr.student_id and pr.status=1 and student_id=@studentId 
and ((@course>0 and pr.n_seme in (@course*2,@course*2-1) ) or @course=0) and ((@maxSem>0 and pr.n_seme<@maxSem) or @maxSem=0)
and pr.controll_type_id in (select gg.controll_type_id from univer_controll_type_gpa gg where gg.stage_id=st.stage_id and gg.gpa=1) and pr.controll_type_id>0
end

	RETURN isnull(@ret,0)

END


go

