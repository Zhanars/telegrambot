-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE test
    @from nvarchar(max),
	@field nvarchar(500),
	@param nvarchar(500),
	@val nvarchar(500)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	declare @t table (r nvarchar);declare @r nvarchar(max);  
		execute(N'declare @res nvarchar(max); set @res=N'''' select @res+='+@field+'+'','' from '+@from+' where '+@param+'='+@val+'; insert into @t(r) values (@res);');
		select @r= r from @t  
    -- Insert statements for procedure here
	SELECT @r
END
go

