
-- =============================================
-- Author:		Yerlan
-- Create date: 22.12.2015
-- Description: Получить количество публикаций (имеется ввиду статьи) 
-- (@indicatorConst=1 - учебно-методические статьи 
-- @indicatorConst=2 - если ККСОН
-- @indicatorConst=3 - Количество статей на английском языке, опубликованных в научных периодических изданиях ближнего(@editionTypeId=2)/дальнего(@editionTypeId=3) зарубежья, неиндексируемых в базах данных Thomson Reuters и Scopus
-- @indicatorConst=4 - Количество научных статей, опубликованных в журналах с ненулевым импакт-фактором индексируемых 
--										в Thomson Reuters
-- @indicatorConst=5 - Количество научных статей, опубликованных в журналах индексируемых в Scopus
-- @indicatorConst=6 - Количество статей, опубликованных в англоязычных научных журналах КазНУ совместно с авторами из дальнего зарубежья с высокой цитируемостью публикаций: International Journal of Mathematics and Physics, International Journal of Biology and Chemistry, Eurasian Journal of Social Sciences and Humanities, Physical Sciences and Technology
-- @indicatorConst=7 - Количество статей, опубликованных на английском языке в неанглоязычных журналах КазНУ
-- @indicatorConst=8 - Количество статей опубликованных в Nature & Science
-- =============================================
CREATE FUNCTION [dbo].[IP_NIR_getSciPapers_Count_By]
(
	@categoryId int,
	@personalId int,
	@chairId int,
	@facultyId int,
	@year int,
	@editionTypeId int,
	@indicatorConst int
)
RETURNS real
AS
BEGIN
DECLARE @Result real
-- ==================================== если учебно-методические статьи
IF (@indicatorConst=1)
BEGIN
	SELECT @Result = COUNT(*)
		FROM 
			DBScience.dbo.Papers p,
			DBScience.dbo.L_Person_Paper_Authors a,
			DBScience.dbo.OtherPeriodicEditions op
		WHERE
		-- статья не архивирована
		p.status != 2 AND
		-- статья должна иметь другое пер. издание с типом "сборник уч.методических статей"
		op.otherPeriodicEdition_id = p.periodicEdition_id AND
		p.periodicEditionType_id = 10 AND
		-- статья этого года
		p.yearPublication in (@year, @year + 1) AND
		-- не дублированная и подтвержденная
		p.is_overlap IS NULL AND
		p.is_approve=1 AND
		-- статья этого автора (ППС, потому personType = 1)
		p.paper_id = a.paper_id AND
		a.personType = 1 AND 
		(
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		)
END

-- ==================================== если ККСОН
IF (@indicatorConst = 2)
BEGIN
	SELECT @Result = COUNT(*)
		FROM 
			DBScience.dbo.Papers p,
			DBScience.dbo.L_Person_Paper_Authors a,
			DBScience.dbo.SciJournals sj
		WHERE
		-- статья не архивирована
		p.status != 2 AND
		-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
		sj.sciJournal_id = p.periodicEdition_id AND
		p.periodicEditionType_id = 1 AND
		-- журнал должен быть рекомендуемый ККСОН
		sj.recommendedByKKSON = 1 AND
		-- статья этого года
		p.yearPublication in (@year, @year + 1) AND
		-- не дублированная и подтвержденная
		p.is_overlap IS NULL AND
		p.is_approve=1 AND
		-- статья этого автора (ППС, потому personType = 1)
		p.paper_id = a.paper_id AND
		a.personType = 1 AND (
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		)
END
-- ==================================== Количество статей на английском языке, опубликованных в научных периодических изданиях ближнего/
--										дальнего зарубежья, неиндексируемых в базах данных Thomson Reuters и Scopus
IF (@indicatorConst = 3)
BEGIN
	SELECT @Result = m1.pCount + m2.thCount
		FROM
		(SELECT COUNT(*) as pCount
		FROM 
			DBScience.dbo.Papers p,
			DBScience.dbo.L_Person_Paper_Authors a,
			DBScience.dbo.SciJournals sj, 
			DBScience.dbo.Countries c
		WHERE
		-- статья не архивирована
		p.status != 2 AND
		-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
		sj.sciJournal_id = p.periodicEdition_id AND
		p.periodicEditionType_id = 1 AND
		-- страна журнала должна быть в  ближнего(@editionTypeId=2)/дальнего(@editionTypeId=3) зарубежье и не текущей (Казахстан)
		sj.journalCountry_id = c.country_id AND
		(
		(@editionTypeId=2 AND c.foreignType in (0,1) )
		OR
		(@editionTypeId=3 AND c.foreignType in (2) )
		)
		AND c.countryCurrent = 0 AND
		-- журнал должен быть нерекомендуемый ККСОН
		sj.recommendedByKKSON <> 1 AND
		-- на английском языке
		p.language_id=4 AND
		-- статья этого года
		p.yearPublication in (@year, @year + 1) AND	
		-- не дублированная и подтвержденная
		p.is_overlap IS NULL AND
		p.is_approve=1 AND
		-- статья этого автора (ППС, потому personType = 1)
		p.paper_id = a.paper_id AND
		a.personType = 1  AND (
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		) AND
		-- неиндексируемых в базах данных Thomson Reuters и Scopus
		p.paper_id NOT IN 
			(
				select p2.paper_id
				FROM 
					DBScience.dbo.Papers p2,
					DBScience.dbo.L_Person_Paper_Authors a,
					DBScience.dbo.SciJournals sj,
					DBScience.dbo.L_SciJournal_IFRatingAgencies sip
				WHERE
				-- статья не архивирована
				p2.status != 2 AND
				-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
				sj.sciJournal_id = p2.periodicEdition_id AND
				p2.periodicEditionType_id = 1 AND
				-- импакт факторы, принадлежащие этой статье должны относиться к Томсон Ройтерс (id = 1) 
				-- и быть > 0
				sip.sciJournal_id = sj.sciJournal_id AND
				sip.IFRatingAgency_id = 1 AND sip.factorValue > 0 AND
				-- статья этого года
				p2.yearPublication in (@year, @year+1)  AND
				-- статья этого автора (ППС, потому personType = 1)
				p2.paper_id = a.paper_id AND
				a.personType = 1 AND 
				a.person_id = @personalId
				UNION
				SELECT p3.paper_id
				FROM 
					DBScience.dbo.Papers p3,
					DBScience.dbo.L_Person_Paper_Authors a,
					DBScience.dbo.SciJournals sj
				WHERE
				-- статья не архивирована
				p3.status != 2 AND
				-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
				sj.sciJournal_id = p.periodicEdition_id AND
				p3.periodicEditionType_id = 1 AND
				-- журнал должен иметь галочку "относится к scopus"
				sj.indexedByScopus = 1 AND
				-- статья этого года
				p3.yearPublication in (@year, @year+1) AND
				-- статья этого автора (ППС, потому personType = 1)
				p3.paper_id = a.paper_id AND
				a.personType = 1 AND 
				a.person_id = @personalId
			) 
		) m1,
		(SELECT COUNT(*) as thCount
		FROM
			DBScience.dbo.Thesises th,
			DBScience.dbo.L_Person_Thesis_Authors a,
			DBScience.dbo.SciEvents se,
			DBScience.dbo.Countries c
		WHERE
			-- тезис не архивирован
			th.status != 2 AND
			-- мероприятие этого тезиса
			se.sciEvent_id = th.sciEvent_id AND
			-- мероприятие международное (id=5)
			se.sciEventForm_id = 5 AND
			-- страна мероприятия должна быть ближнего(@editionTypeId=2)/дальнего(@editionTypeId=3) зарубежья и не текущей
			se.country_id = c.country_id AND 
			(
			(@editionTypeId=2 AND c.foreignType in (0,1) )
			OR
			(@editionTypeId=3 AND c.foreignType in (2) )
			)
			AND c.countryCurrent = 0 AND
			-- тезис этого года (по мероприятию)
			YEAR(se.eventStart) in (@year, @year + 1) AND
			-- не дублированная и подтвержденная
			th.is_overlap IS NULL AND
			th.is_approve=1 AND
			-- тезис этого автора (ППС, потому personType = 1)
			th.thesis_id = a.thesis_id AND
			a.personType = 1  AND (
			-- на уровне ппс
			(@categoryId=3 AND a.person_id = @personalId)
			OR
			-- на уровне кафедры
			(@categoryId=2 AND a.person_id IN 
				(SELECT
					DISTINCT p.personal_id
				FROM
					univer_personal p,
					univer_structure_division_1c sd,
					univer_personal_struct_pos_link_1c spl
				WHERE
					p.personal_id = spl.personal_id AND
					sd.structure_division_id = spl.structure_division_id AND
					sd.structure_division_id = @chairId AND
					spl.status != 2  AND p.status != 2
					AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
				))
			OR
			-- на уровне факультета
			(@categoryId=1 AND a.person_id IN 
				(SELECT
					DISTINCT p.personal_id
				FROM
					univer_personal p,
					univer_structure_division_1c sd,
					univer_personal_struct_pos_link_1c spl
				WHERE
					p.personal_id = spl.personal_id AND
					sd.structure_division_id = spl.structure_division_id AND
					sd.structure_division_ext = @facultyId AND
					spl.status != 2  AND p.status != 2
					AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
				))
			)
		) m2
END
-- ==================================== Количество научных статей, опубликованных в журналах с ненулевым импакт-фактором индексируемых 
--										в Thomson Reuters
IF (@indicatorConst = 4)
BEGIN
		SELECT @Result = COUNT(*)
		FROM 
			DBScience.dbo.Papers p,
			DBScience.dbo.L_Person_Paper_Authors a,
			DBScience.dbo.SciJournals sj,
			DBScience.dbo.L_SciJournal_IFRatingAgencies sip
		WHERE
		-- статья не архивирована
		p.status != 2 AND
		-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
		sj.sciJournal_id = p.periodicEdition_id AND
		p.periodicEditionType_id = 1 AND
		-- импакт факторы, принадлежащие этой статье должны относиться к Томсон Ройтерс (id = 1) 
		-- и быть > 0
		sip.sciJournal_id = sj.sciJournal_id AND
		sip.IFRatingAgency_id = 1 AND sip.factorValue > 0 AND
		-- статья этого года
		p.yearPublication in (@year, @year+1)  AND
		-- не дублированная и подтвержденная
		p.is_overlap IS NULL AND
		p.is_approve=1 AND
		-- статья этого автора (ППС, потому personType = 1)
		p.paper_id = a.paper_id AND
		a.personType = 1 AND  (
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		) 
END

-- ==================================== Количество научных статей, опубликованных в журналах индексируемых в Scopus
IF (@indicatorConst = 5)
BEGIN
		SELECT @Result = COUNT(*)
		FROM 
			DBScience.dbo.Papers p,
			DBScience.dbo.L_Person_Paper_Authors a,
			DBScience.dbo.SciJournals sj
		WHERE
		-- статья не архивирована
		p.status != 2 AND
		-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
		sj.sciJournal_id = p.periodicEdition_id AND
		p.periodicEditionType_id = 1 AND
		-- журнал должен иметь галочку "относится к scopus"
		sj.indexedByScopus = 1 AND
		-- статья этого года
		p.yearPublication in (@year, @year+1) AND
		-- не дублированная и подтвержденная
		p.is_overlap IS NULL AND
		p.is_approve=1 AND
		-- статья этого автора (ППС, потому personType = 1)
		p.paper_id = a.paper_id AND
		a.personType = 1 AND  (
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		) 
END

-- ==================================== Количество статей, опубликованных в англоязычных научных журналах КазНУ совместно с авторами из
--										дальнего зарубежья с высокой цитируемостью публикаций: 
-- International Journal of Mathematics and Physics, International Journal of Biology and Chemistry, Eurasian Journal of Social Sciences and Humanities, Physical Sciences and Technology
IF (@indicatorConst = 6)
BEGIN
		SELECT @Result = COUNT(*)
		FROM 
			DBScience.dbo.Papers p,
			DBScience.dbo.L_Person_Paper_Authors a,
			DBScience.dbo.SciJournals sj,
			DBScience.dbo.Countries c,
			DBScience.dbo.Publishers pb
		WHERE
		-- статья не архивирована
		p.status != 2 AND
		-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
		sj.sciJournal_id = p.periodicEdition_id AND
		p.periodicEditionType_id = 1 AND
		-- страна журнала должна быть Казахстан
		sj.journalCountry_id = c.country_id AND
		c.countryCurrent = 1 AND
		--научные журналы с названиями International Journal of Mathematics and Physics, International Journal of Biology and Chemistry,
		--		Eurasian Journal of Social Sciences and Humanities, Physical Sciences and Technology
		(
			sj.name LIKE '%International Journal of Mathematics and Physics%' OR 
			sj.name LIKE '%International Journal of Biology and Chemistry%' OR 
			sj.name LIKE '%Eurasian Journal of Social Sciences and Humanities%' OR 
			sj.name LIKE '%Physical Sciences and Technology%' 
		) AND
		--издательство КазНУ
		pb.publisher_id = sj.publisher_id AND
		pb.name LIKE N'%КазНУ%' AND
		-- на английском языке
		p.language_id=4 AND
		-- статья этого года
		p.yearPublication in (@year, @year+1) AND
		-- не дублированная и подтвержденная
		p.is_overlap IS NULL AND
		p.is_approve=1 AND
		-- статья этого автора (ППС, потому personType = 1)
		p.paper_id = a.paper_id AND
		a.personType = 1 AND  (
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		)
		AND EXISTS(SELECT * FROM DBScience.dbo.L_Person_Paper_Authors at,DBScience.dbo.Others ot WHERE p.paper_id = at.paper_id AND at.personType=4/*Other*/ AND ot.other_id=at.person_id AND ot.foreigner=1/*Inostranets*/) 
END

-- ==================================== Количество статей, опубликованных на английском языке в неанглоязычных журналах КазНУ
IF (@indicatorConst = 7)
BEGIN
		SELECT @Result = COUNT(*)
		FROM 
			DBScience.dbo.Papers p,
			DBScience.dbo.L_Person_Paper_Authors a,
			DBScience.dbo.SciJournals sj,
			DBScience.dbo.Countries c,
			DBScience.dbo.Publishers pb
		WHERE
		-- статья не архивирована
		p.status != 2 AND
		-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
		sj.sciJournal_id = p.periodicEdition_id AND
		p.periodicEditionType_id = 1 AND
		-- страна журнала должна быть Казахстан
		sj.journalCountry_id = c.country_id AND
		c.countryCurrent = 1 AND
		--научные журналы с названиями кроме International Journal of Mathematics and Physics, International Journal of Biology 
		--		and Chemistryб Eurasian Journal of Social Sciences and Humanities, Physical Sciences and Technology
		(
			sj.name NOT LIKE '%International Journal of Mathematics and Physics%' AND
			sj.name NOT LIKE '%International Journal of Biology and Chemistry%' AND
			sj.name NOT LIKE '%Eurasian Journal of Social Sciences and Humanities%' AND
			sj.name NOT LIKE '%Physical Sciences and Technology%' 
		) AND
		--издательство КазНУ
		pb.publisher_id = sj.publisher_id AND
		pb.name LIKE N'%КазНУ%' AND
		-- на английском языке
		p.language_id=4 AND
		-- статья этого года
		p.yearPublication in (@year, @year+1) AND
		-- не дублированная и подтвержденная
		p.is_overlap IS NULL AND
		p.is_approve=1 AND
		-- статья этого автора (ППС, потому personType = 1)
		p.paper_id = a.paper_id AND
		a.personType = 1 AND  (
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		) 
END

-- ==================================== Количество статей опубликованных в Nature & Science
IF (@indicatorConst = 8)
BEGIN
		SELECT @Result = COUNT(*)
		FROM 
			DBScience.dbo.Papers p,
			DBScience.dbo.L_Person_Paper_Authors a,
			DBScience.dbo.SciJournals sj,
			DBScience.dbo.Countries c
		WHERE
		-- статья не архивирована
		p.status != 2 AND
		-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
		sj.sciJournal_id = p.periodicEdition_id AND
		p.periodicEditionType_id = 1 AND
		-- страна журнала должна быть Казахстан
		sj.journalCountry_id = c.country_id AND
		--c.countryCurrent = 1 AND
		--научные журналы с названиями Nature & Science
		sj.name LIKE 'Nature & Science' AND
		-- статья этого года
		p.yearPublication in (@year, @year+1) AND
		-- не дублированная и подтвержденная
		p.is_overlap IS NULL AND
		p.is_approve=1 AND
		-- статья этого автора (ППС, потому personType = 1)
		p.paper_id = a.paper_id AND
		a.personType = 1 AND  (
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		) 
END

RETURN ISNULL(@Result, 0)

END

go

