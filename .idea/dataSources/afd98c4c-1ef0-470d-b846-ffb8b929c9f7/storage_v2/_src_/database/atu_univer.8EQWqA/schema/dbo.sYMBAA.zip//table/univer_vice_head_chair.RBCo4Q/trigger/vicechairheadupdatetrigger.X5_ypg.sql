-- =============================================
-- Author:		Саша
-- Create date: 2011-10-12 
-- Description:	Удаление или добавлении права доступа при изменении статуса сотрудника
-- =============================================
CREATE TRIGGER [dbo].[vicechairHeadUpdateTrigger]
   ON  [dbo].[univer_vice_head_chair]
   AFTER UPDATE
AS 
BEGIN	
	SET NOCOUNT ON;
	
	DECLARE @pi int
	DECLARE @st int
	
	DECLARE insCursor cursor 
		FOR SELECT personal_id, status FROM inserted
	
	IF UPDATE(status)
	BEGIN
		OPEN insCursor
		FETCH NEXT FROM insCursor INTO @pi, @st
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF(@st=1)
				EXEC dbo.personalSetAccess @pi, 'VICE_CHAIR_HEAD'
			ELSE
				EXEC dbo.personalDeleteAccess @pi, 'VICE_CHAIR_HEAD'
				
			FETCH NEXT FROM insCursor INTO @pi, @st
		END
		CLOSE insCursor
	END

END
go

