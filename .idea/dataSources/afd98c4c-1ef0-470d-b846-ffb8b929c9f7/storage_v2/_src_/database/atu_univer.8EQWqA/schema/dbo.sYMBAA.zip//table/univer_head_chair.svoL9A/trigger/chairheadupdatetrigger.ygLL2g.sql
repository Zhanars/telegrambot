-- =============================================
-- Author:		@LFER
-- Create date: 2009-09-28
-- Description:	Удаление или добавлении права доступа при изменении статуса сотрудника
-- =============================================
CREATE TRIGGER [dbo].[chairHeadUpdateTrigger]
   ON  [dbo].[univer_head_chair]
   AFTER UPDATE
AS 
BEGIN	
	SET NOCOUNT ON;
	
	DECLARE @pi int
	DECLARE @st int
	
	DECLARE insCursor cursor 
		FOR SELECT personal_id, status FROM inserted
	
	IF UPDATE(status)
	BEGIN
		OPEN insCursor
		FETCH NEXT FROM insCursor INTO @pi, @st
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF(@st=1)
				EXEC dbo.personalSetAccess @pi, 'CHAIR_HEAD'
			ELSE
				EXEC dbo.personalDeleteAccess @pi, 'CHAIR_HEAD'
				
			FETCH NEXT FROM insCursor INTO @pi, @st
		END
		CLOSE insCursor
	END

END
go

