-- =============================================
-- Author:		@LFER
-- Create date: 2009-08-30 16:42:38.330
-- Description:	Изменение кредитов учебного плана
-- =============================================
CREATE TRIGGER [dbo].[educPlanPosCreditDelete] ON  [dbo].[univer_educ_plan_credit]
   AFTER DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	BEGIN TRANSACTION
		DECLARE @id int
		DECLARE @v int
		
		DECLARE curs cursor FOR SELECT educ_plan_id, credit FROM deleted
	
		OPEN curs
		
		FETCH NEXT FROM curs INTO @id, @v
		WHILE @@FETCH_STATUS = 0
		BEGIN
			UPDATE univer_educ_plan SET educ_plan_min_cred_total=educ_plan_min_cred_total-@v WHERE educ_plan_id=@id
			FETCH NEXT FROM curs INTO @id, @v			
		END
		CLOSE curs
		DEALLOCATE curs
	COMMIT
END
go

