-- =============================================
-- Author:		YERLAN
-- Create date: 13.09.2011
-- Description:	Определяет состояние учебы студента
-- =============================================
CREATE FUNCTION [dbo].[getStudentMarkTypeArg] 
(
 @studentId int,
 @year int,
 @modSemester int
)
RETURNS int
AS
BEGIN
	DECLARE @ret float;
	DECLARE @excellent int;
	DECLARE @good int;
	DECLARE @normal int;
	DECLARE @fail int;
	DECLARE @other int;
	DECLARE @all int;

	select 
	@excellent = SUM(case when mt.mark_type_arg in (5) then 1 else 0 end),
	@good = SUM(case when mt.mark_type_arg in (4) then 1 else 0 end) ,
	@normal = SUM(case when mt.mark_type_arg in (3) then 1 else 0 end),
	@fail = SUM(case when mt.mark_type_arg in (2,6,7) then 1 else 0 end),
	@other = SUM(case when mt.mark_type_arg in (0,1) then 1 else 0 end) ,
	@all = SUM(1)
	from univer_progress pr, univer_mark_type mt where pr.status=1 and pr.mark_type_id=mt.mark_type_id and pr.n_seme<>(select (@year-s.educ_plan_adm_year+1)*2-@modSemester from univer_students s where s.students_id=pr.student_id) AND pr.student_id = @studentId
	group by pr.student_id	
	select @ret = case when @excellent=@all-@other then 5
			when @good+@excellent=@all-@other then 4
			when @normal+@excellent+@good=@all-@other then 3
			when @fail>0 then 2
			else 0 end
	RETURN isnull(ROUND(@ret, 0),0)
END
go

