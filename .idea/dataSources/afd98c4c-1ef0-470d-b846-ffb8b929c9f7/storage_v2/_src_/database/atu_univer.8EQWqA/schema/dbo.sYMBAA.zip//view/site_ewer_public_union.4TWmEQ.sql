CREATE VIEW dbo.site_ewer_public_union
AS
SELECT     dbo.univer_dl_ewer_public_union.responsible_personal_id, dbo.univer_dl_ewer_public_union.dl_ewer_public_union_id, 
                      dbo.univer_dl_ewer_public_union.dl_ewer_public_union_name_kz, dbo.univer_dl_ewer_public_union.dl_ewer_public_union_name_en, 
                      dbo.univer_dl_ewer_public_union.dl_ewer_public_union_name_ru, dbo.univer_dl_ewer_public_union.dl_ewer_public_union_desc_kz, 
                      dbo.univer_dl_ewer_public_union.dl_ewer_public_union_desc_en, dbo.univer_dl_ewer_public_union.dl_ewer_public_union_desc_ru, 
                      dbo.univer_dl_ewer_public_union.dl_ewer_public_union_create,
                          (SELECT     COUNT(dl_ewer_public_union_id) AS Expr1
                            FROM          dbo.univer_dl_ewer_public_union_student_link
                            WHERE      (dbo.univer_dl_ewer_public_union.dl_ewer_public_union_id = dl_ewer_public_union_id)) AS participants_count
FROM         dbo.univer_dl_ewer_public_union INNER JOIN
                      dbo.univer_dl_ewer_public_union_student_link AS univer_dl_ewer_public_union_student_link_1 ON 
                      dbo.univer_dl_ewer_public_union.dl_ewer_public_union_id = univer_dl_ewer_public_union_student_link_1.dl_ewer_public_union_id
WHERE     (dbo.univer_dl_ewer_public_union.status = 1)
go

