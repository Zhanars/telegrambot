-- =============================================
-- Author:		Yerlan
-- Create date: 2013-10-27 17:44:33.680
-- Description:	Добавление записи о том что данные студента были изменены (триггер токо для UPDATE,так как при добавлении у студента статус еще не StatusNormal)
-- =============================================
CREATE TRIGGER [dbo].[certificateUpdateTriggerForPlatonus]
   ON  [dbo].[univer_certificates] 
   AFTER INSERT,UPDATE
AS 
BEGIN
	
	IF @@ROWCOUNT =0
    RETURN
	
	SET NOCOUNT ON;
	
	IF EXISTS(SELECT * FROM inserted i INNER JOIN univer_students s ON i.students_id=s.students_id AND s.status=1)
	BEGIN
		INSERT INTO platonus_univer_students(student_id,command) 
		SELECT DISTINCT i.students_id, 'update' FROM inserted i INNER JOIN univer_students s ON i.students_id=s.students_id AND s.status=1
		WHERE NOT EXISTS(SELECT * FROM platonus_univer_students WHERE student_id=i.students_id)
	END
	
END
go

