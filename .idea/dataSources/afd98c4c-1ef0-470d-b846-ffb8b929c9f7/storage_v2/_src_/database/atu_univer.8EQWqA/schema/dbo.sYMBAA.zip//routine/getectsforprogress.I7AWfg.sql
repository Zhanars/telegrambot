
-- =============================================
-- Author:		Sasha
-- Create date: 04.07.2014
-- Description:	Расчет кредитов ECTS по progress_id
-- =============================================
CREATE FUNCTION [dbo].[getECTSForProgress]
(
 @prId int
)
RETURNS float
AS
BEGIN
	DECLARE @ret float; 
    set @ret=0;
    declare @studentId integer,
    @ct integer,
	@stageId integer,
	@educFormId integer,
	@eduLevelId integer,
	@academYear integer,
	@subjType integer,
	@specId integer,
	@subjectId integer,
	@practiceType integer,
	@credit integer;
	select 
		@studentId=student_id,
		@ct=controll_type_id,
		@stageId=st.stage_id,
		@educFormId=st.education_form_id,
		@eduLevelId=st.edu_levels_id,
		@academYear= st.educ_plan_adm_year,--+p.n_seme/2-1,--p.academ_year,
		@subjType =p.subject_type,
		@specId=st.speciality_id,
		@subjectId=p.subject_id,
		@practiceType=isnull(p.educ_plan_pos_addit,0),
		@credit=p.progress_credit
    from univer_progress p, univer_students st where progress_id=@prId and st.students_id=p.student_id;
    
--select top 1 @ret=case when ects_const_value>0 then 
--	ects_const_value 
--else 
--	case when ects_calc_type=1 then
--		case when ects_max_value>0 and @credit*ects_ratio>ects_max_value then ects_max_value else @credit*ects_ratio end
--	else
--		cast(isnull(ects_case_value.value('(/ArrayOfEntry/Entry[Key=sql:variable("@credit")]/Value)[1]', 'float'),0) as real)
		
--	end
--end

-- from univer_ects_ratio r where status=1  and (controll_type_id=@ct or controll_type_id =0)
-- and
 
-- isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="educFormId"]/Value)[1]', 'int'),0) in (0,@educFormId) and 
-- isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="stageId"]/Value)[1]', 'int'),0) in( 0,@stageId) and
-- isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="eduLevelId"]/Value)[1]', 'int'),0) in (0,@eduLevelId) and
-- isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="academYear"]/Value)[1]', 'int'),0) in(0,@academYear) and
-- isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="subjType"]/Value)[1]', 'int'),0) in(0,@subjType) and
-- isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="specId"]/Value)[1]', 'int'),0) in(0,@specId) and
-- isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="subjectId"]/Value)[1]', 'int'),0) in(0,@subjectId) and
-- isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="practiceType"]/Value)[1]', 'int'),0)  in(0,@practiceType)
-- order by controll_type_id, (len(cast(ects_compare_filter as nvarchar(MAX)))- len(replace(cast(ects_compare_filter as nvarchar(MAX)),'<Key>','')))/LEN('<Key>') desc

 select  top 1 @ret=t.vv from (select case when ects_const_value>0 then 
	ects_const_value 
else 
	case when ects_calc_type=1 then
		case when ects_max_value>0 and @credit*ects_ratio>ects_max_value then ects_max_value else @credit*ects_ratio end
	else
		cast(isnull(ects_case_value.value('(/ArrayOfEntry/Entry[Key=sql:variable("@credit")]/Value)[1]', 'float'),0) as real)
		
	end
end vv, t.subjectId, t.practiceType, t.subjType,t.specId, t.academYear, t.eduLevelId, t.educFormId, t.stageId from (select  isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="educFormId"]/Value)[1]', 'int'),0) educFormId,
 isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="stageId"]/Value)[1]', 'int'),0) stageId,
 isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="eduLevelId"]/Value)[1]', 'int'),0) eduLevelId,
 isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="academYear"]/Value)[1]', 'int'),0) academYear,
 isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="subjType"]/Value)[1]', 'int'),0) subjType,
 isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="specId"]/Value)[1]', 'int'),0) specId,
 isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="subjectId"]/Value)[1]', 'int'),0) subjectId,
 isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="practiceType"]/Value)[1]', 'int'),0)  practiceType, r.ects_ratio,r.ects_const_value,ects_case_value,ects_calc_type,ects_max_value  from univer_ects_ratio r where controll_type_id = @ct
 and status=1) t where 
 t.academYear in (0,@academYear) and
 t.eduLevelId in (0,@eduLevelId) and
 t.educFormId in (0,@educFormId) and 
 t.practiceType in (0,@practiceType) and
 t.specId in (0,@specId) and
 t.stageId in (0, @stageId) and 
 t.subjType in (0,@subjType) and 
 t.subjectId in (0,@subjectId) 
) t
where t.vv is not null 
order by t.subjectId desc, t.practiceType desc, t.subjType desc,t.specId desc, t.academYear desc, t.eduLevelId desc, t.educFormId desc, t.stageId desc
	RETURN isnull(@ret,0)

END

go

