
-- =============================================
-- Author:		Sasha
-- Create date: 04.02.2016
-- Description: Проверка, может ли студент сесть в группу
-- =============================================
CREATE FUNCTION [dbo].[checkRegStudentGroup]
(
	@studentId int,
	@groupId int
)
RETURNS nvarchar(max)
AS
BEGIN
declare @mes nvarchar(max);set @mes='';
declare @check int;
declare @studCount int;
--нужные параметры группы

declare @teacherId int;
declare @chairId int;
declare @maxStud int;
declare @retake int;
declare @year int;
declare @subjectId int;
declare @subjectType int;
declare @planId int;
declare @langDivId int;
declare @specId int;
declare @educLangId int;
declare @credit int;

declare @facultyId int;
declare @degreeSubCount int;

select 
	@teacherId=g.teacher_id,
	@year=group_year,
	@chairId=g.chair_id,
	@maxStud=g.group_students_max,   
	@retake=group_retake_semestr, 
	@subjectId=pp.subject_id,
	@subjectType=sb.subject_type, 
	@planId=pp.educ_plan_id, 
	@langDivId=isnull(g.lang_division_id,0), 
	@specId=isnull(pp.specialization_id,0), 
	@educLangId=g.educ_lang_id, 
	@credit=pp.educ_plan_pos_credit
from univer_group g, univer_educ_plan_pos pp, univer_subject sb where pp.educ_plan_pos_id=g.educ_plan_pos_id and sb.subject_id=pp.subject_id and g.group_id=@groupId;

 
--1. Проверяем, что группа не ретейк
if @retake>0 begin set @mes=@mes+N'{retake}' end;

--2. Проверяем, подходит ли группа студенту по учебному плану
select @check=count(*) from univer_students st, univer_educ_plan p where
st.students_id=@studentId and 
p.status=1 and 
p.speciality_id=st.speciality_id and 
p.education_form_id=st.education_form_id and 
p.edu_level_id=st.edu_levels_id and 
p.educ_plan_adm_year=st.educ_plan_adm_year and 
p.educ_plan_id=@planId and 
@langDivId  in (0, isnull(st.lang_division_id,0)) and 
@specId in (0, isnull(st.specialization_id,0)) 

if @check<=0 begin set @mes=@mes+N'{place}' end; set @check=0;
--3. Проверяем максимальное количество студентов
if @maxStud>0
begin select @studCount=count(distinct gs.student_id) from univer_group_student gs where gs.student_id<>@studentId and gs.group_id=@groupId;
if @maxStud>0 and @studCount>=@maxStud begin set @mes=@mes+N'{max}' end;
end;
if (@teacherId<>0) begin
select top 1  @facultyId=c.faculty_id from univer_teacher_chair_link tcl, univer_chair c where c.chair_id=tcl.chair_id and tcl.teacher_id=@teacherId  order by stavka desc
--4. Проверяем на максимальное количество дисциплин у преподавателя
----4.1 Выбираем ограничение для преподавателя
select top 1 @degreeSubCount=isnull(sdc.max_subject_count,0) from univer_teacher t, univer_personal p left join univer_personal_scientific_degree_1c sd on sd.personal_id=p.personal_id
left join univer_scientific_degree_subject_count sdc on isnull(sd.scientific_degree_id,0)=sdc.scientific_degree_id and @facultyId=sdc.faculty_id where p.personal_id=t.personal_id and t.teacher_id=@teacherId
order by sd.personal_scientific_degree_date desc
if (@degreeSubCount>0) and (@subjectType in (0,1)) begin
--Надо проверить ограничение на максимальное количество дисциплин у препода
--1. Проверяем есть ли у препода уже группы со студентами по этой дисциплине. Если есть, то вполне можно продолжить регистрацию
set @check=0;
select @check=count(*)
from univer_group g, univer_educ_plan_pos pp, univer_subject sb where pp.educ_plan_pos_id=g.educ_plan_pos_id and sb.subject_id=pp.subject_id and g.teacher_id=@teacherId and @subjectId=pp.subject_id
and @langDivId=g.lang_division_id and g.group_year=@year and  @educLangId=g.educ_lang_id and @credit=pp.educ_plan_pos_credit and sb.subject_type in (0,1) and (select count(*) from univer_group_student gs where gs.group_id=g.group_id)>0;
if (@check=0)
begin
select @check=count(*) from (select distinct g.teacher_id,  pp.subject_id, pp.educ_plan_pos_credit, g.lang_division_id, g.educ_lang_id from univer_group g, univer_educ_plan_pos pp, univer_subject sb where g.educ_plan_pos_id=pp.educ_plan_pos_id and group_year=@year and g.group_retake_semestr=0 and pp.subject_id=sb.subject_id and pp.status=1
and (select count(*) from univer_group_student gs where gs.group_id=g.group_id)>0
and g.teacher_id=@teacherId) t;
if (@check>=@degreeSubCount)
begin set @mes=@mes+N'{subcount}' end; set @check=0;
end;

	end;
	end;
	return @mes--+case when cast (ROUND(((select random from RANDOM)* 63),0) as int) % 2>0 then '{subcount}' else '' end;

END

go

