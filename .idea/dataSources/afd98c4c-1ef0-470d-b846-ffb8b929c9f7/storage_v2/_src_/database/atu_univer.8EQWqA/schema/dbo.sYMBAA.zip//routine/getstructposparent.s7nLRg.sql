-- =============================================
-- Author:		sasha
-- Create date: 23.01.2016
-- Description:	Получение всех структурных подразделений верхнего уровня
-- =============================================
CREATE PROCEDURE [dbo].[getStructPosParent] 
@structPosId int,
@lang nvarchar(2)
AS
BEGIN
	SET NOCOUNT ON;
    declare @ids nvarchar(max);
    declare @parentId int;      
    set @ids='';
    set @parentId=@structPosId;
    while (@parentId>0)
    begin 
    set @ids=@ids+'{'+cast(@parentId as nvarchar)+'}';
    select @parentId=structure_division_ext from univer_structure_division_1c where structure_division_id=@parentId and status=1
    end
    -- Insert statements for procedure here
	select structure_division_id,
	case @lang
    when N'kz' then structure_division_name_kz
    when N'ru' then structure_division_name_ru
    when N'en' then structure_division_name_en end as structure_division_name from univer_structure_division_1c where @ids like '%{'+cast(structure_division_id as nvarchar)+'}%'
END
go

