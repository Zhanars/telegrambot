-- =============================================
-- Author:		Sasha
-- Create date: 11.02.2016
-- Description: Средний балл по последнему анкетированию преподаватель глазами студентов
-- =============================================
CREATE FUNCTION getAVGBallLastRatingStudentAnket
(
	@personalId int
)
RETURNS real
AS
BEGIN
	declare @ratingId int;
	set @ratingId=(SELECT top 1 isnull(rating_id,0) FROM univer_rating r WHERE r.rating_date_end<getdate() and r.rating_type_id=1 
	and exists(select * from univer_rating_result rr, univer_rating_subject rs where rs.rating_subject_id=rr.rating_subject_id 
	and rs.rating_id=r.rating_id and rr.personal_id=@personalId and rs.rating_subject_type=1)
	 order by rating_date_end desc)
    if (@ratingId=0) return null;

	declare @ret real;
	SELECT @ret=round(avg(cast(rr.rating_value as real)),2) FROM univer_rating_result rr, univer_rating_subject rs WHERE rs.rating_id=@ratingId AND rs.rating_subject_id=rr.rating_subject_id and rs.rating_subject_type=1
	AND rr.personal_id=@personalId
	RETURN @ret;

END
go

