-- =============================================
-- Author:		Yerlan
-- Create date: 2013-10-27 17:44:33.680
-- Description:	Добавление записи о том что данные студента были изменены (триггер токо для UPDATE,так как при добавлении у студента статус еще не StatusNormal)
-- =============================================
CREATE TRIGGER [dbo].[diplomDeleteTriggerForPlatonus]
   ON  [dbo].[univer_diplom] 
   AFTER delete
AS 
BEGIN
	
	IF @@ROWCOUNT =0
    RETURN
	
	SET NOCOUNT ON;
	
	IF EXISTS(SELECT * FROM inserted i INNER JOIN univer_students s ON i.student_id=s.students_id 
			AND (s.status=1 OR s.student_edu_status_id in (20,21,102)))
	BEGIN
		INSERT INTO platonus_univer_studentdiplominfo(student_id,command) 
		SELECT DISTINCT i.student_id, 2 FROM inserted i INNER JOIN univer_students s ON i.student_id=s.students_id 
				AND (s.status=1 OR s.student_edu_status_id in (20,21,102))
		WHERE NOT EXISTS(SELECT * FROM platonus_univer_studentdiplominfo WHERE student_id=i.student_id)
	END
	 
	delete from platonus_univer_students where student_id in (select i.student_id from deleted i)

	insert into platonus_univer_students(student_id, command)
	select s.students_id, 
	case 
		when s.status=2 and s.student_edu_status_id in (20, 21,102) then 'delete'
		else 'update' 
	end as command
	from deleted i
	inner join univer_students s on s.students_id=i.student_id
END
go

