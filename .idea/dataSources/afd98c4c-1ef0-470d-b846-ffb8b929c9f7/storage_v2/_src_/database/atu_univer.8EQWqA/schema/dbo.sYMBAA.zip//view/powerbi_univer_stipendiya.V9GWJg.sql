CREATE VIEW dbo.powerbi_univer_stipendiya
AS
SELECT     [Идентификатор студента], [Идентификатор приказа], CASE WHEN replace([Дата начала получения стипендии], 'xsi:nil="true"', '') != [Дата начала получения стипендии] THEN NULL 
                      ELSE CONVERT(datetime, [Дата начала получения стипендии], 126) END AS [Дата начала получения стипендии], CASE WHEN replace([Дата окончания получения стипендии], 'xsi:nil="true"', 
                      '') != [Дата окончания получения стипендии] THEN NULL ELSE CONVERT(datetime, [Дата окончания получения стипендии], 126) END AS [Дата окончания получения стипендии], 
                      [Идентификатор оценки для стипендии], [Идентификатор категории стипендии]
FROM         (SELECT DISTINCT 
                                              st.students_id AS [Идентификатор студента], o.order_id AS [Идентификатор приказа], REPLACE(REPLACE(CONVERT(nvarchar(MAX), 
                                              o.order_data.query('(/ScholarshipOrder/dateFrom)')), '<dateFrom>', ''), '</dateFrom>', '') AS [Дата начала получения стипендии], REPLACE(REPLACE(CONVERT(nvarchar(MAX), 
                                              o.order_data.query('(/ScholarshipOrder/dateTo)')), '<dateTo>', ''), '</dateTo>', '') AS [Дата окончания получения стипендии], 
                                              s.scholarship_mark_type_id AS [Идентификатор оценки для стипендии], s.scholarship_category_id AS [Идентификатор категории стипендии]
                       FROM          dbo.univer_scholarship AS s INNER JOIN
                                              dbo.univer_order_student_link AS osl ON s.student_id = osl.student_id AND s.order_id = osl.order_id INNER JOIN
                                              dbo.univer_order AS o ON osl.order_id = o.order_id INNER JOIN
                                              dbo.univer_students AS st ON osl.student_id = st.students_id
                       WHERE      (st.status = 1) AND (o.status IN (21, 22)) AND (o.order_type_id = 101) AND (o.order_id =
                                                  (SELECT     TOP (1) osl.order_id
                                                    FROM          dbo.univer_order_student_link AS osl CROSS JOIN
                                                                           dbo.univer_order AS o
                                                    WHERE      (o.order_id = osl.order_id) AND (o.status IN (21, 22)) AND (o.order_type_id = 101) AND (osl.student_id = st.students_id)
                                                    ORDER BY o.order_date_create DESC))) AS t
go

