-- =============================================
-- Author:		sasha
-- Create date: 30.10.2017 
-- Description:	Добавление студентам сообщения об обновлении аттестации
-- =============================================
CREATE TRIGGER [dbo].[progressAlert]
   ON  [dbo].[univer_progress]
   After UPDATE,INSERT 
AS 
BEGIN	
	SET NOCOUNT ON;
	
	IF EXISTS(SELECT * FROM inserted) and (UPDATE(progress_result) or UPDATE(progress_result_rk1) or UPDATE(progress_result_rk2) or UPDATE(progress_result_mt))
	BEGIN
	INSERT INTO univer_alert (alert_code, user_id, alert_date) 
	select 4,st.user_id,getdate() from univer_students st, inserted p where p.student_id=st.students_id
	and not exists(select * from univer_alert a where a.user_id=st.user_id and a.alert_code=4);	
	END	
END
go

