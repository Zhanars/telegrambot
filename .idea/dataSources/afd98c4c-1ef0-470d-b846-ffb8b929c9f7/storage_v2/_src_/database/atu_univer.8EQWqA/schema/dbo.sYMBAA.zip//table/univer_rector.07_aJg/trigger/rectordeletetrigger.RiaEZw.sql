-- =============================================
-- Author:		@LFER
-- Create date: 2009-03-31 10:16:25.873
-- Description:	Триггер на удаление записи о ректоре
-- =============================================
CREATE TRIGGER [dbo].[rectorDeleteTrigger]
   ON  [dbo].[univer_rector]
   AFTER DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @pi int
	DECLARE @st int
	
	DECLARE insCursor cursor 
		FOR SELECT personal_id FROM deleted
	
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @pi
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC dbo.personalDeleteAccess @pi, 'RECTOR'
			
		FETCH NEXT FROM insCursor INTO @pi
	END
	CLOSE insCursor
END
go

