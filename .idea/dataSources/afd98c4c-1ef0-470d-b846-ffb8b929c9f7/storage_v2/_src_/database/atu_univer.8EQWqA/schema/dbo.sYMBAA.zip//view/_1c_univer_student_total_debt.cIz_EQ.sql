CREATE VIEW dbo._1c_univer_student_total_debt
AS
SELECT     s._1c_univer_student_id AS student_id, ROUND(SUM(d._1c_student_contract_debt), 2) AS debt
FROM         dbo._1c_univer_student_contract_debt AS d INNER JOIN
                      dbo._1c_univer_student_contract AS c LEFT OUTER JOIN
                      dbo._1c_univer_student_contract_delay AS d2 ON d2._1c_student_contract_id = c._1c_student_contract_id ON d._1c_student_contract_id = c._1c_student_contract_id INNER JOIN
                      dbo._1c_univer_student AS s ON c._1c_student_id = s._1c_student_id
WHERE     (d._1c_student_contract_debt < 0) AND (ISNULL(d2._1c_student_contract_to, GETDATE() - 1) < GETDATE())
GROUP BY s._1c_univer_student_id
go

