-- =============================================
-- Author:		@LFER
-- Create date: 
-- Description:	
-- =============================================
CREATE TRIGGER [dbo].[orderInsertTrigger]
   ON  [dbo].[univer_order]
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
    DECLARE @oi int;
    DECLARE @os bigint;
    DECLARE @ons bigint;
    DECLARE @approved bit;
	
	DECLARE insCursor cursor 
		FOR SELECT order_id, order_signed, order_type_need_signed, order_approved FROM inserted i, univer_order_type ot WHERE i.order_type_id=ot.order_type_id
	
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @oi, @os, @ons, @approved
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @os=@ons AND @approved=0
		BEGIN
			UPDATE univer_order SET order_date_approve=getdate(), order_approved=1 WHERE order_id=@oi
		END
		FETCH NEXT FROM insCursor INTO @oi, @os, @ons, @approved
	END
	CLOSE insCursor
	DEALLOCATE insCursor
END
go

