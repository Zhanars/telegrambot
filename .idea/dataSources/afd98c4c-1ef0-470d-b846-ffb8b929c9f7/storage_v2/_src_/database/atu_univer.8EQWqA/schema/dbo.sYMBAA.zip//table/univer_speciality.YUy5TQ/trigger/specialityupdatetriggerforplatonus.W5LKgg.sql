create TRIGGER [dbo].[specialityUpdateTriggerForPlatonus]
   ON  [dbo].[univer_speciality] 
   AFTER UPDATE,INSERT,DELETE
AS 
BEGIN
	
	IF @@ROWCOUNT =0
    RETURN
	
	SET NOCOUNT ON;
	
	--Insert block, all new inserted subject_id will be writed as update
	IF EXISTS(SELECT * FROM inserted) AND NOT EXISTS(SELECT * FROM deleted)
	BEGIN
		INSERT INTO platonus_univer_speciality(speciality_id, operation)
		SELECT speciality_id,1 FROM inserted i 
		WHERE i.status=1 AND i.speciality_id NOT IN (SELECT speciality_id FROM platonus_univer_speciality)
	END
	
	
	--Update block, all new updated subject_id will be writed as update, and old subject_id from deleted will be writed as delete.
	--This block usually triggers when programmer updates subject_id in educ_plan_pos table to zips catalog of subject.
	--Delete will trigger only for subject_id changing
	IF (UPDATE(speciality_name_ru) OR UPDATE(speciality_name_kz) or update(speciality_name_en) or update(status) or update(speciality_okpd)) 
	AND EXISTS(SELECT * FROM inserted) AND EXISTS(SELECT * FROM deleted)
	BEGIN
		delete from platonus_univer_speciality where speciality_id in (select speciality_id from deleted)
		
		insert into platonus_univer_speciality(speciality_id, operation)
		select i.speciality_id, 1 from inserted i where i.status=1
		
		insert into platonus_univer_speciality(speciality_id, operation)
		select i.speciality_id, 2 from inserted i, deleted d where i.speciality_id=d.speciality_id and i.status=2 and d.status=1
		
	END
	
	--DELETE block, in univer there are only 2 ways: insert and delete. 
	IF EXISTS(SELECT * FROM deleted d WHERE d.status=1) AND NOT EXISTS(SELECT * FROM inserted i)
	BEGIN
		delete from platonus_univer_speciality where speciality_id in (select speciality_id from deleted where status=1)
		
		INSERT INTO platonus_univer_speciality(speciality_id,operation)
		SELECT speciality_id,2 FROM deleted d 
		WHERE d.status=1
	END
END
go

