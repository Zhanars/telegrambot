-- =============================================
-- Author:		Yerlan
-- Create date: 23.09.2016
-- Description:	
-- =============================================
CREATE FUNCTION [dbo].[GetPersonalMainStrPosLink]
(
	@personalId		int,
	@status			int=1
)
RETURNS @retTbl table(personal_id int, structure_division_id int, personal_position_id int, type_id int, personal_rate real)
AS
BEGIN
	INSERT INTO @retTbl
	SELECT TOP 1 spl.personal_id, spl.structure_division_id, spl.personal_position_id, spl.type_id, spl.personal_rate
	FROM univer_personal_struct_pos_link_1c spl WHERE spl.personal_id=@personalId AND spl.status=@status 
	ORDER BY spl.type_id, spl.personal_rate DESC;
	return;
END
go

