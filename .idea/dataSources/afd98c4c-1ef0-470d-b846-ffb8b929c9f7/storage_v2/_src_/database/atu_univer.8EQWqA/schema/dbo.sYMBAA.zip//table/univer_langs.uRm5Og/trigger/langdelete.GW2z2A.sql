-- =============================================
-- Author:		@LFER
-- Create date: 2009-03-19 11:27:31.030
-- Description:	Триггер на удаление записи о языке
-- =============================================
CREATE TRIGGER [dbo].[langDelete]
   ON  [dbo].[univer_langs]
   AFTER DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
	DECLARE @langName nvarchar(5)
	DECLARE insCursor cursor 
		FOR SELECT lang_name FROM deleted
		
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @langName
	WHILE @@FETCH_STATUS = 0
	BEGIN
		DECLARE @query nvarchar(500), @defname VARCHAR(100);
		SET @defname = 
			(SELECT name 
			FROM sysobjects so JOIN sysconstraints sc
			ON so.id = sc.constid 
			WHERE object_name(so.parent_obj) = 'univer_prorector'
			AND so.xtype = 'D'
			AND sc.colid = 
			 (SELECT colid FROM syscolumns 
			 WHERE id = object_id('dbo.univer_prorector') AND 
			 name = 'prorector_speciality_' + @langName))
			 
		SET @query='ALTER TABLE univer_prorector DROP CONSTRAINT ' + @defname + '; ALTER TABLE univer_prorector DROP COLUMN prorector_speciality_' + @langName;
		EXEC (@query);
		FETCH NEXT FROM insCursor INTO @langName;
	END
	CLOSE insCursor
	
	
	

END
go

