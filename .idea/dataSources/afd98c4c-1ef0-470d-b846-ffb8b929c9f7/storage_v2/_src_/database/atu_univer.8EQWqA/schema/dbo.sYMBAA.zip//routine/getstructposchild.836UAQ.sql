-- =============================================
-- Author:		sasha
-- Create date: 26.10.2016
-- Description:	Получение всех структурных подразделений нижнего уровня
-- =============================================
CREATE FUNCTION [dbo].[getStructPosChild] 
(
    @structPosId int,
    @lang nvarchar(2)
)
RETURNS 
@retTbl table(structure_division_id int, structure_division_name nvarchar(500))

AS
BEGIN
	 declare @ids nvarchar(max);
    set @ids='{'+cast(@structPosId as nvarchar)+'}';
    
    while exists (select * from univer_structure_division_1c where @ids like '%{'+cast(structure_division_ext as nvarchar)+'}%'
    and @ids not like '%{'+cast(structure_division_id as nvarchar)+'}%'
    )
    
    begin
    select @ids=@ids+'{'+cast(sd.structure_division_id as nvarchar)+'}' from univer_structure_division_1c sd where @ids like '%{'+cast(structure_division_ext as nvarchar)+'}%'
    and @ids not like '%{'+cast(structure_division_id as nvarchar)+'}%'
    end
    insert into @retTbl(structure_division_id,structure_division_name)
	select structure_division_id,
	case @lang
    when N'kz' then structure_division_name_kz
    when N'ru' then structure_division_name_ru
    when N'en' then structure_division_name_en end as structure_division_name from univer_structure_division_1c where @ids like '%{'+cast(structure_division_id as nvarchar)+'}%' and status=1
    order by structure_division_name
	
	RETURN 
END
go

