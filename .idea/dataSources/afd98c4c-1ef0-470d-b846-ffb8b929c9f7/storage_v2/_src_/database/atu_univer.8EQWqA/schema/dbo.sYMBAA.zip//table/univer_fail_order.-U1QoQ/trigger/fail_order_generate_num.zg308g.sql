-- =============================================
-- Author:		sasha
-- Create date: 23.12.2014
-- Description:	генерация номера для заявки
-- =============================================
CREATE TRIGGER [dbo].[fail_order_generate_num]
   ON  [dbo].[univer_fail_order] 
   AFTER insert
AS 
BEGIN
	SET NOCOUNT ON;

    declare @lastNum int;
    declare @id int;
    declare @studentId int;
    declare @year int;
    declare @status int;
    DECLARE insCursor cursor 
		FOR SELECT fail_order_id, student_id, fail_order_year,status FROM inserted 
				
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @id,@studentId,@year,@status
	WHILE @@FETCH_STATUS = 0
	BEGIN
	if (@status=6 and (select fail_order_number from univer_fail_order where fail_order_id=@id) is null) begin
	declare @facultyId int; select @facultyId=faculty_id from univer_students where students_id=@studentId;
	
	
	 set @lastNum=isnull((select top 1 cast(/*substring(*/fail_order_number/*,case st.faculty_id when 22 then 5 else 3 end,LEN(fail_order_number))*/ as int) n from univer_fail_order fo, univer_students st 
where fail_order_number is not null and  st.students_id=fo.student_id and st.faculty_id=@facultyId and fo.fail_order_year=@year and fo.fail_order_id<>@id --and fo.status in (4,6,7)
order by n desc),0)+1;
	--select @lastNum=count(*)+1 from univer_fail_order fo, univer_students st where st.students_id=fo.student_id and st.faculty_id=@facultyId and fo.fail_order_year=@year and fo.fail_order_id<>@id and fo.status in (4,6,7);
	declare @num nvarchar(250);
	
	
	set @num=/*case @facultyId when 14  then N'ВШ'
						    when 1 then N'ММ'
							when 4 then N'БФ'
							when 10 then N'ВФ'
							when 5 then N'ГФ'
							when 6 then N'ЖФ'
							when 7 then N'ИФ'
							when 9 then N'МО'
							when 8 then N'ФФ'
							when 13 then N'ФП'
							when 3 then N'ХФ'
							when 2 then N'ФТ'
							when 15 then N'ЮФ'
							when 22 then N'ВШОЗ' else N'NN' end+*/cast(@lastNum as nvarchar);						
    update univer_fail_order set fail_order_number=@num where fail_order_id=@id; 
	end
	FETCH NEXT FROM insCursor INTO @id,@studentId,@year,@status;
	END
	CLOSE insCursor

END
go

