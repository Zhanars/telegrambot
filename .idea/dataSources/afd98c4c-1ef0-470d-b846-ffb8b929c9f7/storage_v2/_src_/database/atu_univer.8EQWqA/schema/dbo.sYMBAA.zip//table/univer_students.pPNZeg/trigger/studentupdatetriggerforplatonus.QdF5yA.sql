-- =============================================
-- Author:		Yerlan
-- Create date: 2013-10-27 17:44:33.680
-- Description:	Добавление записи о том что данные студента были изменены (триггер токо для UPDATE,так как при добавлении у студента статус еще не StatusNormal)
-- =============================================
CREATE TRIGGER [dbo].[studentUpdateTriggerForPlatonus]
   ON  [dbo].[univer_students] 
   AFTER UPDATE
AS 
BEGIN
	
	
	SET NOCOUNT ON;
	
	delete from platonus_univer_students where student_id in (select i.students_id from inserted i)

	insert into platonus_univer_students(student_id, command)
	select i.students_id, 
	case 
		when i.status=2 and i.student_edu_status_id in (20, 21,102) then 'delete'
		else 'update' 
	end as command
	from inserted i 
	
	
	
	--IF @@ROWCOUNT =0
 --   RETURN
	
	--SET NOCOUNT ON;
	
	--DECLARE @si int
	--DECLARE @st int
	
	--IF EXISTS(SELECT * FROM inserted i JOIN deleted d ON i.students_id=d.students_id AND d.status IN (1,2) AND i.status=1)
	--BEGIN
	--	INSERT INTO platonus_univer_students(student_id,command)
	--	SELECT tab.StudentID,'update' FROM
	--	(
	--		SELECT 
	--			s.students_id												as [StudentID]
	--			,s.students_name											as [firstname]
	--			,s.students_sname											as [lastname]
	--			,s.students_father_name										as [patronymic]
	--			,s.students_birth_date										as [BirthDate]
	--			,ISNULL(s.students_date_admission,s.student_reg_date)			as [StartDate]
	--			,isnull(s.students_mobile_phone,s.students_contact_town_phone)	as [phone]
	--			,s.students_email											as [mail]
	--			,s.students_adress											as [adress]
	--			,s.students_sex												as [SexID]
	--			,s.nationality_id											as [NationID]
	--			,s.stage_id 
	--			,s.education_form_id
	--			,s.edu_levels_id 
	--			,s.educ_plan_adm_year										as [StudyFormID]
	--			,s.lang_division_id											as [StudyLanguageID]
	--			,s.student_photo_file_name									as [photo]
	--			,s.speciality_id											as [ProfessionID]
	--			,students_curce_number										as [CourseNumber]
	--			,students_sik												as [sikplt]
	--			,students_identify_code										as [iinplt]
	--			,s.graduate_info_id											as [pasteduinforu]
	--			,s.students_marital_status									as [ismarried]
	--			,s.students_birthd_place_ru									as [birthplace]
	--			,s.students_document_identity_number						as [icnumber]
	--			,s.students_document_identity_date							as [icdate]
	--			,s.students_document_identity_issued						as [icdepartment]
	--			--,isnull((case when dbo.getDiplomTypeForStudent(s.students_id,1)=1 then 1 else 0 end),0)				as [hasExcellent]
	--			,s.status													as [isStudent]
	--			--,ROUND(dbo.getGPAForStudent(s.students_id, 0, 0),2)			as [GPA]
	--			,s.settlement_status_id										as [residence]
	--			,s.citizenship_id											as [sitizenshipID]
	--			,s.students_need_hostel										as [dorm_state]
	--			,s.country_id												as [fromid]
	--			,s.region_id												AS [local]
	--			,s.region_id												as [city]
	--			,s.specialization_id										as [specializationID]
	--			,s.admission_reason_id										as [altynBelgi]
	--		FROM inserted s WHERE s.status=1
	--		UNION -- NOTE: UNION, not UNION ALL.  UNION by itself removes duplicate 
	--		SELECT 
	--			s.students_id												as [StudentID]
	--			,s.students_name											as [firstname]
	--			,s.students_sname											as [lastname]
	--			,s.students_father_name										as [patronymic]
	--			,s.students_birth_date										as [BirthDate]
	--			,ISNULL(s.students_date_admission,s.student_reg_date)			as [StartDate]
	--			,isnull(s.students_mobile_phone,s.students_contact_town_phone)	as [phone]
	--			,s.students_email											as [mail]
	--			,s.students_adress											as [adress]
	--			,s.students_sex												as [SexID]
	--			,s.nationality_id											as [NationID]
	--			,s.stage_id 
	--			,s.education_form_id
	--			,s.edu_levels_id 
	--			,s.educ_plan_adm_year										as [StudyFormID]
	--			,s.lang_division_id											as [StudyLanguageID]
	--			,s.student_photo_file_name									as [photo]
	--			,s.speciality_id											as [ProfessionID]
	--			,students_curce_number										as [CourseNumber]
	--			,students_sik												as [sikplt]
	--			,students_identify_code										as [iinplt]
	--			,s.graduate_info_id											as [pasteduinforu]
	--			,s.students_marital_status									as [ismarried]
	--			,s.students_birthd_place_ru									as [birthplace]
	--			,s.students_document_identity_number						as [icnumber]
	--			,s.students_document_identity_date							as [icdate]
	--			,s.students_document_identity_issued						as [icdepartment]
	--			--,isnull((case when dbo.getDiplomTypeForStudent(s.students_id,1)=1 then 1 else 0 end),0)				as [hasExcellent]
	--			,s.status													as [isStudent]
	--			--,ROUND(dbo.getGPAForStudent(s.students_id, 0, 0),2)			as [GPA]
	--			,s.settlement_status_id										as [residence]
	--			,s.citizenship_id											as [sitizenshipID]
	--			,s.students_need_hostel										as [dorm_state]
	--			,s.country_id												as [fromid]
	--			,s.region_id												AS [local]
	--			,s.region_id												as [city]
	--			,s.specialization_id										as [specializationID]
	--			,s.admission_reason_id										as [altynBelgi]
	--		FROM deleted s WHERE s.status=1
	--	) AS tab WHERE tab.StudentID NOT IN (SELECT s.student_id FROM platonus_univer_students s) AND tab.isStudent=1
	--	GROUP BY tab.StudentID
	--	HAVING COUNT(*)>1
	--END
	
	--IF EXISTS(SELECT * FROM inserted i JOIN deleted d ON i.students_id=d.students_id AND d.status=1 AND i.status<>1)
	--BEGIN
	--	INSERT INTO platonus_univer_students(student_id,command)
	--	SELECT DISTINCT students_id,'delete' FROM inserted i 
	--	WHERE i.students_id NOT IN (SELECT s.student_id FROM platonus_univer_students s) AND i.status<>1
	--END
END
go

