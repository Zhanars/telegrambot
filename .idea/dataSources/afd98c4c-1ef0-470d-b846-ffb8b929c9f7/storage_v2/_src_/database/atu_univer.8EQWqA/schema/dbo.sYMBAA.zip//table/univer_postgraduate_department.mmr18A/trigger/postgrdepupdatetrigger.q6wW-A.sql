-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[postGrDepUpdateTrigger]
   ON  [dbo].[univer_postgraduate_department]  
   AFTER UPDATE
AS 
BEGIN
SET NOCOUNT ON;	
	DECLARE @pi int
	DECLARE @st int	
	DECLARE insCursor cursor 
		FOR SELECT personal_id, status FROM inserted	
	IF UPDATE(status)
	BEGIN
		OPEN insCursor
		FETCH NEXT FROM insCursor INTO @pi, @st
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF(@st=1)
				EXEC dbo.personalSetAccess @pi, 'POSTGRADUATE_DEPART'
			ELSE
				EXEC dbo.personalDeleteAccess @pi, 'POSTGRADUATE_DEPART'
				
			FETCH NEXT FROM insCursor INTO @pi, @st
		END
		CLOSE insCursor
	END
END
go

