-- =============================================
-- Author:		Twice
-- Create date: 31.01.2012
-- Description: Получить количество подготовленных и представленных потенциальным инвесторам ТЭО, ФЭО, бизнес-планов - в разрезе кафедр
-- =============================================
CREATE FUNCTION IP_NIR_getInvestorsBusinessPlan_Count_ByChairId_DESC
(
	@chairId int,
	@year int
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @Result NVARCHAR(MAX)

SELECT @Result = N''

-- Return the result of the function
RETURN @Result

END
go

