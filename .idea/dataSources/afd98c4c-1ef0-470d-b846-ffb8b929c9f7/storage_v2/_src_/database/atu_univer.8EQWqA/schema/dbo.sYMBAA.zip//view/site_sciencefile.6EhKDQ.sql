
CREATE VIEW [dbo].[site_scienceFile]
AS
SELECT     fileInfo_id, status, filePrefix, path, serverFileName, showName, size, uploadDate, uploadedUser_id, downloadCount, lastDownloadDate
FROM         DBScience.dbo.FileInfos
where status!=2


go

