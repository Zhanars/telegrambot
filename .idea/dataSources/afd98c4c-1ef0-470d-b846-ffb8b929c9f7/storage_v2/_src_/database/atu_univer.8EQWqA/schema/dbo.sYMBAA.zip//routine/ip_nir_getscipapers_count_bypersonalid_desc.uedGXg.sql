-- =============================================
-- Author:		Twice
-- Create date: 31.01.2012
-- Description: Получить количество публикаций (имеется ввиду статьи) (1 - в казахстанских изданиях по МОН РК, 2- ближнее зарубежье, 3 - дальнее зарубежье) - в разрезе сотрудника
-- =============================================
CREATE FUNCTION [dbo].[IP_NIR_getSciPapers_Count_ByPersonalId_DESC]
(
	@personalId int,
	@year int,
	@editionTypeId int
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @Result NVARCHAR(MAX)
DECLARE @PaperStr NVARCHAR(MAX)
DECLARE @ThesisStr NVARCHAR(MAX)
-- ==================================== если ККСОН
IF (@editionTypeId = 1)
BEGIN
	SELECT @Result = COALESCE(@Result + ';\n\n', '') + 
		ISNULL(N'Статья\nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en +
		N'\nЖурнал:' + sj.name, '')
		--AS [description]
	FROM 
		DBScience.dbo.Papers p,
		DBScience.dbo.L_Person_Paper_Authors a,
		DBScience.dbo.SciJournals sj
	WHERE
	-- статья не архивирована
	p.status != 2 AND
	-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
	sj.sciJournal_id = p.periodicEdition_id AND
	p.periodicEditionType_id = 1 AND
	-- журнал должен быть рекомендуемый ККСОН
	sj.recommendedByKKSON = 1 AND
	-- статья этого года
	p.yearPublication in (@year, @year + 1) AND
	-- статья этого автора (ППС, потому personType = 1)
	p.paper_id = a.paper_id AND
	a.personType = 1 AND 
	a.person_id = @personalId AND
	p.paper_id NOT IN 
			(
				select p2.paper_id
				FROM 
					DBScience.dbo.Papers p2,
					DBScience.dbo.L_Person_Paper_Authors a,
					DBScience.dbo.SciJournals sj,
					DBScience.dbo.L_SciJournal_IFRatingAgencies sip
				WHERE
				-- статья не архивирована
				p2.status != 2 AND
				-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
				sj.sciJournal_id = p2.periodicEdition_id AND
				p2.periodicEditionType_id = 1 AND
				-- импакт факторы, принадлежащие этой статье должны относиться к Томсон Ройтерс (id = 1) 
				-- и быть > 0
				sip.sciJournal_id = sj.sciJournal_id AND
				sip.IFRatingAgency_id = 1 AND sip.factorValue > 0 AND
				-- статья этого года
				p2.yearPublication in (@year, @year+1)  AND
				-- статья этого автора (ППС, потому personType = 1)
				p2.paper_id = a.paper_id AND
				a.personType = 1 AND 
				a.person_id = @personalId
				UNION
				SELECT p3.paper_id
				FROM 
					DBScience.dbo.Papers p3,
					DBScience.dbo.L_Person_Paper_Authors a,
					DBScience.dbo.SciJournals sj
				WHERE
				-- статья не архивирована
				p3.status != 2 AND
				-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
				sj.sciJournal_id = p.periodicEdition_id AND
				p3.periodicEditionType_id = 1 AND
				-- журнал должен иметь галочку "относится к scopus"
				sj.indexedByScopus = 1 AND
				-- статья этого года
				p3.yearPublication in (@year, @year+1) AND
				-- статья этого автора (ППС, потому personType = 1)
				p3.paper_id = a.paper_id AND
				a.personType = 1 AND 
				a.person_id = @personalId
			) 
END
-- ==================================== если издание или мероприятие ближнего зарубежья
IF (@editionTypeId = 2)
BEGIN
	SELECT @PaperStr = COALESCE(@PaperStr + ';\n\n', '') + 
		ISNULL(N'Статья\nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en +
		N'\nЖурнал:' + sj.name + N'\nСтрана журнала:' + c.name_ru, '')
		--AS [description]
	FROM 
		DBScience.dbo.Papers p,
		DBScience.dbo.L_Person_Paper_Authors a,
		DBScience.dbo.SciJournals sj,
		DBScience.dbo.Countries c
	WHERE
	-- статья не архивирована
	p.status != 2 AND
	-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
	sj.sciJournal_id = p.periodicEdition_id AND
	p.periodicEditionType_id = 1 AND
	-- страна журнала должна быть в ближнем зарубежье и не текущей (Казахстан)
	sj.journalCountry_id = c.country_id AND
	c.foreignType in (0, 1) AND c.countryCurrent = 0 AND
	-- статья этого года
	p.yearPublication in (@year, @year + 1) AND
	-- статья этого автора (ППС, потому personType = 1)
	p.paper_id = a.paper_id AND
	a.personType = 1 AND 
	a.person_id = @personalId AND
	p.paper_id NOT IN 
			(
				select p2.paper_id
				FROM 
					DBScience.dbo.Papers p2,
					DBScience.dbo.L_Person_Paper_Authors a,
					DBScience.dbo.SciJournals sj,
					DBScience.dbo.L_SciJournal_IFRatingAgencies sip
				WHERE
				-- статья не архивирована
				p2.status != 2 AND
				-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
				sj.sciJournal_id = p2.periodicEdition_id AND
				p2.periodicEditionType_id = 1 AND
				-- импакт факторы, принадлежащие этой статье должны относиться к Томсон Ройтерс (id = 1) 
				-- и быть > 0
				sip.sciJournal_id = sj.sciJournal_id AND
				sip.IFRatingAgency_id = 1 AND sip.factorValue > 0 AND
				-- статья этого года
				p2.yearPublication in (@year, @year+1)  AND
				-- статья этого автора (ППС, потому personType = 1)
				p2.paper_id = a.paper_id AND
				a.personType = 1 AND 
				a.person_id = @personalId
				UNION
				SELECT p3.paper_id
				FROM 
					DBScience.dbo.Papers p3,
					DBScience.dbo.L_Person_Paper_Authors a,
					DBScience.dbo.SciJournals sj
				WHERE
				-- статья не архивирована
				p3.status != 2 AND
				-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
				sj.sciJournal_id = p.periodicEdition_id AND
				p3.periodicEditionType_id = 1 AND
				-- журнал должен иметь галочку "относится к scopus"
				sj.indexedByScopus = 1 AND
				-- статья этого года
				p3.yearPublication in (@year, @year+1) AND
				-- статья этого автора (ППС, потому personType = 1)
				p3.paper_id = a.paper_id AND
				a.personType = 1 AND 
				a.person_id = @personalId
			) 
	
	SELECT @ThesisStr = 
		COALESCE(@ThesisStr + ';\n\n', '') + 
				ISNULL(tp.name_ru + N' KZ: ' +   th.name_kz + N'\nRU: ' + th.name_ru + N'\nEN: ' + th.name_en +
				N'\nМероприятие: ' + st.name_ru + N' KZ: '+se.name_kz + N'\nRU: ' +
				se.name_ru + N'\EN: ' + se.name_en + N'\nСтрана:' + c.name_ru, '')
	FROM
		DBScience.dbo.Thesises th,
		DBScience.dbo.L_Person_Thesis_Authors a,
		DBScience.dbo.SciEvents se,
		DBScience.dbo.SciEventTypes st,
		DBScience.dbo.ThesisTypes tp,
		DBScience.dbo.Countries c
	WHERE
		-- тезис не архивирован
		th.status != 2 AND
		-- тезис этого автора (ППС, потому personType = 1)
		th.thesis_id = a.thesis_id AND
		a.personType = 1 AND 
		a.person_id = @personalId AND
		tp.thesisType_id = th.thesisType_id AND
		-- мероприятие этого тезиса
		se.sciEvent_id = th.sciEvent_id AND
		-- мероприятие международное (id=5)
		se.sciEventForm_id = 5 AND st.sciEventType_id = se.sciEventType_id AND
		-- страна мероприятия должна быть ближнего зарубежья и не текущей
		se.country_id = c.country_id AND c.foreignType in (0, 1) AND c.countryCurrent = 0 AND
		-- тезис этого года (по мероприятию)
		YEAR(se.eventStart) in (@year, @year + 1)
		
SELECT @Result = ISNULL(@PaperStr,'') + N'\n\n' + ISNULL(@ThesisStr,'')

END
-- ==================================== если издание или мероприятие ближнего зарубежья
IF (@editionTypeId = 3)
BEGIN
	SELECT @PaperStr = COALESCE(@PaperStr + ';\n\n', '') + 
		ISNULL(N'Статья\nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en +
		N'\nЖурнал:' + sj.name + N'\nСтрана журнала:' + c.name_ru, '')
		--AS [description]
	FROM 
		DBScience.dbo.Papers p,
		DBScience.dbo.L_Person_Paper_Authors a,
		DBScience.dbo.SciJournals sj,
		DBScience.dbo.Countries c
	WHERE
	-- статья не архивирована
	p.status != 2 AND
	-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
	sj.sciJournal_id = p.periodicEdition_id AND
	p.periodicEditionType_id = 1 AND
	-- страна журнала должна быть в ближнем зарубежье и не текущей (Казахстан)
	sj.journalCountry_id = c.country_id AND
	c.foreignType in (2) AND
	-- статья этого года
	p.yearPublication in (@year, @year + 1) AND
	-- статья этого автора (ППС, потому personType = 1)
	p.paper_id = a.paper_id AND
	a.personType = 1 AND 
	a.person_id = @personalId AND
	p.paper_id NOT IN 
			(
				select p2.paper_id
				FROM 
					DBScience.dbo.Papers p2,
					DBScience.dbo.L_Person_Paper_Authors a,
					DBScience.dbo.SciJournals sj,
					DBScience.dbo.L_SciJournal_IFRatingAgencies sip
				WHERE
				-- статья не архивирована
				p2.status != 2 AND
				-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
				sj.sciJournal_id = p2.periodicEdition_id AND
				p2.periodicEditionType_id = 1 AND
				-- импакт факторы, принадлежащие этой статье должны относиться к Томсон Ройтерс (id = 1) 
				-- и быть > 0
				sip.sciJournal_id = sj.sciJournal_id AND
				sip.IFRatingAgency_id = 1 AND sip.factorValue > 0 AND
				-- статья этого года
				p2.yearPublication in (@year, @year+1)  AND
				-- статья этого автора (ППС, потому personType = 1)
				p2.paper_id = a.paper_id AND
				a.personType = 1 AND 
				a.person_id = @personalId
				UNION
				SELECT p3.paper_id
				FROM 
					DBScience.dbo.Papers p3,
					DBScience.dbo.L_Person_Paper_Authors a,
					DBScience.dbo.SciJournals sj
				WHERE
				-- статья не архивирована
				p3.status != 2 AND
				-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
				sj.sciJournal_id = p.periodicEdition_id AND
				p3.periodicEditionType_id = 1 AND
				-- журнал должен иметь галочку "относится к scopus"
				sj.indexedByScopus = 1 AND
				-- статья этого года
				p3.yearPublication in (@year, @year+1) AND
				-- статья этого автора (ППС, потому personType = 1)
				p3.paper_id = a.paper_id AND
				a.personType = 1 AND 
				a.person_id = @personalId
			) 
	
	SELECT @ThesisStr = 
		COALESCE(@ThesisStr + ';\n\n', '') + 
				ISNULL(tp.name_ru + N' KZ: ' +   th.name_kz + N'\nRU: ' + th.name_ru + N'\nEN: ' + th.name_en +
				N'\nМероприятие: ' + st.name_ru + N' KZ: '+se.name_kz + N'\nRU: ' +
				se.name_ru + N'\EN: ' + se.name_en + N'\nСтрана:' + c.name_ru, '')
	FROM
		DBScience.dbo.Thesises th,
		DBScience.dbo.L_Person_Thesis_Authors a,
		DBScience.dbo.SciEvents se,
		DBScience.dbo.SciEventTypes st,
		DBScience.dbo.ThesisTypes tp,
		DBScience.dbo.Countries c
	WHERE
		-- тезис не архивирован
		th.status != 2 AND
		-- тезис этого автора (ППС, потому personType = 1)
		th.thesis_id = a.thesis_id AND
		a.personType = 1 AND 
		a.person_id = @personalId AND
		tp.thesisType_id = th.thesisType_id AND
		-- мероприятие этого тезиса
		se.sciEvent_id = th.sciEvent_id AND
		-- мероприятие международное (id=5)
		se.sciEventForm_id = 5 AND st.sciEventType_id = se.sciEventType_id AND
		-- страна мероприятия должна быть ближнего зарубежья и не текущей
		se.country_id = c.country_id AND c.foreignType in (2)AND
		-- тезис этого года (по мероприятию)
		YEAR(se.eventStart) in (@year, @year + 1)
		
SELECT @Result = ISNULL(@PaperStr,'') + N'\n\n' + ISNULL(@ThesisStr,'')
END


-- Return the result of the function
RETURN @Result

END
go

