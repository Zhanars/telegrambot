-- =============================================
-- Author:		sasha
-- Create date: 2018-06-01 
-- Description:	Автоопределение уровня структурных подразделений
-- =============================================
CREATE TRIGGER [dbo].[structDivLevelUpd]
   ON  [dbo].univer_structure_division_1c
   After UPDATE,INSERT 
AS 
BEGIN	

	SET NOCOUNT ON;
	
	IF EXISTS(SELECT * FROM inserted) and (UPDATE(structure_division_ext))
	BEGIN
	declare @level int;
	UPDATE s
    SET s.structure_division_level = isnull((select ss.structure_division_level+1 from univer_structure_division_1c ss where ss.structure_division_id=(select structure_division_ext from inserted)),0)
    FROM [dbo].univer_structure_division_1c s
    where s.structure_division_id in (select structure_division_id from inserted)
		
		
	END	
END
go

