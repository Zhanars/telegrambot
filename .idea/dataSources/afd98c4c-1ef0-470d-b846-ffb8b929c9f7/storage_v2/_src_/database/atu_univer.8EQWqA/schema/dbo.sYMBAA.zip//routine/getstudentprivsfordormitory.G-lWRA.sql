


-- =============================================
-- Author:		Ruslan
-- Create date: 31.07.2017
-- Description: Получить льготы студента с различным приоритетом для заселения в общежитие в виде строки
-- =============================================
CREATE FUNCTION [dbo].[GetStudentPrivsForDormitory]
(
	@studentId int,
	@priority int
)

-----------------------------------------------------------------
RETURNS NVARCHAR(1)
AS
BEGIN
DECLARE @Result NVARCHAR(1)

-- ==================================== 
BEGIN
    /**************************************************************************************/
    DECLARE @propTable table (pid int);
    INSERT INTO @propTable(pid)
    SELECT s.properties_id
    FROM univer_students_properties s,univer_student_properties_link spl where s.properties_id = spl.properties_id AND s.status=1 AND spl.students_id=@studentId 

	IF (@priority = 3)
		SET @Result = case when [dbo].[IsStudentExcellent](@studentId)=1 then N'+' else N'-' end 
	ELSE IF (@priority = 5)
	SELECT @Result = case when (SELECT st.citizenship_id FROM univer_students st WHERE st.students_id = @studentId) != 1 then N'+' else N'-' end 
	ELSE
	SELECT @Result = case when EXISTS(SELECT * FROM @propTable t
	WHERE ((t.pid IN (1) AND @priority = 1) OR (t.pid IN (15, 16, 17, 19, 91) AND @priority = 2) OR (t.pid IN (106, 107, 108, 109, 110) AND @priority = 4)
	OR (t.pid IN (102) AND @priority = 6))
	) then N'+' else N'-' end 
			
END

RETURN @Result
END


go

