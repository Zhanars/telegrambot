-- =============================================
-- Author:		@LFER, Baton
-- Create date: 2009-09-07
-- Description:	Добавление права доступа сотруднику при добавлении строки
-- =============================================
CREATE TRIGGER [dbo].[viceDekanInsertTrigger] ON  [dbo].[univer_vice_dekan] AFTER INSERT
AS 
BEGIN	
	SET NOCOUNT ON;	
	DECLARE @pi int
	
	DECLARE insCursor cursor 
		FOR SELECT personal_id FROM inserted WHERE status=1
		
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @pi
	WHILE @@FETCH_STATUS = 0
	BEGIN
		exec dbo.personalSetAccess @pi, 'VICE_DEKAN'
		FETCH NEXT FROM insCursor INTO @pi;
	END
	CLOSE insCursor
END
go

