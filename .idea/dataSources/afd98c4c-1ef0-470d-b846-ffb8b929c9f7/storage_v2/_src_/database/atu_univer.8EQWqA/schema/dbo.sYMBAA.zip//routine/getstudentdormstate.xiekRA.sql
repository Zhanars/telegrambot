

-- =============================================
-- Author:		Ruslan
-- Create date: 20.06.2018
-- Description:	Определить статус общежития (dorm_state, Платонус) для студента 
-- =============================================
CREATE FUNCTION [dbo].[getStudentDormState]
(
 @studentId int
)
RETURNS int
AS
BEGIN
	DECLARE @ret int=0;
	DECLARE @needHostel bit;
	SELECT TOP 1 @needHostel = students_need_hostel FROM univer_students WHERE students_id = @studentId

	if (@needHostel = 0)  
		begin
			set @ret = 1;
		end;

	if (@needHostel = 1) 
		begin
			if (NOT EXISTS(SELECT 1 from univer_student_dormitory_room_link sdrl WHERE student_id = @studentId AND year = YEAR(DATEADD(month,-7,GETDATE())))) 
				begin
					set @ret = 2;
				end;
			else
				begin
					set @ret = 3;
				end;
		end;

	RETURN isnull(@ret,0);
END


go

