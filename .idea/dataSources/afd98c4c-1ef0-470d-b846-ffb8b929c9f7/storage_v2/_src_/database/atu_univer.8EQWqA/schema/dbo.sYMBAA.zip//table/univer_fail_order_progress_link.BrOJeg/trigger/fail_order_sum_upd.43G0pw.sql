-- =============================================
-- Author:		sasha
-- Create date: 02.06.2015
-- Description:	запись истории для заявки
-- =============================================
CREATE TRIGGER [dbo].[fail_order_sum_upd]
   ON  [dbo].[univer_fail_order_progress_link] 
   AFTER update
AS 
BEGIN
	SET NOCOUNT ON;
    IF UPDATE(cost)
	BEGIN
    declare @id int;
   
    DECLARE insCursor cursor 
		FOR SELECT fail_order_id FROM inserted 				
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @id
	WHILE @@FETCH_STATUS = 0
	BEGIN	
    insert into univer_fail_order_history(fail_order_id, status, user_id, date_change, comments) values (
    @id,(select status from univer_fail_order where fail_order_id=@id),-1,GETDATE(),N'Изменение суммы');    
	FETCH NEXT FROM insCursor INTO @id
	END
	CLOSE insCursor
     end
END
go

