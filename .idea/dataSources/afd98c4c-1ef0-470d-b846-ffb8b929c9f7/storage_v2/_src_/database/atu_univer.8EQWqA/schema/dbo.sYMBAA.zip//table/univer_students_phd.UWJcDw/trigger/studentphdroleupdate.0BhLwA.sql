-- =============================================
-- Author:		Baton
-- Create date: 2009-09-22
-- Description:	Удаление или добавлении права доступа при изменении бакалавра
-- =============================================
CREATE TRIGGER [dbo].[studentPhdRoleUpdate] ON  [dbo].[univer_students_phd]
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	IF UPDATE(students_id)	
	BEGIN
	
		DECLARE @userId int
		DECLARE @studId int
		
		DECLARE delCursor cursor 
			FOR SELECT students_id FROM deleted
		
			OPEN delCursor
			FETCH NEXT FROM delCursor INTO @studId
			WHILE @@FETCH_STATUS = 0
			BEGIN
				SELECT @userId = user_id FROM univer_students WHERE students_id = @studId
				EXEC dbo.usersDeleteAccess @userId, 'STUDENT_PHD'			
				FETCH NEXT FROM delCursor INTO @userId
			END
		CLOSE delCursor
		
		DECLARE insCursor cursor 
			FOR SELECT students_id  FROM inserted
			OPEN insCursor
			FETCH NEXT FROM insCursor INTO @studId
			WHILE @@FETCH_STATUS = 0
			BEGIN			
				SELECT @userId = user_id FROM univer_students WHERE students_id = @studId
				EXEC dbo.usersSetAccess @userId, 'STUDENT_PHD'
				FETCH NEXT FROM insCursor INTO @studId
			END
		CLOSE insCursor
		
	END

END
go

