-- =============================================
-- Author:		sasha
-- Create date: 28.01.2015
-- Description:	обновление названий полей формы авторизации
-- =============================================
CREATE PROCEDURE [dbo].[UpdAuthForm] 	
AS
BEGIN

	SET NOCOUNT ON;
     declare @num int;declare @rnum real;
     set @rnum=(select random from RANDOM);
		set @num=ROUND((@rnum* 25),0)+5;
     declare @login nvarchar(250);
     set @login=N'L'+dbo.getRandString(@num); 
     declare @pass nvarchar(250);    
     set @rnum=(select random from RANDOM);
		set @num=ROUND((@rnum* 25),0)+5;
     set @pass=N'P'+dbo.getRandString(@num);
      
     declare @rkey nvarchar(250);    
     set @rnum=(select random from RANDOM);
		set @num=ROUND((@rnum* 50),0)+5;
     set @rkey=dbo.getRandString(@num);
     set @pass=substring(@pass,0,len(@pass)/2)+N'password'+substring(@pass,len(@pass)/2,len(@pass)/2);
     if (exists(select * from univer_auth_form))
     update univer_auth_form set login_name=@login, password_name=@pass, date=GETDATE(), rand_key=@rkey
     else
     insert into univer_auth_form(login_name,password_name,date,rand_key)values (@login,@pass,GETDATE(),@rkey);
END
go

