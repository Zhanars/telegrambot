

-- =============================================
-- Author:		Yerlan
-- Create date: 28.09.2016
-- Description:	Can this history of settling student in dormitory be send to 1C
-- =============================================
CREATE FUNCTION [dbo].[1C_CanSendHistoryOfDormitorySettling]
(
 @studentId int,
 @orderType int,
 @orderDate datetime,
 @dormitoryId int,
 @roomSize int=0
)
RETURNS int
AS
BEGIN
	DECLARE @ret int=0;
	DECLARE @orderSts2 int=2;
	DECLARE @orderSts4 int=4;
	DECLARE @orderSts5 int=5;
	DECLARE @yesterday datetime,@tomorrow datetime;
	SET @yesterday = DATEADD(DAY,-1,@orderDate);
	SET @tomorrow = DATEADD(DAY,1,@orderDate);

	DECLARE @existHistoryOfUnsettle int=0, @existHistoryOfSettle int=0;
	IF (@orderType=1/*SETTLE*/)
	BEGIN
		set @existHistoryOfUnsettle = (
			SELECT TOP 1 h.history_id
			FROM univer_student_dormitory_room_settle_history h
			WHERE h.order_date=@yesterday AND h.order_type=3/*UNSETTLE*/ AND h.order_status IN (@orderSts2, @orderSts4, @orderSts5)/*DONE*/ AND h.student_id=@studentId --AND h.dormitory_id=@dormitoryId
		);
		
		IF (@existHistoryOfUnsettle>0)
		BEGIN
			set @existHistoryOfSettle = (
				SELECT TOP 1 h.history_id
				FROM univer_student_dormitory_room_settle_history h, univer_students st, univer_dormitory_rooms dr
				WHERE st.students_id=h.student_id AND dr.dormitory_id=h.dormitory_id AND h.order_status IN (@orderSts2, @orderSts4, @orderSts5)/*DONE*/ AND dr.status=1 AND h.order_date<@yesterday AND h.order_type=@orderType AND st.students_id=@studentId 
						AND h.dormitory_room_id=dr.dormitory_room_id AND (h.dormitory_room_size<>@roomSize OR h.dormitory_id<>@dormitoryId/*changes in roomSize or in dormitory*/)
				ORDER BY h.order_date DESC
			);
			IF (@existHistoryOfSettle>0)
			BEGIN
				set @ret = 1;
			END
		END;
		ELSE
		BEGIN
			SET @ret = 1;
		END;
	END;
	ELSE IF (@orderType=3/*UNSETTLE*/)
	BEGIN
		IF EXISTS(SELECT * FROM univer_student_dormitory_room_settle_history h, univer_students st, univer_dormitory_rooms dr
					WHERE st.students_id=h.student_id AND dr.dormitory_id=h.dormitory_id AND h.order_status IN (@orderSts2, @orderSts4, @orderSts5)/*DONE*/ AND dr.status=1 AND h.order_date=@tomorrow AND h.order_type=1/*SETTLE*/ AND st.students_id=@studentId 
						AND h.dormitory_room_id=dr.dormitory_room_id)
		BEGIN
			set @existHistoryOfSettle = (
				SELECT COUNT(*) FROM (
					SELECT DISTINCT t.dormitory_id, t.dormitory_room_size, t.stage_id
					FROM (
					SELECT h.dormitory_id, h.dormitory_room_size, st.stage_id
					FROM univer_student_dormitory_room_settle_history h, univer_students st, univer_dormitory_rooms dr
					WHERE st.students_id=h.student_id AND dr.dormitory_id=h.dormitory_id AND dr.status=1 AND h.order_date=@tomorrow AND h.order_type=1/*SETTLE*/ AND st.students_id=@studentId 
						AND h.dormitory_room_id=dr.dormitory_room_id AND h.order_status IN (@orderSts2, @orderSts4, @orderSts5)/*DONE*/
					UNION 
					SELECT TOP 1 h.dormitory_id, h.dormitory_room_size, st.stage_id
					FROM univer_student_dormitory_room_settle_history h, univer_students st, univer_dormitory_rooms dr
					WHERE st.students_id=h.student_id AND dr.dormitory_id=h.dormitory_id AND dr.status=1 AND h.order_date<@orderDate AND h.order_type=1/*SETTLE*/ AND st.students_id=@studentId 
						AND h.dormitory_room_id=dr.dormitory_room_id AND h.order_status IN (@orderSts2, @orderSts4, @orderSts5)/*DONE*/
					ORDER BY h.order_date DESC
					) t
				) AS t
			);
			IF (@existHistoryOfSettle>1)
			BEGIN
				SET @ret = 1;
			END;
		END
		ELSE
		BEGIN
			SET @ret = 1;
		END;
	END;

	RETURN isnull(@ret,0)

END


go

