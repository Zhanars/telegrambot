

-- =============================================
-- Author:		Sasha
-- Create date: 06.10.2014
-- Description:	Суммарная оценка по прогрессу
-- =============================================
CREATE FUNCTION [dbo].[getTotalForProgressAddit] 
(
 @progressId int
)
RETURNS float
AS
BEGIN
	DECLARE @ret float

	select @ret=sum(ctl.control_portion * case c.control_title when N'' then p.additsem_progress_result when N'_rk1' then p.additsem_progress_result_rk1 when N'_rk2' then p.additsem_progress_result_rk2 when N'_mt' then p.additsem_progress_result_mt end) from univer_additsem_progress p, univer_additsem_position pp, univer_controll_type ct, univer_controll_type_control_link ctl, univer_control c where pp.additsem_position_id=p.additsem_position_id and pp.controll_type_id=ct.controll_type_id and ct.controll_type_id=ctl.controll_type_id and ctl.control_id=c.control_id and p.additsem_progress_id=@progressId;

	RETURN isnull(@ret,0)

END


go

