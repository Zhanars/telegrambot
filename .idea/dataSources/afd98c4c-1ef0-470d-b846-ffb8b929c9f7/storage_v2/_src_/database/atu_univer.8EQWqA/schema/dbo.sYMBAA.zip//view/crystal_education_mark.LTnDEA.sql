CREATE VIEW dbo.crystal_education_mark
AS
SELECT     s.students_zachetka AS student, p.subject_id, N'' AS day, p.semestr AS term, p.academ_year AS year, N'AT1' AS mark_type, p.progress_result_rk1 AS mark
FROM         dbo.univer_students s, univer_progress p
WHERE     s.students_id = p.student_id AND s.status = 1 AND p.status = 1 AND p.controll_type_id IN (2, 3, 4) AND s.education_form_id = 1
UNION
SELECT     s.students_zachetka AS student, p.subject_id, N'' AS day, p.semestr AS term, p.academ_year AS year, N'AT2' AS mark_type, p.progress_result_rk2 AS mark
FROM         dbo.univer_students s, univer_progress p
WHERE     s.students_id = p.student_id AND s.status = 1 AND p.status = 1 AND p.controll_type_id IN (2, 3, 4) AND s.education_form_id = 1
UNION
SELECT     s.students_zachetka AS student, p.subject_id, N'' AS day, p.semestr AS term, p.academ_year AS year, N'SMB' AS mark_type, p.progress_result_rk1 AS mark
FROM         dbo.univer_students s, univer_progress p
WHERE     s.students_id = p.student_id AND s.status = 1 AND p.status = 1 AND p.controll_type_id IN (7, 30, 31) AND s.education_form_id = 1
UNION
SELECT     s.students_zachetka AS student, p.subject_id, N'' AS day, p.semestr AS term, p.academ_year AS year, N'EXB' AS mark_type, p.progress_result AS mark
FROM         dbo.univer_students s, univer_progress p
WHERE     s.students_id = p.student_id AND s.status = 1 AND p.status = 1 AND p.controll_type_id IN (2, 3, 4, 30, 31) AND s.education_form_id = 1
go

