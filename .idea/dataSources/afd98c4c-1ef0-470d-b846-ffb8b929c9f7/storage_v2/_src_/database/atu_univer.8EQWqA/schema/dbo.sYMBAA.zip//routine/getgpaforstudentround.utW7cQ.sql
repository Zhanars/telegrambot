-- =============================================
-- Author:		Sasha
-- Create date: 13.05.2010
-- Description:	Подсчет GPA для студента (@maxSem-семестр, до которого нужно считать GPA, если 0, то считается за все семестры; @course-курс, за который считать GPA, если 0 - то считается общее GPA)
-- =============================================
CREATE FUNCTION [dbo].[getGPAForStudentRound]
(
 @studentId int,
 @maxSem int,
 @course int,
 @roundDigitCount int
)
RETURNS float
AS
BEGIN
	DECLARE @ret float

	SELECT @ret=dbo.getGPAForStudent(@studentId,@maxSem,@course);
	
	RETURN isnull(ROUND(@ret, @roundDigitCount),0)

END


go

