

-- =============================================
-- Author:		Yerlan
-- Create date: 18.01.2013
-- Description: Просуммировать или получить ср. значение для показателей Кафедр или Факультетов и сохранить
-- =============================================
CREATE procedure [dbo].[IP_CalcSumOrAVGOfAnketIndicators]
(
	@personalId int,
	@categoryId int,
	@year int,
	@semester int,
	@planPeriod bit,
	@factPeriod bit
)
AS
BEGIN
DECLARE @Res NVARCHAR(MAX);
DECLARE @strucDivId INT
-- ================================================= ЕСЛИ КАТЕГОРИЯ КАФЕДРАЛЬНАЯ
IF (@categoryId=2)
BEGIN
	SELECT @strucDivId =  c.structure_division_id 
	FROM univer_head_chair hc, univer_chair c WHERE hc.chair_id = c.chair_id AND hc.status=1 AND c.status=1 AND hc.personal_id = @personalId
END
-- ================================================= ЕСЛИ КАТЕГОРИЯ ФАКУЛЬТЕТСКАЯ
ELSE IF (@categoryId=1)
BEGIN
	SELECT @strucDivId =  f.structure_division_id 
	FROM univer_dekan d, univer_faculty f WHERE d.faculty_id = f.faculty_id AND d.status=1 AND f.status=1 AND d.personal_id = @personalId
END
SET @Res = '';
DECLARE @subIndPlanId INT, @indPlanId INT, @indPlanCalcType INT, @indPlanCodeId INT;
--SET CURSOR_CLOSE_ON_COMMIT OFF;
--BEGIN TRANSACTION;
	DECLARE indicatorId CURSOR LOCAL FAST_FORWARD FOR
		SELECT i.ind_plan_indicator_id, i.ind_plan_code_id, 1--i.ind_plan_indicator_calc_type
		FROM univer_ind_plan_indicator i 
		WHERE i.status=1 AND i.ind_plan_category_id=@categoryId
		ORDER BY i.ind_plan_indicator_id;
	OPEN indicatorId;
	FETCH NEXT FROM indicatorId INTO @indPlanId, @indPlanCodeId, @indPlanCalcType;
	WHILE @@FETCH_STATUS=0
	BEGIN
		PRINT ' @indPlanId='+Convert(nvarchar(10),@indPlanId)+' @indPlanCodeId='+Convert(nvarchar(10),@indPlanCodeId);
		DECLARE @valueF REAL,@valueP REAL;
		DECLARE @valueDescF NVARCHAR(MAX),@valueDescP NVARCHAR(MAX);
		SELECT @subIndPlanId = 
		(SELECT TOP 1 i.ind_plan_indicator_id 
			FROM univer_ind_plan_indicator i 
			WHERE i.status=1 AND i.ind_plan_code_id = @indPlanCodeId 
				AND i.ind_plan_category_id = (CASE WHEN @categoryId=2 THEN 3 WHEN @categoryId=1 THEN 2 END) AND year<=@year 
			ORDER BY year DESC
		)
		IF (@subIndPlanId IS NOT NULL)
		BEGIN
		PRINT '@subIndPlanId='+Convert(nvarchar(10),@subIndPlanId)+' @indPlanCalcType='+Convert(nvarchar(10),@indPlanCalcType)+
		' @categoryId='+Convert(nvarchar(10),@categoryId)+' @strucDivId='+Convert(nvarchar(10),@strucDivId)+
		' @year='+Convert(nvarchar(10),@year)+' @semester='+Convert(nvarchar(10),@semester);
		IF (@planPeriod=1)
		BEGIN
		SET @valueP = dbo.IP_CalcSumOrAVGForIndicator(@subIndPlanId, @indPlanCalcType, @categoryId, @strucDivId, @year, 1);
		SET @valueDescP = dbo.IP_CalcSumOrAVGForIndicatorDESC(@subIndPlanId, @categoryId, @strucDivId, @year, 1);
		END
		IF (@factPeriod=1)
		BEGIN
		SET @valueF = dbo.IP_CalcSumOrAVGForIndicator(@subIndPlanId, @indPlanCalcType, @categoryId, @strucDivId, @year, 2);
		SET @valueDescF = dbo.IP_CalcSumOrAVGForIndicatorDESC(@subIndPlanId, @categoryId, @strucDivId, @year, 2);
		END
		PRINT N' @valueF='+Convert(nvarchar(MAX),@valueF);
		PRINT N' @valueFDesc='+@valueDescF;
		--SET @Res = N' valueF='+Convert(nvarchar(10),@valueF);
		--PRINT @Res;
		IF (EXISTS(SELECT * FROM univer_ind_plan_personal p 
					WHERE p.year = @year /*AND p.semester = @semester*/ AND p.personal_id = @personalId AND p.ind_plan_indicator_id = @indPlanId)
			)
			BEGIN
			SET @Res = @Res + ' update @valueF='+Convert(nvarchar(10),@valueF);
			END
		ELSE
			BEGIN
			SET @Res = @Res + ' INSERT @valueF='+Convert(nvarchar(10),@valueF);
			END	
		END
			--PRINT @Res;		
		FETCH NEXT FROM indicatorId INTO @indPlanId, @indPlanCodeId, @indPlanCalcType;
	END
	CLOSE indicatorId;
	DEALLOCATE indicatorId;
	PRINT @Res;
--COMMIT;
END
go

