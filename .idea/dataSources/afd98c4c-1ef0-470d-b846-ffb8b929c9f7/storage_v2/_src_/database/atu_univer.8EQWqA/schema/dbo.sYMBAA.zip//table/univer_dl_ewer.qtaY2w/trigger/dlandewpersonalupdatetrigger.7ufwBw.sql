-- =============================================
-- Author:		yerlan
-- Create date: 12.09.2011
-- Description:	Тригер на обновление статуса пользователя департамента языка и воспитательной работы
-- =============================================
CREATE TRIGGER [dbo].[dlAndEWpersonalUpdateTrigger]
   ON  [dbo].[univer_dl_ewer]
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
    DECLARE @pi int
	DECLARE @st int
	
	DECLARE insCursor cursor 
		FOR SELECT personal_id, status FROM inserted
		
	IF UPDATE(status)
	BEGIN
		OPEN insCursor
		FETCH NEXT FROM insCursor INTO @pi, @st
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF(@st=1)
				EXEC dbo.personalSetAccess @pi, 'Dl_EW'
			ELSE
				EXEC dbo.personalDeleteAccess @pi, 'Dl_EW'
				
			FETCH NEXT FROM insCursor INTO @pi, @st
		END
		CLOSE insCursor
	END
END
go

