

CREATE VIEW [dbo].[site_personal_scientific_degree_1c]
AS
SELECT     dbo.univer_personal.personal_id, dbo.univer_scientific_degree_1c.scientific_degree_name_kz, dbo.univer_scientific_degree_1c.scientific_degree_name_ru, 
                      dbo.univer_scientific_degree_1c.scientific_degree_name_en, dbo.univer_degree_area_1c.degree_area_name_kz, 
                      dbo.univer_degree_area_1c.degree_area_name_ru, dbo.univer_degree_area_1c.degree_area_name_en, dbo.univer_degree_area_1c.degree_area_short_name_kz, 
                      dbo.univer_degree_area_1c.degree_area_short_name_ru, dbo.univer_degree_area_1c.degree_area_short_name_en, 
                      dbo.univer_personal_scientific_degree_1c.personal_scientific_degree_number, univer_personal_scientific_degree_1c.personal_scientific_degree_date, dbo.univer_scientific_degree_1c.status
FROM         dbo.univer_personal_scientific_degree_1c 
			  INNER JOIN dbo.univer_scientific_degree_1c ON dbo.univer_personal_scientific_degree_1c.scientific_degree_id = dbo.univer_scientific_degree_1c.scientific_degree_id 
			  INNER JOIN dbo.univer_personal ON dbo.univer_personal_scientific_degree_1c.personal_id = dbo.univer_personal.personal_id
			  LEFT JOIN dbo.univer_degree_area_1c ON dbo.univer_degree_area_1c.degree_area_id = dbo.univer_personal_scientific_degree_1c.degree_area_id


go

