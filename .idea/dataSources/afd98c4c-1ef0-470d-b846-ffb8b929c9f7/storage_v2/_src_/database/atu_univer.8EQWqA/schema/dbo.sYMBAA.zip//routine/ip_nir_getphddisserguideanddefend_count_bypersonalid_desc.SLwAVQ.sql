-- =============================================
-- Author:		Twice
-- Create date: 31.01.2012
-- Description: Получить количество руководства над PhD-диссертациями и защит PhD-диссертации - в разрезе сотрудника
-- =============================================
CREATE FUNCTION IP_NIR_getPhdDisserGuideAndDefend_Count_ByPersonalId_DESC
(
	@personalId int,
	@year int
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @Result NVARCHAR(MAX)

SELECT @Result = N''

-- Return the result of the function
RETURN @Result

END
go

