-- =============================================
-- Author:		@LFER
-- Create date: 2009-06-25 17:22:39.300
-- Description:	Удаление соответствующего права у сотрудника при удалении строки
-- =============================================
CREATE TRIGGER [dbo].[admitcomDeleteTrigger]
   ON  [dbo].[univer_admitting_commission]
   AFTER DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @pi int
	DECLARE @st int
	
	DECLARE insCursor cursor 
		FOR SELECT personal_id FROM deleted
	
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @pi
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC dbo.personalDeleteAccess @pi, 'ADMITING_COMMISSION'
			
		FETCH NEXT FROM insCursor INTO @pi
	END
	CLOSE insCursor
END
go

