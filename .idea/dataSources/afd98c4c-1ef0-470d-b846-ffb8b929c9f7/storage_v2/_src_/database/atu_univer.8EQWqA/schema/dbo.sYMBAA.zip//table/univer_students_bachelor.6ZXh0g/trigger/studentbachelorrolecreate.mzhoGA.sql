-- =============================================
-- Author:		<Baton>
-- Create date: <27.04.2009>
-- Description:	<Тригер на присвоения "права" абитуриента при создании записи>
-- =============================================
CREATE TRIGGER [dbo].[studentBachelorRoleCreate] ON  [dbo].[univer_students_bachelor] FOR INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	-- Insert statements for trigger here
	-- Цифра доступа для данной сущности
	DECLARE @userId int
	DECLARE @studId int
	DECLARE @status int
		DECLARE insCursor cursor 
		FOR SELECT students_id FROM inserted		
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @studId
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SELECT @userId = user_id FROM univer_students WHERE students_id = @studId
		SELECT @status = status  FROM univer_students WHERE students_id = @studId
		IF (@status != 11)
			BEGIN
				exec dbo.usersSetAccess @userId, 'STUDENT_BAKALAVR'
			END
		
		FETCH NEXT FROM insCursor INTO @studId
	END
	CLOSE insCursor
END
go

