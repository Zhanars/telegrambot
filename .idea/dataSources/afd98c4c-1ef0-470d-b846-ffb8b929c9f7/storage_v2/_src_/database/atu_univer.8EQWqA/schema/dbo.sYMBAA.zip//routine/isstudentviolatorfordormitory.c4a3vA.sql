

-- =============================================
-- Author:		Yerlan
-- Create date: 23.08.2017
-- Description:	Определить является ли студент нарушителем при проживании в общежитии
-- =============================================
CREATE FUNCTION [dbo].[IsStudentViolatorForDormitory]
(
 @studentId int
)
RETURNS int
AS
BEGIN
	DECLARE @ret int=0;

	if exists(select * from univer_student_properties_link spl where spl.students_id=@studentId and spl.properties_id=104/*Naruwitel*/)
	begin
		set @ret = 1;
	end;

	RETURN isnull(@ret,0);
END
go

