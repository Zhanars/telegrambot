-- =============================================
-- Author:		Yerlan
-- Create date: 03.06.2012
-- Description: Получить количество кружков (0 - все кружки на всех уровнях, 1 - на уровне кафедры, 2- на уровне факультета, 3 - на уровне университета) - в разрезе сотрудника
-- =============================================
CREATE FUNCTION [dbo].[IP_VR_getPublicUnions_Count_ByPersonalId]
(
	@personalId int,
	@levelId int
)
RETURNS real
AS
BEGIN
DECLARE @Result real

-- ==================================== если все
IF (@levelId = 0)
BEGIN
	SELECT @Result = COUNT(*)
		FROM 
			univer_dl_ewer_public_union pu
		WHERE
		-- только не архивированные мероприятия
		pu.status = 1 AND
		-- руководитель
		(SELECT COUNT(*) FROM univer_dl_ewer_public_union_managers m WHERE m.personal_id=@personalId 
		AND m.dl_ewer_public_union_id=pu.dl_ewer_public_union_id)>0 
END

-- ==================================== если кафедра
IF (@levelId = 1)
BEGIN
	SELECT @Result = COUNT(*)
		FROM 
			univer_dl_ewer_public_union pu
		WHERE
		-- уровень кафедры
		pu.dl_ewer_public_union_level=11 AND
		-- только не архивированные мероприятия
		pu.status = 1 AND
		-- руководитель
		(SELECT COUNT(*) FROM univer_dl_ewer_public_union_managers m WHERE m.personal_id=@personalId 
		AND m.dl_ewer_public_union_id=pu.dl_ewer_public_union_id)>0 
END
-- ==================================== если факультет
IF (@levelId = 2)
BEGIN
	SELECT @Result = COUNT(*)
		FROM 
			univer_dl_ewer_public_union pu
		WHERE
		-- уровень факультет
		pu.dl_ewer_public_union_level=10 AND
		-- только не архивированные мероприятия
		pu.status = 1 AND
		-- руководитель
		(SELECT COUNT(*) FROM univer_dl_ewer_public_union_managers m WHERE m.personal_id=@personalId 
		AND m.dl_ewer_public_union_id=pu.dl_ewer_public_union_id)>0 
END
-- ==================================== если университетский кружок
IF (@levelId = 3)
BEGIN
	SELECT @Result = COUNT(*)
		FROM 
			univer_dl_ewer_public_union pu
		WHERE
		-- уровень факультет
		pu.dl_ewer_public_union_level=9 AND
		-- только не архивированные мероприятия
		pu.status = 1 AND
		-- руководитель
		(SELECT COUNT(*) FROM univer_dl_ewer_public_union_managers m WHERE m.personal_id=@personalId 
		AND m.dl_ewer_public_union_id=pu.dl_ewer_public_union_id)>0 
END
RETURN ISNULL(@Result,0)
END
go

