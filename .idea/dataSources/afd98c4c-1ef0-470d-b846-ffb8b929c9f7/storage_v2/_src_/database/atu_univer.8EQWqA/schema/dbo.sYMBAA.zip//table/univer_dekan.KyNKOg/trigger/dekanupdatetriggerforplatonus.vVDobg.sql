create TRIGGER [dbo].[dekanUpdateTriggerForPlatonus]
   ON  [dbo].[univer_dekan] 
   AFTER UPDATE,INSERT--, DELETE
AS 
BEGIN
	
	IF @@ROWCOUNT =0
    RETURN
	
	SET NOCOUNT ON;
	
	--Insert block, all new inserted subject_id will be writed as update
	IF EXISTS(SELECT * FROM inserted) AND NOT EXISTS(SELECT * FROM deleted)
	BEGIN
		--if not exists(select faculty_id from platonus_univer_faculty f, inserted i where i.faculty_id=f.faculty_id and i.status=1)
		INSERT INTO platonus_univer_faculty(faculty_id, operation)
		SELECT distinct faculty_id, 1 FROM inserted i 
		WHERE i.status=1 and i.faculty_id not in (select faculty_id from platonus_univer_faculty)
	END
	
	
	IF (UPDATE(faculty_id)) and EXISTS(SELECT * FROM inserted) AND EXISTS(SELECT * FROM deleted)
	BEGIN
		
		--delete from platonus_univer_faculty where faculty_id in (select d.faculty_id from deleted d) and operation=1
		
		insert into platonus_univer_faculty(faculty_id, operation)
		select i.faculty_id, 1 from inserted i where i.status=1
		and i.faculty_id not in (select faculty_id from platonus_univer_faculty)
		
		
	END
	
	----DELETE block, in univer there are only 2 ways: insert and delete. 
	--IF EXISTS(SELECT * FROM deleted d WHERE d.status=1) AND NOT EXISTS(SELECT * FROM inserted i)
	--BEGIN
	--	INSERT INTO platonus_univer_faculty(faculty_id,operation)
	--	SELECT faculty_id, 1 FROM deleted d 
	--	WHERE d.status=1
	--END
END
go

