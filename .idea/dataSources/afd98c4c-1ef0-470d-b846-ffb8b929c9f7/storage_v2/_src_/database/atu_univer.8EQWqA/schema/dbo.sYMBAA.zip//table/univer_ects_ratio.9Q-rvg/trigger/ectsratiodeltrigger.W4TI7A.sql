-- =============================================
-- Author:	sasha
-- Create date: 22.05.2015
-- Description:	Обновление кредитов при изименении коэффициента
-- =============================================
CREATE TRIGGER [dbo].[ectsratiodeltrigger]
   ON  [dbo].[univer_ects_ratio]
   AFTER DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @ct int
	
	DECLARE uCursor cursor 
		FOR SELECT controll_type_id FROM deleted WHERE status=1
		
	OPEN uCursor
	FETCH NEXT FROM uCursor INTO @ct
	WHILE @@FETCH_STATUS = 0
	BEGIN
		update univer_progress set progress_credit_ects=dbo.getECTSForProgress(progress_id) where controll_type_id =@ct and student_id in (select students_id from univer_students where status=1)
		FETCH NEXT FROM uCursor INTO @ct;
	END
	CLOSE uCursor
END
go

disable trigger ectsratiodeltrigger on univer_ects_ratio
go

