-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[postGrDepDeleteTrigger]
   ON  [dbo].[univer_postgraduate_department]  
   AFTER DELETE
AS 
BEGIN
	SET NOCOUNT ON;
    DECLARE @pi int
	DECLARE @st int
    DECLARE insCursor cursor 
		FOR SELECT personal_id FROM deleted
	
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @pi
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC dbo.personalDeleteAccess @pi, 'POSTGRADUATE_DEPART'
			
		FETCH NEXT FROM insCursor INTO @pi
	END
	CLOSE insCursor

END
go

