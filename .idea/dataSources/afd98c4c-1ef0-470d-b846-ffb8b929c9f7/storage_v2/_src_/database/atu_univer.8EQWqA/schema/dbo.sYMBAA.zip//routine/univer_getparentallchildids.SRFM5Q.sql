
-- =============================================
-- Author:		Yerlan
-- Create date: 01.03.2017
-- Description:	asdf
-- =============================================
create FUNCTION [dbo].[UNIVER_GetParentAllChildIDs]
(
	@parentId int
)
RETURNS table
AS
	RETURN 
	(
		WITH MyTest as
		(
		  SELECT sd.structure_division_id, sd.structure_division_ext, sd.structure_division_level,sd.structure_division_name_ru
		  FROM univer_structure_division_1c sd
		  WHERE sd.structure_division_id = @parentId

		  UNION ALL

		  SELECT sd1.structure_division_id, sd1.structure_division_ext, sd1.structure_division_level,sd1.structure_division_name_ru
		  FROM univer_structure_division_1c sd1  
		  INNER JOIN MyTest M
		  ON M.structure_division_id = sd1.structure_division_ext and sd1.status=1
		 )	 
		SELECT structure_division_id From MyTest
	);

go

