-- =============================================
-- Author:		Yerlan
-- Create date: 2012-01-05 
-- Description:	Добавление соответствующего права для сотрудника при добалений строки
-- =============================================
create TRIGGER [dbo].[DOAdminUpdateTrigger]
   ON  [dbo].[univer_distance_learn_admin]
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
    DECLARE @pi int
	DECLARE @st int
	
	DECLARE insCursor cursor 
		FOR SELECT personal_id, status FROM inserted
		
	IF UPDATE(status)
	BEGIN
		OPEN insCursor
		FETCH NEXT FROM insCursor INTO @pi, @st
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF(@st=1)
				EXEC dbo.personalSetAccess @pi, 'DISTANCE_LEARNING'
			ELSE
				EXEC dbo.personalDeleteAccess @pi, 'DISTANCE_LEARNING'
				
			FETCH NEXT FROM insCursor INTO @pi, @st
		END
		CLOSE insCursor
	END
END
go

