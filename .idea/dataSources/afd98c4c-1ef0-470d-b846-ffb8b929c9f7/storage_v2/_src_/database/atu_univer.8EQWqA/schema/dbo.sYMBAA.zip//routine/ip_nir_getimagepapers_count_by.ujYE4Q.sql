-- =============================================
-- Author:		Yerlan
-- Create date: 22.12.2015
-- Description: Получить количество имиджевых публикации
-- (@indicatorConst=1 - Количество имиджевых публикации достижениях КазНУ - в СМИ страны
-- @indicatorConst=2 - Количество имиджевых публикации достижениях КазНУ - в зарубежных СМИ
-- @indicatorConst=3 - Количество имиджевых публикации достижениях КазНУ - в газете "Қазақ университеті"
-- =============================================
CREATE FUNCTION [dbo].[IP_NIR_getImagePapers_Count_By]
(
	@categoryId int,
	@personalId int,
	@chairId int,
	@facultyId int,
	@year int,
	@publisherTypeId int,
	@indicatorConst int
)
RETURNS real
AS
BEGIN
DECLARE @Result real
-- ==================================== в СМИ страны
IF (@indicatorConst=1)
BEGIN
	SELECT @Result = COUNT(*)
		FROM 
			DBScience.dbo.ImagePapers p,
			DBScience.dbo.L_Person_ImagePaper_Authors a,
			DBScience.dbo.OtherPeriodicEditions op,
			DBScience.dbo.Countries c,
			DBScience.dbo.Publishers pb
		WHERE
		-- статья не архивирована
		p.status != 2 AND
		-- статья должна иметь другое пер. издание с типом "Газета"
		op.otherPeriodicEdition_id = p.periodicEdition_id AND
		op.otherPeriodicEditionType_id = 3 AND
		-- периодическое издание должен иметь издательство из Казахстана
		op.publisher_id = pb.publisher_id AND
		pb.country_id = c.country_id AND
		c.countryCurrent = 1 AND
		-- Издательство "Қазақ Университеті"
		pb.name NOT LIKE N'%Қазақ университеті%' AND
		-- статья этого года
		p.yearPublication in (@year, @year + 1) AND
		-- не дублированная и подтвержденная
		p.is_overlap IS NULL AND
		p.is_approve=1 AND
		-- статья этого автора (ППС, потому personType = 1)
		p.imagePaper_id = a.imagePaper_id AND
		a.personType = 1 AND 
		(
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		)
END

-- ==================================== в зарубежных СМИ
IF (@indicatorConst=2)
BEGIN
	SELECT @Result = COUNT(*)
		FROM 
			DBScience.dbo.ImagePapers p,
			DBScience.dbo.L_Person_ImagePaper_Authors a,
			DBScience.dbo.OtherPeriodicEditions op,
			DBScience.dbo.Countries c,
			DBScience.dbo.Publishers pb
		WHERE
		-- статья не архивирована
		p.status != 2 AND
		-- статья должна иметь другое пер. издание с типом "Газета"
		op.otherPeriodicEdition_id = p.periodicEdition_id AND
		op.otherPeriodicEditionType_id = 3 AND
		-- периодическое издание должен иметь издательство не из Казахстана
		op.publisher_id = pb.publisher_id AND
		pb.country_id = c.country_id AND
		c.countryCurrent = 0 AND
		-- статья этого года
		p.yearPublication in (@year, @year + 1) AND
		-- не дублированная и подтвержденная
		p.is_overlap IS NULL AND
		p.is_approve=1 AND
		-- статья этого автора (ППС, потому personType = 1)
		p.imagePaper_id = a.imagePaper_id AND
		a.personType = 1 AND 
		(
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		)
END

-- ==================================== в газете "Қазақ университеті"
IF (@indicatorConst=3)
BEGIN
	SELECT @Result = COUNT(*)
		FROM 
			DBScience.dbo.ImagePapers p,
			DBScience.dbo.L_Person_ImagePaper_Authors a,
			DBScience.dbo.OtherPeriodicEditions op,
			DBScience.dbo.Publishers pb,
			DBScience.dbo.Countries c
		WHERE
		-- статья не архивирована
		p.status != 2 AND
		-- статья должна иметь другое пер. издание с типом "Газета"
		op.otherPeriodicEdition_id = p.periodicEdition_id AND
		op.otherPeriodicEditionType_id = 3 AND
		-- издательство этой страны
		pb.publisher_id = op.publisher_id AND
		c.country_id = pb.country_id AND
		c.countryCurrent = 1 AND
		-- Издательство "Қазақ Университеті"
		pb.name LIKE N'%Қазақ университеті%' AND
		-- статья этого года
		p.yearPublication in (@year, @year + 1) AND
		-- не дублированная и подтвержденная
		p.is_overlap IS NULL AND
		p.is_approve=1 AND
		-- статья этого автора (ППС, потому personType = 1)
		p.imagePaper_id = a.imagePaper_id AND
		a.personType = 1 AND 
		(
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		)
END

-- Return the result of the function
RETURN ISNULL(@Result, 0)

END
go

