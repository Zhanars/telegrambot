-- =============================================
-- Author:		sasha
-- Create date: 20.10.2017
-- Description:	Копирование академического календаря за семестр из одного учебного плана в другой
-- =============================================
CREATE PROCEDURE [dbo].[copyACfromPlanToPlan]
@planIdFrom int,---план, откуда копируем
@planIdTo int,---план, куда копируем
@numSemFrom int,---номер семестра, из которого надо скопировать
@numSemTo int---номер семестра, в который надо скопировать
AS
BEGIN
	
	SET NOCOUNT ON;
	begin transaction
	
	insert into _tmp_academ_calendar_pos (educ_plan_id, acpos_semester, acpos_module, control_id, acpos_weeks, acpos_date_start, acpos_date_end)
    select @planIdTo,@numSemTo,acpos_module,control_id,acpos_weeks,acpos_date_start,acpos_date_end 
		from univer_academ_calendar_pos ap, 
			 univer_educ_plan pl,univer_speciality sp 
	    where pl.speciality_id=sp.speciality_id and 
			  pl.educ_plan_id=ap.educ_plan_id and 
			  pl.status=1 and 
			  ap.educ_plan_id=@planIdFrom and 
			  ap.acpos_semester=@numSemFrom and 
			  ap.acpos_module=0 and 
			  not exists (select * from univer_academ_calendar_pos ap2 
						  where ap2.educ_plan_id=@planIdTo and 
						  ap2.acpos_semester=@numSemTo and 
						  ap2.acpos_module=ap.acpos_module and 
						  ap2.control_id=ap.control_id) and 
			  exists(select * from univer_educ_plan p, univer_speciality s
				     where s.speciality_id=p.speciality_id and 
				     p.educ_plan_id=@planIdTo and 
				     p.status=1 and 
				     p.educ_plan_number_of_semestr>=@numSemTo and 
				     s.faculty_id=sp.faculty_id and 
				     s.stage_id=sp.stage_id)
	
	insert into univer_academ_calendar_pos (educ_plan_id, acpos_semester, acpos_module, control_id, acpos_weeks, acpos_date_start, acpos_date_end)
    select @planIdTo,@numSemTo,acpos_module,control_id,acpos_weeks,acpos_date_start,acpos_date_end 
		from univer_academ_calendar_pos ap, 
			 univer_educ_plan pl,univer_speciality sp 
	    where pl.speciality_id=sp.speciality_id and 
			  pl.educ_plan_id=ap.educ_plan_id and 
			  pl.status=1 and 
			  ap.educ_plan_id=@planIdFrom and 
			  ap.acpos_semester=@numSemFrom and 
			  ap.acpos_module=0 and 
			  not exists (select * from univer_academ_calendar_pos ap2 
						  where ap2.educ_plan_id=@planIdTo and 
						  ap2.acpos_semester=@numSemTo and 
						  ap2.acpos_module=ap.acpos_module and 
						  ap2.control_id=ap.control_id) and 
			  exists(select * from univer_educ_plan p, univer_speciality s
				     where s.speciality_id=p.speciality_id and 
				     p.educ_plan_id=@planIdTo and 
				     p.status=1 and 
				     p.educ_plan_number_of_semestr>=@numSemTo and 
				     s.faculty_id=sp.faculty_id and 
				     s.stage_id=sp.stage_id)
				     commit
    
END
go

