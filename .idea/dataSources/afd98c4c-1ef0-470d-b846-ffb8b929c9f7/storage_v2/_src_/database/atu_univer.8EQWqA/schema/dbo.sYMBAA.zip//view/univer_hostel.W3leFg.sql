CREATE VIEW dbo.univer_hostel
AS
SELECT     p.personal_id, p.personal_sname, p.personal_name, p.personal_father_name, p.personal_work_email, sd.structure_division_id, sd.structure_division_name_ru
FROM         dbo.univer_personal AS p INNER JOIN
                      dbo.univer_personal_struct_pos_link_1c AS l ON p.personal_id = l.personal_id INNER JOIN
                      dbo.univer_structure_division_1c AS sd ON l.structure_division_id = sd.structure_division_id INNER JOIN
                      dbo.univer_personal_position_1c AS pos ON l.personal_position_id = pos.personal_position_id
WHERE     (p.status = 1) AND (l.status = 1) AND (pos.status = 1) AND (pos.personal_position_id = 141)
go

