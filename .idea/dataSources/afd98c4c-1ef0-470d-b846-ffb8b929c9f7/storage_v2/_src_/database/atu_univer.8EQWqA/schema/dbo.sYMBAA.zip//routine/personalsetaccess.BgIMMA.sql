-- =============================================
-- Author:		@LFER
-- Create date: 2009-03-30 13:26:15.400
-- Description: Установка права доступа сотруднику
-- =============================================
CREATE PROCEDURE [dbo].[personalSetAccess] @personal_id int, @role nvarchar(50)
AS
BEGIN
	DECLARE @user_id int
	SELECT @user_id=user_id FROM univer_personal WHERE personal_id=@personal_id
	UPDATE univer_users SET user_access = (user_access | dbo.accessGetByRole(@role)) WHERE user_id=@user_id

	-- Добавление записи о том, что пользователю необходимо перелогиниться
	if (select COUNT(*) from univer_alert where alert_code=2 and user_id=@user_id)<=0 and @user_id>0
	INSERT INTO univer_alert (alert_code, user_id, alert_date) VALUES (2, @user_id, getdate())
END
go

