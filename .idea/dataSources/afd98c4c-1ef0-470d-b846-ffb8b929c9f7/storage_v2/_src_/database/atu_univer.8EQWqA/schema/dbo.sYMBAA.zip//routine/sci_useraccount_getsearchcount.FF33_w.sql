-- =============================================
-- Author:		Twice
-- Create date: 31.01.2012
-- Description:	Получить количество строк поиска пользователей DbScience
-- =============================================
CREATE FUNCTION sci_userAccount_GetSearchCount 
(
	@loginStr nvarchar(50)='',
	@fioStr NVARCHAR(50) = '',
	@roleId int = 0
)
RETURNS int
AS
BEGIN
	DECLARE @Result int

	SELECT @Result = COUNT(*) 
		FROM
		(
				SELECT uu.user_id as [univer_user_id],
					uu.user_login as [login],
					uu.user_password as [password],
					uu.user_temppass as [tempPass],
					uu.user_pass_change_date as [passChangeDate], 
					su.person_id as [person_id],
					su.personType as [personType],
					CASE 
					WHEN p.personal_sname IS NOT NULL THEN p.personal_sname COLLATE Kazakh_100_CI_AI
					WHEN st.students_sname IS NOT NULL THEN st.students_sname COLLATE Kazakh_100_CI_AI
					END as [surname],
					CASE 
					WHEN p.personal_name IS NOT NULL THEN p.personal_name COLLATE Kazakh_100_CI_AI
					WHEN st.students_name IS NOT NULL THEN st.students_name COLLATE Kazakh_100_CI_AI
					END as [name],
					CASE 
					WHEN p.personal_father_name IS NOT NULL THEN p.personal_father_name COLLATE Kazakh_100_CI_AI
					WHEN st.students_father_name IS NOT NULL THEN st.students_father_name COLLATE Kazakh_100_CI_AI
					END as [fatherName],
					su.lastLogon as [lastLogon],
					su.role_id as [role_id],
					su.linkedDivision_id as [linkedDivision_id]
				FROM 
					univer_users uu
					INNER JOIN DBScience.dbo.univer_userAccounts su ON uu.user_id = su.univer_user_id 
					LEFT JOIN univer_personal p ON p.user_id = uu.user_id
					LEFT JOIN univer_students st ON st.user_id = uu.user_id
				WHERE
					(CHARINDEX(@loginStr,uu.user_login) > 0 OR LEN(@loginStr)=0) AND
					((CHARINDEX(@fioStr, p.personal_sname + ' ' + 
							p.personal_name + ' ' + p.personal_father_name) > 0 OR LEN(@fioStr)=0) 
							OR
					(CHARINDEX(@fioStr, st.students_sname + ' ' + 
							st.students_sname + ' ' + st.students_father_name) > 0 OR LEN(@fioStr)=0))
					AND (role_id = @roleId OR @roleId = 0)
			) m

	-- Return the result of the function
	RETURN @Result

END
go

