-- =============================================
-- Author:		Twice
-- Create date: 31.01.2012
-- Description: Получить количество публикаций (имеется ввиду статьи) (1 - в казахстанских изданиях по МОН РК, 2- ближнее зарубежье, 3 - дальнее зарубежье) - в разрезе кафедр
-- =============================================
CREATE FUNCTION [dbo].[IP_NIR_getSciPapers_Count_ByChairId]
(
	@chairId int,
	@year int,
	@editionTypeId int
)
RETURNS real
AS
BEGIN
DECLARE @Result real

-- ==================================== если ККСОН
IF (@editionTypeId = 1)
BEGIN
	SELECT @Result = COUNT(DISTINCT p.paper_id)
		FROM 
			DBScience.dbo.Papers p,
			DBScience.dbo.L_Person_Paper_Authors a,
			DBScience.dbo.SciJournals sj
		WHERE
		-- статья не архивирована
		p.status != 2 AND
		-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
		sj.sciJournal_id = p.periodicEdition_id AND
		p.periodicEditionType_id = 1 AND
		-- журнал должен быть рекомендуемый ККСОН
		sj.recommendedByKKSON = 1 AND
		-- статья этого года
		p.yearPublication in (@year, @year + 1) AND
		-- статья этого автора (ППС, потому personType = 1)
		p.paper_id = a.paper_id AND
		a.personType = 1 AND 
		-- ППС только с этой кафедры
		a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
			) AND
		p.paper_id NOT IN 
			(
				select p2.paper_id
				FROM 
					DBScience.dbo.Papers p2,
					DBScience.dbo.L_Person_Paper_Authors a,
					DBScience.dbo.SciJournals sj,
					DBScience.dbo.L_SciJournal_IFRatingAgencies sip
				WHERE
				-- статья не архивирована
				p2.status != 2 AND
				-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
				sj.sciJournal_id = p2.periodicEdition_id AND
				p2.periodicEditionType_id = 1 AND
				-- импакт факторы, принадлежащие этой статье должны относиться к Томсон Ройтерс (id = 1) 
				-- и быть > 0
				sip.sciJournal_id = sj.sciJournal_id AND
				sip.IFRatingAgency_id = 1 AND sip.factorValue > 0 AND
				-- статья этого года
				p2.yearPublication in (@year, @year+1)  AND
				-- статья этого автора (ППС, потому personType = 1)
				p2.paper_id = a.paper_id AND
				a.personType = 1 AND 
				-- ППС только с этой кафедры
				a.person_id IN
					(SELECT
						DISTINCT p.personal_id
					FROM
						univer_personal p,
						univer_structure_division_1c sd,
						univer_personal_struct_pos_link_1c spl
					WHERE
						p.personal_id = spl.personal_id AND
						sd.structure_division_id = spl.structure_division_id AND
						sd.structure_division_id = @chairId AND
						spl.status != 2  AND p.status != 2
					)
				UNION
				SELECT p3.paper_id
				FROM 
					DBScience.dbo.Papers p3,
					DBScience.dbo.L_Person_Paper_Authors a,
					DBScience.dbo.SciJournals sj
				WHERE
				-- статья не архивирована
				p3.status != 2 AND
				-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
				sj.sciJournal_id = p.periodicEdition_id AND
				p3.periodicEditionType_id = 1 AND
				-- журнал должен иметь галочку "относится к scopus"
				sj.indexedByScopus = 1 AND
				-- статья этого года
				p3.yearPublication in (@year, @year+1) AND
				-- статья этого автора (ППС, потому personType = 1)
				p3.paper_id = a.paper_id AND
				a.personType = 1 AND 
				-- ППС только с этой кафедры
				a.person_id IN
					(SELECT
						DISTINCT p.personal_id
					FROM
						univer_personal p,
						univer_structure_division_1c sd,
						univer_personal_struct_pos_link_1c spl
					WHERE
						p.personal_id = spl.personal_id AND
						sd.structure_division_id = spl.structure_division_id AND
						sd.structure_division_id = @chairId AND
						spl.status != 2  AND p.status != 2
					)
			) 
END

-- ==================================== если издание или мероприятие ближнего зарубежья
IF (@editionTypeId = 2)
BEGIN
	SELECT @Result = m1.pCount + m2.thCount
		FROM
		(SELECT COUNT(DISTINCT p.paper_id) as pCount
		FROM 
			DBScience.dbo.Papers p,
			DBScience.dbo.L_Person_Paper_Authors a,
			DBScience.dbo.SciJournals sj, 
			DBScience.dbo.Countries c
		WHERE
		-- статья не архивирована
		p.status != 2 AND
		-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
		sj.sciJournal_id = p.periodicEdition_id AND
		p.periodicEditionType_id = 1 AND
		-- страна журнала должна быть в ближнем зарубежье и не текущей (Казахстан)
		sj.journalCountry_id = c.country_id AND
		c.foreignType in (0,1) 
		AND c.countryCurrent = 0 AND
		-- статья этого года
		p.yearPublication in (@year, @year + 1) AND	
		-- статья этого автора (ППС, потому personType = 1)
		p.paper_id = a.paper_id AND
		a.personType = 1 AND 
		-- ППС только с этой кафедры
		a.person_id IN
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
			)
		AND
		p.paper_id NOT IN 
			(
				select p2.paper_id
				FROM 
					DBScience.dbo.Papers p2,
					DBScience.dbo.L_Person_Paper_Authors a,
					DBScience.dbo.SciJournals sj,
					DBScience.dbo.L_SciJournal_IFRatingAgencies sip
				WHERE
				-- статья не архивирована
				p2.status != 2 AND
				-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
				sj.sciJournal_id = p2.periodicEdition_id AND
				p2.periodicEditionType_id = 1 AND
				-- импакт факторы, принадлежащие этой статье должны относиться к Томсон Ройтерс (id = 1) 
				-- и быть > 0
				sip.sciJournal_id = sj.sciJournal_id AND
				sip.IFRatingAgency_id = 1 AND sip.factorValue > 0 AND
				-- статья этого года
				p2.yearPublication in (@year, @year+1)  AND
				-- статья этого автора (ППС, потому personType = 1)
				p2.paper_id = a.paper_id AND
				a.personType = 1 AND 
				-- ППС только с этой кафедры
				a.person_id IN
					(SELECT
						DISTINCT p.personal_id
					FROM
						univer_personal p,
						univer_structure_division_1c sd,
						univer_personal_struct_pos_link_1c spl
					WHERE
						p.personal_id = spl.personal_id AND
						sd.structure_division_id = spl.structure_division_id AND
						sd.structure_division_id = @chairId AND
						spl.status != 2  AND p.status != 2
					)
				UNION
				SELECT p3.paper_id
				FROM 
					DBScience.dbo.Papers p3,
					DBScience.dbo.L_Person_Paper_Authors a,
					DBScience.dbo.SciJournals sj
				WHERE
				-- статья не архивирована
				p3.status != 2 AND
				-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
				sj.sciJournal_id = p.periodicEdition_id AND
				p3.periodicEditionType_id = 1 AND
				-- журнал должен иметь галочку "относится к scopus"
				sj.indexedByScopus = 1 AND
				-- статья этого года
				p3.yearPublication in (@year, @year+1) AND
				-- статья этого автора (ППС, потому personType = 1)
				p3.paper_id = a.paper_id AND
				a.personType = 1 AND 
				-- ППС только с этой кафедры
				a.person_id IN
					(SELECT
						DISTINCT p.personal_id
					FROM
						univer_personal p,
						univer_structure_division_1c sd,
						univer_personal_struct_pos_link_1c spl
					WHERE
						p.personal_id = spl.personal_id AND
						sd.structure_division_id = spl.structure_division_id AND
						sd.structure_division_id = @chairId AND
						spl.status != 2  AND p.status != 2
					)
			) 
		) m1,
		(SELECT COUNT(DISTINCT th.thesis_id) as thCount
		FROM
			DBScience.dbo.Thesises th,
			DBScience.dbo.L_Person_Thesis_Authors a,
			DBScience.dbo.SciEvents se,
			DBScience.dbo.Countries c
		WHERE
			-- тезис не архивирован
			th.status != 2 AND
			-- тезис этого автора (ППС, потому personType = 1)
			th.thesis_id = a.thesis_id AND
			a.personType = 1 AND 
			-- ППС только с этой кафедры
			a.person_id IN
				(SELECT
					DISTINCT p.personal_id
				FROM
					univer_personal p,
					univer_structure_division_1c sd,
					univer_personal_struct_pos_link_1c spl
				WHERE
					p.personal_id = spl.personal_id AND
					sd.structure_division_id = spl.structure_division_id AND
					sd.structure_division_id = @chairId AND
					spl.status != 2  AND p.status != 2
				) 
			AND
			-- мероприятие этого тезиса
			se.sciEvent_id = th.sciEvent_id AND
			-- мероприятие международное (id=5)
			se.sciEventForm_id = 5 AND
			-- страна мероприятия должна быть ближнего зарубежья и не текущей
			se.country_id = c.country_id AND c.foreignType in (0,1) 
			AND c.countryCurrent = 0 AND
			-- тезис этого года (по мероприятию)
			YEAR(se.eventStart) in (@year, @year + 1)
		) m2
END

-- ==================================== если издание или мероприятие ближнего зарубежья
IF (@editionTypeId = 3)
BEGIN
	SELECT @Result = m1.pCount + m2.thCount
		FROM
		(SELECT COUNT(DISTINCT p.paper_id) as pCount
		FROM 
			DBScience.dbo.Papers p,
			DBScience.dbo.L_Person_Paper_Authors a,
			DBScience.dbo.SciJournals sj,
			DBScience.dbo.Countries c
		WHERE
		-- статья не архивирована
		p.status != 2 AND
		-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
		sj.sciJournal_id = p.periodicEdition_id AND
		p.periodicEditionType_id = 1 AND
		-- страна журнала должна быть в ближнем зарубежье и не текущей (Казахстан)
		sj.journalCountry_id = c.country_id AND
		c.foreignType in (2) AND
		-- статья этого года
		p.yearPublication in (@year, @year + 1) AND
		-- статья этого автора (ППС, потому personType = 1)
		p.paper_id = a.paper_id AND
		a.personType = 1 AND 
		-- ППС только с этой кафедры
		a.person_id IN
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
			) 
		AND
		p.paper_id NOT IN 
			(
				select p2.paper_id
				FROM 
					DBScience.dbo.Papers p2,
					DBScience.dbo.L_Person_Paper_Authors a,
					DBScience.dbo.SciJournals sj,
					DBScience.dbo.L_SciJournal_IFRatingAgencies sip
				WHERE
				-- статья не архивирована
				p2.status != 2 AND
				-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
				sj.sciJournal_id = p2.periodicEdition_id AND
				p2.periodicEditionType_id = 1 AND
				-- импакт факторы, принадлежащие этой статье должны относиться к Томсон Ройтерс (id = 1) 
				-- и быть > 0
				sip.sciJournal_id = sj.sciJournal_id AND
				sip.IFRatingAgency_id = 1 AND sip.factorValue > 0 AND
				-- статья этого года
				p2.yearPublication in (@year, @year+1)  AND
				-- статья этого автора (ППС, потому personType = 1)
				p2.paper_id = a.paper_id AND
				a.personType = 1 AND 
				a.person_id IN
					(SELECT
						DISTINCT p.personal_id
					FROM
						univer_personal p,
						univer_structure_division_1c sd,
						univer_personal_struct_pos_link_1c spl
					WHERE
						p.personal_id = spl.personal_id AND
						sd.structure_division_id = spl.structure_division_id AND
						sd.structure_division_id = @chairId AND
						spl.status != 2  AND p.status != 2
					) 
				UNION
				SELECT p3.paper_id
				FROM 
					DBScience.dbo.Papers p3,
					DBScience.dbo.L_Person_Paper_Authors a,
					DBScience.dbo.SciJournals sj
				WHERE
				-- статья не архивирована
				p3.status != 2 AND
				-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
				sj.sciJournal_id = p.periodicEdition_id AND
				p3.periodicEditionType_id = 1 AND
				-- журнал должен иметь галочку "относится к scopus"
				sj.indexedByScopus = 1 AND
				-- статья этого года
				p3.yearPublication in (@year, @year+1) AND
				-- статья этого автора (ППС, потому personType = 1)
				p3.paper_id = a.paper_id AND
				a.personType = 1 AND 
				-- ППС только с этой кафедры
				a.person_id IN
					(SELECT
						DISTINCT p.personal_id
					FROM
						univer_personal p,
						univer_structure_division_1c sd,
						univer_personal_struct_pos_link_1c spl
					WHERE
						p.personal_id = spl.personal_id AND
						sd.structure_division_id = spl.structure_division_id AND
						sd.structure_division_id = @chairId AND
						spl.status != 2  AND p.status != 2
					) 
			) 
		) m1,
		(SELECT COUNT(DISTINCT th.thesis_id) as thCount
		FROM
			DBScience.dbo.Thesises th,
			DBScience.dbo.L_Person_Thesis_Authors a,
			DBScience.dbo.SciEvents se,
			DBScience.dbo.Countries c
		WHERE
			-- тезис не архивирован
			th.status != 2 AND
			-- тезис этого автора (ППС, потому personType = 1)
			th.thesis_id = a.thesis_id AND
			a.personType = 1 AND 
			-- ППС только с этой кафедры
			a.person_id IN
				(SELECT
					DISTINCT p.personal_id
				FROM
					univer_personal p,
					univer_structure_division_1c sd,
					univer_personal_struct_pos_link_1c spl
				WHERE
					p.personal_id = spl.personal_id AND
					sd.structure_division_id = spl.structure_division_id AND
					sd.structure_division_id = @chairId AND
					spl.status != 2  AND p.status != 2
				)  
			AND
			-- мероприятие этого тезиса
			se.sciEvent_id = th.sciEvent_id AND
			-- мероприятие международное (id=5)
			se.sciEventForm_id = 5 AND
			-- страна мероприятия должна быть ближнего зарубежья и не текущей
			se.country_id = c.country_id AND c.foreignType in (2) AND
			-- тезис этого года (по мероприятию)
			YEAR(se.eventStart) in (@year, @year + 1)
		) m2
END




RETURN @Result

END
go

