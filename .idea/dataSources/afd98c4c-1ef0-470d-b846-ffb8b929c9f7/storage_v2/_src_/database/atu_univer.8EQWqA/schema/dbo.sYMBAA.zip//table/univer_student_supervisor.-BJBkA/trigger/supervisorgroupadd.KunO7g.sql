-- =============================================
-- Author:		sasha
-- Create date: 19.10.2017
-- Description:	Триггер на автоматическое добавление групп по руководителям дипломных работ
-- =============================================
Create TRIGGER [dbo].[SuperVisorGroupAdd]
   ON  [dbo].[univer_student_supervisor]
   AFTER INSERT
AS 
BEGIN

	SET NOCOUNT ON;
	
    DECLARE @student_id int
	DECLARE @teacher_id int
	
	DECLARE superVis cursor
		FOR SELECT student_id, teacher_id FROM inserted
	OPEN superVis
	FETCH NEXT FROM superVis INTO @student_id, @teacher_id
	WHILE @@FETCH_STATUS = 0
		BEGIN
		exec dbo.updDiplomGroup @student_id, @teacher_id, 1;				
		FETCH NEXT FROM superVis INTO @student_id, @teacher_id
		END
	CLOSE superVis

END
go

disable trigger SuperVisorGroupAdd on univer_student_supervisor
go

