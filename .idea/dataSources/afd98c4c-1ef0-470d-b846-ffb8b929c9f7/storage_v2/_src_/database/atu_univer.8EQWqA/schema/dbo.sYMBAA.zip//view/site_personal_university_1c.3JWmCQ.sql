
CREATE VIEW [dbo].[site_personal_university_1c]
AS
SELECT     TOP (100) PERCENT dbo.univer_personal.personal_id, pu.personal_university_graduate_date, ui.university_name_kz, ui.university_name_ru, ui.university_name_en,
                       ef.education_form_id, ef.education_form_name_ru, ef.education_form_name_kz, ed.education_id, ed.education_name_ru, ed.education_name_kz
FROM         dbo.univer_personal_university_1c AS pu INNER JOIN
                      dbo.univer_universities_1c AS ui ON pu.university_id = ui.university_id INNER JOIN
                      dbo.univer_education_form_1c AS ef ON ef.education_form_id = pu.education_form_id INNER JOIN
                      dbo.univer_education_1c AS ed ON ed.education_id = pu.education_id INNER JOIN
                      dbo.univer_personal ON pu.personal_id = dbo.univer_personal.personal_id
ORDER BY pu.personal_university_graduate_date DESC

go

