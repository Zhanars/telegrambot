-- =============================================
-- Author:		Twice
-- Create date: 31.01.2012
-- Description: Получить суммарный импакт-фактор публикаций (ISI Web of Knowledge, Thomson Reuters) - в разрезе сотрудника
-- =============================================
CREATE FUNCTION [dbo].[IP_NIR_getSummaryImpactFactor_ByPersonalId]
(
	@personalId int,
	@year int
)
RETURNS real
AS
BEGIN
DECLARE @Result real

SELECT @Result = ISNULL(ROUND(SUM(sip.factorValue), 5), 0)
	FROM 
		DBScience.dbo.Papers p,
		DBScience.dbo.L_Person_Paper_Authors a,
		DBScience.dbo.SciJournals sj,
		DBScience.dbo.L_SciJournal_IFRatingAgencies sip
	WHERE
		p.status != 2 AND
		-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
		sj.sciJournal_id = p.periodicEdition_id AND
		p.periodicEditionType_id = 1 AND
		-- импакт факторы, принадлежащие этой статье должны относитсья к Томсон Ройтерс (id = 1)
		sip.sciJournal_id = sj.sciJournal_id AND
		sip.IFRatingAgency_id = 1 AND
		-- статья этого года
		p.yearPublication in (@year, @year+1)  AND
		-- статья этого автора (ППС, потому personType = 1)
		p.paper_id = a.paper_id AND
		a.personType = 1 AND 
		a.person_id = @personalId
	
-- Return the result of the function
RETURN ISNULL(@Result, 0)

END
go

