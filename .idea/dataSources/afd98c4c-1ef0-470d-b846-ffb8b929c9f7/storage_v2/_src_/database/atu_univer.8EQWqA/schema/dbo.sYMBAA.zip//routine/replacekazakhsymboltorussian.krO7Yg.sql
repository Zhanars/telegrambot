-- =============================================
-- Author:		Yerlan
-- Create date: 
-- Description:	For Perco
-- =============================================
create FUNCTION [dbo].[ReplaceKazakhSymbolToRussian]
(
	@str NVARCHAR(100)
)
RETURNS NVARCHAR(100)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ret NVARCHAR(100)

	-- Add the T-SQL statements to compute the return value here
	SELECT @ret = REPLACE(@str, N'қ' collate KAZAKH_100_CS_AS, N'к') 
	SELECT @ret = REPLACE(@ret, N'Қ' collate KAZAKH_100_CS_AS, N'К') 
									
	SELECT @ret = REPLACE(@ret, N'ң' collate KAZAKH_100_CS_AS, N'н') 
	SELECT @ret = REPLACE(@ret, N'Ң' collate KAZAKH_100_CS_AS, N'Н')
									
	SELECT @ret = REPLACE(@ret, N'ә' collate KAZAKH_100_CS_AS, N'а')
	SELECT @ret = REPLACE(@ret, N'Ә' collate KAZAKH_100_CS_AS, N'А')
									
	SELECT @ret = REPLACE(@ret, N'ғ' collate KAZAKH_100_CS_AS, N'г')
	SELECT @ret = REPLACE(@ret, N'Ғ' collate KAZAKH_100_CS_AS, N'Г')
									
	SELECT @ret = REPLACE(@ret, N'ұ' collate KAZAKH_100_CS_AS, N'у')
	SELECT @ret = REPLACE(@ret, N'Ұ' collate KAZAKH_100_CS_AS, N'У')
									
	SELECT @ret = REPLACE(@ret, N'ө' collate KAZAKH_100_CS_AS, N'о')
	SELECT @ret = REPLACE(@ret, N'Ө' collate KAZAKH_100_CS_AS, N'О')
									
	SELECT @ret = REPLACE(@ret, N'ү' collate KAZAKH_100_CS_AS, N'у')
	SELECT @ret = REPLACE(@ret, N'Ү' collate KAZAKH_100_CS_AS, N'У')
	
	SELECT @ret = REPLACE(@ret, N'һ' collate KAZAKH_100_CS_AS, N'х')	
	SELECT @ret = REPLACE(@ret, N'Һ' collate KAZAKH_100_CS_AS, N'Х')	
	
	RETURN @ret

END
go

