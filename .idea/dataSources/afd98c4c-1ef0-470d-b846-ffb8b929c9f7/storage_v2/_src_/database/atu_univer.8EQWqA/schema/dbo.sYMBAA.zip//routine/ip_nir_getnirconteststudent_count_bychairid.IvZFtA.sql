-- =============================================
-- Author:		Twice
-- Create date: 31.01.2012
-- Description: Получить количество НИР студентов получивших дипломы за участие в республиканском конкурсе НИР - в разрезе кафедр
-- =============================================
CREATE FUNCTION IP_NIR_getNIRContestStudent_Count_ByChairId
(
	@chairId int,
	@year int
)
RETURNS real
AS
BEGIN
DECLARE @Result real

SELECT @Result = 0

-- Return the result of the function
RETURN @Result

END
go

