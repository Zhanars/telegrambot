CREATE VIEW dbo.powerbi_indplan_analize
AS
select tbl.personal_id, tbl.structure_division_id, tbl.type_id, tbl.personal_position_id, tbl.personal_rate, tbl.personal_sname, tbl.personal_name
				, tbl.personal_father_name, tbl.personal_birthday_date 
	, ic.ind_plan_code
	, (case when ic.ind_plan_code_parent_id>0 then ipip.ind_plan_indicator_name_ru+' ['+ipi.ind_plan_indicator_name_ru+']' else ipi.ind_plan_indicator_name_ru end) as indicator_name
	, id.ind_plan_direction_name_ru, ip.ind_plan_personal_f_value, ip.ind_plan_personal_p_value, ip.year
	, pp.personal_position_name_ru, sd.structure_division_name_ru
	,deg.scientific_degree_name_ru
	,rnk.scientific_rank_name_ru
from univer_ind_plan_indicator ipi
	, univer_ind_plan_code ic left join  univer_ind_plan_indicator ipip 
		on ic.ind_plan_code_parent_id>0 and ic.ind_plan_code_parent_id=ipip.ind_plan_code_id and ipip.ind_plan_category_id=3
	,univer_ind_plan_direction id
	, univer_ind_plan_personal ip
	, univer_personal_position_1c pp
	, univer_structure_division_1c sd
	,(	
		SELECT tbl.personal_id, tbl.structure_division_id, tbl.type_id, tbl.personal_position_id, tbl.personal_rate, tbl.personal_sname, tbl.personal_name
				, tbl.personal_father_name, tbl.personal_birthday_date 
		FROM (
			SELECT tbl.personal_id, tbl.structure_division_id, tbl.type_id, tbl.personal_position_id, tbl.personal_rate
			, p.personal_sname, p.personal_name, p.personal_father_name, p.personal_birthday_date
			FROM 
			(
				select spl.personal_id, spl.structure_division_id, spl.personal_position_id, spl.type_id, spl.personal_rate, ROW_NUMBER() OVER(PARTITION BY spl.personal_id 
					ORDER BY spl.type_id, spl.personal_rate DESC) row_num
				from univer_personal_struct_pos_link_1c spl 
				where spl.status=1
			) tbl , univer_personal p
			WHERE tbl.row_num<=1 and tbl.personal_id = p.personal_id and p.status=1
		) as tbl) as tbl
			left join
				(
					select dg.scientific_degree_name_ru,dg.personal_id from(
						select sdc.scientific_degree_name_ru, sdd.personal_id
								, ROW_NUMBER() OVER(PARTITION BY sdd.personal_id ORDER BY sdd.personal_scientific_degree_date DESC) row_num
							from univer_personal_scientific_degree_1c sdd, univer_scientific_degree_1c sdc
							where sdc.scientific_degree_id=sdd.scientific_degree_id and sdc.status=1 
					) as dg where dg.row_num<=1) as deg on tbl.personal_id=deg.personal_id
					
			left join
				(
					select dg.scientific_rank_name_ru,dg.personal_id from(
						select sdc.scientific_rank_name_ru, sdd.personal_id
								, ROW_NUMBER() OVER(PARTITION BY sdd.personal_id ORDER BY sdd.personal_scientific_rank_date DESC) row_num
							from univer_personal_scientific_rank_1c sdd, univer_scientific_rank_1c sdc
							where sdc.scientific_rank_id=sdd.scientific_rank_id and sdc.status=1 
					) as dg where dg.row_num<=1) as rnk on tbl.personal_id=rnk.personal_id
where ipi.status=1 and ipi.ind_plan_code_id=ic.ind_plan_code_id and ipi.ind_plan_indicator_id=ip.ind_plan_indicator_id 
		and ip.year=2016 and ip.personal_id=tbl.personal_id
		and ipi.ind_plan_direction_id=id.ind_plan_direction_id and id.status=1 and ipi.ind_plan_category_id=3
		and pp.personal_position_id=tbl.personal_position_id and sd.structure_division_id=tbl.structure_division_id

go

