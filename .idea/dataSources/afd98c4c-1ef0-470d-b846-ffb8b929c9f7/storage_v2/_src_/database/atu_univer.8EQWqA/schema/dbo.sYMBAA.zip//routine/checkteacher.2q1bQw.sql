-- =============================================
-- Author:		Sasha	
-- Create date: 25.01.2016
-- Description:	для проверки преподавателей
-- =============================================
CREATE FUNCTION checkTeacher
(
	@id int
)
RETURNS bit
AS
BEGIN
	-- Declare the return variable here
	DECLARE @cnt int;

	SELECT @cnt=count(*) from univer_teacher where teacher_id=@id

	-- Return the result of the function
	RETURN case when @id=0 or @cnt>0 then 1 else 0 end

END
go

