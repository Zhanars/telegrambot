-- =============================================
-- Author:		sasha
-- Create date: 02.11.2017
-- Description: Проверить как работают уведомления о баллах
-- =============================================
CREATE TRIGGER [dbo].[trg_alert] 
   ON  [dbo].[univer_alert] 
   AFTER DELETE
AS 
BEGIN
    update _tmp_alert_del set alert_del_count=alert_del_count+1
    where exists (select * from deleted d where _tmp_alert_del.user_id=d.user_id)
    
    insert into _tmp_alert_del (user_id, alert_del_count)
	select distinct d.user_id,1 from deleted d 
	where not exists (select * from _tmp_alert_del where _tmp_alert_del.user_id=d.user_id)
	SET NOCOUNT ON;
     

END
go

