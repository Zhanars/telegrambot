-- =============================================
-- Author:		sasha
-- Create date: 19.10.2017
-- Description:	Триггер на автоматическое удаление студента из групп по руководителям дипломных работ
-- =============================================
CREATE TRIGGER [dbo].[SuperVisorGroupDel]
   ON  [dbo].[univer_student_supervisor]
   AFTER DELETE
AS 
BEGIN

	SET NOCOUNT ON;
	
    DECLARE @student_id int
	DECLARE @teacher_id int
	
	DECLARE superVis cursor
		FOR SELECT student_id, teacher_id FROM deleted
	OPEN superVis
	FETCH NEXT FROM superVis INTO @student_id, @teacher_id
	WHILE @@FETCH_STATUS = 0
		BEGIN
		exec dbo.updDiplomGroup @student_id, @teacher_id, 0;				
		FETCH NEXT FROM superVis INTO @student_id, @teacher_id
		END
	CLOSE superVis

END
go

disable trigger SuperVisorGroupDel on univer_student_supervisor
go

