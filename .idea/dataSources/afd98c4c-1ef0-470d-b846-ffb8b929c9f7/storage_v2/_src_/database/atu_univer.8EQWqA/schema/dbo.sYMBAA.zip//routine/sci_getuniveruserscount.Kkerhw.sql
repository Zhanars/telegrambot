-- =============================================
-- Author:		Twice
-- Create date: 08.12.2011
-- Description:	Получить количество строк результата поиска по univer_users
-- =============================================
CREATE FUNCTION sci_getUniverUsersCount 
(
	-- Add the parameters for the function here
	@loginStr nvarchar(50) = '', 
	@fioStr nvarchar(50) = '',
	@typeOfUser int = 0
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result int

	-- Add the T-SQL statements to compute the return value here
	SELECT @Result = COUNT(*)
		FROM
		(
			SELECT 
				u.user_id as [userId],
				u.user_login as [userLogin],
				p.personal_sname COLLATE Kazakh_100_CI_AI as [surname],
				p.personal_name COLLATE Kazakh_100_CI_AI as [name],
				p.personal_father_name COLLATE Kazakh_100_CI_AI as [fatherName],
				1 as [typeOfUser]
			FROM
				univer_users u,
				univer_personal p
			WHERE
				u.user_access != 0 AND
				u.user_id = p.user_id AND
				--u.user_login like N'%'+@loginStr+'%' 
				(CHARINDEX(@loginStr,u.user_login) > 0 OR LEN(@loginStr)=0)
				AND
				(CHARINDEX(@fioStr, p.personal_sname + ' ' + 
					p.personal_name + ' ' + p.personal_father_name) > 0 
					OR LEN(@fioStr)=0)
				
			UNION
				SELECT 
				u.user_id as [userId],
				u.user_login as [userLogin],
				st.students_sname as [surname],
				st.students_name as [name],
				st.students_father_name as [fatherName],
				2 as [typeOfUser]
			FROM
				univer_users u,
				univer_students st
			WHERE
				u.user_access !=0 AND
				u.user_id = st.user_id AND
				(CHARINDEX(@loginStr,u.user_login) > 0 OR LEN(@loginStr)=0)
				AND
				(CHARINDEX(@fioStr, st.students_sname + ' ' + 
					st.students_name + ' ' + st.students_father_name) > 0 
					OR LEN(@fioStr)=0)
		)m
		WHERE (m.typeOfUser = @typeOfUser OR @typeOfUser=0)


	-- Return the result of the function
	RETURN Isnull(@Result, 0)

END
go

