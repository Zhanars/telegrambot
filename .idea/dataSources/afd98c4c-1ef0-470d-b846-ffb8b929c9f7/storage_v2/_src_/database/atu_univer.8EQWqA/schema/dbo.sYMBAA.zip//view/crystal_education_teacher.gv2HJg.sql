CREATE VIEW dbo.crystal_education_teacher
AS
SELECT     p.personal_sname AS surname, p.personal_name AS firstname, p.personal_father_name AS middlename, N'ONLINE' AS teacher_status, N'' AS phone, 
                      N'' AS room
FROM         dbo.univer_personal AS p INNER JOIN
                      dbo.univer_teacher AS t ON p.personal_id = t.personal_id
WHERE     (p.status = 1) AND (t.status = 1)
go

