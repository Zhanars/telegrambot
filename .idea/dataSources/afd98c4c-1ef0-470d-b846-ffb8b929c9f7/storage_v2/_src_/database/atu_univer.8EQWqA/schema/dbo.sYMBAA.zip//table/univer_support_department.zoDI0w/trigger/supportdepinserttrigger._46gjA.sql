-- =============================================
-- Author:		@LFER
-- Create date: 2009-07-13 11:32:47.090
-- Description:	Триггер на добавление сотрудника отдела сопровожения
-- =============================================
CREATE TRIGGER [dbo].[supportDepInsertTrigger]
   ON  [dbo].[univer_support_department] 
   AFTER INSERT
AS 
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	-- Insert statements for trigger here
	-- Цифра доступа для данной сущности
	DECLARE @pi int
	
	DECLARE insCursor cursor 
		FOR SELECT personal_id FROM inserted WHERE status=1
		
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @pi
	WHILE @@FETCH_STATUS = 0
	BEGIN
		exec dbo.personalSetAccess @pi, 'SUPPORT_DEPART'
		FETCH NEXT FROM insCursor INTO @pi;
	END
	CLOSE insCursor
END
go

