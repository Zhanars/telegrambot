-- =============================================
-- Author:		@LFER, Baton
-- Create date: 2009-11-13 
-- Description:	Удаление соответствующего права у сотрудника при удалении строки
-- =============================================
CREATE TRIGGER [dbo].[schedulerDeleteTrigger]
   ON  [dbo].[univer_scheduler]
   FOR DELETE
AS 
BEGIN	
	SET NOCOUNT ON;
	
	DECLARE @pi int
	DECLARE @st int
	
	DECLARE insCursor cursor 
		FOR SELECT personal_id FROM deleted
	
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @pi
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC dbo.personalDeleteAccess @pi, 'SCHEDULER'
			
		FETCH NEXT FROM insCursor INTO @pi
	END
	CLOSE insCursor
END
go

