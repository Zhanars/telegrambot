
CREATE VIEW [dbo].[site_personal_scientific_rank_1c]
AS
SELECT     dbo.univer_personal.personal_id, dbo.univer_scientific_rank_1c.scientific_rank_name_kz, dbo.univer_scientific_rank_1c.scientific_rank_name_ru, 
                      dbo.univer_scientific_rank_1c.scientific_rank_name_en, dbo.univer_scientific_rank_1c.status, 
                      dbo.univer_personal_scientific_rank_1c.personal_scientific_rank_number, univer_personal_scientific_rank_1c.personal_scientific_rank_date
FROM         dbo.univer_personal_scientific_rank_1c INNER JOIN
                      dbo.univer_scientific_rank_1c ON dbo.univer_personal_scientific_rank_1c.scientific_rank_id = dbo.univer_scientific_rank_1c.scientific_rank_id INNER JOIN
                      dbo.univer_personal ON dbo.univer_personal_scientific_rank_1c.personal_id = dbo.univer_personal.personal_id

go

