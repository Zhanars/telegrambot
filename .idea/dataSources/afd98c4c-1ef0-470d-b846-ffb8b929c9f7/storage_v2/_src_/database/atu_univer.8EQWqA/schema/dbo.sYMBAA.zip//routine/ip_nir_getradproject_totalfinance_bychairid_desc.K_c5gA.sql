-- =============================================
-- Author:		Twice
-- Create date: 31.01.2012
-- Description: Получить общий объем финансирования научных исследований - в разрезе кафедр
-- =============================================
CREATE FUNCTION IP_NIR_getRADProject_TotalFinance_ByChairId_DESC
(
	@chairId int,
	@year int
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @Result NVARCHAR(MAX)

SELECT @Result = N''

-- Return the result of the function
RETURN @Result

END
go

