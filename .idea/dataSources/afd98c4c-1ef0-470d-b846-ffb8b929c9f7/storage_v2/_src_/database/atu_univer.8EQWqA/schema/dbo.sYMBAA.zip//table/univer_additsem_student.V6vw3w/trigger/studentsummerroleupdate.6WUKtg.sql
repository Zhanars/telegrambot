-- =============================================
-- Author:		Саша
-- Create date: 20.04.2011
-- Description:	Удаление или добавлении права доступа при изменении статуса студента летнего семестра
-- =============================================
CREATE TRIGGER [dbo].[studentSummerRoleUpdate] ON  [dbo].[univer_additsem_student]
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @userId int
	DECLARE @st int
	
	IF UPDATE(status)
	BEGIN
		DECLARE insCursor cursor 
			FOR SELECT user_id, status FROM inserted
		
		OPEN insCursor
		FETCH NEXT FROM insCursor INTO @userId, @st
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF(@st<>1)
			BEGIN
				EXEC dbo.usersDeleteAccess @userId, 'ADDIT_STUDENT'
			END
			ELSE
			BEGIN
				EXEC dbo.usersSetAccess @userId, 'ADDIT_STUDENT'
			END	
			FETCH NEXT FROM insCursor INTO @userId, @st
		END
		CLOSE insCursor
		DEALLOCATE insCursor
	END

END
go

