-- =============================================
-- Author:		Twice
-- Create date: 31.01.2012
-- Description: Получить количество публикаций (имеется ввиду статьи) (1 - в казахстанских изданиях по МОН РК, 2- ближнее зарубежье, 3 - дальнее зарубежье) - в разрезе кафедр
-- =============================================
CREATE FUNCTION [dbo].[IP_NIR_getSciPapers_Count_ByChairId_DESC]
(
	@chairId int,
	@year int,
	@editionTypeId int
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @Result NVARCHAR(MAX)
DECLARE @PaperStr NVARCHAR(MAX)
DECLARE @ThesisStr NVARCHAR(MAX)

-- ==================================== если ККСОН
IF (@editionTypeId = 1)
BEGIN
	SELECT @Result = COALESCE(@Result + '\n\n', '') + 
		ISNULL(
		CONVERT(NVARCHAR(MAX), ROW_NUMBER() OVER (ORDER BY dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.paper_id, 2))) +N') '
		+ N'Автор(ы): ' + dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.paper_id, 2) 
		+ N'Научная статья:\nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en
		+ N'\nЖурнал:' + sj.name, '')
		--AS [description]
	FROM 
		DBScience.dbo.Papers p,
		DBScience.dbo.SciJournals sj
	WHERE
	p.paper_id IN
	(SELECT 
		DISTINCT p.paper_id
	FROM
		DBScience.dbo.Papers p,
		DBScience.dbo.L_Person_Paper_Authors a,
		DBScience.dbo.SciJournals sj
	WHERE
		-- статья не архивирована
		p.status != 2 AND
		-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
		sj.sciJournal_id = p.periodicEdition_id AND
		p.periodicEditionType_id = 1 AND
		-- журнал должен быть рекомендуемый ККСОН
		sj.recommendedByKKSON = 1 AND
		-- статья этого года
		p.yearPublication in (@year, @year + 1) AND
		-- статья этого автора (ППС, потому personType = 1)
		p.paper_id = a.paper_id AND
		a.personType = 1 AND 
		-- ППС только с этой кафедры
		a.person_id IN
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
			) AND
		p.paper_id NOT IN 
			(
				select p2.paper_id
				FROM 
					DBScience.dbo.Papers p2,
					DBScience.dbo.L_Person_Paper_Authors a,
					DBScience.dbo.SciJournals sj,
					DBScience.dbo.L_SciJournal_IFRatingAgencies sip
				WHERE
				-- статья не архивирована
				p2.status != 2 AND
				-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
				sj.sciJournal_id = p2.periodicEdition_id AND
				p2.periodicEditionType_id = 1 AND
				-- импакт факторы, принадлежащие этой статье должны относиться к Томсон Ройтерс (id = 1) 
				-- и быть > 0
				sip.sciJournal_id = sj.sciJournal_id AND
				sip.IFRatingAgency_id = 1 AND sip.factorValue > 0 AND
				-- статья этого года
				p2.yearPublication in (@year, @year+1)  AND
				-- статья этого автора (ППС, потому personType = 1)
				p2.paper_id = a.paper_id AND
				a.personType = 1 AND 
				-- ППС только с этой кафедры
				a.person_id IN
					(SELECT
						DISTINCT p.personal_id
					FROM
						univer_personal p,
						univer_structure_division_1c sd,
						univer_personal_struct_pos_link_1c spl
					WHERE
						p.personal_id = spl.personal_id AND
						sd.structure_division_id = spl.structure_division_id AND
						sd.structure_division_id = @chairId AND
						spl.status != 2  AND p.status != 2
					)
				UNION
				SELECT p3.paper_id
				FROM 
					DBScience.dbo.Papers p3,
					DBScience.dbo.L_Person_Paper_Authors a,
					DBScience.dbo.SciJournals sj
				WHERE
				-- статья не архивирована
				p3.status != 2 AND
				-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
				sj.sciJournal_id = p.periodicEdition_id AND
				p3.periodicEditionType_id = 1 AND
				-- журнал должен иметь галочку "относится к scopus"
				sj.indexedByScopus = 1 AND
				-- статья этого года
				p3.yearPublication in (@year, @year+1) AND
				-- статья этого автора (ППС, потому personType = 1)
				p3.paper_id = a.paper_id AND
				a.personType = 1 AND 
				-- ППС только с этой кафедры
				a.person_id IN
					(SELECT
						DISTINCT p.personal_id
					FROM
						univer_personal p,
						univer_structure_division_1c sd,
						univer_personal_struct_pos_link_1c spl
					WHERE
						p.personal_id = spl.personal_id AND
						sd.structure_division_id = spl.structure_division_id AND
						sd.structure_division_id = @chairId AND
						spl.status != 2  AND p.status != 2
					)
			)
	) AND sj.sciJournal_id = p.periodicEdition_id 
END

-- ==================================== если издание или мероприятие ближнего зарубежья
IF (@editionTypeId = 2)
BEGIN
	SELECT @PaperStr = COALESCE(@PaperStr + '\n\n', '') + 
		ISNULL(
		CONVERT(NVARCHAR(MAX), ROW_NUMBER() OVER (ORDER BY dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.paper_id, 2))) +N') '
		+ N'Научная статья\n' +
		+ N'Автор(ы): ' + dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.paper_id, 2) 
		+ N'\nНазвание: \nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en 
		+ N'\nЖурнал:' + sj.name + N'\nСтрана журнала:' + c.name_ru, '')
		--AS [description]
	FROM 
		DBScience.dbo.Papers p,
		DBScience.dbo.SciJournals sj,
		DBScience.dbo.Countries c
	WHERE
	p.paper_id IN
	(SELECT
		DISTINCT p.paper_id
	FROM
		DBScience.dbo.Papers p,
		DBScience.dbo.L_Person_Paper_Authors a,
		DBScience.dbo.SciJournals sj,
		DBScience.dbo.Countries c
	WHERE
		-- статья не архивирована
		p.status != 2 AND
		-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
		sj.sciJournal_id = p.periodicEdition_id AND
		p.periodicEditionType_id = 1 AND
		-- страна журнала должна быть в ближнем зарубежье и не текущей (Казахстан)
		sj.journalCountry_id = c.country_id AND
		c.foreignType in (0, 1) AND c.countryCurrent = 0 AND
		-- статья этого года
		p.yearPublication in (@year, @year + 1) AND
		-- статья этого автора (ППС, потому personType = 1)
		p.paper_id = a.paper_id AND
		a.personType = 1 AND 
		-- ППС этой кафедры
		a.person_id IN
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
			) 
		AND
		p.paper_id NOT IN 
			(
				select p2.paper_id
				FROM 
					DBScience.dbo.Papers p2,
					DBScience.dbo.L_Person_Paper_Authors a,
					DBScience.dbo.SciJournals sj,
					DBScience.dbo.L_SciJournal_IFRatingAgencies sip
				WHERE
				-- статья не архивирована
				p2.status != 2 AND
				-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
				sj.sciJournal_id = p2.periodicEdition_id AND
				p2.periodicEditionType_id = 1 AND
				-- импакт факторы, принадлежащие этой статье должны относиться к Томсон Ройтерс (id = 1) 
				-- и быть > 0
				sip.sciJournal_id = sj.sciJournal_id AND
				sip.IFRatingAgency_id = 1 AND sip.factorValue > 0 AND
				-- статья этого года
				p2.yearPublication in (@year, @year+1)  AND
				-- статья этого автора (ППС, потому personType = 1)
				p2.paper_id = a.paper_id AND
				a.personType = 1 AND 
				-- ППС этой кафедры
				a.person_id IN
					(SELECT
						DISTINCT p.personal_id
					FROM
						univer_personal p,
						univer_structure_division_1c sd,
						univer_personal_struct_pos_link_1c spl
					WHERE
						p.personal_id = spl.personal_id AND
						sd.structure_division_id = spl.structure_division_id AND
						sd.structure_division_id = @chairId AND
						spl.status != 2  AND p.status != 2
					)
				UNION
				SELECT p3.paper_id
				FROM 
					DBScience.dbo.Papers p3,
					DBScience.dbo.L_Person_Paper_Authors a,
					DBScience.dbo.SciJournals sj
				WHERE
				-- статья не архивирована
				p3.status != 2 AND
				-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
				sj.sciJournal_id = p.periodicEdition_id AND
				p3.periodicEditionType_id = 1 AND
				-- журнал должен иметь галочку "относится к scopus"
				sj.indexedByScopus = 1 AND
				-- статья этого года
				p3.yearPublication in (@year, @year+1) AND
				-- статья этого автора (ППС, потому personType = 1)
				p3.paper_id = a.paper_id AND
				a.personType = 1 AND 
				-- ППС этой кафедры
				a.person_id IN
					(SELECT
						DISTINCT p.personal_id
					FROM
						univer_personal p,
						univer_structure_division_1c sd,
						univer_personal_struct_pos_link_1c spl
					WHERE
						p.personal_id = spl.personal_id AND
						sd.structure_division_id = spl.structure_division_id AND
						sd.structure_division_id = @chairId AND
						spl.status != 2  AND p.status != 2
					)
			)
	) AND p.periodicEdition_id = sj.sciJournal_id AND c.country_id = sj.journalCountry_id
	
	SELECT @ThesisStr = COALESCE(@ThesisStr + '\n\n', '') + 
		ISNULL(
		CONVERT(NVARCHAR(MAX), ROW_NUMBER() OVER (ORDER BY dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(th.thesis_id, 3))) +N') '
		+  tp.name_ru +
		+ N'\nАвтор(ы): ' + dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(th.thesis_id, 3) 
		+ N'Название:\nKZ: ' +   th.name_kz + N'\nRU: ' + th.name_ru + N'\nEN: ' + th.name_en 
		+ N'\nМероприятие: ' + st.name_ru + N'\nKZ: '+se.name_kz + N'\nRU: ' +
		se.name_ru + N'\nEN: ' + se.name_en + N'\nСтрана:' + c.name_ru, '')
	FROM
		DBScience.dbo.Thesises th,
		DBScience.dbo.SciEvents se,
		DBScience.dbo.SciEventTypes st,
		DBScience.dbo.ThesisTypes tp,
		DBScience.dbo.Countries c
	WHERE
		th.thesis_id IN
		(SELECT
			DISTINCT th.thesis_id
		FROM
			DBScience.dbo.Thesises th,
			DBScience.dbo.L_Person_Thesis_Authors a,
			DBScience.dbo.SciEvents se,
			DBScience.dbo.SciEventTypes st,
			DBScience.dbo.ThesisTypes tp,
			DBScience.dbo.Countries c
		WHERE
			-- тезис не архивирован
			th.status != 2 AND
			-- тезис этого автора (ППС, потому personType = 1)
			th.thesis_id = a.thesis_id AND
			a.personType = 1 AND 
			-- ППС этой кафедры
			a.person_id IN
				(SELECT
					DISTINCT p.personal_id
				FROM
					univer_personal p,
					univer_structure_division_1c sd,
					univer_personal_struct_pos_link_1c spl
				WHERE
					p.personal_id = spl.personal_id AND
					sd.structure_division_id = spl.structure_division_id AND
					sd.structure_division_id = @chairId AND
					spl.status != 2  AND p.status != 2
				) 
			AND
			tp.thesisType_id = th.thesisType_id AND
			-- мероприятие этого тезиса
			se.sciEvent_id = th.sciEvent_id AND
			-- мероприятие международное (id=5)
			se.sciEventForm_id = 5 AND st.sciEventType_id = se.sciEventType_id AND
			-- страна мероприятия должна быть ближнего зарубежья и не текущей
			se.country_id = c.country_id AND c.foreignType in (0, 1) AND c.countryCurrent = 0 AND
			-- тезис этого года (по мероприятию)
			YEAR(se.eventStart) in (@year, @year + 1)
		) AND th.sciEvent_id = se.sciEvent_id AND st.sciEventType_id = se.sciEventType_id AND
		th.thesisType_id = tp.thesisType_id AND
		se.country_id = c.country_id 
		
SELECT @Result = 
	N'------------- Научные статьи -----------\n' + ISNULL(@PaperStr,'') 
	+ N'\n\n' 
	+ N'------------- Труды в материалах мероприятий -----------\n' + ISNULL(@ThesisStr,'')
END

-- ==================================== если издание или мероприятие дальнего зарубежья
IF (@editionTypeId = 3)
BEGIN
	SELECT @PaperStr = COALESCE(@PaperStr + '\n\n', '') + 
		ISNULL(
		CONVERT(NVARCHAR(MAX), ROW_NUMBER() OVER (ORDER BY dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.paper_id, 2))) +N') '
		+ N'Научная статья\n' +
		+ N'Автор(ы): ' + dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.paper_id, 2) 
		+ N'\nНазвание: \nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en 
		+ N'\nЖурнал:' + sj.name + N'\nСтрана журнала:' + c.name_ru, '')
		--AS [description]
	FROM 
		DBScience.dbo.Papers p,
		DBScience.dbo.SciJournals sj,
		DBScience.dbo.Countries c
	WHERE
	p.paper_id IN
	(SELECT
		DISTINCT p.paper_id
	FROM
		DBScience.dbo.Papers p,
		DBScience.dbo.L_Person_Paper_Authors a,
		DBScience.dbo.SciJournals sj,
		DBScience.dbo.Countries c
	WHERE
		-- статья не архивирована
		p.status != 2 AND
		-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
		sj.sciJournal_id = p.periodicEdition_id AND
		p.periodicEditionType_id = 1 AND
		-- страна журнала должна быть в ближнем зарубежье и не текущей (Казахстан)
		sj.journalCountry_id = c.country_id AND
		c.foreignType in (2) AND
		-- статья этого года
		p.yearPublication in (@year, @year + 1) AND
		-- статья этого автора (ППС, потому personType = 1)
		p.paper_id = a.paper_id AND
		a.personType = 1 AND 
		-- ППС этой кафедры
		a.person_id IN
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
			) 
		AND
		p.paper_id NOT IN 
			(
				select p2.paper_id
				FROM 
					DBScience.dbo.Papers p2,
					DBScience.dbo.L_Person_Paper_Authors a,
					DBScience.dbo.SciJournals sj,
					DBScience.dbo.L_SciJournal_IFRatingAgencies sip
				WHERE
				-- статья не архивирована
				p2.status != 2 AND
				-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
				sj.sciJournal_id = p2.periodicEdition_id AND
				p2.periodicEditionType_id = 1 AND
				-- импакт факторы, принадлежащие этой статье должны относиться к Томсон Ройтерс (id = 1) 
				-- и быть > 0
				sip.sciJournal_id = sj.sciJournal_id AND
				sip.IFRatingAgency_id = 1 AND sip.factorValue > 0 AND
				-- статья этого года
				p2.yearPublication in (@year, @year+1)  AND
				-- статья этого автора (ППС, потому personType = 1)
				p2.paper_id = a.paper_id AND
				a.personType = 1 AND 
				-- ППС этой кафедры
				a.person_id IN
					(SELECT
						DISTINCT p.personal_id
					FROM
						univer_personal p,
						univer_structure_division_1c sd,
						univer_personal_struct_pos_link_1c spl
					WHERE
						p.personal_id = spl.personal_id AND
						sd.structure_division_id = spl.structure_division_id AND
						sd.structure_division_id = @chairId AND
						spl.status != 2  AND p.status != 2
					)
				UNION
				SELECT p3.paper_id
				FROM 
					DBScience.dbo.Papers p3,
					DBScience.dbo.L_Person_Paper_Authors a,
					DBScience.dbo.SciJournals sj
				WHERE
				-- статья не архивирована
				p3.status != 2 AND
				-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
				sj.sciJournal_id = p.periodicEdition_id AND
				p3.periodicEditionType_id = 1 AND
				-- журнал должен иметь галочку "относится к scopus"
				sj.indexedByScopus = 1 AND
				-- статья этого года
				p3.yearPublication in (@year, @year+1) AND
				-- статья этого автора (ППС, потому personType = 1)
				p3.paper_id = a.paper_id AND
				a.personType = 1 AND 
				-- ППС этой кафедры
				a.person_id IN
					(SELECT
						DISTINCT p.personal_id
					FROM
						univer_personal p,
						univer_structure_division_1c sd,
						univer_personal_struct_pos_link_1c spl
					WHERE
						p.personal_id = spl.personal_id AND
						sd.structure_division_id = spl.structure_division_id AND
						sd.structure_division_id = @chairId AND
						spl.status != 2  AND p.status != 2
					)
			)
	) AND p.periodicEdition_id = sj.sciJournal_id AND c.country_id = sj.journalCountry_id
	
	SELECT @ThesisStr = COALESCE(@ThesisStr + '\n\n', '') + 
		ISNULL(
		CONVERT(NVARCHAR(MAX), ROW_NUMBER() OVER (ORDER BY dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(th.thesis_id, 3))) +N') '
		+  tp.name_ru +
		+ N'\nАвтор(ы): ' + dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(th.thesis_id, 3) 
		+ N'Название:\nKZ: ' +   th.name_kz + N'\nRU: ' + th.name_ru + N'\nEN: ' + th.name_en 
		+ N'\nМероприятие: ' + st.name_ru + N'\nKZ: '+se.name_kz + N'\nRU: ' +
		se.name_ru + N'\nEN: ' + se.name_en + N'\nСтрана:' + c.name_ru, '')
	FROM
		DBScience.dbo.Thesises th,
		DBScience.dbo.SciEvents se,
		DBScience.dbo.SciEventTypes st,
		DBScience.dbo.ThesisTypes tp,
		DBScience.dbo.Countries c
	WHERE
		th.thesis_id IN
		(SELECT
			DISTINCT th.thesis_id
		FROM
			DBScience.dbo.Thesises th,
			DBScience.dbo.L_Person_Thesis_Authors a,
			DBScience.dbo.SciEvents se,
			DBScience.dbo.SciEventTypes st,
			DBScience.dbo.ThesisTypes tp,
			DBScience.dbo.Countries c
		WHERE
			-- тезис не архивирован
			th.status != 2 AND
			-- тезис этого автора (ППС, потому personType = 1)
			th.thesis_id = a.thesis_id AND
			a.personType = 1 AND 
			-- ППС этой кафедры
			a.person_id IN
				(SELECT
					DISTINCT p.personal_id
				FROM
					univer_personal p,
					univer_structure_division_1c sd,
					univer_personal_struct_pos_link_1c spl
				WHERE
					p.personal_id = spl.personal_id AND
					sd.structure_division_id = spl.structure_division_id AND
					sd.structure_division_id = @chairId AND
					spl.status != 2  AND p.status != 2
				) 
			AND
			tp.thesisType_id = th.thesisType_id AND
			-- мероприятие этого тезиса
			se.sciEvent_id = th.sciEvent_id AND
			-- мероприятие международное (id=5)
			se.sciEventForm_id = 5 AND st.sciEventType_id = se.sciEventType_id AND
			-- страна мероприятия должна быть ближнего зарубежья и не текущей
			se.country_id = c.country_id AND c.foreignType in (2) AND
			-- тезис этого года (по мероприятию)
			YEAR(se.eventStart) in (@year, @year + 1)
		) AND th.sciEvent_id = se.sciEvent_id AND st.sciEventType_id = se.sciEventType_id AND
		th.thesisType_id = tp.thesisType_id AND
		se.country_id = c.country_id 
		
SELECT @Result = 
	N'------------- Научные статьи -----------\n' + ISNULL(@PaperStr,'') 
	+ N'\n\n' 
	+ N'------------- Труды в материалах мероприятий -----------\n' + ISNULL(@ThesisStr,'')
END

RETURN @Result

END
go

