-- =============================================
-- Author:		Ruslan
-- Create date: 15.07.2016
-- Description:	Триггер на добавление коменданта
-- =============================================
CREATE TRIGGER [dbo].[commandantInsertTrigger] ON  [dbo].[univer_commandant] FOR INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	-- Insert statements for trigger here
	-- Цифра доступа для данной сущности
	DECLARE @pi int
	
	DECLARE insCursor cursor 
		FOR SELECT personal_id FROM inserted WHERE status=1
		
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @pi
	WHILE @@FETCH_STATUS = 0
	BEGIN
		exec dbo.personalSetAccess @pi, 'COMMANDANT'
		FETCH NEXT FROM insCursor INTO @pi;
	END
	CLOSE insCursor
END
go

