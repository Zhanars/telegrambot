
-- =============================================
-- Author:		Yerlan
-- Create date: 11.02.2016
-- Description:	Подсчет общего балла по рейтингу ППС для преподавателя в процентах
-- =============================================
CREATE FUNCTION [dbo].[IP_GetTotalRatingPPSBallInPercent]
(
 @personalId int,
 @year int,
 @categoryId int
)
RETURNS float
AS
BEGIN
	DECLARE @ret float;
	DECLARE @bestRes float;
	DECLARE @summ float;
	
	IF NOT EXISTS(SELECT * FROM univer_indicator_rating_personal p, univer_indicators i WHERE p.personal_id=@personalId AND p.year = @year AND p.indicator_id = i.indicator_id AND i.indicator_category_id=@categoryId)
	BEGIN
		SET @ret = -1;
	END;
	ELSE
	BEGIN
		SET @bestRes = 7000;/*Максимальный балл за рейтинг для любого преподавателя*/
		SET @summ = ISNULL((SELECT CONVERT(decimal(10,0), SUM(ISNULL((case when irp1.indicator_rating_personal_approve_value IS NOT NULL THEN irp1.indicator_rating_personal_approve_value 
								ELSE irp1.indicator_rating_personal_value END),0)*ISNULL(case when i.indicator_direction_id=1 then 0.35 when i.indicator_direction_id=2 then 0.5 when i.indicator_direction_id=3 then 0.15 
								when i.indicator_direction_id=7 then 0.5 else 0 end,1))) as appScore
				FROM univer_indicator_rating_personal irp1 INNER JOIN univer_indicators i ON irp1.indicator_id=i.indicator_id and irp1.personal_id=@personalId AND irp1.year=@year 
					AND irp1.indicator_rating_personal_approve=1
					AND i.indicator_category_id=@categoryId --AND i.status=@status 
				--INNER JOIN univer_indicator_cost ic ON i.indicator_id = ic.indicator_id /*and ic.status=@status and ic.year=2015*/ 
				WHERE i.indicator_category_id=@categoryId and irp1.year=@year /*and i.status=@status */and irp1.personal_id=@personalId
					AND irp1.indicator_rating_personal_approve=1),0);
		SET @ret = ROUND(@summ * 100/@bestRes,0);
		IF (@ret>100)
		begin
			set @ret = 100;
		end;
	END;
	RETURN isnull(@ret,0)
END
go

