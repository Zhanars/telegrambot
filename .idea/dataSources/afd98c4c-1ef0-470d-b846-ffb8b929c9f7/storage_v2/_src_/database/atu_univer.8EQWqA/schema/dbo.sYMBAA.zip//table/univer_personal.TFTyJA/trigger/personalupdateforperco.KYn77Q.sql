-- =============================================
-- Author:		Yerlan
-- Create date: 23.09.2016
-- Description:	for perco
-- =============================================
CREATE TRIGGER [dbo].[personalUpdateForPerco]
   ON  [dbo].[univer_personal]
   AFTER update
AS 
BEGIN

	IF @@ROWCOUNT =0
    RETURN
    
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	--Update block.
	DELETE FROM perco_univer_personal WHERE personal_id IN (select DISTINCT i.personal_id from inserted i INNER JOIN deleted d ON i.personal_id=d.personal_id AND i.status=1 AND d.status=2);
	insert into perco_univer_personal(personal_id, operation)
	select DISTINCT i.personal_id, 4/*RESTORE*/ 
	from inserted i INNER JOIN deleted d ON i.personal_id=d.personal_id AND i.status=1 AND d.status=2
	
	DELETE FROM perco_univer_personal WHERE personal_id IN (select DISTINCT i.personal_id from inserted i INNER JOIN deleted d ON i.personal_id=d.personal_id AND i.status=2 AND d.status=1);
	insert into perco_univer_personal(personal_id, operation)
	select DISTINCT i.personal_id, 3/*DISMISS*/ 
	from inserted i INNER JOIN deleted d ON i.personal_id=d.personal_id AND i.status=2 AND d.status=1
    
END
go

