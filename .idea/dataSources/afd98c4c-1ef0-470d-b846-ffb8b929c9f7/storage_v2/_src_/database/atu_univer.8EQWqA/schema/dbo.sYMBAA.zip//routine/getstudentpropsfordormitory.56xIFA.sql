

-- =============================================
-- Author:		Yerlan
-- Create date: 18.07.2016
-- Description: Получить Наличие преимущественного права студента для заселения в общежитий в виде строки
-- =============================================
CREATE FUNCTION [dbo].[GetStudentPropsForDormitory]
(
	@studentId int,
	@langId int
)

-----------------------------------------------------------------
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @Result NVARCHAR(MAX)

-- ==================================== 
BEGIN
	DECLARE @propertyType int;
	DECLARE @localVar nvarchar(max);
    /**************************************************************************************/
    DECLARE @propTable table (pid int, ptype int, pname nvarchar(150));
    INSERT INTO @propTable(pid, ptype, pname)
    SELECT s.properties_id,s.properties_type,case when @langId=2 then s.properties_name_ru else s.properties_name_kz end
    FROM univer_students_properties s,univer_student_properties_link spl where s.properties_id = spl.properties_id AND s.status=1 AND spl.students_id=@studentId 
		--and s.properties_id not in (15,16,17,19,91,5,26,6,27,94,95,92,93,2,3,4,23,97)
    order by s.properties_type;
    
    /**@propertyType=1*****Nagrada*/
    set @propertyType=1;
	SELECT @localVar = COALESCE(@localVar, '') + 
		ISNULL(CONVERT(NVARCHAR(MAX), ROW_NUMBER() OVER (ORDER BY t.pid)) +N') '
		+N'\n' + t.pname+';', '')
		FROM @propTable t
		WHERE t.ptype=@propertyType;
	IF LEN(@localVar)>0
	BEGIN
		SET @Result = (case when @langId=1 then N'Марапаттары: ' else N'Награды: ' end)+@localVar + '\n';
	END;
	
	SET @localVar = '';		
    /**@propertyType=2*****Kvota*/
    set @propertyType=2;    
	SELECT @localVar = COALESCE(@localVar, '') + 
		ISNULL(CONVERT(NVARCHAR(MAX), ROW_NUMBER() OVER (ORDER BY t.pid)) +N') '
		+N'\n' + t.pname+';', '')
		FROM @propTable t
		WHERE t.ptype=@propertyType;
	IF LEN(@localVar)>0
	BEGIN
		SET @Result = ISNULL(@Result,'') + '\n'+(case when @langId=1 then N'Квоталар: ' else N'Квоты: ' end)+@localVar + '\n';
	END;
			
	SET @localVar = '';	
    /**@propertyType=3*****Соц. характеристика*/
    set @propertyType=3;
    
	SELECT @localVar = COALESCE(@localVar, '') + 
		ISNULL(CONVERT(NVARCHAR(MAX), ROW_NUMBER() OVER (ORDER BY t.pid)) +N') '
		+N'\n' + t.pname+';', '')
		--AS [description]
		FROM 
			@propTable t
		WHERE t.ptype=@propertyType;
	IF LEN(@localVar)>0
	BEGIN
		SET @Result = ISNULL(@Result,'') + '\n'+(case when @langId=1 then N'Соц. характеристика: ' else N'Соц. характеристика: ' end)+@localVar + '\n';
	END;
			
	DECLARE @admitReason nvarchar(100), @childCnt int, @citizenship nvarchar(100), @married bit;
	
	select @admitReason = (CASE WHEN @langId=1 then ar.admission_reason_name_kz else ar.admission_reason_name_ru end)
		,@childCnt = st.students_children_count
		,@citizenship = (CASE WHEN @langId=1 then c.country_name_kz else c.country_name_ru end)
		,@married = st.students_marital_status
	from univer_students st 
		LEFT JOIN univer_admission_reason ar ON ar.admission_reason_id=st.admission_reason_id and ar.status=1 
		LEFT JOIN univer_country c ON st.citizenship_id=c.country_id and c.status=1 
	where st.students_id=@studentId;
	
	SET @Result = ISNULL(@Result,'') + (case when @langId=2 then N'Основание для поступления: ' else N'Түсу негiзі: ' end)+ISNULL(@admitReason,'') + '\n';
	SET @Result = ISNULL(@Result,'') + (case when @langId=2 then N'Кол. несов. детей или студентов : ' else N'Отбасыдағы кәмелетке толмаған/студенттер: ' end)+ISNULL(CAST(@childCnt AS NVARCHAR(10)),'') + '\n';
	SET @Result = ISNULL(@Result,'') + (case when @langId=2 then N'Гражданство: ' else N'Азаматтығы: ' end)+ISNULL(@citizenship,'') + '\n';
	SET @Result = ISNULL(@Result,'') + (case when @langId=2 then N'Сем. полож.: ' else N'Отбасы жағд.: ' end)+ISNULL(case when @married=1 then (case when @langId=1 then N'Үйленген/Тұрмыс құрған ' else N'Женат/Замежем ' end) else (case when @langId=1 then N'Бойдақ/Тұрмыс құрмаған ' else N'Холост/ Не замужем' end) end,'') + '\n';
			
END

RETURN ISNULL(@Result,N'')
END


go

