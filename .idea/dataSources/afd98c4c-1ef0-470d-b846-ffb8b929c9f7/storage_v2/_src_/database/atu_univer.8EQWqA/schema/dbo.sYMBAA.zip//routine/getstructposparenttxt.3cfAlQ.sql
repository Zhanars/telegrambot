CREATE FUNCTION [dbo].[getStructPosParentTXT]
(
	@structPosId int,
    @lang nvarchar(2)
)
RETURNS nvarchar(max)
AS
BEGIN
    declare @ret nvarchar(max);
    set @ret='';
    declare @parentId int; 
    set @parentId=@structPosId;
    while (@parentId>0)
    begin 
    select @parentId=structure_division_ext,
    @ret=case when structure_division_ext>0 then '->'+case @lang
    when N'kz' then isnull(structure_division_name_kz,structure_division_name_ru)
    when N'ru' then structure_division_name_ru
    when N'en' then isnull(structure_division_name_en,structure_division_name_ru) else '' end else '' end+ @ret
     from univer_structure_division_1c where structure_division_id=@parentId and status=1
    end;
	
  

set @ret=substring(@ret,3,len(@ret));
return @ret
END

go

