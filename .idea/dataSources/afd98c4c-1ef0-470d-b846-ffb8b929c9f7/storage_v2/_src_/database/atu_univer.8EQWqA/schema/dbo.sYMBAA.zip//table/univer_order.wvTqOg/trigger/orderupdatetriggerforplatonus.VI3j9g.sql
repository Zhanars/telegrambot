-- =============================================
-- Author:		Yerlan
-- Create date: 2013-11-05 17:44:33.680
-- Description:	Добавление записи о том что данные приказа были изменены 
-- =============================================
CREATE TRIGGER [dbo].[orderUpdateTriggerForPlatonus]
   ON  [dbo].[univer_order]
   AFTER UPDATE
AS 
BEGIN
	
	IF @@ROWCOUNT =0
    RETURN
	 
	SET NOCOUNT ON;
	--Update block.
	IF EXISTS(SELECT * FROM inserted i WHERE i.status IN (21,22,2)) AND  NOT EXISTS(SELECT * FROM deleted)
	BEGIN
		DELETE FROM platonus_univer_order WHERE order_id in(select order_id from inserted);

		INSERT INTO platonus_univer_order(order_id, command)
		SELECT DISTINCT i.order_id,'delete' from inserted i where i.status=2
		
		INSERT INTO platonus_univer_order(order_id, command)
		SELECT DISTINCT i.order_id,'update' FROM inserted i   where i.status<>2
	END

	--Update block.
	IF EXISTS(SELECT * FROM inserted i WHERE i.status IN (21,22,2)) AND EXISTS(SELECT * FROM deleted)
	BEGIN
		DELETE FROM platonus_univer_order WHERE order_id in(select order_id from deleted union all select order_id from inserted);

		INSERT INTO platonus_univer_order(order_id, command)
		SELECT DISTINCT d.order_id,'delete'
		FROM deleted d  WHERE d.order_id not in(select order_id from inserted i where i.status<>2)
		
		INSERT INTO platonus_univer_order(order_id, command)
		SELECT DISTINCT i.order_id,'update'
		FROM inserted i   where i.status<>2
	END
	
	
	--DELETE block, in univer there are only 2 ways: insert and delete. 
	--IF EXISTS(SELECT * FROM deleted d WHERE d.status=1) AND NOT EXISTS(SELECT * FROM inserted i)
	--BEGIN
	--	INSERT INTO platonus_univer_progress(progress_id,command)
	--	SELECT DISTINCT progress_id,'delete' FROM deleted i 
	--	WHERE i.status=1 AND i.progress_id NOT IN (SELECT subject_id FROM platonus_univer_progress)
	--END
END
go

