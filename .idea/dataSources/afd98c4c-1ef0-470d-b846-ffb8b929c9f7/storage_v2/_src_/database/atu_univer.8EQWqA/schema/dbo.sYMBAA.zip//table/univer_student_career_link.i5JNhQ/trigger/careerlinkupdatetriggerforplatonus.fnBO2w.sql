create TRIGGER [dbo].[CareerLinkUpdateTriggerForPlatonus]
   ON  [dbo].[univer_student_career_link] 
   AFTER UPDATE,INSERT,DELETE
AS 
BEGIN
	
	IF @@ROWCOUNT =0
    RETURN
	
	SET NOCOUNT ON;
	
	--Insert block, all new inserted subject_id will be writed as update
	IF EXISTS(SELECT * FROM inserted) AND NOT EXISTS(SELECT * FROM deleted)
	BEGIN
		INSERT INTO platonus_univer_students(student_id, command)
		SELECT student_id,'update' FROM inserted i 
		WHERE i.student_id NOT IN (SELECT student_id FROM platonus_univer_students)
	END
	
	
	--Update block, all new updated subject_id will be writed as update, and old subject_id from deleted will be writed as delete.
	--This block usually triggers when programmer updates subject_id in educ_plan_pos table to zips catalog of subject.
	--Delete will trigger only for subject_id changing
	IF EXISTS(SELECT * FROM deleted) AND EXISTS(SELECT * FROM inserted i)
	BEGIN
		delete from platonus_univer_students where student_id in (select student_id from deleted)
		
		insert into platonus_univer_students(student_id, command)
		select i.student_id, 'update' from inserted i
		WHERE i.student_id NOT IN (SELECT student_id FROM platonus_univer_students)
		
	END
	
	--DELETE block, in univer there are only 2 ways: insert and delete. 
	IF EXISTS(SELECT * FROM deleted d) AND NOT EXISTS(SELECT * FROM inserted i)
	BEGIN
				
		INSERT INTO platonus_univer_students(student_id,command)
		SELECT student_id,'update' FROM deleted d 
		WHERE d.student_id NOT IN (SELECT student_id FROM platonus_univer_students)
	END
END
go

