CREATE VIEW dbo.site_faculty_1c
AS
SELECT     structure_division_id AS faculty_id, structure_division_name_kz AS faculty_name_kz, structure_division_name_ru AS faculty_name_ru, 
                      structure_division_name_en AS faculty_name_en
FROM         dbo.univer_structure_division_1c
WHERE     (structure_division_ext = 8) AND (status = 1) AND (structure_division_id NOT IN (340, 11))
go

