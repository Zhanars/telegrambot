
-- =============================================
-- Author:		Yerlan
-- Create date: 26.12.2016
-- Description: Получить Количество учебно-методических статей через Доклады в материалах в научно-методических конференциях
-- (1.4если учебно-методических статей ; 2.8Количество статей, опубликованных в материалах международных научных конференций (Proceedings), индексируемых в международной базе данных Scopus)
-- =============================================
CREATE FUNCTION [dbo].[IP_NIR_NEW_getSciThesises_Count_By]
(
	@categoryId int,
	@personalId int=0,
	@chairId int=0,
	@facultyId int=0,
	@year int=0,
	@indicatorCode varchar(10)
)
RETURNS int
AS
BEGIN
	DECLARE @Result int=0;
	declare @Result2 int =0;
-- ==================================== если учебно-методических статей 
IF (@indicatorCode='1.4')
	BEGIN
		SELECT @Result =  COUNT(*)
		FROM
			DBScience.dbo.Thesises th,
			DBScience.dbo.L_Person_Thesis_Authors a,
			DBScience.dbo.SciEvents se
		WHERE
			-- тезис не архивирован
			th.status != 2 AND
			EXISTS(select * from DBScience.dbo.IndPlanIndicator ind WHERE ind.code=@indicatorCode AND ind.ipIndicator_id=th.ipIndicator_id) AND
			th.sciEvent_id = se.sciEvent_id AND
			-- тезис этого года
			YEAR(se.eventStart) in (@year, @year+1) and
			-- не дублированная и подтвержденная
			th.is_overlap IS NULL AND
			th.is_approve=1 AND
			-- тезис этого автора (ППС, потому personType = 1)
			th.thesis_id = a.thesis_id AND
			a.personType = 1 AND 
			(
			-- на уровне ппс
			(@categoryId=3 AND a.person_id = @personalId)
			OR
			-- на уровне кафедры
			(@categoryId=2 AND a.person_id IN 
				(SELECT
					DISTINCT p.personal_id
				FROM
					univer_personal p,
					univer_structure_division_1c sd,
					univer_personal_struct_pos_link_1c spl
				WHERE
					p.personal_id = spl.personal_id AND
					sd.structure_division_id = spl.structure_division_id AND
					sd.structure_division_id = @chairId AND
					spl.status != 2  AND p.status != 2
					AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
				))
			OR
			-- на уровне факультета
			(@categoryId=1 AND a.person_id IN 
				(SELECT
					DISTINCT p.personal_id
				FROM
					univer_personal p,
					univer_structure_division_1c sd,
					univer_personal_struct_pos_link_1c spl
				WHERE
					p.personal_id = spl.personal_id AND
					sd.structure_division_id = spl.structure_division_id AND
					sd.structure_division_ext = @facultyId AND
					spl.status != 2  AND p.status != 2
					AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
				))
			);
			
		SELECT @Result2 = COUNT(*)
		FROM 
			DBScience.dbo.ImagePapers p,
			DBScience.dbo.L_Person_ImagePaper_Authors a,
			DBScience.dbo.OtherPeriodicEditions op,
			DBScience.dbo.Countries c,
			DBScience.dbo.Publishers pb
		WHERE
			-- статья не архивирована
			p.status != 2 AND
			op.otherPeriodicEdition_id = p.periodicEdition_id AND
			op.publisher_id = pb.publisher_id AND
			pb.country_id = c.country_id AND
			EXISTS(select * from DBScience.dbo.IndPlanIndicator ind WHERE ind.code=@indicatorCode AND ind.ipIndicator_id=p.ipIndicator_id) AND
			-- статья этого года
			p.yearPublication in (@year, @year + 1) AND
			-- не дублированная и подтвержденная
			p.is_overlap IS NULL AND
			p.is_approve=1 AND
			-- статья этого автора (ППС, потому personType = 1)
			p.imagePaper_id = a.imagePaper_id AND
			a.personType = 1 AND 
			(
			-- на уровне ппс
			(@categoryId=3 AND a.person_id = @personalId)
			OR
			-- на уровне кафедры
			(@categoryId=2 AND a.person_id IN 
				(SELECT
					DISTINCT p.personal_id
				FROM
					univer_personal p,
					univer_structure_division_1c sd,
					univer_personal_struct_pos_link_1c spl
				WHERE
					p.personal_id = spl.personal_id AND
					sd.structure_division_id = spl.structure_division_id AND
					sd.structure_division_id = @chairId AND
					spl.status != 2  AND p.status != 2
					AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
				))
			OR
			-- на уровне факультета
			(@categoryId=1 AND a.person_id IN 
				(SELECT
					DISTINCT p.personal_id
				FROM
					univer_personal p,
					univer_structure_division_1c sd,
					univer_personal_struct_pos_link_1c spl
				WHERE
					p.personal_id = spl.personal_id AND
					sd.structure_division_id = spl.structure_division_id AND
					sd.structure_division_ext = @facultyId AND
					spl.status != 2  AND p.status != 2
					AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
				))
			)
			
	END;
	/********************Количество статей, опубликованных в материалах международных научных конференций (Proceedings), индексируемых в международной базе данных Scopus******/
IF (@indicatorCode='2.8')
	BEGIN
		SELECT @Result =  COUNT(*)
		FROM
			DBScience.dbo.Thesises th,
			DBScience.dbo.L_Person_Thesis_Authors a,
			DBScience.dbo.SciEvents se
		WHERE
			-- тезис не архивирован
			th.status != 2 AND
			EXISTS(select * from DBScience.dbo.IndPlanIndicator ind WHERE ind.code=@indicatorCode AND ind.ipIndicator_id=th.ipIndicator_id) AND
			-- тезис этого года (по мероприятию)
			th.sciEvent_id = se.sciEvent_id AND
			-- тезис этого года
			YEAR(se.eventStart) in (@year, @year+1) and
			-- не дублированная и подтвержденная
			th.is_overlap IS NULL AND
			th.is_approve=1 AND
			-- тезис этого автора (ППС, потому personType = 1)
			th.thesis_id = a.thesis_id AND
			a.personType = 1 AND 
			(
			-- на уровне ппс
			(@categoryId=3 AND a.person_id = @personalId)
			OR
			-- на уровне кафедры
			(@categoryId=2 AND a.person_id IN 
				(SELECT
					DISTINCT p.personal_id
				FROM
					univer_personal p,
					univer_structure_division_1c sd,
					univer_personal_struct_pos_link_1c spl
				WHERE
					p.personal_id = spl.personal_id AND
					sd.structure_division_id = spl.structure_division_id AND
					sd.structure_division_id = @chairId AND
					spl.status != 2  AND p.status != 2
					AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
				))
			OR
			-- на уровне факультета
			(@categoryId=1 AND a.person_id IN 
				(SELECT
					DISTINCT p.personal_id
				FROM
					univer_personal p,
					univer_structure_division_1c sd,
					univer_personal_struct_pos_link_1c spl
				WHERE
					p.personal_id = spl.personal_id AND
					sd.structure_division_id = spl.structure_division_id AND
					sd.structure_division_ext = @facultyId AND
					spl.status != 2  AND p.status != 2
					AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
				))
			);
	END;
		
	RETURN @Result+@Result2;

END

go

