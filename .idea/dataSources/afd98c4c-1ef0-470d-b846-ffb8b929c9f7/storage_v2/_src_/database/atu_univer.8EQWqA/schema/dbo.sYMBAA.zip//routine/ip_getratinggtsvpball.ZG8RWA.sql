-- =============================================
-- Author:		yerlan
-- Create date: 18.04.2015
-- Description:	
-- =============================================
CREATE FUNCTION [dbo].[IP_GetRatingGTSVPBall]
(
 @value real
)
RETURNS float
AS
BEGIN
	DECLARE @ret float

    if (@value <= 0) begin set @ret = 0; end
    else if (@value > 0  and @value < 26) begin set @ret = 0; end
    else if (@value >= 26  and @value < 61) begin set @ret = 90; end
    else if (@value >= 61  and @value < 86) begin set @ret = 180; end
    else if (@value >= 86  and @value <= 100) begin set @ret = 300; end

	RETURN isnull(@ret,0)

END
go

