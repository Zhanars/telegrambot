-- =============================================
-- Author:		Twice
-- Create date: 31.01.2012
-- Description: Получить количество прохождений научной стажировки (1 - ближнее зарубежье, 2 - дальнее) - в разрезе сотрудника
-- =============================================
CREATE FUNCTION IP_NIR_getSciTrainigs_Count_ByPersonalId_DESC
(
	@personalId int,
	@year int,
	@foreignTypeId int
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @Result NVARCHAR(MAX)

SELECT @Result = N''

-- Return the result of the function
RETURN @Result

END
go

