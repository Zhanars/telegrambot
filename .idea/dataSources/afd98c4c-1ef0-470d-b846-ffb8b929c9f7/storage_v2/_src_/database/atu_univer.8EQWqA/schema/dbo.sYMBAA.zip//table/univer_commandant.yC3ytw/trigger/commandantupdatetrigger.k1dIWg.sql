-- =============================================
-- Author:		Ruslan
-- Create date: 15.07.2016
-- Description:	Триггер на изменение коменданта
-- =============================================
CREATE TRIGGER [dbo].[commandantUpdateTrigger]
   ON  [dbo].[univer_commandant]
   FOR UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @pi int
	DECLARE @st int
	
	DECLARE insCursor cursor 
		FOR SELECT personal_id, status FROM inserted
	
	IF UPDATE(status)
	BEGIN
		OPEN insCursor
		FETCH NEXT FROM insCursor INTO @pi, @st
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF(@st=1)
				EXEC dbo.personalSetAccess @pi, 'COMMANDANT'
			ELSE
				EXEC dbo.personalDeleteAccess @pi, 'COMMANDANT'
				
			FETCH NEXT FROM insCursor INTO @pi, @st
		END
		CLOSE insCursor
	END

END
go

