


CREATE VIEW [dbo].[site_chair_1c]
AS
SELECT     TOP (100) PERCENT structure_division_id AS chair_id, structure_division_ext AS faculty_id,
                          (SELECT     structure_division_name_kz
                            FROM          dbo.univer_structure_division_1c AS sd1
                            WHERE      (dbo.univer_structure_division_1c.structure_division_ext = structure_division_id)) AS faculty_name_kz,
                          (SELECT     structure_division_name_ru
                            FROM          dbo.univer_structure_division_1c AS sd1
                            WHERE      (dbo.univer_structure_division_1c.structure_division_ext = structure_division_id)) AS faculty_name_ru,
                          (SELECT     structure_division_name_en
                            FROM          dbo.univer_structure_division_1c AS sd1
                            WHERE      (dbo.univer_structure_division_1c.structure_division_ext = structure_division_id)) AS faculty_name_en, structure_division_name_kz AS chair_name_kz, 
                      structure_division_name_ru AS chair_name_ru, structure_division_name_en AS chair_name_en
FROM         dbo.univer_structure_division_1c
WHERE     (structure_division_ext IN (9, 29, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50, 52, 11, 15, 539)) AND (status = 1) AND (structure_division_id IN (28, 72, 76, 77, 103, 121, 132, 107, 
                      30, 85, 83, 89, 90, 97, 33, 102, 127, 118, 35, 74, 95, 96, 79, 37, 131, 94, 101, 109, 133, 39, 84, 92, 41, 78, 75, 43, 98, 99, 82, 86, 87, 88, 93, 91, 45, 80, 111, 116, 112, 
                      110, 108, 105, 106, 125, 47, 49, 73, 128, 129, 124, 104, 117, 114, 122, 123, 51, 53, 81, 119, 115, 113, 12, 227, 31, 100, 120, 126, 130, 510, 533, 544, 541, 543))
ORDER BY faculty_id


go

