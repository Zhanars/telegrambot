-- =============================================
-- Author:		Sasha
-- Create date: 04.07.2018
-- Description:	Копирование УП.
-- =============================================
CREATE Procedure [dbo].[educPlanCopy] 
(
	@planIDFrom int, --План, из которого копируем
    @planIDTo int, --План, куда копируем
    @sem int --Номер семестра, который надо скопировать
)
AS
BEGIN

--Копирование УП
begin transaction
declare @check int=0
--Проверяем, что УП подходят для копирования
set @check = (select case when p2.educ_plan_number_of_semestr>=@sem then 1 else 0 end from univer_educ_plan p, univer_educ_plan p2 where
p.educ_plan_id=@planIDFrom and p2.educ_plan_id=@planIDTo 
and p.edu_level_id=p2.edu_level_id and p.educ_plan_adm_year<=p2.educ_plan_adm_year 
and p.educ_plan_type=p2.educ_plan_type and p.education_form_id=p2.education_form_id and p.speciality_id=p2.speciality_id 
and p.status=1 and p2.status=1)
 
if (@check=1)
begin
--Выбираем то, что нужно скопировать
declare @tblPos table (educ_plan_pos_id int, specialization_id int, subject_id int, lang_division_id int, faculty_id int, chair_id int, controll_type_id int, rup_kz nvarchar(50), rup_ru nvarchar(50), rup_en nvarchar(50), educ_plan_pos_credit int, educ_plan_pos_semestr int, cycle_id int, pos_group_id int, acpos_module int, educ_plan_pos_addit bigint, compute_weight bit, exam_form_id int, new_id int);

insert into @tblPos (educ_plan_pos_id, specialization_id, subject_id, lang_division_id, faculty_id, chair_id, controll_type_id, rup_kz, rup_ru, rup_en, educ_plan_pos_credit, educ_plan_pos_semestr, cycle_id, pos_group_id, acpos_module, educ_plan_pos_addit, compute_weight, exam_form_id)
select educ_plan_pos_id, specialization_id, subject_id, lang_division_id, faculty_id, chair_id, controll_type_id, rup_kz, rup_ru, rup_en, educ_plan_pos_credit, educ_plan_pos_semestr, cycle_id, pos_group_id, acpos_module, educ_plan_pos_addit, compute_weight, exam_form_id from univer_educ_plan_pos where educ_plan_id=@planIDFrom and educ_plan_pos_semestr=@sem
--Удаляем то, что уже есть в новом УП
delete t from @tblPos t where exists (select * from univer_educ_plan_pos pp where pp.educ_plan_id=@planIDTo and pp.subject_id=t.subject_id and pp.educ_plan_pos_semestr=t.educ_plan_pos_semestr and pp.status=1)
--Выбираем группы позиций 
declare @tblPosGroup table (pos_group_id int, educ_plan_id int, educ_plan_pos_semestr int, pos_group_name_ru nvarchar(800), pos_group_name_kz nvarchar(800), pos_group_name_en nvarchar(800), pos_group_sel_num int, module_group_id int, pos_group_sel_credit int, trajectory_id int, new_id int);
insert into @tblPosGroup (pos_group_id, educ_plan_id, educ_plan_pos_semestr, pos_group_name_ru, pos_group_name_kz, pos_group_name_en, pos_group_sel_num, module_group_id, pos_group_sel_credit, trajectory_id)
select pos_group_id, @planIDTo, educ_plan_pos_semestr, pos_group_name_ru, pos_group_name_kz, pos_group_name_en, pos_group_sel_num, module_group_id, pos_group_sel_credit, trajectory_id from univer_educ_plan_pos_groups where pos_group_id in (select distinct t.pos_group_id from @tblPos t)
--Выбираем модули 
declare @tblPosModGroup table (module_group_id int, module_group_name_kz nvarchar(1000), module_group_name_ru nvarchar(1000), module_group_name_en nvarchar(1000), status int, educ_plan_id int, new_id int);
insert into @tblPosModGroup (module_group_id, module_group_name_kz, module_group_name_ru, module_group_name_en, status, educ_plan_id)
select module_group_id, module_group_name_kz, module_group_name_ru, module_group_name_en, status, @planIDTo from univer_educ_plan_module_groups where module_group_id in (select distinct t.module_group_id from @tblPosGroup t)
--Копируем модули
declare @i int=0;
    DECLARE mod_cr cursor 
		FOR SELECT module_group_id FROM @tblPosModGroup 
	OPEN mod_cr
	FETCH NEXT FROM mod_cr INTO @i
	WHILE @@FETCH_STATUS = 0
	BEGIN
		insert into univer_educ_plan_module_groups(module_group_name_kz, module_group_name_ru, module_group_name_en, status, educ_plan_id)
		select module_group_name_kz, module_group_name_ru, module_group_name_en, status, educ_plan_id from @tblPosModGroup t where t.module_group_id=@i
		
		update @tblPosModGroup set new_id=@@IDENTITY where module_group_id=@i		
	FETCH NEXT FROM mod_cr INTO @i;
	END
	CLOSE mod_cr
	deallocate mod_cr
--обновим id модуля в группах
update t
set t.module_group_id = isnull((select new_id from @tblPosModGroup m where m.module_group_id=t.module_group_id),0)
from @tblPosGroup t
--Копируем группы
set @i=0;
    DECLARE g_cr cursor 
		FOR SELECT pos_group_id FROM @tblPosGroup 
	OPEN g_cr
	FETCH NEXT FROM g_cr INTO @i
	WHILE @@FETCH_STATUS = 0
	BEGIN
		insert into univer_educ_plan_pos_groups ( educ_plan_id, educ_plan_pos_semestr, pos_group_name_ru, pos_group_name_kz, pos_group_name_en, pos_group_sel_num, module_group_id, pos_group_sel_credit, trajectory_id)
		select educ_plan_id, educ_plan_pos_semestr, pos_group_name_ru, pos_group_name_kz, pos_group_name_en, pos_group_sel_num, module_group_id, pos_group_sel_credit, trajectory_id from @tblPosGroup t where t.pos_group_id=@i
		update @tblPosGroup set new_id=@@IDENTITY where pos_group_id=@i		
	FETCH NEXT FROM g_cr INTO @i;
	END
	CLOSE g_cr
	deallocate g_cr
--Обновим Id групп в позициях
update t
set t.pos_group_id = isnull((select new_id from @tblPosGroup g where g.pos_group_id=t.pos_group_id),0)
from @tblPos t
--Копируем позиции
set @i=0;
    DECLARE pp_cr cursor 
		FOR SELECT educ_plan_pos_id FROM @tblPos 
	OPEN pp_cr
	FETCH NEXT FROM pp_cr INTO @i
	WHILE @@FETCH_STATUS = 0
	BEGIN
		insert into univer_educ_plan_pos( educ_plan_id, status, specialization_id, subject_id, lang_division_id, faculty_id, chair_id, controll_type_id, rup_kz, rup_ru, rup_en, educ_plan_pos_credit, educ_plan_pos_semestr, cycle_id, pos_group_id, acpos_module, educ_plan_pos_addit, compute_weight, exam_form_id)
		select @planIDTo,1, specialization_id, subject_id, lang_division_id, faculty_id, chair_id, controll_type_id, rup_kz, rup_ru, rup_en, educ_plan_pos_credit, educ_plan_pos_semestr, cycle_id, pos_group_id, acpos_module, educ_plan_pos_addit, compute_weight, exam_form_id from @tblPos t where t.educ_plan_pos_id=@i
		update @tblPos set new_id=@@IDENTITY where educ_plan_pos_id=@i		
	FETCH NEXT FROM pp_cr INTO @i;
	END
	CLOSE pp_cr
	deallocate pp_cr
----Копируем распределение кредитов
insert into univer_educ_plan_pos_credit (educ_plan_pos_id,educ_type_id,credit,status)
select distinct pp.new_id,ppc.educ_type_id, ppc.credit, ppc.status from univer_educ_plan_pos_credit ppc, @tblPos pp where pp.educ_plan_pos_id=ppc.educ_plan_pos_id 
----копируем ссылки на курсовые
insert into univer_educ_plan_pos_self_link(educ_plan_pos_id,educ_plan_pos_id_link)
select pp.new_id, pp2.new_id from univer_educ_plan_pos_self_link l inner join @tblPos pp on pp.educ_plan_pos_id =l.educ_plan_pos_id 
inner join @tblPos pp2 on pp2.educ_plan_pos_id=l.educ_plan_pos_id_link
end

commit



END
go

