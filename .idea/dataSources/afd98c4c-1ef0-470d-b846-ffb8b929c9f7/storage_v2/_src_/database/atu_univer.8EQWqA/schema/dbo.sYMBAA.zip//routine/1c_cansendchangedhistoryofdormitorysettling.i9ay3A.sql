


-- =============================================
-- Author:		Ruslan
-- Create date: 10.11.2016
-- Description:	Can this changed history of dormitory settling be send to 1C
-- =============================================
CREATE FUNCTION [dbo].[1C_CanSendChangedHistoryOfDormitorySettling]
(
 @studentId int,
 @orderType int,
 @orderDate datetime,
 @dormitoryId int,
 @roomSize int=0,
 @orderSts int
)
RETURNS int
AS
BEGIN
	DECLARE @ret int= (
		SELECT count(history_id)
		FROM univer_student_dormitory_room_settle_history h, univer_dormitory_rooms dr
		 where dr.dormitory_room_id = h.dormitory_room_id and student_id = @studentId and order_date = @orderDate 
		 and order_type =  @orderType and h.dormitory_id =  @dormitoryId and order_guid IS NULL and order_status = (11-@orderSts) and dr.dormitory_room_size =  @roomSize
		);
	RETURN isnull(@ret,0)
END


go

