
-- =============================================
-- Author:		Yerlan
-- Create date: 05.12.2016
-- Description:	asdf
-- =============================================
CREATE FUNCTION [dbo].[PERCO_GetParentAllChildIDs]
(
	@parentId int
)
RETURNS table
AS
	RETURN 
	(
		WITH MyTest as
		(
		  SELECT P.subdiv_id_internal, P.subdiv_id_parent, P.subdiv_level , P.subdiv_displayname
		  FROM perco_univer_subdiv P
		  WHERE P.subdiv_id_internal = 1350900

		  UNION ALL

		  SELECT P1.subdiv_id_internal, P1.subdiv_id_parent, P1.subdiv_level  , P1.subdiv_displayname
		  FROM perco_univer_subdiv P1  
		  INNER JOIN MyTest M
		  ON M.subdiv_id_internal = P1.subdiv_id_parent and P1.subdiv_visible=1
		 )	 
		SELECT subdiv_id_internal From MyTest
	);

go

