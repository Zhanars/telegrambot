-- =============================================
-- Author:		Sasha
-- Create date: 11.05.2009
-- Description:	Триггер на изменение статуса сотрудника учебного отдела
-- =============================================
create TRIGGER [dbo].[icdWorkerUpdateTrigger]
   ON  [dbo].[univer_icd_workers] 
   AFTER UPDATE
AS 
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @pi int
	DECLARE @st int
	
	DECLARE insCursor cursor 
		FOR SELECT personal_id, status FROM inserted
	
	IF UPDATE(status)
	BEGIN
		OPEN insCursor
		FETCH NEXT FROM insCursor INTO @pi, @st
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF(@st=1)
				EXEC dbo.personalSetAccess @pi, 'ICD'
			ELSE
				EXEC dbo.personalDeleteAccess @pi, 'ICD'
				
			FETCH NEXT FROM insCursor INTO @pi, @st
		END
		CLOSE insCursor
	END
END
go

