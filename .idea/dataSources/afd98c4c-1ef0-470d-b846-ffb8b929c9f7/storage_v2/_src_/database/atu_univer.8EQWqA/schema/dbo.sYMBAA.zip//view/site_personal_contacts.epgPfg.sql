CREATE VIEW dbo.site_personal_contacts
AS
SELECT     personal_id, personal_adress, personal_work_adress, personal_email, personal_work_email, personal_work_phone, personal_mobile_phone, 
                      personal_home_phone, personal_fax, personal_info_hidden_fields
FROM         dbo.univer_personal
go

