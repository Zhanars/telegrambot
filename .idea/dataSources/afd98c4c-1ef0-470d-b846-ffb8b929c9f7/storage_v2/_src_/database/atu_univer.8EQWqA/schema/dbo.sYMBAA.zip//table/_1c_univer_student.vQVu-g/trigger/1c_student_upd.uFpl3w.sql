-- =============================================
-- Author:		sasha
-- Create date: 13.01.2015
-- Description:	обновление 1с-id
-- =============================================
CREATE TRIGGER [dbo].[1c_student_upd]
   ON  [dbo].[_1c_univer_student] 
   AFTER update
AS 
BEGIN
	SET NOCOUNT ON;

    declare @student_id int;
    declare @1c_id nvarchar(36);
    DECLARE insCursor cursor 
		FOR SELECT _1c_univer_student_id,_1c_student_id FROM inserted 
				
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @student_id,@1c_id
	WHILE @@FETCH_STATUS = 0
	BEGIN
	if (@student_id is not null and @student_id>0) begin						
    update univer_students set student_id_1c=@1c_id where students_id=@student_id;
    end
	FETCH NEXT FROM insCursor INTO @student_id,@1c_id
	END
	CLOSE insCursor

END
go

