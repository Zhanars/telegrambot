-- =============================================
-- Author:		Twice
-- Create date: 31.01.2012
-- Description: Получить количество научных монографий (1 - в казахстанских издательствах, 2 - зарубежных издательствах) - в разрезе кафедр
-- =============================================
CREATE FUNCTION [dbo].[IP_NIR_getSciTreatises_Count_ByChairId]
(
	@chairId int,
	@year int,
	@publisherTypeId int
)
RETURNS real
AS
BEGIN
DECLARE @Result real

IF (@publisherTypeId = 1)
BEGIN
SELECT @Result = COUNT(DISTINCT t.treatise_id)
		FROM 
			DBScience.dbo.Treatises t,
			DBScience.dbo.L_Person_Treatise_Authors a,
			DBScience.dbo.Publishers p,
			DBScience.dbo.Countries c
		WHERE
		-- не архивированная
		t.status != 2 AND
		-- издательство этой страны
		p.publisher_id = t.publisher_id AND
		c.country_id = p.country_id AND
		c.countryCurrent = 1 AND
		-- книга должна быть монографией
		t.treatiseType_id = 1 AND
		-- книга этого года или следующего
		t.yearPublication in (@year, @year+1) AND
		-- книга этого автора (ППС, потому personType = 1)
		t.treatise_id = a.treatise_id AND
		a.personType = 1 AND 
		a.person_id IN
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
			)
END
IF (@publisherTypeId = 2)
BEGIN
SELECT @Result = COUNT(DISTINCT t.treatise_id)
		FROM 
			DBScience.dbo.Treatises t,
			DBScience.dbo.L_Person_Treatise_Authors a,
			DBScience.dbo.Publishers p,
			DBScience.dbo.Countries c
		WHERE
		-- не архивированная
		t.status != 2 AND
		-- издательство этой страны
		p.publisher_id = t.publisher_id AND
		c.country_id = p.country_id AND
		c.countryCurrent <> 1 AND
		-- книга должна быть монографией
		t.treatiseType_id = 1 AND
		-- книга этого года или следующего
		t.yearPublication in (@year, @year+1) AND
		-- книга этого автора (ППС, потому personType = 1)
		t.treatise_id = a.treatise_id AND
		a.personType = 1 AND 
		a.person_id IN
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
			)
END

RETURN ISNULL(@Result, 0)

END
go

