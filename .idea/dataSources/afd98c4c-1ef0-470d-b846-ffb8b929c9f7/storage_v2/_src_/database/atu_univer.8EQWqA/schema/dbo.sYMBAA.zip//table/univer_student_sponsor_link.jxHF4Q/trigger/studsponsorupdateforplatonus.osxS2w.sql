-- =============================================
-- Author:		Yerlan
-- Create date: 2013-10-27 17:44:33.680
-- Description:	Добавление записи о том что данные студента были изменены (триггер токо для UPDATE,так как при добавлении у студента статус еще не StatusNormal)
-- =============================================
create TRIGGER [dbo].[StudSponsorUpdateForPlatonus]
   ON  [dbo].[univer_student_sponsor_link]
   AFTER INSERT
AS 
BEGIN
	
	IF @@ROWCOUNT =0
    RETURN
	
	SET NOCOUNT ON;
	
	IF EXISTS(SELECT * FROM inserted i INNER JOIN univer_students s ON i.student_id=s.students_id AND s.status=1)
	BEGIN
		INSERT INTO platonus_univer_students(student_id,command)
		SELECT DISTINCT i.student_id, 'update' FROM inserted i 
			INNER JOIN univer_students s ON i.student_id=s.students_id AND s.status=1
		WHERE NOT EXISTS(SELECT * FROM platonus_univer_students a WHERE a.student_id=i.student_id)
	END	
END
go

