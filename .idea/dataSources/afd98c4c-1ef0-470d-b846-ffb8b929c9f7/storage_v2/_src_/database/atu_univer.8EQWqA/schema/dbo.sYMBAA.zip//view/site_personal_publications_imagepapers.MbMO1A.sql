
/* имиджевые статьи 
 ФИО авторов. название работы // название журнала. – год, том, номер, стр. с.. по ..; 
 (ФИО авторов из КазНУ выделить жирным шрифтом)*/
CREATE VIEW [dbo].[site_personal_publications_imagePapers]
AS
SELECT     TOP (100) PERCENT p.personal_id, pspl.structure_division_id AS chair_id, p.personal_sname + ' ' + LEFT(p.personal_name, 1) + '.' + LEFT(p.personal_father_name, 1)
                       + '.' AS author, DBScience.dbo.support_getCoauthorsOfPublication(ip.imagePaper_id, 4, p.personal_id) AS coauthors, ip.imagePaper_id, ip.name_kz, ip.name_ru, 
                      ip.name_en, op.name, ip.yearPublication, ip.issueNumber, ip.startPage, ip.endPage, ip.pageCount, ip.annotationFile_id, fi.serverFileName AS annotationFile, 
                      ip.imagePaperFile_id, fi2.showName AS imagePaperFile
FROM         dbo.univer_personal AS p LEFT OUTER JOIN
                      DBScience.dbo.L_Person_ImagePaper_Authors AS lpa ON lpa.personType = 1 AND lpa.person_id = p.personal_id AND p.status = 1 INNER JOIN
                      DBScience.dbo.ImagePapers AS ip ON ip.imagePaper_id = lpa.imagePaper_id AND ip.status <> 2 LEFT OUTER JOIN
                      DBScience.dbo.OtherPeriodicEditions AS op ON op.otherPeriodicEdition_id = ip.periodicEdition_id LEFT OUTER JOIN
                      DBScience.dbo.FileInfos AS fi ON ip.annotationFile_id = fi.fileInfo_id LEFT OUTER JOIN
                      DBScience.dbo.FileInfos AS fi2 ON ip.imagePaperFile_id = fi2.fileInfo_id LEFT OUTER JOIN
                      dbo.univer_personal_struct_pos_link_1c AS pspl ON p.personal_id = pspl.personal_id AND pspl.status = 1 AND pspl.type_id IN (1, 2)
ORDER BY p.personal_id

go

