
-- =============================================
-- Author:		Yerlan
-- Create date: 18.01.2013
-- Description:	Посчитать сумму или ср. значение для конкретного показателя по анкетным данным ППС (для кафедры) или Кафедры (для факультета)
-- =============================================
CREATE FUNCTION [dbo].[IP_CalcSumOrAVGForIndicator] 
(
	-- Add the parameters for the function here
	@indPlanIndicatorId		INT,
	@calcType				INT,-- Тип расчета, 1 - суммирование, 2 - среднее значение
	@categoryId				INT,
	@strucDivId				INT,
	@year					INT,
	/*@semester				INT,*/
	@whichValue				INT -- Если равно 1, то нужно получить плановые значения, если 2 то фактические.
)
RETURNS REAL
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result REAL
	-- ================================================= ЕСЛИ КАТЕГОРИЯ КАФЕДРАЛЬНАЯ
	IF (@categoryId=2)
	BEGIN
		SELECT @Result = 
		(
			SELECT 
				ISNULL(SUM(CASE WHEN @whichValue=1 THEN 
						(case when ipp.ind_plan_personal_p_approve_value is not null then ipp.ind_plan_personal_p_approve_value else ipp.ind_plan_personal_p_value end) 
					ELSE 
						(case when ipp.ind_plan_personal_f_approve_value is not null then ipp.ind_plan_personal_f_approve_value else ipp.ind_plan_personal_f_value end) 
					END),0) 
				FROM 
					(
						SELECT DISTINCT p.personal_id, spl.structure_division_id FROM univer_personal p, univer_personal_struct_pos_link_1c spl 
						WHERE p.personal_id=spl.personal_id AND p.status=1 AND spl.status=1 AND spl.structure_division_id=@strucDivId
					) p
					--,univer_ind_plan_indicator ipi
					,univer_ind_plan_personal ipp
				WHERE 
				--ipi.ind_plan_indicator_id = ipp.ind_plan_indicator_id 
				-- сравнение с персоналом
				p.personal_id=ipp.personal_id
				-- по всем категориям если 0 или конкретная категория (1 - Фак, 2 - Каф, 3 - ППС)
				--AND ipi.ind_plan_category_id=3 
				-- только активные показатели
				--AND ipi.status = 1 
				-- по ИД кода показателя
				AND ipp.ind_plan_indicator_id=@indPlanIndicatorId				
				-- за академ. год и за тек. семестр
				AND ipp.year = @year
				/*AND ipp.semester = @semester*/
				--ZDES PROVERAEM (wtatniy pps na etoi kafedre ili wtatniy no s adm. doljnostiu)
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,p.structure_division_id,1)=1	
		);

		if (@calcType=2)/*AVG*/
		begin
			Declare @teacherCnt int =0;
			set @teacherCnt = (SELECT COUNT(distinct spl1.personal_id)
								FROM univer_personal_struct_pos_link_1c spl1, univer_personal_position_1c pp
								WHERE spl1.structure_division_id = @strucDivId AND (pp.personal_position_is_teacher=1) and spl1.personal_position_id = pp.personal_position_id
									AND spl1.status=1);
			set @teacherCnt = case when isnull(@teacherCnt,0)=0 then 1 else @teacherCnt end;
			set @Result = @Result/@teacherCnt;
		end;
	END
	-- ================================================= ЕСЛИ КАТЕГОРИЯ ФАКУЛЬТЕТСКАЯ
	ELSE IF (@categoryId=1)
	BEGIN
		SELECT @Result = 
		(
			SELECT 
				CASE WHEN @calcType=1 
					THEN ISNULL(SUM(CASE WHEN @whichValue=1 THEN 
						(case when ipp.ind_plan_personal_p_approve_value is not null then ipp.ind_plan_personal_p_approve_value else ipp.ind_plan_personal_p_value end) 
					ELSE 
						(case when ipp.ind_plan_personal_f_approve_value is not null then ipp.ind_plan_personal_f_approve_value else ipp.ind_plan_personal_f_value end) 
					END),0) 
					 WHEN @calcType=2 
					THEN ISNULL(AVG(CASE WHEN @whichValue=1 THEN 
						(case when ipp.ind_plan_personal_p_approve_value is not null then ipp.ind_plan_personal_p_approve_value else ipp.ind_plan_personal_p_value end) 
					ELSE 
						(case when ipp.ind_plan_personal_f_approve_value is not null then ipp.ind_plan_personal_f_approve_value else ipp.ind_plan_personal_f_value end) 
					END),0) 
				END
				FROM 
					(
					SELECT DISTINCT p.personal_id, hc.chair_id FROM univer_personal p, univer_head_chair hc 
					WHERE p.personal_id=hc.personal_id AND p.status=1 AND hc.status=1
					) p
					,univer_ind_plan_personal ipp
					, univer_chair c, univer_faculty f
				WHERE 
				-- по факультету
				f.structure_division_id = @strucDivId AND f.faculty_id=c.faculty_id AND f.status=1
				-- по кафедре
				AND c.chair_id = p.chair_id AND c.status=1 
				-- сравнение с персоналом
				AND p.personal_id=ipp.personal_id
				-- по ИД кода показателя
				AND ipp.ind_plan_indicator_id=@indPlanIndicatorId				 
				-- за академ. год и за тек. семестр
				AND ipp.year = @year
				/*AND ipp.semester = @semester*/
		)
	END
	RETURN ISNULL(@Result,0)
END

go

