-- =============================================
-- Author:		@LFER
-- Create date: 2009-07-03 17:56:14.163
-- Description:	Триггер на изменение статуса сотрудника отдела кадров
-- =============================================
CREATE TRIGGER [dbo].[personnelDepartUpdateTrigger]
   ON  [dbo].[univer_personnel_depart] 
   AFTER UPDATE
AS 
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @pi int
	DECLARE @st int
	
	DECLARE insCursor cursor 
		FOR SELECT personal_id, status FROM inserted
	
	IF UPDATE(status)
	BEGIN
		OPEN insCursor
		FETCH NEXT FROM insCursor INTO @pi, @st
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF(@st=1)
				EXEC dbo.personalSetAccess @pi, 'PERSONNEL_DEPART'
			ELSE
				EXEC dbo.personalDeleteAccess @pi, 'PERSONNEL_DEPART'
				
			FETCH NEXT FROM insCursor INTO @pi, @st
		END
		CLOSE insCursor
	END
END
go

