CREATE VIEW dbo.site_personal_publications_thesises
AS
SELECT     TOP (100) PERCENT p.personal_id, pspl.structure_division_id AS chair_id, p.personal_sname + ' ' + LEFT(p.personal_name, 1) + '.' + LEFT(p.personal_father_name, 1)
                       + '.' AS author, DBScience.dbo.support_getCoauthorsOfPublication(th.thesis_id, 3, p.personal_id) AS coauthors, th.thesis_id, th.name_kz, th.name_ru, th.name_en, 
                      se.name_kz AS event_name_kz, se.name_ru AS event_name_ru, se.name_en AS event_name_en, c.name_ru AS Expr4, se.address, th.pageCount, 
                      YEAR(se.eventStart) AS yearEvent, th.thesisFile_id, fi.showName AS thesisFile
FROM         dbo.univer_personal AS p LEFT OUTER JOIN
                      DBScience.dbo.L_Person_Thesis_Authors AS lta ON lta.personType = 1 AND lta.person_id = p.personal_id INNER JOIN
                      DBScience.dbo.Thesises AS th ON th.thesis_id = lta.thesis_id AND th.status <> 2 LEFT OUTER JOIN
                      DBScience.dbo.SciEvents AS se ON se.sciEvent_id = th.sciEvent_id LEFT OUTER JOIN
                      DBScience.dbo.Countries AS c ON c.country_id = se.country_id LEFT OUTER JOIN
                      DBScience.dbo.FileInfos AS fi ON th.thesisFile_id = fi.fileInfo_id LEFT OUTER JOIN
                      dbo.univer_personal_struct_pos_link_1c AS pspl ON pspl.personal_id = p.personal_id AND pspl.status = 1 AND pspl.type_id IN (1, 2)
ORDER BY p.personal_id
go

