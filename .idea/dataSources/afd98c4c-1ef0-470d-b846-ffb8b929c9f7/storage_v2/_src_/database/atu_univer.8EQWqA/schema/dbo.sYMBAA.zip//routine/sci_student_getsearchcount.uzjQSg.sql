-- =============================================
-- Author:		Twice
-- Create date: 02.02.2012
-- Description:	Получить количество результатов поиска студентов
-- =============================================
CREATE FUNCTION sci_student_GetSearchCount
(
	@nameStr NVARCHAR(80),
	@facultyId int = 0,
	@stageId int = 0,
	@specialityId int = 0
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result int

	-- Add the T-SQL statements to compute the return value here
	SELECT @Result = COUNT(*)
			FROM 
				univer_students st
			WHERE
				status != 2 AND
				(CHARINDEX(@nameStr, st.students_sname + ' ' + 
				st.students_sname + ' ' + st.students_father_name) > 0 OR LEN(@nameStr)=0) AND
				(st.faculty_id = @facultyId OR @facultyId = 0) AND
				(st.stage_id = @stageId OR @stageId = 0) AND
				(st.speciality_id = @specialityId OR @specialityId = 0)

	-- Return the result of the function
	RETURN @Result

END
go

