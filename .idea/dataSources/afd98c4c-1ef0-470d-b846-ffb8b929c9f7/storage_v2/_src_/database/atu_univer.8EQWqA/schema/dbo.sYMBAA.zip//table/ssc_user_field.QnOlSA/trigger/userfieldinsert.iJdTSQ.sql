-- =============================================
-- Author:		<Ulugbek>
-- Create date: <28.04.2016 21:00>
-- Description:	<Данный триггер сработает при добавлении данных, где тип: FILE, FORM_ENGLISH_KNOWLEDGE, SC_CREATE_DOCUMENT>
-- =============================================
create TRIGGER [dbo].[UserFieldInsert] ON [dbo].[ssc_user_field]
   FOR INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    insert into ssc_FD_files(user_field_id, file_id)
		select i.user_field_id, case f.field_type_id
			when 7 then i.field_data_xml.value('(/FD_FILE/fileId)[1]', 'int')						--FILE
			when 500 then i.field_data_xml.value('(/FD_FORM_ENGLISH_KNOWLEDGE/file/id)[1]', 'int')	--FORM_ENGLISH_KNOWLEDGE
			when 1001 then i.field_data_xml.value('(/SFD_CREATE_DOCUMENT/file/id)[1]', 'int')		--SC_CREATE_DOCUMENT
			else 0 end
		from inserted i, ssc_field f
		where i.field_id=f.field_id
		and f.field_type_id in (7, 500,	1001)
END
go

