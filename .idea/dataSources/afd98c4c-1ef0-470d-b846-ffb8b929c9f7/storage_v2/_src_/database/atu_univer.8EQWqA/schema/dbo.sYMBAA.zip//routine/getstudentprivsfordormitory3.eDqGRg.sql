



-- =============================================
-- Author:		Ruslan
-- Create date: 31.07.2017
-- Description: Получить льготы студента с различным приоритетом для заселения в общежитие в виде строки
-- =============================================
CREATE FUNCTION [dbo].[GetStudentPrivsForDormitory3]
(
	@studentId int
)

-----------------------------------------------------------------
RETURNS int
AS
BEGIN
DECLARE @Result NVARCHAR(6)

-- ==================================== 
BEGIN
    /**************************************************************************************/
    DECLARE @propTable table (pid int);
    INSERT INTO @propTable(pid)
    SELECT s.properties_id
    FROM univer_students_properties s,univer_student_properties_link spl where s.properties_id = spl.properties_id AND s.status=1 AND spl.students_id=@studentId 

    set @Result='';
	SELECT @Result = @Result + case when EXISTS(SELECT 1 FROM @propTable t WHERE t.pid IN (1)) then '2' else '1' end 
	SELECT @Result = @Result + case when EXISTS(SELECT 1 FROM @propTable t WHERE t.pid IN (15, 16, 17, 19, 91)) then '2' else '1' end 
	SELECT @Result = @Result + case when [dbo].[IsStudentExcellent](@studentId)=1 then '2' else '1' end
	SELECT @Result = @Result + case when EXISTS(SELECT 1 FROM @propTable t WHERE t.pid IN (106, 107, 108, 109, 110)) then '2' else '1' end
	SELECT @Result = @Result + case when (SELECT st.citizenship_id FROM univer_students st WHERE st.students_id = @studentId) != 1 then '2' else '1' end 
	SELECT @Result = @Result + case when EXISTS(SELECT 1 FROM @propTable t WHERE t.pid IN (102)) then '2' else '1' end 
			
END

RETURN @Result
END


go

