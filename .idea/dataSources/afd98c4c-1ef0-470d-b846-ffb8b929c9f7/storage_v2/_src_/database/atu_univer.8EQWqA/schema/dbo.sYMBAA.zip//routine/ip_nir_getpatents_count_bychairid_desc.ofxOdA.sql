-- =============================================
-- Author:		Twice
-- Create date: 31.01.2012
-- Description: Получить количество полученных охранных документов - в разрезе кафедр
-- =============================================
CREATE FUNCTION IP_NIR_getPatents_Count_ByChairId_DESC
(
	@chairId int,
	@year int
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @Result NVARCHAR(MAX)

SELECT @Result = N''

-- Return the result of the function
RETURN @Result

END
go

