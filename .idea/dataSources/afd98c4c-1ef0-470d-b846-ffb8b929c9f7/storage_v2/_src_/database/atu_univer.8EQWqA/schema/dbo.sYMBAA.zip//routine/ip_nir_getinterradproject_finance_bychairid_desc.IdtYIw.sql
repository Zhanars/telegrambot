-- =============================================
-- Author:		Twice
-- Create date: 31.01.2012
-- Description: Получить объем финансирования международных научных и научно-образовательных  проектов и программ (гранты) - в разрезе кафедр
-- =============================================
CREATE FUNCTION IP_NIR_getInterRADProject_Finance_ByChairId_DESC
(
	@chairId int,
	@year int
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @Result NVARCHAR(MAX)

SELECT @Result = N''

-- Return the result of the function
RETURN @Result

END
go

