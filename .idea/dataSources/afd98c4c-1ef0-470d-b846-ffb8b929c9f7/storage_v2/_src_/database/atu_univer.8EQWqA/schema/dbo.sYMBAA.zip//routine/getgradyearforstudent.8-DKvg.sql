

-- =============================================
-- Author:		Sasha
-- Create date: 06.04.2018
-- Description:	Получить год выпуска по студенту
-- =============================================
CREATE FUNCTION [dbo].[getGradYearForStudent]
(
 @studentId int
)
RETURNS int
AS
BEGIN
	DECLARE @ret int
    select @ret=max(year(o.order_date)) from univer_order o, univer_order_student_link osl where osl.order_id=o.order_id and osl.student_id= @studentId and o.order_type_id in (71,80) and o.status in (21,22)

	RETURN isnull(@ret,0);

END

go

