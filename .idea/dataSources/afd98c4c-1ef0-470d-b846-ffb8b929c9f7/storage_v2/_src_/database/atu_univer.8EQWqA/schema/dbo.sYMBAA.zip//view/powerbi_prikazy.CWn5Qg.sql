
CREATE VIEW [dbo].[powerbi_prikazy]
AS
SELECT distinct s.students_id AS ид_студента, o.order_id AS ид_приказа, o.order_type_id AS ид_типа_приказа, ot.order_type_name_ru AS тип_приказа, o.order_number AS номер_приказа, 
                      o.order_date AS дата_приказа, o.order_semester AS академический_семестр, o.order_year AS академический_год, o.order_date_create AS дата_создания_приказа
FROM         dbo.univer_order AS o INNER JOIN
                      dbo.univer_order_student_link AS osl ON o.order_id = osl.order_id INNER JOIN
                      dbo.univer_students AS s ON osl.student_id = s.students_id INNER JOIN
                      dbo.univer_order_type AS ot ON o.order_type_id = ot.order_type_id
WHERE     (s.status = 1) AND (o.status IN (22, 21)) AND (o.order_type_id IN (1, 8, 10, 31, 32, 33, 41, 42, 43, 70, 71, 80, 90, 101, 105, 200))

go

