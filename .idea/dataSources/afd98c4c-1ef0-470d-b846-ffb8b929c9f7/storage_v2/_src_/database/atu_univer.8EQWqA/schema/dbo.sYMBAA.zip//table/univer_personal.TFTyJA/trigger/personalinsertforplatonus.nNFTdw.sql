-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[personalInsertForPlatonus]
   ON  [dbo].[univer_personal]
   AFTER insert
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    delete from platonus_univer_personals where personal_id in (select i.personal_id from inserted i);
    insert into platonus_univer_personals(personal_id, operation)
    select i.personal_id, 1 from inserted i
    
END
go

