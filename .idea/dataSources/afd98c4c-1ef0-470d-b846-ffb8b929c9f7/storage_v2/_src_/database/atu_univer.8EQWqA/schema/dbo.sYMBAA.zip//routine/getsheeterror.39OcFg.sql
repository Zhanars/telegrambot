-- =============================================
-- Author:		Sasha
-- Create date: 01.02.2018
-- Description:	Ошибка при создании ведомости
-- =============================================
CREATE FUNCTION [dbo].[getSheetError] 
(
	-- Add the parameters for the function here
	@sheetType int,
    @groupId int,
	@studentId int,
	@maxDebt int,
	@antipl bit,
	@failOrder bit
)
RETURNS Nvarchar(200)
AS
BEGIN
declare @minRK int=0;
declare @ret nvarchar(200)=null;


           if (exists(select * from univer_sheet_type where sheet_type_id=@sheetType and sheet_type_need_access=1 and sheet_kind_id=1)) 
		   begin
select @minRK=case when @sheetType in (25) then 20 else ct.controll_type_min_rk end from univer_controll_type ct, univer_educ_plan_pos pp, univer_group g, univer_controll_type_control_link cc
                where g.educ_plan_pos_id=pp.educ_plan_pos_id and pp.controll_type_id=ct.controll_type_id and pp.status=1 and cc.controll_type_id=ct.controll_type_id and cc.sheet_type_id=@sheetType and g.group_id=@groupId; 
            
			end
        
            --выбираем ошибки
            set @ret= (select top 1
            ---Проверки
            case 
            ---на тип группы
            when g.educ_type_id not in (0,(select top 1 et.educ_type_id from univer_educ_plan_pos_credit pc, univer_educ_type et where pc.credit>0 and pc.educ_plan_pos_id=pp.educ_plan_pos_id and pc.educ_type_id=et.educ_type_id order by et.educ_type_sheet_priority))
            then N'  Группа не подходит для создания ведомости  '
            ---на существование ведомости
            when exists (select distinct s.sheet_id from univer_sheet s, univer_sheet_result sr where sr.sheet_id=s.sheet_id and sr.student_id=st.students_id and sr.academ_year=g.group_year and sr.semestr=g.group_semestr and sr.n_seme=pp.educ_plan_pos_semestr and sr.subject_id=pp.subject_id and s.acpos_module=g.acpos_module and s.sheet_type_id=@sheetType)
            then N' Ведомость уже существует '
            ---на закрытие всех предыдущих ведомостей
            when exists (            
            select ccl2.control_number from univer_controll_type_control_link ccl, univer_controll_type_control_link ccl2
            left join (select sr1.*, s1.acpos_module from univer_sheet_result sr1, univer_sheet s1 where s1.sheet_id=sr1.sheet_id and s1.sheet_kind_id=1) sr on sr.control=ccl2.control_id and sr.subject_id=pp.subject_id and sr.n_seme=pp.educ_plan_pos_semestr and sr.acpos_module=g.acpos_module and sr.academ_year=g.group_year and sr.semestr=g.group_semestr and sr.student_id=st.students_id   left join univer_sheet s on  s.sheet_id=sr.sheet_id and s.acpos_module=g.acpos_module and s.sheet_type_id=ccl2.sheet_type_id and s.sheet_kind_id=1  
             where ccl.controll_type_id=pp.controll_type_id and ccl2.controll_type_id=ccl.controll_type_id and ccl2.sheet_type_id<>@sheetType and  ccl.sheet_type_id=@sheetType and (s.sheet_id is null or sr.result is null) and ccl2.sheet_type_id<>25 
             group by  ccl2.control_number
             having ccl2.control_number<min(ccl.control_number)
             )
            then N'  Предыдущие ведомости не закрыты  '
            ---на допуск к контролю по РК
            when @minRK>0 and (select (pr.progress_result_rk1+progress_result_rk2) from univer_progress pr where pr.subject_id=pp.subject_id and pr.n_seme=pp.educ_plan_pos_semestr and pr.status=1 and pr.student_id=st.students_id)<@minRK 
            then N'  Не набран минимум по РК  '
            ---на допуск к контролю по связанной дисциплине
            when (select count(*) from univer_educ_plan_pos_self_link pk, univer_educ_plan_pos pp2 left join univer_progress pr on pr.student_id=st.students_id and pr.status=1 and pr.n_seme=pp2.educ_plan_pos_semestr and pr.subject_id=pp2.subject_id left join univer_mark_type mt on mt.mark_type_id=pr.mark_type_id where pk.educ_plan_pos_id=pp.educ_plan_pos_id and pp2.educ_plan_pos_id=pk.educ_plan_pos_id_link and ISNULL(mt.mark_type_arg,-1) in (-1,2,7,6))<>0
            then N'  Не набран минимум по связанной дисциплине  '
            ---на допуск к сдаче связанной дисциплины по рк исходной
            when @minRK>0 and (select count(*) from univer_educ_plan_pos_self_link pk, univer_educ_plan_pos pp2 left join univer_progress pr on pr.student_id=st.students_id and pr.status=1 and pr.n_seme=pp2.educ_plan_pos_semestr and pr.subject_id=pp2.subject_id where pk.educ_plan_pos_id=pp2.educ_plan_pos_id and pp.educ_plan_pos_id=pk.educ_plan_pos_id_link and pr.progress_result_rk1+pr.progress_result_rk2<@minRK)<>0
            then N'  Не набран минимум РК по дисциплине, к которой привязана данная  '
            ---на дистанционное обучение
            when (st.student_edu_status_id=1 AND g.group_isdo is not null) 
            then N'  Студент не должен сидеть в группе дистанционного обучения  '
            ---на дистанционное обучение
            when (st.student_edu_status_id<>1 AND g.group_isdo is null) 
            then N'  Студент должен обучаться дистанционно  '
            ---на наличие долга по оплате
when @sheetType in (5, 7, 8, 18, 19) and g.group_retake_semestr=0 and isnull(dbo.get1cDebtForStudent(st.students_id),0)<0-@maxDebt
then N'  Студент имеет задолженность по оплате  '
            ---на антиплагиат
                        /*
						when @sheetType in (8, 18, 19) and @antipl=1 and not exists(select * 
                        from univer_antipl_work aw 
                        where aw.user_id=st.user_id
	                        AND aw.student_diplom_file_type_id=1/*Тип работы - дипломная*/ 
	                        AND aw.report_indexed IS NOT NULL/*Работа добавлена в базу источников руководителем*/ 
	                        AND aw.work_check_for_index=1/*Отправлена на проверку руководителю*/ 
	                        AND aw.report_check_status=2/*Успешно проверена*/)
                        then N'  Студент не прошел проверку на антиплагиат  '
						*/
	        ---если группа повторного обучения на повышение gpa
                when g.group_retake_semestr>0 and exists(select * from univer_progress pr, univer_mark_type mt where pr.student_id=st.students_id and pr.subject_id=pp.subject_id and pr.n_seme=pp.educ_plan_pos_semestr and mt.mark_type_id=pr.mark_type_id and pr.status in (1,4) and mt.mark_type_arg not in (6,2,7))
                then null
                ---если группа повторного обучения, то наличие неуд.оценки
when g.group_retake_semestr>0 and not exists(select * from univer_progress pr, univer_mark_type mt where pr.student_id=st.students_id and pr.subject_id=pp.subject_id and pr.n_seme=pp.educ_plan_pos_semestr and mt.mark_type_id=pr.mark_type_id and pr.status in (1,4) /*and (pr.academ_year<>g.group_year or pr.acpos_module<>g.acpos_module or pr.semestr<>g.group_semestr)*/)
            then N'  У студента нет неудовлетворительной оценки  '
                 ---если грантник и оценка R
                when @failOrder=1 and g.group_retake_semestr>0 and st.payment_forms_id=5 and exists(select * from univer_progress pr, univer_mark_type mt where pr.student_id=st.students_id and pr.subject_id=pp.subject_id and pr.n_seme=pp.educ_plan_pos_semestr and mt.mark_type_id=pr.mark_type_id and pr.status in (1,4) and mt.mark_type_arg in (6))
                and not exists(select * from univer_progress pr, univer_mark_type mt where pr.student_id=st.students_id and pr.subject_id=pp.subject_id and pr.n_seme=pp.educ_plan_pos_semestr and mt.mark_type_id=pr.mark_type_id and pr.status in (4) and mt.mark_type_arg in (2))
                then null
                ---на существование заявки на повторное обучение
                when @failOrder=1 and g.group_retake_semestr>0 and not exists(select * from univer_progress pr, univer_fail_order fo, univer_fail_order_progress_link fp where pr.student_id=st.students_id and pr.subject_id=pp.subject_id and pr.n_seme=pp.educ_plan_pos_semestr and fp.progress_id=pr.progress_id and fp.fail_order_id=fo.fail_order_id and fo.fail_order_semestr=g.group_semestr and fo.fail_order_year=g.group_year and pr.status in (1,4) and fo.status in (6,7))
                then  N'  Студент не подал заявку на повторное обучение  '
                ---на оплату заявки на повторное обучение
                when  @failOrder=1 and g.group_retake_semestr>0 and @sheetType in (5, 7, 8, 18, 19, 25) and (exists(select * from univer_progress pr, univer_fail_order fo, univer_fail_order_progress_link fp where pr.student_id=st.students_id and pr.subject_id=pp.subject_id and pr.n_seme=pp.educ_plan_pos_semestr and fp.progress_id=pr.progress_id and fp.fail_order_id=fo.fail_order_id and pr.status in (1,4) and fo.status in (6,1)) or not exists(select * from univer_progress pr, univer_fail_order fo, univer_fail_order_progress_link fp where pr.student_id=st.students_id and pr.subject_id=pp.subject_id and pr.n_seme=pp.educ_plan_pos_semestr and fp.progress_id=pr.progress_id and fp.fail_order_id=fo.fail_order_id and fo.fail_order_semestr=g.group_semestr and fo.fail_order_year=g.group_year and pr.status in (1,4) and fo.status in (7)))
                then N'  Студент не оплатил заявку на повторное обучение  '
                 else null end error
                from univer_group g, univer_group_student gs, univer_educ_plan_pos pp, univer_students st, univer_educ_plan p where g.group_id=gs.group_id and gs.student_id=st.students_id and p.edu_level_id=st.edu_levels_id and p.educ_plan_adm_year=st.educ_plan_adm_year and p.education_form_id=st.education_form_id and p.speciality_id=st.speciality_id and p.status=1 and pp.educ_plan_pos_id=g.educ_plan_pos_id and pp.educ_plan_id=p.educ_plan_id and pp.status=1 and st.status=1 and st.students_id=@studentId
                and g.group_id=@groupId) 
				return @ret
END
go

