-- =============================================
-- Author:		Саша
-- Create date: 14.06.2012
-- Description:	Средний балл анкетирования глазами коллег для зав. кафедры
-- =============================================
CREATE FUNCTION getAvgBallForInterview
(
		@chairId int, 
	    @year int
)
RETURNS real
AS
BEGIN
	-- Declare the return variable here
	DECLARE @sball real

	select @sball=AVG(convert(real,ir.interview_result)) from univer_interview_result ir where ir.interview_questions_id in (
select q.interview_questions_id from univer_interview_questions q where q.interview_id=(select top 1 interview_id from univer_interview where year(interview_date_end)>=@year order by interview_date_end desc)) and ir.personal_valued_id in (select personal_id from univer_head_chair where chair_id=@chairId and status=1)

	-- Return the result of the function
	RETURN @sball

END
go

