-- =============================================
-- Author:		@LFER
-- Create date: 2009-09-28
-- Description:	Добавление права доступа сотруднику при добавлении строки
-- =============================================
CREATE TRIGGER [dbo].[chairHeadInsertTrigger] ON  [dbo].[univer_head_chair] AFTER INSERT
AS 
BEGIN	
	SET NOCOUNT ON;	
	DECLARE @pi int
	
	DECLARE insCursor cursor 
		FOR SELECT personal_id FROM inserted WHERE status=1
		
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @pi
	WHILE @@FETCH_STATUS = 0
	BEGIN
		exec dbo.personalSetAccess @pi, 'CHAIR_HEAD'
		FETCH NEXT FROM insCursor INTO @pi;
	END
	CLOSE insCursor
END
go

