-- =============================================
-- Author:		@LFER
-- Create date: 2009-03-30 13:26:15.400
-- Description: Установка права доступа сотруднику
-- =============================================
CREATE PROCEDURE [dbo].[personalDeleteAccess] @personal_id int, @role nvarchar(50)
AS
BEGIN
	DECLARE @user_id int
	SELECT @user_id=user_id FROM univer_personal WHERE personal_id=@personal_id
	IF(@user_id>0)
	BEGIN
		UPDATE univer_users SET user_access = user_access & (~CONVERT(bigint, dbo.accessGetByRole(@role)))  WHERE user_id=@user_id

	-- Добавление записи о том, что пользователю необходимо перелогиниться
		INSERT INTO univer_alert (alert_code, user_id, alert_date) VALUES (2, @user_id, getdate())
	END
END
go

