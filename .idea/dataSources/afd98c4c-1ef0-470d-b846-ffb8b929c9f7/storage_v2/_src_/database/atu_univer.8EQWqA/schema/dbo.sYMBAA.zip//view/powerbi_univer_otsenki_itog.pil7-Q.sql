
CREATE VIEW [dbo].[powerbi_univer_otsenki_itog]
AS
SELECT     [ид_записи_об_оценке], [баллы_итог]
FROM         (SELECT DISTINCT progress_id [ид_записи_об_оценке], univer.dbo.getTotalForProgress(progress_id)[баллы_итог] from univer_progress where status=1 and student_id in (SELECT        st.students_id 
FROM            univer_students AS st LEFT OUTER JOIN               
                univer.dbo.univer_educ_plan AS p ON st.edu_levels_id = p.edu_level_id AND st.educ_plan_adm_year = p.educ_plan_adm_year AND 
                         st.education_form_id = p.education_form_id AND st.speciality_id = p.speciality_id
WHERE        (p.status = 1) AND (st.status != 10))) AS t

go

