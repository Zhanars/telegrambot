-- =============================================
-- Author:		Yerlan
-- Create date: 21.01.2014
-- Description:	<Description,,>
-- =============================================
create TRIGGER [dbo].[SponsorUpdateForPlatonus] 
   ON  [dbo].[univer_sponsor_organization]
   AFTER INSERT,DELETE,UPDATE
AS 
BEGIN
	IF @@ROWCOUNT =0
    RETURN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
    if exists(select * from inserted) and not exists(select * from deleted)
    begin 
		insert into platonus_univer_sponsor_organization(sponsor_organization_id, operation)
		select i.sponsor_organization_id,1 from inserted i
		where i.status=1 and i.sponsor_organization_id not in (select sponsor_organization_id from platonus_univer_sponsor_organization)
    end
    
    if exists(select * from inserted) and exists(select * from deleted)
    begin
		delete from platonus_univer_sponsor_organization where sponsor_organization_id in (select sponsor_organization_id from deleted)
		
		insert into platonus_univer_sponsor_organization(sponsor_organization_id, operation)
		select i.sponsor_organization_id, 1 from inserted i
		where i.status=1
		
		insert into platonus_univer_sponsor_organization(sponsor_organization_id, operation)
		select i.sponsor_organization_id, 2 from inserted i, deleted d
		where i.status=2 and d.status=1 and i.sponsor_organization_id=d.sponsor_organization_id
				
    end
    
    if not exists(select * from inserted) and exists(select * from deleted where status=1)
    begin
		delete from platonus_univer_sponsor_organization 
		where sponsor_organization_id in (select sponsor_organization_id from deleted where status=1)
		
		insert into platonus_univer_sponsor_organization(sponsor_organization_id, operation)
		select sponsor_organization_id, 2 from deleted d where d.status=1
    end
    

END
go

