-- =============================================
-- Author:		@LFER
-- Create date: 2009-03-19 10:44:35.710
-- Description:	Триггер на добавление языка
-- =============================================
CREATE TRIGGER [dbo].[langInsert]
   ON  [dbo].[univer_langs]
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
	DECLARE @langName nvarchar(5)
	DECLARE insCursor cursor 
		FOR SELECT lang_name FROM inserted
	
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @langName
	WHILE @@FETCH_STATUS = 0
	BEGIN
		DECLARE @query nvarchar(500);
		SET @query='if not Exists(select * from sys.columns where Name = N''prorector_speciality_'+ @langName +'''  
            and Object_ID = Object_ID(N''univer_prorector''))
            begin 
            ALTER TABLE univer_prorector ADD prorector_speciality_' + @langName + ' nvarchar(200) not null default N''''
            end';
		EXEC (@query);
		FETCH NEXT FROM insCursor INTO @langName;
	END
	CLOSE insCursor
END
go

