-- =============================================
-- Author:		@LFER
-- Create date: 2009-05-22 12:57:14.750
-- Description:	Удаление соответствующего права у сотрудника при удалении строки
-- =============================================
CREATE TRIGGER [dbo].[teacherDeleteTrigger]
   ON  [dbo].[univer_teacher]
   FOR DELETE
AS 
BEGIN
	SET NOCOUNT ON;	
	DECLARE @pi int
	DECLARE @st int	
	DECLARE insCursor cursor 
		FOR SELECT personal_id FROM deleted	
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @pi
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC dbo.personalDeleteAccess @pi, 'TEACHER'
		-- архивируем этого пользователя в науке, если у него роль была ППС
		EXEC dbo.SCI_PPS_SetStatus @pi, 2
		FETCH NEXT FROM insCursor INTO @pi
	END
	CLOSE insCursor
END
go

