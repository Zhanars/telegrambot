-- =============================================
-- Author:		Sasha
-- Create date: 11.05.2009
-- Description:	Триггер на удаление офис-регистратора
-- =============================================
CREATE TRIGGER [dbo].[officeRegDeleteTrigger]
   ON  [dbo].[univer_office_registrator]
   AFTER DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    DECLARE @pi int
	DECLARE @st int
	DECLARE @type int
    DECLARE insCursor cursor 
		FOR SELECT personal_id FROM deleted
	
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @pi
	WHILE @@FETCH_STATUS = 0
	BEGIN
	set @type=(SELECT type FROM deleted WHERE personal_id=@pi)
	if (@type=1) begin
		EXEC dbo.personalDeleteAccess @pi, 'OFICE_REGISTRATOR' end
	if (@type=2) begin
		EXEC dbo.personalDeleteAccess @pi, 'METODIST' end			
	FETCH NEXT FROM insCursor INTO @pi
	END
	CLOSE insCursor

END
go

