



-- =============================================
-- Author:		Ruslan
-- Create date: 31.07.2017
-- Description: Получить льготы студента с различным приоритетом для заселения в общежитие в виде строки
-- =============================================
CREATE FUNCTION [dbo].[GetStudentPrivsForDormitory2]
(
	@studentId int,
	@langId int
)

-----------------------------------------------------------------
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @Result NVARCHAR(MAX)

-- ==================================== 
BEGIN
	DECLARE @localVar nvarchar(max);
    /**************************************************************************************/
	DECLARE @propTable table (pid int, ptype int, pname nvarchar(150));
    INSERT INTO @propTable(pid, ptype, pname)
    SELECT s.properties_id,s.properties_type,case when @langId=2 then s.properties_name_ru else (case when @langId=1 then s.properties_name_kz else s.properties_name_en end) end
    FROM univer_students_properties s,univer_student_properties_link spl where s.properties_id = spl.properties_id AND s.status=1 AND spl.students_id=@studentId 

	SELECT @localVar = COALESCE(@localVar, '') + ISNULL(t.pname+', ', '')
		FROM @propTable t
		WHERE t.pid IN (1);
	IF LEN(@localVar)>1
	BEGIN
		SET @Result = N'1) ' + LEFT(@localVar, LEN(@localVar) - 2);
	END;
	
	SET @localVar = '';		
	SELECT @localVar = COALESCE(@localVar, '') + ISNULL(t.pname+', ', '')
		FROM @propTable t
		WHERE t.pid IN (15, 16, 17, 19, 91);
	IF LEN(@localVar)>1
	BEGIN
		SET @Result = ISNULL(@Result,'') + (case when @Result IS NOT NULL then N'<br/>' else '' end) +
		N'2) ' + LEFT(@localVar, LEN(@localVar) - 2);
	END;

	SET @localVar = '';	 
	SELECT @localVar = case when [dbo].[IsStudentExcellent](@studentId)=1 then (case when @langId=2 then N'Отличник учебы' else (case when @langId=1 then N'Оқу озаты' else N'Excellent student' end) end) else N'' end 
	IF LEN(@localVar)>0
	BEGIN
		SET @Result = ISNULL(@Result,'') + (case when @Result IS NOT NULL then N'<br/>' else '' end) +
		N'3) ' + @localVar;
	END;

	SET @localVar = '';		
	SELECT @localVar = COALESCE(@localVar, '') + ISNULL(t.pname+', ', '')
		FROM @propTable t
		WHERE t.pid IN (106, 107, 108, 109, 110);
	IF LEN(@localVar)>1
	BEGIN
		SET @Result = ISNULL(@Result,'') + (case when @Result IS NOT NULL then N'<br/>' else '' end) +
		N'4) ' + LEFT(@localVar, LEN(@localVar) - 2);
	END;

	SET @localVar = '';	 
	SELECT @localVar = case when (SELECT st.citizenship_id FROM univer_students st WHERE st.students_id = @studentId) != 1 
	then (case when @langId=2 then N'Иностранный студент' else (case when @langId=1 then N'Шетелдік студент' else N'Foreign student' end) end) else N'' end 
	IF LEN(@localVar)>0
	BEGIN
		SET @Result = ISNULL(@Result,'') + (case when @Result IS NOT NULL then N'<br/>' else '' end) + 
		N'5) ' + @localVar;
	END;

	SET @localVar = '';		
	SELECT @localVar = COALESCE(@localVar, '') + ISNULL(t.pname+', ', '')
		FROM @propTable t
		WHERE t.pid IN (102);
	IF LEN(@localVar)>1
	BEGIN
		SET @Result = ISNULL(@Result,'') + (case when @Result IS NOT NULL then N'<br/>' else '' end) + 
		N'6) ' + LEFT(@localVar, LEN(@localVar) - 2);
	END;
			
END

RETURN ISNULL(@Result,N'')
END


go

