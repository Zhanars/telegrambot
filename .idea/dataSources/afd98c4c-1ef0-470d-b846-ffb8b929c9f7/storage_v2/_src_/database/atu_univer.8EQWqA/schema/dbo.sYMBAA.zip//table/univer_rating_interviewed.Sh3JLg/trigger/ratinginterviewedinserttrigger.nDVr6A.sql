-- =============================================
-- Author:		yerlan
-- Create date: 2010-05-24
-- Description:	Добавление суммарного анкетного балла ппс в Рейтинговую систему
-- =============================================
CREATE TRIGGER [dbo].[ratingInterviewedInsertTrigger] ON  [dbo].[univer_rating_interviewed] AFTER INSERT
AS 
BEGIN	
	SET NOCOUNT ON;	
	DECLARE @pi int;
	DECLARE @ri int;
	DECLARE @formula_id int;
	--формула "АНКЕТА_ГЛАЗАМИ_СТУДЕНТОВ"=5
	SET @formula_id = 5;
	
	DECLARE insCursor cursor 
		FOR SELECT personal_id,rating_id FROM inserted
		
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @pi,@ri
	WHILE @@FETCH_STATUS = 0
	BEGIN
		exec dbo.personalRatingPPSSetValue @pi, @ri,@formula_id
		FETCH NEXT FROM insCursor INTO @pi,@ri;
	END
	CLOSE insCursor
END
go

disable trigger ratingInterviewedInsertTrigger on univer_rating_interviewed
go

