-- =============================================
-- Author:		Twice
-- Create date: 31.01.2012
-- Description: Получить долю студентов, магистрантов, PhD-докторантов, участвующих в выполнении проектов, от общего количества исполнителей проекта - в разрезе кафедр
-- =============================================
CREATE FUNCTION IP_NIR_getStudentsInRAD_ShareInProjectMembers_ByChairId
(
	@chairId int,
	@year int
)
RETURNS real
AS
BEGIN
DECLARE @Result real

SELECT @Result = 0

-- Return the result of the function
RETURN @Result

END
go

