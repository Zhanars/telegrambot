-- =============================================
-- Author:		@LFER
-- Create date: 2009-06-17 13:40:34.937
-- Description:	Триггер на удаление записи о персонале
-- =============================================
CREATE TRIGGER [dbo].[personalDeleteTrigger]
   ON  [dbo].[univer_personal]
   AFTER DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @ui int
	DECLARE @st int
	
	DECLARE insCursor cursor 
		FOR SELECT user_id FROM deleted
	
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @ui
	WHILE @@FETCH_STATUS = 0
	BEGIN
		update univer_users set user_access=0 WHERE user_id=@ui
			
		FETCH NEXT FROM insCursor INTO @ui
	END
	CLOSE insCursor
END
go

