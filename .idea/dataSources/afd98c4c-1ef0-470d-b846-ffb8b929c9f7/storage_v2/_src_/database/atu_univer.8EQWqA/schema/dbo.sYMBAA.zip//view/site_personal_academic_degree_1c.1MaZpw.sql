CREATE VIEW dbo.site_personal_academic_degree_1c
AS
SELECT     dbo.univer_personal.personal_id, dbo.univer_academic_degree_1c.academic_degree_id, dbo.univer_academic_degree_1c.academic_degree_name_kz, 
                      dbo.univer_academic_degree_1c.academic_degree_name_ru, dbo.univer_academic_degree_1c.academic_degree_name_en, 
                      dbo.univer_degree_area_1c.degree_area_name_kz, dbo.univer_degree_area_1c.degree_area_name_ru, dbo.univer_degree_area_1c.degree_area_name_en, 
                      dbo.univer_degree_area_1c.degree_area_short_name_kz, dbo.univer_degree_area_1c.degree_area_short_name_ru, 
                      dbo.univer_degree_area_1c.degree_area_short_name_en, dbo.univer_personal_academic_degree_1c.personal_academic_degree_number, 
                      CASE WHEN dbo.univer_personal_academic_degree_1c.personal_academic_degree_date < '3086-10-21 00:00:00.000' THEN NULL ELSE DATEADD(YYYY, - 2000, 
                      dbo.univer_personal_academic_degree_1c.personal_academic_degree_date) END AS personal_academic_degree_date, 
                      dbo.univer_academic_degree_1c.status
FROM         dbo.univer_personal_academic_degree_1c INNER JOIN
                      dbo.univer_personal ON dbo.univer_personal_academic_degree_1c.personal_id = dbo.univer_personal.personal_id LEFT OUTER JOIN
                      dbo.univer_academic_degree_1c ON 
                      dbo.univer_personal_academic_degree_1c.academic_degree_id = dbo.univer_academic_degree_1c.academic_degree_id LEFT OUTER JOIN
                      dbo.univer_degree_area_1c ON dbo.univer_personal_academic_degree_1c.degree_area_id = dbo.univer_degree_area_1c.degree_area_id
go

