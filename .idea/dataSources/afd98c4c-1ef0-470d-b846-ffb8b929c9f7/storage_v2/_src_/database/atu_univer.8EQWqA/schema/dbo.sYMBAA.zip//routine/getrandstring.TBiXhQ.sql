
-- =============================================
-- Author:		Sasha
-- Create date: 20.10.2010
-- Description:	Генерация строки из N символов с цифрами
-- =============================================
CREATE FUNCTION [dbo].[getRandString]
(
 @N int
)
RETURNS nvarchar(50)
AS
BEGIN
	 declare @user_pwd nvarchar(50)
	 if @N>50 begin set @N=50 end
		DECLARE @I int; set @I=0;
		declare @num int;declare @rnum real;
		set @user_pwd='';
		declare @ch nvarchar(1)
		while(@I<=@N)
		begin
		set @rnum=(select random from RANDOM);
		set @num=ROUND((@rnum* 63),0);
		select @ch=case @num when 1 then N'a' when 2 then N'b' when 3 then N'c' when 4 then N'd' when 5 then N'e' when 6 then N'f' when 7 then N'g' when 8 then N'h' when 9 then N'i' when 10 then N'j' when 11 then N'k' when 12 then N'l' when 13 then N'm' when 14 then N'n' when 15 then N'o' when 16 then N'p' when 17 then N'q' when 18 then N'r' when 19 then N's' when 20 then N't' when 21 then N'u' when 22 then N'v' when 23 then N'w' when 24 then N'x' when 25 then N'y' when 26 then N'z' when 27 then N'A' when 28 then N'B' when 29 then N'C' when 30 then N'D' when 31 then N'E' when 32 then N'F' when 33 then N'G' when 34 then N'H' when 35 then N'I' when 36 then N'J' when 37 then N'K' when 38 then N'L' when 39 then N'M' when 40 then N'N' when 41 then N'O' when 42 then N'P' when 43 then N'Q' when 44 then N'R' when 45 then N'S' when 46 then N'T' when 47 then N'U' when 48 then N'V' when 49 then N'W' when 50 then N'X' when 51 then N'Y' when 52 then N'Z' when 53 then N'0' when 54 then N'1' when 55 then N'2' when 56 then N'3' when 57 then N'4' when 58 then N'5' when 59 then N'6' when 60 then N'7' when 61 then N'8' when 62 then N'9' else N'Z' end
	    set @user_pwd=@user_pwd+@ch	
	    set @I=@I+1;
	    end 	  	    
	RETURN isnull(@user_pwd,'')

END

go

