
CREATE function [dbo].[MakeFio]
	(
		@sname nvarchar(1000),
		@name nvarchar(1000),
		@fname nvarchar(1000),
		@snameFirst bit
	)
returns nvarchar(1000)
as 
begin
	declare @ret nvarchar(1000) = '';

	set @sname=isnull(ltrim(rtrim(@sname)), '');
	set @name=isnull(ltrim(rtrim(@name)), '');
	set @fname=isnull(ltrim(rtrim(@fname)), '');

	if (@snameFirst = 1) BEGIN
		if (@sname != '') BEGIN
			set @ret = @sname;
			if (@name != '') set @ret = @ret + ' ' + LEFT(@name, 1) + '.'
			if (@fname != '') set @ret = @ret + ' ' + LEFT(@fname, 1) + '.'
		END
		ELSE BEGIN
			set @ret = @name;
			if (@fname != '') set @ret = @ret + ' ' + LEFT(@fname, 1) + '.'
		END
	END
	ELSE BEGIN
		if (@sname != '') BEGIN
			if (@name != '') set @ret = @ret + LEFT(@name, 1) + '. '
			if (@fname != '') set @ret = @ret + LEFT(@fname, 1) + '. '
			set @ret = @ret + @sname
		END
		ELSE BEGIN
			if (@fname != '') set @ret = @ret + LEFT(@fname, 1) + '. '
			set @ret = @ret + @name
		END
	END

	return @ret;
end


go

