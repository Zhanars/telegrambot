-- =============================================
-- Author:		sasha
-- Create date: 24.01.2017
-- Description:	Функция обновления роли по таблице соответствия должностей и ролей
-- =============================================
CREATE PROCEDURE [dbo].[updAccessByStructPos]
     @personalId int
AS
BEGIN
	
	SET NOCOUNT ON;
    declare @userId int;--ид пользователя
    declare @status int;--статус сотрудника
    --выбираем данные сотрудника
    select @userId=user_id, @status=status from univer_personal where personal_id=@personalId;    
    if @status=1
    begin
    --выбираем данные его должностей с нужными ролями
    declare @roles bigint;--необходимые роли  
    set @roles=0;
    --выбираем необходимые роли
    select @roles = @roles | rl.user_access from univer_struct_pos_role_link rl, univer_personal_struct_pos_link_1c pp where rl.user_access>0
    and rl.personal_position_id=pp.personal_position_id and rl.structure_division_id=pp.structure_division_id and pp.status=1 and pp.personal_id=@personalId
    --если роли есть, а пользователь еще не создан, то создаем пользователя
    if @userId <=0 and @roles>0
    begin
     --Получаем логин
     declare @login nvarchar(50);
     select @login=lower(dbo.translit(rtrim(ltrim(p.personal_sname))+'.'+rtrim(ltrim(p.personal_name)))) from univer_personal p where p.personal_id=@personalId;
     if (@login is null or len(@login)<1)
     begin
      set @login=N'user';
      declare @i int;
      set @i=1;
      while (exists(select * from univer_users where user_login=@login))
      begin
      set @login=N'user'+cast (@i as nvarchar(100));
      set @i=@i+1;
      end;
     end;
	 else
	 begin
      set @i=1;
      while (exists(select * from univer_users where user_login=@login))
      begin
      set @login=@login+cast (@i as nvarchar(100));
      set @i=@i+1;
      end;
	 end;
     --Генерим пароль
     declare @randNum int; 
	 set @randNum=ROUND((5000*(select random from RANDOM)),0);      
     declare @tmppass nvarchar(50);        
     declare @password char(128);
     select TOP 1 @tmppass=temp_pass, @password=temp_pass_hash from univer_temp_pass order by abs(@randNum-temp_pass_num);
     insert into univer_users (user_login,user_access,user_password,user_pass_change_date,user_last_login,user_temppass)
     values (@login,@roles,@password,null,null,@tmppass)
     set @userId=@@identity;
     update univer_personal set user_id=@userId where personal_id=@personalId;
    end
    --если пользователь уже есть, то обновляем роли
    if @userId>0 and @roles>0
    begin
     --Факультет по умолчанию
	   declare @facultyDef int;
	   select top 1 @facultyDef=faculty_id from univer_faculty where status=1 order by faculty_id desc;
	   set @facultyDef=isnull(@facultyDef,0)
     --по всем ролям заполняем дополнительные таблицы
     --РОЛЬ-------------------------------------ТАБЛИЦА-----------------------------Доп.поля
	 --TEACHER = 16;							univer_teacher						заполнить univer_teacher_chair_link
	   if ((@roles & cast(16 as bigint))>0)
	   begin
	   declare @teacherId int;
	   if (select count(c.chair_id) from univer_personal_struct_pos_link_1c pp, univer_chair c where pp.personal_id=@personalId and pp.status=1
	   and c.structure_division_id in (select t.structure_division_id from dbo.[getStructPosParents](pp.structure_division_id,'ru') t) and c.status=1)>0
	   begin
	   select @teacherId=isnull(teacher_id,0) from univer_teacher where personal_id=@personalId;
	   if(isnull(@teacherId,0)<=0) begin
	   insert into univer_teacher(personal_id,status) values (@personalId,1);
	   set @teacherId=@@identity;	   end; else begin
	   update univer_teacher set status=1 where teacher_id=@teacherId;
	   end;
	   delete from univer_teacher_chair_link where teacher_id=@teacherId;
	   insert into univer_teacher_chair_link(teacher_id,chair_id,stavka,p_type)
	   select @teacherId,c.chair_id,case when sum(pp.personal_rate)>=1 then 1 else 0 end, 0 from univer_personal_struct_pos_link_1c pp, univer_chair c where pp.personal_id=@personalId and pp.status=1
	   and c.structure_division_id in ((select t.structure_division_id from dbo.[getStructPosParents](pp.structure_division_id,'ru') t)) and c.status=1 and not exists(select * from univer_teacher_chair_link tcl where tcl.chair_id=c.chair_id and tcl.teacher_id=@teacherId) group by c.chair_id
	   end;
	   end;
	   
	   
	 --ADVICER = 32;							univer_advicer						faculty_id, chair_id
	 -----ПОКА ЭТО НЕВОЗМОЖНО!!!!!!!!
	   ---- if ((@roles & cast(32 as bigint))>0)
	   ----begin
	   ----declare @advicerId int;
	   ----declare @f int;	 
	   ----select @advicerId=advicer_id from univer_advicer where personal_id=@personalId;
	   ----if(@advicerId<=0) begin
	   ----insert into univer_advicer( personal_id,faculty_id,status) values (@personalId,@f,1);
	   ----set @advicerId=@@identity;	   end; else begin
	   ----update univer_advicer set status=1, faculty_id=@f where advicer_id=@advicerId;
	   ----end;  	   
	   ----end;
	 --OFICE_REGISTRATOR = 64;					univer_office_registrator			faculty_id, type, univer_office_registrator_faculty_link
	   if ((@roles & cast(64 as bigint))>0)
	   begin
	   declare @ofregId int;
	   select @ofregId=office_registrator_id from univer_office_registrator where personal_id=@personalId;
	   if(isnull(@ofregId,0)<=0) begin
	   insert into univer_office_registrator(personal_id,faculty_id,type,status) values (@personalId,@facultyDef,1,1);
	   set @ofregId=@@identity;	   end; else begin
	   update univer_office_registrator set status=1, type=1 where office_registrator_id=@ofregId;
	   end;	  
	   end;
	 --METODIST = 536870912;					univer_office_registrator			faculty_id, type, univer_office_registrator_faculty_link
	   if ((@roles & cast(536870912 as bigint))>0)
	   begin
	   declare @methId int;
	   select @methId=office_registrator_id from univer_office_registrator where personal_id=@personalId;
	   if(isnull(@methId,0)<=0) begin
	   insert into univer_office_registrator(personal_id,faculty_id,type,status) values (@personalId,@facultyDef,2,1);
	   set @methId=@@identity;	   end; else begin
	   update univer_office_registrator set status=1, type=2 where office_registrator_id=@methId;
	   end;	  
	   end;
	 
	 --CHAIR_HEAD = 128;						univer_head_chair					chair_id, start_date, end_date
	   if ((@roles & cast(128 as bigint))>0)
	   begin
	   declare @chairHeadId int;
	   declare @chairId int;
	   select @chairHeadId=head_chair_id from univer_head_chair where personal_id=@personalId;
	   select top 1 @chairId=c.chair_id from univer_personal_struct_pos_link_1c pp, univer_chair c where pp.personal_id=@personalId and pp.status=1
	   and c.structure_division_id in ((select t.structure_division_id from dbo.[getStructPosParents](pp.structure_division_id,'ru') t)) and c.status=1 	
	   order by pp.personal_rate desc  
	   if (@chairId is not null)
	   begin	
	   if(isnull(@chairHeadId,0)<=0) begin
	   insert into univer_head_chair(personal_id,status,head_chair_start_date,chair_id) values (@personalId,1, getdate(),@chairId);
	   set @chairHeadId=@@identity;	   end; else begin
	   update univer_head_chair set status=1, chair_id=@chairId,head_chair_start_date=case when status<>1 then getdate() else head_chair_start_date end where head_chair_id=@chairHeadId;
	   end;	   
	   update univer_head_chair set status=2, head_chair_end_date=getdate() where head_chair_id<>@chairHeadId and chair_id=@chairId and status=1;
	   end;
	   end;
	 --VICE_CHAIR_HEAD = 34359738368;			univer_vice_head_chair				chair_id,start_date, end_date, type
	   if ((@roles & cast(34359738368 as bigint))>0)
	   begin
	   declare @vchairHeadId int;
	   declare @vchairId int;
	   select @vchairHeadId=vice_head_chair_id from univer_vice_head_chair where personal_id=@personalId;
	   select top 1 @vchairId=c.chair_id from univer_personal_struct_pos_link_1c pp, univer_chair c where pp.personal_id=@personalId and pp.status=1
	   and c.structure_division_id in ((select t.structure_division_id from dbo.[getStructPosParents](pp.structure_division_id,'ru') t)) and c.status=1 	
	   order by pp.personal_rate desc    
	   if (@chairId is not null)
	   begin
	   if(isnull(@vchairHeadId,0)<=0) begin
	   insert into univer_vice_head_chair(personal_id,status,vice_head_chair_start_date,chair_id,vice_head_chair_type_id) values (@personalId,1, getdate(),@vchairId,0);
	   set @vchairHeadId=@@identity;	   end; else begin
	   update univer_vice_head_chair set status=1, chair_id=@vchairId,vice_head_chair_start_date=case when status<>1 then getdate() else vice_head_chair_start_date end where vice_head_chair_id=@vchairHeadId;
	   end;
	   end;
	   end;
	 --DEAN = 256;								univer_dekan						faculty_id, post_id, start_date, end_date
	   if ((@roles & cast(256 as bigint))>0)
	   begin
	   declare @deanId int;
	   declare @facultyId int;
	   select @deanId=dekan_id from univer_dekan where personal_id=@personalId;
	   select top 1 @facultyId=f.faculty_id from univer_personal_struct_pos_link_1c pp, univer_faculty f where pp.personal_id=@personalId and pp.status=1
	   and f.structure_division_id  in ((select t.structure_division_id from dbo.[getStructPosParents](pp.structure_division_id,'ru') t)) and f.status=1 
	   order by pp.personal_rate desc
	   if (@facultyId is not null)
	   begin	   	  
	   if(isnull(@deanId,0)<=0) begin
	   insert into univer_dekan(personal_id,status,faculty_id,post_id,dekan_start_date) values (@personalId,1,@facultyId, 1, getdate());
	   set @deanId=@@identity;	   end; else begin
	   update univer_dekan set status=1, faculty_id=@facultyId,dekan_start_date=case when status<>1 then getdate() else dekan_start_date end where dekan_id=@deanId;
	   end;
	   update univer_dekan set status=2, dekan_end_date=getdate() where dekan_id<>@deanId and faculty_id=@facultyId and status=1;
	   end
	   end;
	 --VICE_DEKAN = 67108864;					univer_vice_dekan					faculty_id, start_date, end_date, type
	   if ((@roles & cast(67108864 as bigint))>0)
	   begin
	   declare @vdeanId int;
	   declare @vfacultyId int;
	   select @vdeanId=vice_dekan_id from univer_vice_dekan where personal_id=@personalId;
	   select top 1 @facultyId=f.faculty_id from univer_personal_struct_pos_link_1c pp, univer_faculty f where pp.personal_id=@personalId and pp.status=1
	   and f.structure_division_id in ((select t.structure_division_id from dbo.[getStructPosParents](pp.structure_division_id,'ru') t)) and f.status=1 
	   order by pp.personal_rate desc
	   if (@facultyId is not null)
	   begin		   	   	  	      
	   if(isnull(@vdeanId,0)<=0) begin
	   insert into univer_vice_dekan(personal_id,status,faculty_id,vice_dekan_type,vice_dekan_start_date) values (@personalId,1,@facultyId, 1, getdate());
	   set @vdeanId=@@identity;	   end; else begin
	   update univer_vice_dekan set status=1, faculty_id=@facultyId,vice_dekan_start_date=case when status<>1 then getdate() else vice_dekan_start_date end  where vice_dekan_id=@vdeanId;
	   end;
	   end;
	   end;
	 --RECTOR = 512;							univer_rector						start_date, end_date
	   if ((@roles & cast(512 as bigint))>0)
	   begin	            
	   update univer_rector set status=2, rector_dateend=getdate() where personal_id<>@personalId and status=1;
	   if (not exists(select * from univer_rector where status=1))
	   begin
	   insert into univer_rector(personal_id,status,rector_datestart) values (@personalId,1,getdate());	
	   end;
	   end;
	 --PRORECTOR = 1024;						univer_prorector					type,date_start, date_end, speciality
	   if ((@roles & cast(1024 as bigint))>0)
	   begin
	   declare @vrecId int;
	   select @vrecId=prorector_id from univer_prorector where personal_id=@personalId;
	     	      
	   if(isnull(@vrecId,0)<=0) begin
	   insert into univer_prorector(personal_id,status,prorector_datestart,prorector_type_id) values (@personalId,1,getdate(),2);
	   set @vrecId=@@identity;	   end; else begin
	   update univer_prorector set status=1, prorector_datestart=case when status<>1 then getdate() else prorector_datestart end where prorector_id=@vrecId;
	   end;
	   end;
	 --METHOD_DEPART = 2048;					univer_method_department 
	   if ((@roles & cast(2048 as bigint))>0)
	   begin
	   declare @mdId int;
	   select @mdId=method_department_worker_id from univer_method_department where personal_id=@personalId;	     	      
	   if(isnull(@mdId,0)<=0) begin
	   insert into univer_method_department(personal_id,status) values (@personalId,1);
	   set @mdId=@@identity;	   end; else begin
	   update univer_method_department set status=1 where method_department_worker_id=@mdId;
	   end;
	   end;
	 --LEARN_DEPART = 4096;						univer_educ_department	 
	   if ((@roles & cast(4096 as bigint))>0)
	   begin
	   declare @ldId int;
	   select @ldId=educ_department_worker_id from univer_educ_department where personal_id=@personalId;	     	      
	   if(isnull(@ldId,0)<=0) begin
	   insert into univer_educ_department(personal_id,status) values (@personalId,1);
	   set @ldId=@@identity;	   end; else begin
	   update univer_educ_department set status=1 where educ_department_worker_id=@ldId;
	   end;
	   end;
	 --STUD_DEPART = 16384;						univer_student_department
	   if ((@roles & cast(16384 as bigint))>0)
	   begin
	   declare @sdId int;
	   select @sdId=stud_dep_id from univer_student_department where personal_id=@personalId;	     	      
	   if(isnull(@sdId,0)<=0) begin
	   insert into univer_student_department(personal_id,status) values (@personalId,1);
	   set @sdId=@@identity;	   end; else begin
	   update univer_student_department set status=1 where stud_dep_id=@sdId;
	   end;
	   end;
	   
	 --TEST_DEPART = 2097152;					univer_test_departs
	   if ((@roles & cast(2097152 as bigint))>0)
	   begin
	   declare @tdId int;
	   select @tdId=test_depart_id from univer_test_departs where personal_id=@personalId;	     	      
	   if(isnull(@tdId,0)<=0) begin
	   insert into univer_test_departs(personal_id,status) values (@personalId,1);
	   set @tdId=@@identity;	   end; else begin
	   update univer_test_departs set status=1 where test_depart_id=@tdId;
	   end;
	   end;
	   
	 --PERSONNEL_DEPART = 16777216;				univer_personnel_depart
	   if ((@roles & cast(16777216 as bigint))>0)
	   begin
	   declare @pdId int;
	   select @pdId=personnel_depart_id from univer_personnel_depart where personal_id=@personalId;	     	      
	   if(isnull(@pdId,0)<=0) begin
	   insert into univer_personnel_depart(personal_id,status) values (@personalId,1);
	   set @pdId=@@identity;	   end; else begin
	   update univer_personnel_depart set status=1 where personnel_depart_id=@pdId;
	   end;
	   end;
	 
	 --POSTGRADUATE_DEPART = 33554432;			univer_postgraduate_department
	   if ((@roles & cast(33554432 as bigint))>0)
	   begin
	   declare @pgdId int;
	   select @pgdId=postgraduate_depart_id from univer_postgraduate_department where personal_id=@personalId;	     	      
	   if(isnull(@pgdId,0)<=0) begin
	   insert into univer_postgraduate_department(personal_id,status) values (@personalId,1);
	   set @pgdId=@@identity;	   end; else begin
	   update univer_postgraduate_department set status=1 where postgraduate_depart_id=@pgdId;
	   end;
	   end;
	 
	 --LEADER_OTHER = 134217728;				univer_leader_other	
	   if ((@roles & cast(134217728 as bigint))>0)
	   begin
	   declare @loId int;
	   select @loId =leader_id  from univer_leader_other where personal_id=@personalId;	     	      
	   if(isnull(@loId,0)<=0) begin
	   insert into univer_leader_other(personal_id,status) values (@personalId,1);
	   set @loId=@@identity;	   end; else begin
	   update univer_leader_other set status=1 where leader_id=@loId;
	   end;
	   end;
	 
	 --DISTANCE_LEARNING = 274877906944;		univer_distance_learn_admin	
	   if ((@roles & cast(274877906944 as bigint))>0)
	   begin
	   declare @dlId int;
	   select @dlId=distance_learn_admin_id  from univer_distance_learn_admin where personal_id=@personalId;	     	      
	   if(isnull(@dlId,0)<=0) begin
	   insert into univer_distance_learn_admin(personal_id,status) values (@personalId,1);
	   set @dlId=@@identity;	   end; else begin
	   update univer_distance_learn_admin set status=1 where distance_learn_admin_id=@dlId;
	   end;
	   end;	
	 	
	 --ICD = 549755813888;						univer_icd_workers		
	   if ((@roles & cast(549755813888 as bigint))>0)
	   begin
	   declare @icdId int;
	   select @icdId=icd_worker_id  from univer_icd_workers where personal_id=@personalId;	     	      
	   if(isnull(@icdId,0)<=0) begin
	   insert into univer_icd_workers(personal_id,status) values (@personalId,1);
	   set @icdId=@@identity;	   end; else begin
	   update univer_icd_workers set status=1 where icd_worker_id=@icdId;
	   end;
	   end;	
	 
	 
	 --ACCOUNTING_DEPART_STUD = 1099511627776;	univer_accounting_department		accounting_department_id	
	   if ((@roles & cast(1099511627776 as bigint))>0)
	   begin
	   declare @ad1Id int;
	   select @ad1Id=accounting_department_worker_id  from univer_accounting_department where personal_id=@personalId;	     	      
	   if(isnull(@ad1Id,0)<=0) begin
	   insert into univer_accounting_department(personal_id,status,accounting_department_id) values (@personalId,1,2);
	   set @ad1Id=@@identity;	   end; else begin
	   update univer_accounting_department set status=1,accounting_department_id=2 where accounting_department_worker_id=@ad1Id;
	   end;
	   end;	
	 
	 --ACCOUNTING_DEPART_ABROAD = 2199023255552;univer_accounting_department		accounting_department_id
	    if ((@roles & cast(2199023255552 as bigint))>0)
	   begin
	   declare @ad1Id2 int;
	   select @ad1Id2=accounting_department_worker_id  from univer_accounting_department where personal_id=@personalId;	     	      
	   if(isnull(@ad1Id2,0)<=0) begin
	   insert into univer_accounting_department(personal_id,status,accounting_department_id) values (@personalId,1,3);
	   set @ad1Id2=@@identity;	   end; else begin
	   update univer_accounting_department set status=1,accounting_department_id=3 where accounting_department_worker_id=@ad1Id2;
	   end;
	   end;	
	 --ACCOUNTING_DEPART = 1048576;				univer_accounting_department		accounting_department_id
	    if ((@roles & cast(1048576 as bigint))>0)
	   begin
	   declare @ad1Id3 int;
	   select @ad1Id3=accounting_department_worker_id  from univer_accounting_department where personal_id=@personalId;	     	      
	   if(isnull(@ad1Id3,0)<=0) begin
	   insert into univer_accounting_department(personal_id,status,accounting_department_id) values (@personalId,1,1);
	   set @ad1Id3=@@identity;	   end; else begin
	   update univer_accounting_department set status=1,accounting_department_id=1 where accounting_department_worker_id=@ad1Id3;
	   end;
	   end;	
	 --ADMITING_COMMISSION = 8192;				univer_admitting_commission			date_start, date_end
	     if ((@roles & cast(8192 as bigint))>0)
	   begin
	   declare @adcom int;
	   select @adcom=admit_com_id  from univer_admitting_commission where personal_id=@personalId;	     	      
	   if(isnull(@adcom,0)<=0) begin
	   insert into univer_admitting_commission(personal_id,status,admit_com_date_begin) values (@personalId,1,getdate());
	   set @adcom=@@identity;	   end; else begin
	   update univer_admitting_commission set status=1, admit_com_date_begin=case when status<>1 then getdate() else admit_com_date_begin end where admit_com_id=@adcom;
	   end;
	   end;	
	 --SCHEDULER = 268435456;					univer_scheduler					faculty_id
	  if ((@roles & cast(268435456 as bigint))>0)
	   begin
	   declare @schId int;
	   select @schId=scheduler_id from univer_scheduler where personal_id=@personalId;
	   if(isnull(@schId,0)<=0) begin
	   insert into univer_scheduler(personal_id,faculty_id,status) values (@personalId,24,1);
	   set @schId=@@identity;	   end; else begin
	   update univer_scheduler set status=1 where scheduler_id=@schId;
	   end;	  
	   end;
	 ------пока невозможно!
	 --METHOD_BYURO = 68719476736;				univer_method_byuro					faculty_id	 
	 --DL_EW = 17179869184;						univer_dl_ewer						dl_ewer_type	 
	 --COMMANDANT = 4398046511104;				univer_commandant					dormitory_id
    
    end 
    end
END
go

