-- =============================================
-- Author:		sasha
-- Create date: 2014-07-11 
-- Description:	Расчет ECTS-кредитов для прогресса
-- =============================================
CREATE TRIGGER [dbo].[progressECTSupd]
   ON  [dbo].[univer_progress]
   After UPDATE,INSERT 
AS 
BEGIN	
	--IF @@ROWCOUNT =0
    --RETURN	
	SET NOCOUNT ON;
	
	IF EXISTS(SELECT * FROM inserted) and (UPDATE(progress_credit) or UPDATE(controll_type_id) or UPDATE(academ_year) or UPDATE(subject_type) or UPDATE(subject_id) or UPDATE(educ_plan_pos_addit))
	BEGIN
	declare @admYear int;
	
	UPDATE p
    SET p.progress_credit_ects = dbo.getECTSForProgress(p.progress_id)
    FROM [dbo].[univer_progress] p
    where p.progress_id in (select progress_id from inserted)
    and p.progress_credit_ects<>dbo.getECTSForProgress(p.progress_id)
		
		
	END	
END
go

