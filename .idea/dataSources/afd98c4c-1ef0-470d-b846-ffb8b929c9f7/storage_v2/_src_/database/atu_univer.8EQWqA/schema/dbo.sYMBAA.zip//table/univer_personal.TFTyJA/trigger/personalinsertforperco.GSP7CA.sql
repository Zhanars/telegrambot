-- =============================================
-- Author:		Yerlan
-- Create date: 23.09.2016
-- Description:	for perco
-- =============================================
create TRIGGER [dbo].[personalInsertForPerco]
   ON  [dbo].[univer_personal]
   AFTER insert
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
    delete from perco_univer_personal where personal_id in (select i.personal_id from inserted i);
    insert into perco_univer_personal(personal_id, operation)
    select i.personal_id, 1 from inserted i
    
END
go

