-- =============================================
-- Author:		Yerlan
-- Create date: 27.06.2016
-- Description:	Функция определния итоговой процентной оценки
-- =============================================
CREATE FUNCTION [dbo].[getProgressMark]
(
	 @controllTypeId int,
	 @resRk1 int,
	 @resRk2 int,
	 @resMt int,
	 @res int
)
RETURNS int
AS
BEGIN
    --declare @wrong int;
    --set @wrong=(select count(*) from univer_controll_type_control_link ccl, univer_control c where c.control_id=ccl.control_id and controll_type_id=@controllTypeId and control_min_ball>@resRk1 and  c.control_title='_rk1')+(select count(*) from univer_controll_type_control_link ccl, univer_control c where c.control_id=ccl.control_id and controll_type_id=@controllTypeId and control_min_ball>@resRk2 and  c.control_title='_rk2')+(select count(*) from univer_controll_type_control_link ccl, univer_control c where c.control_id=ccl.control_id and controll_type_id=@controllTypeId and control_min_ball>@res and  c.control_title='');
    
    declare @rkP1 real, @rkP2 real, @mt real, @resP real;
    set @rkP1 = ISNULL((SELECT TOP 1 control_portion FROM univer_controll_type_control_link ccl, univer_control c 
			WHERE ccl.controll_type_id=@controllTypeId AND c.control_title='_rk1' and c.control_id=ccl.control_id),1);
    set @rkP2 = ISNULL((SELECT TOP 1 control_portion FROM univer_controll_type_control_link ccl, univer_control c 
			WHERE ccl.controll_type_id=@controllTypeId AND c.control_title='_rk2' and c.control_id=ccl.control_id),1);
    set @mt = ISNULL((SELECT TOP 1 control_portion FROM univer_controll_type_control_link ccl, univer_control c 
			WHERE ccl.controll_type_id=@controllTypeId AND c.control_title='_mt' and c.control_id=ccl.control_id),1);
    set @resP = ISNULL((SELECT TOP 1 control_portion FROM univer_controll_type_control_link ccl, univer_control c 
			WHERE ccl.controll_type_id=@controllTypeId AND c.control_title='' and c.control_id=ccl.control_id),1);
    IF (@rkP1=0)
    begin set @rkP1 = 1; end
    IF (@rkP2=0)
    begin set @rkP2 = 1; end
    IF (@mt=0)
    begin set @mt = 1; end
    IF (@resP=0)
    begin set @resP = 1; end
	declare @finalRez int; set @finalRez=ROUND((@resRk1*@rkP1+@resRk2*@rkP2+@resMt*@mt+@res*@resP),0);
	RETURN @finalRez
END
go

