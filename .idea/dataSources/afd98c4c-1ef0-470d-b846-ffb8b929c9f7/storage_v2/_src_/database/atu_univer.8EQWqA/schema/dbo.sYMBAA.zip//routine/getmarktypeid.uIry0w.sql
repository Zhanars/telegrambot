-- =============================================
-- Author:		Sasha
-- Create date: 07.05.2012
-- Update date: 06.09.2013 /*Yerlan*/
-- Description:	Функция определния буквенной оценки (mark_type_id)
-- =============================================
CREATE FUNCTION [dbo].[getMarkTypeId]
(
	 @controllTypeId int,
	 @resRk1 int,
	 @resRk2 int,
	 @res int
)
RETURNS int
AS
BEGIN
    declare @wrong int;
    set @wrong=(select count(*) from univer_controll_type_control_link ccl, univer_control c where c.control_id=ccl.control_id and controll_type_id=@controllTypeId and control_min_ball>@resRk1 and  c.control_title='_rk1')+(select count(*) from univer_controll_type_control_link ccl, univer_control c where c.control_id=ccl.control_id and controll_type_id=@controllTypeId and control_min_ball>@resRk2 and  c.control_title='_rk2')+(select count(*) from univer_controll_type_control_link ccl, univer_control c where c.control_id=ccl.control_id and controll_type_id=@controllTypeId and control_min_ball>@res and  c.control_title='');
    declare @rkP1 real, @rkP2 real, @resP real;
    set @rkP1 = ISNULL((SELECT TOP 1 control_portion FROM univer_controll_type_control_link ccl, univer_control c 
			WHERE ccl.controll_type_id=@controllTypeId AND c.control_title='_rk1' and c.control_id=ccl.control_id),1);
    set @rkP2 = ISNULL((SELECT TOP 1 control_portion FROM univer_controll_type_control_link ccl, univer_control c 
			WHERE ccl.controll_type_id=@controllTypeId AND c.control_title='_rk2' and c.control_id=ccl.control_id),1);
    set @resP = ISNULL((SELECT TOP 1 control_portion FROM univer_controll_type_control_link ccl, univer_control c 
			WHERE ccl.controll_type_id=@controllTypeId AND c.control_title='' and c.control_id=ccl.control_id),1);
    IF (@rkP1=0)
    begin set @rkP1 = 1; end
    IF (@rkP2=0)
    begin set @rkP2 = 1; end
    IF (@resP=0)
    begin set @resP = 1; end
	declare @mt int;
	declare @r int; set @r=case when @wrong<=0 then ISNULL(ROUND((@resRk1*@rkP1+@resRk2*@rkP2+@res*@resP),0), 0) else 0 end;
	set @mt=(select top 1 mt.mark_type_id from univer_controll_type ct,univer_controll_type_mark_type_link mtl, univer_mark_type mt 
	where ct.controll_type_id=mtl.controll_type_id and mt.mark_type_id=mtl.mark_type_id 
	and mt.mark_type_minval<=@r and mt.mark_type_maxval>=@r and ct.controll_type_id=@controllTypeId)
	
	RETURN @mt
END
go

