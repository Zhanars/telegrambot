
-- =============================================
-- Author:		sasha
-- Create date: 26.10.2016
-- Description:	Получение всех структурных подразделений верхнего уровня
-- =============================================
CREATE FUNCTION [dbo].[getStructPosParents] 
(
    @structPosId int,
    @lang nvarchar(2)
)
RETURNS 
@retTbl table(structure_division_id int, structure_division_name nvarchar(500))

AS
BEGIN
	declare @ids nvarchar(max);
    declare @parentId int;      
    set @ids='';
    set @parentId=@structPosId;
    while (@parentId>0)
    begin 
    set @ids=@ids+'{'+cast(@parentId as nvarchar)+'}';
    select @parentId=structure_division_ext from univer_structure_division_1c where structure_division_id=@parentId and status=1
    end
	insert into @retTbl(structure_division_id,structure_division_name)
	select structure_division_id,
	case @lang
    when N'kz' then structure_division_name_kz
    when N'ru' then structure_division_name_ru
    when N'en' then structure_division_name_en end as structure_division_name from univer_structure_division_1c where @ids like '%{'+cast(structure_division_id as nvarchar)+'}%' and status=1
    order by structure_division_name
	RETURN 
END

go

