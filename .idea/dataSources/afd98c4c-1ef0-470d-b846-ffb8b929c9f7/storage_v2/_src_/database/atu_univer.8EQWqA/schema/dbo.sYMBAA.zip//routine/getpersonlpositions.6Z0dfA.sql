-- =============================================
-- Author:		d.aitmukash
-- Create date: 16.04.2018
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[GetPersonlPositions]
(
	-- Add the parameters for the function here
	@personalId int
)
RETURNS nvarchar(max)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @pos nvarchar(max) =N'';
	--declare @personalId int=13;
	--select @pos = @pos + (select top 1 upp.personal_position_name_ru from univer_personal_position_1c upp where upp.personal_position_id=ups.personal_position_id) + N', '
	--from univer_personal_struct_pos_link_1c ups, univer_personal p where  ups.personal_id=p.personal_id and  ups.personal_id=@personalId and ups.status=1

	select @pos =@pos +  upp.personal_position_name_ru + N', ' from  univer_personal_position_1c upp 
	where upp.personal_position_id in(select distinct ups.personal_position_id from univer_personal_struct_pos_link_1c ups where ups.personal_id=@personalId and ups.status=1)
 
	-- Return the result of the function
	RETURN case when LEN(@pos)>0 then substring(@pos, 1,  LEN(@pos)-1) else @pos end;

END
go

