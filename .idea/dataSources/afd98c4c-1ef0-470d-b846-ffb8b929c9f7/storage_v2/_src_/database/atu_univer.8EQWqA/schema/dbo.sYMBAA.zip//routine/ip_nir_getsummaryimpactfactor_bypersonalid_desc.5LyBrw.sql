-- =============================================
-- Author:		Twice
-- Create date: 31.01.2012
-- Description: Получить суммарный импакт-фактор публикаций (ISI Web of Knowledge, Thomson Reuters) - в разрезе сотрудника
-- =============================================
CREATE FUNCTION [dbo].[IP_NIR_getSummaryImpactFactor_ByPersonalId_DESC]
(
	@personalId int,
	@year int
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @Result NVARCHAR(MAX)

DECLARE @summary FLOAT 
SELECT @summary = ISNULL(ROUND(SUM(sip.factorValue), 5), 0)
	FROM 
		DBScience.dbo.Papers p,
		DBScience.dbo.L_Person_Paper_Authors a,
		DBScience.dbo.SciJournals sj,
		DBScience.dbo.L_SciJournal_IFRatingAgencies sip
	WHERE
	p.status != 2 AND
	-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
	sj.sciJournal_id = p.periodicEdition_id AND
	p.periodicEditionType_id = 1 AND
	-- импакт факторы, принадлежащие этой статье должны относитсья к Томсон Ройтерс (id = 1)
	sip.sciJournal_id = sj.sciJournal_id AND
	sip.IFRatingAgency_id = 1 AND
	-- статья этого года
	p.yearPublication in (@year, @year+1)  AND
	-- статья этого автора (ППС, потому personType = 1)
	p.paper_id = a.paper_id AND
	a.personType = 1 AND 
	a.person_id = @personalId

IF (@summary > 0)
	BEGIN 
	SELECT @Result = COALESCE(@Result + ';\n\n', '') + 
		ISNULL(N'Статья\nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en +
		N'\nЖурнал:' + sj.name + N'\nIF(Thomson-Reuters):' + CONVERT(NVARCHAR, sip.factorValue), '')
		--AS [description]
	FROM 
		DBScience.dbo.Papers p,
		DBScience.dbo.L_Person_Paper_Authors a,
		DBScience.dbo.SciJournals sj,
		DBScience.dbo.L_SciJournal_IFRatingAgencies sip
	WHERE
	p.status != 2 AND
	-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
	sj.sciJournal_id = p.periodicEdition_id AND
	p.periodicEditionType_id = 1 AND
	-- импакт факторы, принадлежащие этой статье должны относитсья к Томсон Ройтерс (id = 1)
	sip.sciJournal_id = sj.sciJournal_id AND
	sip.IFRatingAgency_id = 1 AND
	-- статья этого года
	p.yearPublication in (@year, @year+1)  AND
	-- статья этого автора (ППС, потому personType = 1)
	p.paper_id = a.paper_id AND
	a.personType = 1 AND 
	a.person_id = @personalId
END
ELSE
BEGIN
	SELECT @Result = N''
END
RETURN @Result

END
go

