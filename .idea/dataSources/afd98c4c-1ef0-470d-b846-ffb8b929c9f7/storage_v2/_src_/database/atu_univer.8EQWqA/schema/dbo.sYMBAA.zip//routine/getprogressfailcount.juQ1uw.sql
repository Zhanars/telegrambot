-- =============================================
-- Author:		Sasha
-- Create date: 10.10.17
-- Description:	Количество задолженностей у студента
-- =============================================
CREATE FUNCTION [dbo].[getProgressFailCount]
(
	@studentId int
)
RETURNS int
AS
BEGIN
	declare @t_pr table (progress_id bigint)
--ищем записи, по которым есть незакрытые ведомости
	insert into @t_pr(progress_id)
	select distinct p.progress_id from univer_progress p inner join univer_controll_type_control_link ccl on ccl.controll_type_id=p.controll_type_id inner join univer_controll_type ct on ct.controll_type_id=p.controll_type_id inner join univer_control c on c.control_id=ccl.control_id left join univer_sheet_result sr on p.subject_id=sr.subject_id AND p.n_seme=sr.n_seme AND p.academ_year=sr.academ_year AND p.semestr=sr.semestr  and sr.student_id=p.student_id and ccl.control_id=sr.control where p.student_id=@studentId and p.status=1 and sr.date_keep is null /*добавила это условие, чтобы включить тех студентов, кто недопущен к экзамену из-за ненабранного минимума по РК*/ and (p.progress_result_rk1+p.progress_result_rk2>=ct.controll_type_min_rk or c.control_title not in ('','_mt')) 
declare @ret int;
set @ret=0;
--выбираем все неудовлетворительные оценки студента без незакрытых ведомостей
select @ret=count( distinct progress_id) from univer_progress pr, univer_mark_type mt where pr.mark_type_id=mt.mark_type_id and mt.mark_type_arg in (2,6,7) and pr.status=1 and pr.student_id=@studentId and (progress_id not in (select t.progress_id from @t_pr t) or mt.mark_type_id=6)
return @ret;
END
go

