-- =============================================
-- Author:		@LFER
-- Create date: 2009-07-13 11:32:47.090
-- Description:	Триггер на изменение статуса сотрудника отдела сопровождения
-- =============================================
CREATE TRIGGER [dbo].[supportDepUpdateTrigger]
   ON  [dbo].[univer_support_department] 
   AFTER UPDATE
AS 
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @pi int
	DECLARE @st int
	
	DECLARE insCursor cursor 
		FOR SELECT personal_id, status FROM inserted
	
	IF UPDATE(status)
	BEGIN
		OPEN insCursor
		FETCH NEXT FROM insCursor INTO @pi, @st
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF(@st=1)
				EXEC dbo.personalSetAccess @pi, 'SUPPORT_DEPART'
			ELSE
				EXEC dbo.personalDeleteAccess @pi, 'SUPPORT_DEPART'
				
			FETCH NEXT FROM insCursor INTO @pi, @st
		END
		CLOSE insCursor
	END
END
go

