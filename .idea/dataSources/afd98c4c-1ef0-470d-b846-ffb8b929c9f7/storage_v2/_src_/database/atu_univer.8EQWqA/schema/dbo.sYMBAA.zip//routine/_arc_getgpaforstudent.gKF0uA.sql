-- =============================================
-- Author:		Yerlan
-- Create date: 21.05.2014
-- Description:	Подсчет GPA для студента (@maxSem-семестр, до которого нужно считать GPA, если 0, то считается за все семестры; @course-курс, за который считать GPA, если 0 - то считается общее GPA)
-- =============================================
CREATE FUNCTION [dbo].[_arc_getGPAForStudent]
(
 @studentId int,
 @maxSem int,
 @course int
)
RETURNS float
AS
BEGIN
	DECLARE @ret float

	SELECT @ret=sum(isnull(mt.mark_type_gpa,0)*pr.progress_credit)/case when SUM(pr.progress_credit)>0 then SUM(pr.progress_credit) else 1 end  from _arc_univer_progress pr left join univer_mark_type mt on mt.mark_type_id=pr.mark_type_id, _arc_univer_students st where st.students_id=pr.student_id and pr.status=1 and student_id=@studentId 
and ((@course>0 and pr.n_seme in (@course*2,@course*2-1) ) or @course=0) and ((@maxSem>0 and pr.n_seme<@maxSem) or @maxSem=0)
and pr.controll_type_id in (2,4,30,31,20,21,22,32,35,36,37,38,39, case when st.stage_id=3 or st.stage_id=11 then 12 else 0 end, case when st.stage_id=3 or st.stage_id=11 then 13 else 0 end, 10) and pr.controll_type_id>0

	RETURN isnull(@ret,0)

END
go

