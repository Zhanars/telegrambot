-- =============================================
-- Author:		@LFER
-- Create date: 2009-03-31 13:36:32.820
-- Description:	Удаление или добавлении права доступа при изменении статуса сотрудника
-- =============================================
CREATE TRIGGER [dbo].[studentRoleUpdate] ON  dbo.univer_students
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @userId int
	DECLARE @studentID int
	DECLARE @st int
	declare @stage int
	IF UPDATE(status)
	BEGIN
		DECLARE insCursor cursor 
			FOR SELECT user_id, status, students_id, stage_id FROM inserted
		
		OPEN insCursor
		FETCH NEXT FROM insCursor INTO @userId, @st, @studentID,@stage
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF(@st=10)
			BEGIN
				EXEC dbo.usersSetAccess @userId, 'ABITURIENT'
				EXEC dbo.usersDeleteAccess @userId, 'STUDENT'
			END
			ELSE IF(@st=11)
			BEGIN
				EXEC dbo.usersSetAccess @userId, 'ABITURIENT'
				EXEC dbo.usersDeleteAccess @userId, 'STUDENT'
			END			
			ELSE IF (@st=1)
			BEGIN
				EXEC dbo.usersDeleteAccess @userId, 'ABITURIENT'
				EXEC dbo.usersSetAccess @userId, 'STUDENT'
				if (@stage=2)
				EXEC dbo.usersSetAccess @userId, 'STUDENT_BAKALAVR'
				if (@stage=3)
				EXEC dbo.usersSetAccess @userId, 'STUDENT_MAGISTRANT'
				if (@stage=11)
				EXEC dbo.usersSetAccess @userId, 'STUDENT_PHD'
				if (@stage=5)		
				EXEC dbo.usersSetAccess @userId, 'STUDENT_PREUNIVER'
				
			END
			ELSE IF (@st = 2)
			BEGIN
				EXEC dbo.usersDeleteAccess @userId, 'ABITURIENT'
				EXEC dbo.usersDeleteAccess @userId, 'STUDENT'
				EXEC dbo.usersDeleteAccess @userId, 'STUDENT_BAKALAVR'				
				EXEC dbo.usersDeleteAccess @userId, 'STUDENT_MAGISTRANT'
				EXEC dbo.usersDeleteAccess @userId, 'STUDENT_PHD'				
				EXEC dbo.usersDeleteAccess @userId, 'STUDENT_PREUNIVER'
				UPDATE univer_users SET status1 = 2 WHERE user_id = @userId				
			END 
			ELSE
			BEGIN
				EXEC dbo.usersDeleteAccess @userId, 'ABITURIENT'
				EXEC dbo.usersDeleteAccess @userId, 'STUDENT'
			END
			
			
			FETCH NEXT FROM insCursor INTO @userId, @st, @studentID,@stage
		END
		CLOSE insCursor
		DEALLOCATE insCursor
	END

END
go

