-- =============================================
-- Author:		@LFER
-- Create date: 2009-11-30
-- Description:	Удаление соответствующего права у сотрудника при удалении строки
-- =============================================
CREATE TRIGGER [dbo].[parentDeleteTrigger]
   ON  [dbo].[univer_parent]
   FOR DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @userId int
	
	DECLARE insCursor cursor 
		FOR SELECT user_id FROM deleted
	
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @userId
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC dbo.usersDeleteAccess @userId, 'PARENTS'
		DELETE FROM univer_users WHERE user_id=@userId AND user_access=0
			
		FETCH NEXT FROM insCursor INTO @userId
	END
	CLOSE insCursor
END
go

