-- =============================================
-- Author:		Twice
-- Create date: 03.06.2012
-- Description:	Получить количество публикаций в материалах международных конференций РК , республиканских конференций
-- =============================================
CREATE FUNCTION [dbo].[IP_NIR_getThesisesInRK_Count_ByPersonalId]
(
	-- Add the parameters for the function here
	@personalId int,
	@year int
)
RETURNS int
AS
BEGIN
	DECLARE @Result int
	SELECT @Result =  COUNT(*)
	FROM
		DBScience.dbo.Thesises th,
		DBScience.dbo.L_Person_Thesis_Authors a,
		DBScience.dbo.SciEvents se
		INNER JOIN DBScience.dbo.Countries c ON se.country_id = c.country_id
	WHERE
		-- тезис не архивирован
		th.status != 2 AND
		-- тезис этого автора (ППС, потому personType = 1)
		th.thesis_id = a.thesis_id AND
		a.personType = 1 AND 
		a.person_id = @personalId AND
		-- тезис этого года (по мероприятию)
		th.sciEvent_id = se.sciEvent_id AND
		-- мероприятие международное, но в РК
		((se.sciEventForm_id = 5 AND se.country_id = c.country_id AND c.countryCurrent = 1) OR
		-- или мероприятие республиканское
		(se.sciEventForm_id = 3)) 
		AND
		-- тезис этого года
		YEAR(se.eventStart) in (@year, @year+1) 
	
	RETURN @Result

END
go

