CREATE VIEW dbo.esuvo_personal_position
AS
SELECT        p.personal_position_id AS id, CASE p.personal_position_is_teacher WHEN 1 THEN 1 ELSE 2 END AS roletype, p.personal_position_name_ru AS nameru, p.personal_position_name_kz AS namekz, 
                         p.personal_position_name_en AS nameen, NULL AS created, (CASE WHEN p.status = 1 THEN 1 ELSE 2 END) AS operation
FROM            dbo.univer_personal_position_1c AS p INNER JOIN
                         dbo.platonus_univer_tutor_positions AS pp ON p.personal_position_id = pp.position_id
go

