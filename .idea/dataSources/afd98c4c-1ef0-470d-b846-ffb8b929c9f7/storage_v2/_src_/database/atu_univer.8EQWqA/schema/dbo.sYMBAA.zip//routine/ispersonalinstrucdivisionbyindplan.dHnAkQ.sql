-- =============================================
-- Author:		Yerlan
-- Create date: 15.02.2013
-- Description:	Проверяет входит ли данный сотрудник в данное структурное подразделение согласно Инд. плану и Рейтингу. Сотрудник должен сидеть как штатный в данном стр. подразд. или же он должен быть совместителем, а как штатный числиться не в кафедрах (Директора департ. начальники и т.д.).
-- =============================================
CREATE FUNCTION [dbo].[IsPersonalInStrucDivisionByIndPlan]
(
	@personalId		int,
	@strucDivId		int,
	@status			int
)
RETURNS bit
AS
BEGIN
	DECLARE @ret BIT;
	--IF EXISTS(
	--	SELECT * FROM univer_personal_struct_pos_link_1c spl1 
	--	WHERE spl1.status=@status and spl1.structure_division_id=@strucDivId and spl1.personal_id = @personalId
	--		--либо должность из списка должностей или же штатный type_id=1
	--		AND (spl1.personal_position_id IN(6,123,124,348,349,350,351,352,359,360,361,446,447,448,449,506,515))
	--		AND (
	--			spl1.type_id in (1,2)
	--			OR 
	--			EXISTS(
	--				SELECT * FROM univer_personal_struct_pos_link_1c spl2 
	--				WHERE spl2.status=@status AND spl2.personal_id=spl1.personal_id 
	--				-- должность из списка должностей
	--				AND spl2.personal_position_id NOT IN(6,123,124,348,349,350,351,352,359,360,361,446,447,448,449,506,515) 
	--				-- не из этого подразделения
	--				--AND spl2.structure_division_id<>spl1.structure_division_id
	--			)
	--		)
	--)
	
	IF (@strucDivId = ISNULL((
		SELECT TOP 1 tab.structure_division_id 
		FROM (
			SELECT spl1.structure_division_id, spl1.personal_rate,sd.structure_division_name_ru
			, (SELECT COUNT(spl2.pers_struct_pos_link_id) FROM univer_personal_struct_pos_link_1c spl2 WHERE spl2.personal_id = @personalId 
				AND spl2.status=1 AND spl2.structure_division_id=spl1.structure_division_id) AS str_div_cnt
			FROM univer_personal_struct_pos_link_1c spl1, univer_structure_division_1c sd , univer_personal_position_1c pp
			WHERE spl1.personal_id = @personalId
				AND (pp.personal_position_is_teacher=1) and spl1.personal_position_id = pp.personal_position_id
				AND spl1.status=1 AND sd.structure_division_id=spl1.structure_division_id AND sd.status=1
			
		) AS tab
		ORDER BY personal_rate DESC,str_div_cnt DESC,structure_division_name_ru
		),0)
	)
	BEGIN
		SET @ret = 1;
	END	
	RETURN ISNULL(@ret,0);
END
go

