-- =============================================
-- Author:		YERLAN
-- Create date: 28,10,2011
-- Description:	Возвращает расписание с html тэгами по ИД сотрудника, год и семестр
-- =============================================
CREATE FUNCTION [dbo].[getPersonalScheduleForSite] 
(
 @personalId int,
 @year int,
 @semester int
 ,@langId int=1
)
RETURNS nvarchar(max)
AS
BEGIN
	set @langId = ISNULL(@langId,1);
	DECLARE @htmlData nvarchar(max);
	SET @htmlData = '';
	DECLARE @teacherId int;
	DECLARE @status int;
	SET @status = 1;
	

	SELECT @teacherId = teacher_id FROM univer_teacher WHERE personal_id=@personalId;
	if (@teacherId is null) 
	begin
	SET @teacherId = 0;
	end

	DECLARE @time_id int, @weekDay int;
	DECLARE @time_name varchar(50), @week_name varchar(50);

SET @htmlData = @htmlData +'<table id="schedule" cellpadding="0" cellspacing="0">';
if (@langId=2)
begin
	SET @htmlData = @htmlData +N'<tr><th>&nbsp;</th><th>Пн</th><th>Вт</th><th>Ср</th><th>Чт</th><th>Пт</th><th>Сб</th></tr>';
end;
else
begin
	SET @htmlData = @htmlData +N'<tr><th>&nbsp;</th><th>Дс</th><th>Сс</th><th>Ср</th><th>Бс</th><th>Жм</th><th>Сн</th></tr>';
end;
DECLARE time_cursor CURSOR FOR 
SELECT st.schedule_time_id FROM univer_schedule_time st
order by st.schedule_time_id

OPEN time_cursor;

FETCH NEXT FROM time_cursor INTO @time_id;
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @htmlData = @htmlData +'<tr class="'+ CONVERT(varchar,@time_id) +'">';

    --DECLARE day_cursor CURSOR FOR
    --SELECT wd.DayWeek FROM (select 1 as DayWeek union select 2 union select 3 union select 4 union select 5 union select 6) as wd order by wd.DayWeek
    
    --/////////display th with times
    SET @htmlData = @htmlData +'<th class="'+ CONVERT(varchar,@time_id)+'"  style="min-height:100px; min-width:100px;">';
		SELECT @time_name=LEFT(CONVERT(varchar(12),st.schedule_time_begin,108),5)+'-'+LEFT(CONVERT(varchar(12),st.schedule_time_end,108),5) FROM univer_schedule_time st WHERE st.schedule_time_id=@time_id;
	SET @htmlData = @htmlData +@time_name;
	SET @htmlData = @htmlData +'</th>';
	--//////////////////////////////
	
    --OPEN day_cursor
    --FETCH NEXT FROM day_cursor INTO @weekDay;
    SET @weekDay = 1; 
    --WHILE @@FETCH_STATUS = 0
    WHILE @weekDay <> 7
    BEGIN
		DECLARE @subject_name nvarchar(256), @build_name nvarchar(10), @langDivName nvarchar(20), @educTypeName nvarchar(6),@subjectTypeName nvarchar(10),@specName nvarchar(100),@audName nvarchar(20);
		DECLARE @studCount int, @schedule_id int;	
		
		SET @htmlData = @htmlData +'<td class="'+ CONVERT(varchar,@time_id)+'_'+CONVERT(varchar,@weekDay) +'" style="min-height:100px; min-width:100px;">';
		--/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		DECLARE data_cursor CURSOR FOR
		SELECT 
		--sch.schedule_denominator
		   isnull(case when @langId=2 then a.audience_number_ru else a.audience_number_kz end,N' - '),isnull(case when @langId=2 then bg.building_name_ru else bg.building_name_kz end,N' - ')
		   ,case when @langId=2 then ld.lang_division_name_ru else ld.lang_division_name_kz end
		   ,case when @langId=2 then et.educ_type_name_short_ru else et.educ_type_name_short_kz end
		   --,(select COUNT(*) from univer_group_student where group_id=g.group_id) AS student_count
		   , 0 as student_count
		   --,isnull(eppc.credit,0) as credit
		   ,case when @langId=2 then s.subject_name_ru else s.subject_name_kz end
		   --, (case when s.subject_type=0 then N'Обяз.' when s.subject_type=1 then N'Эл.' when s.subject_type=2 then N'Пр.' when s.subject_type=3 then N'Спец.' else N'' end) as subject_type_name
		   ,case when @langId=2 then sp.speciality_name_ru else sp.speciality_name_kz end
	FROM univer_schedule sch left join univer_audience a on sch.audience_id=a.audience_id LEFT join univer_building bg ON a.building_id=bg.building_id AND bg.status=@status
		, univer_group g inner join univer_educ_plan_pos epp
			on g.educ_plan_pos_id=epp.educ_plan_pos_id
			--left join univer_educ_plan_pos_credit eppc
			--on eppc.educ_plan_pos_id=epp.educ_plan_pos_id
			--and eppc.educ_type_id=g.educ_type_id
		,univer_teacher t
		,univer_personal p
		,univer_academ_calendar_pos ap
		,univer_subject s
		,univer_speciality sp
		,univer_educ_plan ep
		,univer_schedule_time st
		,univer_lang_division ld
		,univer_educ_type et

	WHERE sch.group_id=g.group_id and g.teacher_id=@teacherId
		  and g.group_year=@year
		  and g.group_semestr=@semester
		  and g.acpos_module=ap.acpos_module
		  AND g.educ_type_id in (select et.educ_type_id from univer_educ_type et where et.status=@status)  
		  
		  AND st.schedule_time_id=sch.schedule_time_id
		  AND ld.lang_division_id = g.lang_division_id AND ld.status=@status
		  AND et.educ_type_id=g.educ_type_id AND et.status=@status
		  AND sch.schedule_time_id=@time_id AND sch.schedule_week_day=@weekDay
		  
		  and t.teacher_id=g.teacher_id
		  and t.personal_id = p.personal_id
		  and t.status=@status and p.status=@status
		  
		  AND ap.educ_plan_id=epp.educ_plan_id
		  AND ap.acpos_semester=epp.educ_plan_pos_semestr
		  AND ap.control_id=49
		  and s.subject_id=epp.subject_id
		  and s.status = @status
		  and sp.status = @status
		  and sp.speciality_id = ep.speciality_id
		  and ep.status=@status and ep.educ_plan_id=epp.educ_plan_id 
		  and epp.status=@status
		  
		  OPEN data_cursor;
		  FETCH NEXT FROM data_cursor INTO @audName, @build_name,@langDivName,@educTypeName,@studCount,@subject_name,@specName;
		  
		  WHILE @@FETCH_STATUS =0
		  BEGIN 
		  --SET @htmlData = @htmlData + @specName+'('+ @langDivName +')'+'<br />'+ @subject_name+'('+ @educTypeName +')'+'<br />'+CONVERT(nvarchar,@audName)+'('+ CONVERT(nvarchar,@build_name) +')'+'<br />';--+N' Кол. студ:'+CONVERT(varchar,@studCount)+'<br />'
		  SET @htmlData = @htmlData + @subject_name+'('+ @educTypeName +')'+'<br />'+CONVERT(nvarchar,@audName)+'('+ CONVERT(nvarchar,@build_name) +')'+'<br />';	  
		  FETCH NEXT FROM data_cursor INTO @audName, @build_name,@langDivName,@educTypeName,@studCount,@subject_name,@specName;
		  END
		  CLOSE data_cursor;
		  DEALLOCATE data_cursor;
		--/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		SET @htmlData = @htmlData +'</td>';
		
    --FETCH NEXT FROM day_cursor INTO @weekDay;
    SET @weekDay = @weekDay+1;
    end;
    --CLOSE day_cursor;
    --DEALLOCATE day_cursor;
    SET @htmlData = @htmlData +'</tr>';
    FETCH NEXT FROM time_cursor INTO @time_id;
END
CLOSE time_cursor;
DEALLOCATE time_cursor;

SET @htmlData = @htmlData +'</table>';

	RETURN @htmlData;
END
go

