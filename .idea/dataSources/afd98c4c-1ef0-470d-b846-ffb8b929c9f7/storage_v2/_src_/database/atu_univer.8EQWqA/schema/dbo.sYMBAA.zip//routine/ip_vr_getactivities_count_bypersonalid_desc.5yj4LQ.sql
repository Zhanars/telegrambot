-- =============================================
-- Author:		Yerlan
-- Create date: 03.06.2012
-- Description: Получить количество мероприятий (0 - все мероприятия, 1 - на уровне кафедры И КУРАТОРА, 2- на уровне факультета) - в разрезе сотрудника
-- =============================================
CREATE FUNCTION [dbo].[IP_VR_getActivities_Count_ByPersonalId_DESC]
(
	@personalId int,
	@year int,
	@activityLevelId int
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @Result NVARCHAR(MAX)
-- ==================================== если все
IF (@activityLevelId = 0)
BEGIN
	IF (SELECT COUNT(*)
		FROM 
			univer_dl_ewer_activity ac
		WHERE
		-- только не архивированные мероприятия
		ac.status = 1 AND
		-- мероприятия за опред. год (причем академический год)
		YEAR(DATEADD(MONTH,-7, ac.dl_ewer_activity_begin))=@year AND
		-- ответственное лицо 
		(SELECT COUNT(*) FROM univer_dl_ewer_activity_responsers ar WHERE ar.personal_id=@personalId 
		AND ac.dl_ewer_activity_id = ar.dl_ewer_activity_id)>0
		)>0
	BEGIN
		SELECT @Result = COALESCE(@Result + ';\n\n', '') + 
			ISNULL(N'\nKZ: ' + ac.dl_ewer_activity_name_kz + N'\nRU: ' + ac.dl_ewer_activity_name_ru + N'\nEN: ' + ac.dl_ewer_activity_name_en
			, '')
			--AS [description]
		FROM 
			univer_dl_ewer_activity ac
		WHERE
		-- только не архивированные мероприятия
		ac.status = 1 AND
		-- мероприятия за опред. год (причем академический год)
		YEAR(DATEADD(MONTH,-7, ac.dl_ewer_activity_begin))=@year AND
		-- ответственное лицо 
		(SELECT COUNT(*) FROM univer_dl_ewer_activity_responsers ar WHERE ar.personal_id=@personalId 
		AND ac.dl_ewer_activity_id = ar.dl_ewer_activity_id)>0
	END
END
-- ==================================== если кафедра
IF (@activityLevelId = 1)
BEGIN
	IF (SELECT COUNT(*)
		FROM 
			univer_dl_ewer_activity ac
		WHERE
		-- кафедральный уровень имеет ИД 11
		ac.dl_ewer_activity_level IN (11,12) AND
		-- только не архивированные мероприятия
		ac.status = 1 AND
		-- мероприятия за опред. год (причем академический год)
		YEAR(DATEADD(MONTH,-7, ac.dl_ewer_activity_begin))=@year AND
		-- ответственное лицо 
		(SELECT COUNT(*) FROM univer_dl_ewer_activity_responsers ar WHERE ar.personal_id=@personalId 
		AND ac.dl_ewer_activity_id = ar.dl_ewer_activity_id)>0
		)>0
	BEGIN
		SELECT @Result = COALESCE(@Result + ';\n\n', '') + 
			ISNULL(N'\nKZ: ' + ac.dl_ewer_activity_name_kz + N'\nRU: ' + ac.dl_ewer_activity_name_ru + N'\nEN: ' + ac.dl_ewer_activity_name_en
			, '')
			--AS [description]
		FROM 
			univer_dl_ewer_activity ac
		WHERE
		-- кафедральный уровень имеет ИД 11
		ac.dl_ewer_activity_level IN (11,12) AND
		-- только не архивированные мероприятия
		ac.status = 1 AND
		-- мероприятия за опред. год (причем академический год)
		YEAR(DATEADD(MONTH,-7, ac.dl_ewer_activity_begin))=@year AND
		-- ответственное лицо 
		(SELECT COUNT(*) FROM univer_dl_ewer_activity_responsers ar WHERE ar.personal_id=@personalId 
		AND ac.dl_ewer_activity_id = ar.dl_ewer_activity_id)>0
	END
END
-- ==================================== если факультет
IF (@activityLevelId = 2)
BEGIN
	IF (SELECT COUNT(*)
		FROM 
			univer_dl_ewer_activity ac
		WHERE
		-- кафедральный уровень имеет ИД 10
		ac.dl_ewer_activity_level = 10 AND
		-- только не архивированные мероприятия
		ac.status = 1 AND
		-- мероприятия за опред. год (причем академический год)
		YEAR(DATEADD(MONTH,-7, ac.dl_ewer_activity_begin))=@year AND
		-- ответственное лицо 
		(SELECT COUNT(*) FROM univer_dl_ewer_activity_responsers ar WHERE ar.personal_id=@personalId 
		AND ac.dl_ewer_activity_id = ar.dl_ewer_activity_id)>0
		)>0
	BEGIN
		SELECT @Result = COALESCE(@Result + ';\n\n', '') + 
			ISNULL(N'\nKZ: ' + ac.dl_ewer_activity_name_kz + N'\nRU: ' + ac.dl_ewer_activity_name_ru + N'\nEN: ' + ac.dl_ewer_activity_name_en
			, '')
			--AS [description]
		FROM 
			univer_dl_ewer_activity ac
		WHERE
		-- кафедральный уровень имеет ИД 10
		ac.dl_ewer_activity_level = 10 AND
		-- только не архивированные мероприятия
		ac.status = 1 AND
		-- мероприятия за опред. год (причем академический год)
		YEAR(DATEADD(MONTH,-7, ac.dl_ewer_activity_begin))=@year AND
		-- ответственное лицо 
		(SELECT COUNT(*) FROM univer_dl_ewer_activity_responsers ar WHERE ar.personal_id=@personalId 
		AND ac.dl_ewer_activity_id = ar.dl_ewer_activity_id)>0
	END
END
-- Return the result of the function
RETURN @Result

END
go

