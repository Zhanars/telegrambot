CREATE VIEW dbo.site_personal_state_awards_1c
AS
SELECT     dbo.univer_personal.personal_id, dbo.univer_personal_state_awards_1c.state_awards_id, dbo.univer_state_awards_1c.state_awards_name_kz, 
                      dbo.univer_state_awards_1c.state_awards_name_ru, dbo.univer_state_awards_1c.state_awards_name_en, 
                      CASE WHEN dbo.univer_personal_state_awards_1c.personal_state_awards_date < '3086-10-21 00:00:00.000' THEN NULL ELSE DATEADD(YYYY, - 2000, 
                      dbo.univer_personal_state_awards_1c.personal_state_awards_date) END AS personal_state_awards_date
FROM         dbo.univer_personal_state_awards_1c INNER JOIN
                      dbo.univer_state_awards_1c ON dbo.univer_personal_state_awards_1c.state_awards_id = dbo.univer_state_awards_1c.state_awards_id INNER JOIN
                      dbo.univer_personal ON dbo.univer_personal_state_awards_1c.personal_id = dbo.univer_personal.personal_id
go

