
CREATE VIEW [dbo].[site_univer_faculty]
AS
SELECT     faculty_id, faculty_name_ru, faculty_name_kz, faculty_name_en, structure_division_id
FROM         dbo.univer_faculty where status=1

go

