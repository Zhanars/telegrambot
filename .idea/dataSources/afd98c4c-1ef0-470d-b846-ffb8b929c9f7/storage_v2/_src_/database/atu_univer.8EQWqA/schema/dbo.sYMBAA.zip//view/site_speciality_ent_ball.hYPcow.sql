CREATE VIEW dbo.site_speciality_ent_ball
AS
SELECT     TOP (100) PERCENT o.order_year, st.lang_division_id, st.speciality_id, sp.faculty_id, sp.speciality_name_ru, sp.speciality_name_kz, sp.speciality_name_en, sp.speciality_okpd, 
                      MIN(c.certificate_total_mark) AS min_mark, MAX(c.certificate_total_mark) AS max_mark
FROM         dbo.univer_certificates AS c INNER JOIN
                      dbo.univer_students AS st INNER JOIN
                      dbo.univer_order AS o INNER JOIN
                      dbo.univer_order_student_link AS osl ON o.order_id = osl.order_id ON st.students_id = osl.student_id ON c.students_id = st.students_id INNER JOIN
                      dbo.univer_speciality AS sp ON st.speciality_id = sp.speciality_id
WHERE     (o.order_type_id = 1) AND (o.status IN (21, 22)) AND (st.stage_id = 2) AND (o.order_year >= 2011) AND (st.educ_plan_adm_year >= 2011) AND (o.payment_form_id = 5) AND (c.certificate_type_id = 1) 
                      AND (c.certificate_total_mark >= 70) AND (c.certificate_total_mark <= 100)
GROUP BY o.order_year, st.lang_division_id, st.speciality_id, sp.faculty_id, sp.speciality_name_ru, sp.speciality_name_kz, sp.speciality_name_en, sp.speciality_okpd
ORDER BY o.order_year, sp.faculty_id, st.speciality_id, st.lang_division_id
go

