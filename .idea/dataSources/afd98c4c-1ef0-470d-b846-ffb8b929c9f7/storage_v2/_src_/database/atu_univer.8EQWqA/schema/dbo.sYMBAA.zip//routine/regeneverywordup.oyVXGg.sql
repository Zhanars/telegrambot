-- =============================================
-- Author:		Sasha	
-- Create date: 14.06.2016
-- Description:	переделываем регистр в англ. Каждое слово с большой буквы
-- =============================================
CREATE FUNCTION [dbo].[regEnEveryWordUp]
(
	-- Add the parameters for the function here
	@str nvarchar(MAX)
)
RETURNS nvarchar(MAX)
AS
BEGIN
declare @tmp nvarchar(max) = @str;

set @tmp=replace(@tmp,N'  ',N' ');
set @tmp=replace(@tmp,N'  ',N' ');
set @tmp=replace(@tmp,N'  ',N' ');
set @tmp=Rtrim(Ltrim(@tmp));


select @tmp = case when substring(@tmp, number - 1, 1) = ' '
              then stuff( @tmp, number, 1, upper ( substring( @tmp, number, 1) ) )
              else @tmp end 
  from master..spt_values 
  where type = 'P' 
    and number between 1 and len(@tmp)
set @tmp=replace(@tmp,N' Of ',N' of ');
set @tmp=replace(@tmp,N' For ',N' for ');
set @tmp=replace(@tmp,N' An ',N' an ');
set @tmp=replace(@tmp,N' A ',N' a ');
set @tmp=replace(@tmp,N' On ',N' on ');
set @tmp=replace(@tmp,N' In ',N' in ');
set @tmp=replace(@tmp,N' The ',N' the ');
set @tmp=replace(@tmp,N' And ',N' and ');
set @tmp=replace(@tmp,N' Al-',N' al-');

return @tmp

END
go

