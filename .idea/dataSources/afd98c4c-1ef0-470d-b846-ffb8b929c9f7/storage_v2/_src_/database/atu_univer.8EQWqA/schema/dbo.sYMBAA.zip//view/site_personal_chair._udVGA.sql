
CREATE VIEW [dbo].[site_personal_chair]
AS
SELECT     dbo.univer_personal.personal_id, dbo.univer_personal.personal_sname, dbo.univer_personal.personal_name, dbo.univer_personal.personal_father_name, 
                      dbo.univer_teacher_chair_link.chair_id, dbo.univer_chair.chair_name_kz, dbo.univer_chair.chair_name_ru, dbo.univer_chair.chair_name_en, 
                      dbo.univer_chair.status AS chair_status
FROM         dbo.univer_chair INNER JOIN
                      dbo.univer_teacher_chair_link ON dbo.univer_chair.chair_id = dbo.univer_teacher_chair_link.chair_id INNER JOIN
                      dbo.univer_teacher ON dbo.univer_teacher_chair_link.teacher_id = dbo.univer_teacher.teacher_id AND dbo.univer_teacher.status = 1 INNER JOIN
                      dbo.univer_personal ON dbo.univer_teacher.personal_id = dbo.univer_personal.personal_id

go

