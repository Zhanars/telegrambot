-- =============================================
-- Author:		sasha
-- Create date: 19.09.2011
-- Description:	обновление ролей сотрудника при изменении статуса
-- =============================================
CREATE PROCEDURE [dbo].[personalStatusAfterUpdate] 
	-- Add the parameters for the stored procedure here
	@personalId int
AS
BEGIN
	SET NOCOUNT ON;
	IF EXISTS(SELECT * FROM univer_advicer WHERE personal_id = @personalId AND status=1)
	BEGIN
		UPDATE univer_advicer SET status=status WHERE personal_id = @personalId AND status=1
	END
			
	IF EXISTS(SELECT * FROM univer_teacher WHERE personal_id = @personalId AND status=1)
	BEGIN
		UPDATE univer_teacher SET status=status WHERE personal_id = @personalId AND status=1
	END
	
	IF EXISTS(SELECT * FROM univer_rating_personal_admin WHERE personal_id = @personalId AND status=1)
	BEGIN
		UPDATE univer_rating_personal_admin SET status=status WHERE personal_id = @personalId AND status=1
	END
			
	IF EXISTS(SELECT * FROM univer_head_chair WHERE personal_id = @personalId AND status=1)
	BEGIN
		UPDATE univer_head_chair SET status=status WHERE personal_id = @personalId AND status=1
	END		
			
	IF EXISTS(SELECT * FROM univer_method_department WHERE personal_id = @personalId AND status=1)
	BEGIN
		UPDATE univer_method_department SET status=status WHERE personal_id = @personalId AND status=1
	END
			
	IF EXISTS(SELECT * FROM univer_personnel_depart WHERE personal_id = @personalId AND status=1)
	BEGIN
		UPDATE univer_personnel_depart SET status=status WHERE personal_id = @personalId AND status=1
	END
			
	IF EXISTS(SELECT * FROM univer_vice_dekan WHERE personal_id = @personalId AND status=1)
	BEGIN
		UPDATE univer_vice_dekan SET status=status WHERE personal_id = @personalId AND status=1
	END
			
	IF EXISTS(SELECT * FROM univer_vice_head_chair WHERE personal_id = @personalId AND status=1)
	BEGIN
		UPDATE univer_vice_head_chair SET status=status WHERE personal_id = @personalId AND status=1
	END
			
	IF EXISTS(SELECT * FROM univer_dekan WHERE personal_id = @personalId AND status=1)
	BEGIN
		UPDATE univer_dekan SET status=status WHERE personal_id = @personalId AND status=1
	END				
	
	IF EXISTS(SELECT * FROM univer_leader_other WHERE personal_id = @personalId AND status=1)
	BEGIN
		UPDATE univer_leader_other SET status=status WHERE personal_id = @personalId AND status=1
	END		
			
	IF EXISTS(SELECT * FROM univer_office_registrator WHERE personal_id = @personalId AND status=1)
	BEGIN
		UPDATE univer_office_registrator SET status=status WHERE personal_id = @personalId AND status=1
	END		
			
	IF EXISTS(SELECT * FROM univer_scheduler WHERE personal_id = @personalId AND status=1)
	BEGIN
		UPDATE univer_scheduler SET status=status WHERE personal_id = @personalId AND status=1
	END		
			
	IF EXISTS(SELECT * FROM univer_dl_ewer WHERE personal_id = @personalId AND status=1)
	BEGIN
		UPDATE univer_dl_ewer SET status=status WHERE personal_id = @personalId AND status=1
	END		
			
	IF EXISTS(SELECT * FROM univer_support_department WHERE personal_id = @personalId AND status=1)
	BEGIN
		UPDATE univer_support_department SET status=status WHERE personal_id = @personalId AND status=1
	END
			
	IF EXISTS(SELECT * FROM univer_student_department WHERE personal_id = @personalId AND status=1)
	BEGIN
		UPDATE univer_student_department SET status=status WHERE personal_id = @personalId AND status=1
	END	
			
	IF EXISTS(SELECT * FROM univer_admitting_commission WHERE personal_id = @personalId AND status=1)
	BEGIN
		UPDATE univer_admitting_commission SET status=status WHERE personal_id = @personalId AND status=1
	END
	
	IF EXISTS(SELECT * FROM univer_ind_plan_admin WHERE personal_id = @personalId AND status=1)
	BEGIN
		UPDATE univer_ind_plan_admin SET status=status WHERE personal_id = @personalId AND status=1
	END
	
	IF EXISTS(SELECT * FROM univer_prorector WHERE personal_id = @personalId AND status=1)
	BEGIN
		UPDATE univer_prorector SET status=status WHERE personal_id = @personalId AND status=1
	END
	
	IF EXISTS(SELECT * FROM univer_method_byuro WHERE personal_id = @personalId AND status=1)
	BEGIN
		UPDATE univer_method_byuro SET status=status WHERE personal_id = @personalId AND status=1
	END
	
	IF EXISTS(SELECT * FROM univer_educ_department WHERE personal_id = @personalId AND status=1)
	BEGIN
		UPDATE univer_educ_department SET status=status WHERE personal_id = @personalId AND status=1
	END
	
	IF EXISTS(SELECT * FROM univer_postgraduate_department WHERE personal_id = @personalId AND status=1)
	BEGIN
		UPDATE univer_postgraduate_department SET status=status WHERE personal_id = @personalId AND status=1
	END
	
	IF EXISTS(SELECT * FROM univer_rector WHERE personal_id = @personalId AND status=1)
	BEGIN
		UPDATE univer_rector SET status=status WHERE personal_id = @personalId AND status=1
	END
	
	IF EXISTS(SELECT * FROM univer_distance_learn_admin WHERE personal_id = @personalId AND status=1)
	BEGIN
		UPDATE univer_distance_learn_admin SET status=status WHERE personal_id = @personalId AND status=1
	END
	
	IF EXISTS(SELECT * FROM univer_accounting_department WHERE personal_id = @personalId AND status=1)
	BEGIN
		UPDATE univer_accounting_department SET status=status WHERE personal_id = @personalId AND status=1
	END
END
go

