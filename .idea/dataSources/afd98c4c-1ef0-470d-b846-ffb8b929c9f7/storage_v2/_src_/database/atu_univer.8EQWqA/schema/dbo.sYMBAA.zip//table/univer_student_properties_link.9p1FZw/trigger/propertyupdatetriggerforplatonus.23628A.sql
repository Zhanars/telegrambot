-- =============================================
-- Author:		Yerlan
-- Create date: 2013-10-27 17:44:33.680
-- Description:	Добавление записи о том что данные студента были изменены (триггер токо для UPDATE,так как при добавлении у студента статус еще не StatusNormal)
-- =============================================
CREATE TRIGGER [dbo].[propertyUpdateTriggerForPlatonus]
   ON  [dbo].[univer_student_properties_link]
   AFTER INSERT,DELETE
AS 
BEGIN
	
	IF @@ROWCOUNT =0
    RETURN
	
	SET NOCOUNT ON;
	
	IF EXISTS(SELECT * FROM deleted d)
	BEGIN
		DELETE FROM platonus_univer_student_property_link WHERE student_id IN (SELECT students_id FROM deleted);
		
		--IF EXISTS(SELECT * FROM deleted i
		--INNER JOIN univer_students s ON i.students_id=s.students_id AND s.status=1 
		--INNER JOIN univer_students_properties sp ON sp.status=1 AND sp.properties_id=i.properties_id AND sp.properties_type=1
		--WHERE NOT EXISTS(SELECT * FROM platonus_univer_students a WHERE a.student_id=i.students_id))
		--BEGIN
		--	INSERT INTO platonus_univer_students(student_id,command) 
		--	SELECT DISTINCT i.students_id,'update' FROM deleted i
		--		INNER JOIN univer_students s ON i.students_id=s.students_id AND s.status=1 
		--		INNER JOIN univer_students_properties sp ON sp.status=1 AND sp.properties_id=i.properties_id AND sp.properties_type=1
		--	WHERE NOT EXISTS(SELECT * FROM platonus_univer_students a WHERE a.student_id=i.students_id)
		--END
	END
	
	IF EXISTS(SELECT * FROM inserted i 
		INNER JOIN univer_students s ON i.students_id=s.students_id AND s.status=1 
		INNER JOIN univer_students_properties sp ON sp.status=1 AND sp.properties_id=i.properties_id AND sp.properties_type IN (1,2,3)
	WHERE NOT EXISTS(SELECT * FROM platonus_univer_student_property_link a WHERE a.student_id=i.students_id AND a.property_id=i.properties_id))
	BEGIN
		INSERT INTO platonus_univer_student_property_link(student_id,property_id)
		SELECT DISTINCT i.students_id, i.properties_id FROM inserted i 
			INNER JOIN univer_students s ON i.students_id=s.students_id AND s.status=1 
			INNER JOIN univer_students_properties sp ON sp.status=1 AND sp.properties_id=i.properties_id AND sp.properties_type IN (1,2,3)
		WHERE NOT EXISTS(SELECT * FROM platonus_univer_student_property_link a WHERE a.student_id=i.students_id AND a.property_id=i.properties_id)
	END
	
	--IF EXISTS(SELECT * FROM inserted i
	--	INNER JOIN univer_students s ON i.students_id=s.students_id AND s.status=1 
	--	INNER JOIN univer_students_properties sp ON sp.status=1 AND sp.properties_id=i.properties_id AND sp.properties_type=1
	--	WHERE NOT EXISTS(SELECT * FROM platonus_univer_students a WHERE a.student_id=i.students_id))
	--BEGIN
	--	INSERT INTO platonus_univer_students(student_id,command) 
	--	SELECT DISTINCT i.students_id,'update' FROM inserted i
	--		INNER JOIN univer_students s ON i.students_id=s.students_id AND s.status=1 
	--		INNER JOIN univer_students_properties sp ON sp.status=1 AND sp.properties_id=i.properties_id AND sp.properties_type=1
	--	WHERE NOT EXISTS(SELECT * FROM platonus_univer_students a WHERE a.student_id=i.students_id)
	--END
END
go

