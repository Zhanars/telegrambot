
-- =============================================
-- Author:		sasha
-- Create date: 2014-10-06 
-- Description: Генерация ведомостей для УП на семестр
-- =============================================
CREATE PROCEDURE [dbo].[generateSheet] @planId int, @semestr int, @sheetType int
AS
BEGIN
	
       begin distributed transaction
	   begin try
declare @needAccess bit;
select @needAccess=st.sheet_type_need_access from univer_sheet_type st where st.sheet_type_id=@sheetType; 
DECLARE gCursor cursor 
			FOR select distinct g.group_id,pp.educ_plan_pos_id, g.acpos_module,g.lang_division_id,pp.controll_type_id,pp.subject_id, 
			g.group_year,g.group_semestr,g.teacher_id 
			from univer_educ_plan_pos pp, univer_group g (nolock), univer_controll_type_control_link ccl 
			where g.educ_plan_pos_id=pp.educ_plan_pos_id and 
			pp.status=1 and pp.educ_plan_pos_semestr=@semestr and pp.educ_plan_id=@planId and ccl.controll_type_id=pp.controll_type_id and ccl.sheet_type_id=@sheetType and g.teacher_id>0 
		declare @num int; set @num=0;	
		declare @groupId int	
		declare @ppId int	
		declare @apm int
		declare @ldId int
		declare @ctId int
		declare @subId int
		declare @acY int
		declare @acS int
		declare @teacherId int
		
		OPEN gCursor
		FETCH NEXT FROM gCursor INTO @groupId,@ppId,@apm,@ldId,@ctId,@subId,@acY,@acS,@teacherId
		WHILE @@FETCH_STATUS = 0
		BEGIN
		set @num=@num+1;
	    print @num;
	    declare @baseMT int set @baseMT=(select top 1 mt.mark_type_id from univer_controll_type ct, univer_controll_type_mark_type_link mtl, univer_mark_type mt where ct.controll_type_id=mtl.controll_type_id
and mt.mark_type_id=mtl.mark_type_id and mt.mark_status=1 and mt.mark_type_arg in (0,1,2) and ct.controll_type_id=@ctId
 order by mt.mark_type_arg desc);
        declare @students table(student_id int, error nvarchar(500));    
        delete from @students;           
		print (N'Итерация №'+cast(@num as nvarchar));
		print (N'ID Группы '+cast(@groupId as nvarchar));
		declare @minRK int=0;
            if @needAccess=1             
            begin               
	        select @minRK= case when @sheetType=25 then 20 else ct.controll_type_min_rk end from univer_controll_type ct where ct.controll_type_id=@ctId;  
            end;     
		    insert into @students(student_id, error)
		                
            --выбираем всех студентов, для которых можно создать ведомость
            select gs.student_id,dbo.getSheetError(@sheetType,gs.group_id,gs.student_id,10000,1,1) error
           
                from univer_group (nolock) g, univer_group_student (nolock) gs, univer_educ_plan_pos pp, univer_students st, univer_educ_plan p where g.group_id=gs.group_id and gs.student_id=st.students_id and p.edu_level_id=st.edu_levels_id and p.educ_plan_adm_year=st.educ_plan_adm_year and p.education_form_id=st.education_form_id and p.speciality_id=st.speciality_id and p.status=1 and pp.educ_plan_pos_id=g.educ_plan_pos_id and pp.educ_plan_id=p.educ_plan_id and pp.status=1 and st.status=1 and g.group_id=@groupId /*and g.group_retake_semestr=0 */order by error;
		
		
		if exists(select * from @students where error is null)	    
	    begin 
	    print (N'Начинаем создавать ведомость');
	    declare @sheetId int;
	    print (N'определяем дату котроля');
	    declare @dateControl datetime;
	    select @dateControl=isnull(app.acpos_date_start, cast(GETDATE() as date)) from univer_academ_calendar_pos app where app.educ_plan_id=@planId and app.acpos_module=@apm and app.acpos_semester=@semestr and app.control_id=(select top 1 control_id from univer_controll_type_control_link ccl where sheet_type_id=@sheetType and controll_type_id=@ctId order by ccl.control_number);  
        if (@sheetType in (5,7)) begin
		select @dateControl=isnull(max(exam_time),@dateControl) from univer_exam_schedule where group_id in (select distinct g.group_id from univer_group (nolock) g, univer_group_student (nolock) gs, univer_group (nolock) g2, univer_group_student (nolock) gs2 where g.group_id=gs.group_id and g2.group_id=gs2.group_id and g.educ_plan_pos_id=g2.educ_plan_pos_id and g.acpos_module=g2.acpos_module and g.educ_lang_id=g2.educ_lang_id and g.group_retake_semestr=g2.group_retake_semestr and g.lang_division_id=g2.lang_division_id and g.group_year=g2.group_year and g.group_semestr=g2.group_semestr and gs2.student_id=gs.student_id and gs2.group_id=@groupId) and type=2;
		select @teacherId=isnull(min(teacher_id),@teacherId) from univer_exam_schedule_alternate_teacher where group_id in (select distinct g.group_id from univer_group (nolock) g, univer_group_student (nolock) gs, univer_group (nolock) g2, univer_group_student (nolock) gs2 where g.group_id=gs.group_id and g2.group_id=gs2.group_id and g.educ_plan_pos_id=g2.educ_plan_pos_id and g.acpos_module=g2.acpos_module and g.educ_lang_id=g2.educ_lang_id and g.group_retake_semestr=g2.group_retake_semestr and g.lang_division_id=g2.lang_division_id and g.group_year=g2.group_year and g.group_semestr=g2.group_semestr and gs2.student_id=gs.student_id and gs2.group_id=@groupId) and type=1;	
		end
        set  @dateControl=ISNULL( @dateControl,cast(GETDATE() as date));
        print @dateControl	     		
	    print (N'создаем пустую ведомость');
	    insert into univer_sheet(sheet_type_id,sheet_kind_id ,group_id,acpos_module,date_create,date_control,status)
	    values (@sheetType,1,@groupId,@apm,GETDATE(),@dateControl,1)
	    set @sheetId=@@IDENTITY;
	    print @sheetId 
	    print (N'определяем список студентов');
	    insert into [_tmp_sheet_gen](sheet_id,group_id)
	    values (@sheetId, @groupId);
		insert into univer_sheet_result (student_id,subject_id,n_seme,academ_year,semestr,control,sheet_id,teacher_id)
	    (select distinct st.students_id, @subId,@semestr,@acY,@acS,ccl.control_id,@sheetId,@teacherId  from univer_group (nolock) g, univer_group_student (nolock) gs, univer_students st, univer_educ_plan_pos pp,univer_controll_type_control_link ccl, @students es where ccl.controll_type_id=@ctId and sheet_type_id=@sheetType  and g.group_id=gs.group_id and gs.student_id=st.students_id and pp.educ_plan_pos_id=g.educ_plan_pos_id and g.group_id=@groupId and st.status=1 
and es.student_id=st.students_id and es.error is null )
		insert into univer_progress(student_id,subject_id,n_seme,academ_year,semestr,acpos_module,controll_type_id,cycle_id,educ_lang_id,mark_type_id,progress_credit,progress_result,progress_result_rk1,progress_result_rk2,progress_rup_kz, progress_rup_ru, progress_rup_en,status,subject_name_en,subject_name_kz,subject_name_ru,subject_type,teacher_id, educ_plan_pos_addit)
		select distinct sr.student_id,pp.subject_id,pp.educ_plan_pos_semestr,g.group_year,g.group_semestr,g.acpos_module,pp.controll_type_id,pp.cycle_id,g.educ_lang_id,@baseMT,pp.educ_plan_pos_credit,0,0,0,pp.rup_kz, pp.rup_ru, pp.rup_en,1,subject_name_en,subject_name_kz,subject_name_ru,subject_type,g.teacher_id, pp.educ_plan_pos_addit from univer_educ_plan_pos pp, univer_subject s, univer_group (nolock) g, univer_sheet_result(nolock) sr where sr.sheet_id=@sheetId and g.educ_plan_pos_id=pp.educ_plan_pos_id and pp.subject_id=s.subject_id and pp.status=1 and g.group_id=@groupId and (not exists(select * from univer_progress (nolock) p1 where p1.student_id=sr.student_id and p1.subject_id=sr.subject_id and p1.status=1 and p1.n_seme=sr.n_seme))

        update univer_progress set academ_year=@acY, semestr=@acS where progress_id in 
        (select p.progress_id from univer_progress (nolock) p, univer_sheet_result (nolock) sr where sr.subject_id=p.subject_id and sr.student_id=p.student_id and sr.n_seme=p.n_seme and sr.sheet_id=@sheetId) and status=1       
		if ((select COUNT(*) from univer_sheet_result (nolock) where sheet_id=@sheetId)<=0)
	    delete from univer_sheet where sheet_id=@sheetId 	
	    end;		
		FETCH NEXT FROM gCursor INTO @groupId,@ppId,@apm,@ldId,@ctId,@subId,@acY,@acS,@teacherId
		END
		
		CLOSE gCursor
		DEALLOCATE gCursor
	end try
	begin catch
	rollback;
	end catch	
	commit	
END


go

