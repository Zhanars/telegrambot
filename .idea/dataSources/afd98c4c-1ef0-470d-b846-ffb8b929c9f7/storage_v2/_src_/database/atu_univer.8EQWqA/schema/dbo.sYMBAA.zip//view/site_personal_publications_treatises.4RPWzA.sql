
/* книги (включая монографии)
 ФИО авторов. название работы.  место издания, название издательства. – год издания, указать ISBN, кол-во стр./п.л.
 (ФИО авторов из КазНУ выделить жирным шрифтом)*/
CREATE VIEW [dbo].[site_personal_publications_treatises]
AS
SELECT     TOP (100) PERCENT p.personal_id, pspl.structure_division_id AS chair_id, p.personal_sname + ' ' + LEFT(p.personal_name, 1) + '.' + LEFT(p.personal_father_name, 1)
                       + '.' AS author, DBScience.dbo.support_getCoauthorsOfPublication(t.treatise_id, 1, p.personal_id) AS coauthors, t.treatise_id, t.name_kz, t.name_ru, t.name_en, 
                      pub.address, pub.name, c.name_kz as country_name_kz, c.name_ru AS country_name_ru, t.yearPublication, t.ISBN, t.publishPageCount, t.annotationFile_id, fi.serverFileName AS annotationFile, 
                      t.treatiseFile_id, fi2.showName AS treatiseFile
FROM         dbo.univer_personal AS p LEFT OUTER JOIN
                      DBScience.dbo.L_Person_Treatise_Authors AS lta ON lta.personType = 1 AND lta.person_id = p.personal_id INNER JOIN
                      DBScience.dbo.Treatises AS t ON t.treatise_id = lta.treatise_id AND t.status <> 2 LEFT OUTER JOIN
                      DBScience.dbo.TreatiseTypes AS tt ON t.treatiseType_id = tt.treatiseType_id LEFT OUTER JOIN
                      DBScience.dbo.Publishers AS pub ON pub.publisher_id = t.publisher_id LEFT OUTER JOIN
                      DBScience.dbo.Countries AS c ON c.country_id = pub.country_id LEFT OUTER JOIN
                      DBScience.dbo.FileInfos AS fi ON t.annotationFile_id = fi.fileInfo_id LEFT OUTER JOIN
                      DBScience.dbo.FileInfos AS fi2 ON t.treatiseFile_id = fi2.fileInfo_id LEFT OUTER JOIN
                      dbo.univer_personal_struct_pos_link_1c AS pspl ON pspl.personal_id = p.personal_id AND pspl.status = 1 AND pspl.type_id IN (1, 2)
ORDER BY p.personal_id

go

