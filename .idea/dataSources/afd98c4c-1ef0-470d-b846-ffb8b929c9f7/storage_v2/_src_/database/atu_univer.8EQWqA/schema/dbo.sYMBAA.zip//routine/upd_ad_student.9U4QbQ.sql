-- =============================================
-- Author:		sasha
-- Create date: 02/10/2017
-- Description:	Обновление записей в таблице для синхронизации с AD - ac_dir_synch_student
-- =============================================
CREATE PROCEDURE upd_AD_student 
	
AS
BEGIN	
	SET NOCOUNT ON;
	declare @res int; set @res=0;
	begin transaction
	declare @t1 table (tname nvarchar(100))
	--Обновляем всех студентов, которые были отчислены или удалены из БД
	update ac_dir_synch_student set status=2, date_change_univer=GETDATE() where student_id not in 
	(select s.student_id from univer.dbo.univer_ad_sync_students s) and status=1;
	set @res=@res+@@rowcount;
	--Обновляем всех студентов, которые были восстановлены в БД
	update ac_dir_synch_student set status=1, date_change_univer=GETDATE() where student_id in 
	(select s.student_id from univer.dbo.univer_ad_sync_students s) and status=2;
	set @res=@res+@@rowcount;
	--Добавляем новых студентов 
	insert into ac_dir_synch_student(ac_dir_login, ac_dir_password, card_id, date_change_ac_dir, date_change_univer, drop_password, fio_change, status, student_fname, student_id, student_name, student_sname,uni_login) select ac_dir_login, ac_dir_password, card_id, date_change_ac_dir, date_change_univer, drop_password, fio_change, status, student_fname, student_id, student_name, student_sname,uni_login from univer.dbo.univer_ad_sync_students where student_id not in (select student_id from ac_dir_synch_student) and status=1
    set @res=@res+@@rowcount;	
    --Данные карточек
    update x set x.card_id=x.new_card_id, x.date_change_univer=getdate()
    from (select s.student_id, s.date_change_univer, s.card_id, cast(
		(select TOP 1 idf.identifier 
		from perco_univer_identifier idf, perco_univer_staff sf 
		where idf.staff_id_internal=sf.staff_id_internal and sf.staff_tabel_id='st_'+CAST(s.student_id as varchar)
		ORDER BY idf.prohibit) as nvarchar(20)) as new_card_id
	from ac_dir_synch_student s) x
    where ISNULL(x.card_id, '')<>isNull(x.new_card_id, '');
    set @res=@res+@@rowcount;	
    --Обновляем остальные данные AD
    --Логин системы univer
    MERGE ac_dir_synch_student AS target  
    USING (SELECT student_id,date_change_univer,uni_login from  univer.dbo.univer_ad_sync_students s) AS 
    source (student_id,date_change_univer,uni_login)
    ON (target.student_id = source.student_id)    
    WHEN MATCHED and isnull(target.uni_login,'')<>isnull(source.uni_login collate Cyrillic_General_CI_AS,'')
    THEN UPDATE SET uni_login=source.uni_login  collate Cyrillic_General_CI_AS, date_change_univer=getdate()
    OUTPUT $action INTO @t1; 
    --Почта
    MERGE ac_dir_synch_student AS target  
    USING (SELECT student_id,date_change_univer,e_mail from  univer.dbo.univer_ad_sync_students s) AS 
    source (student_id,date_change_univer,e_mail)
    ON (target.student_id = source.student_id)    
    WHEN MATCHED and target.e_mail<>source.e_mail and source.e_mail like '%@%'
    THEN UPDATE SET e_mail=source.e_mail, date_change_univer=getdate()
    OUTPUT $action INTO @t1;
    --ФИО
    MERGE ac_dir_synch_student AS target  
    USING (SELECT student_id,date_change_univer,student_sname,student_name,student_fname,fio_change from  univer.dbo.univer_ad_sync_students s) AS 
    source (student_id,date_change_univer,student_sname,student_name,student_fname,fio_change)
    ON (target.student_id = source.student_id)  
    WHEN MATCHED and (target.student_sname collate Cyrillic_General_CI_AS<>source.student_sname collate Cyrillic_General_CI_AS or target.student_name collate Cyrillic_General_CI_AS<>source.student_name collate Cyrillic_General_CI_AS or target.student_fname collate Cyrillic_General_CI_AS<>source.student_fname collate Cyrillic_General_CI_AS)
    THEN UPDATE SET student_sname=source.student_sname collate Cyrillic_General_CI_AS, student_name=source.student_name collate Cyrillic_General_CI_AS, student_fname=source.student_fname collate Cyrillic_General_CI_AS, fio_change=1, date_change_univer=getdate()    
    OUTPUT $action INTO @t1;  
    set @res=@res+(select count(*) from @t1);
 commit
 select @res as res
END
go

