CREATE VIEW dbo.pvk_users
AS
SELECT     u.user_login, u.user_password, s.students_id, s.students_zachetka, s.students_sname, s.students_name, s.students_father_name, s.students_email, 
                      s.country_id, c.country_name_ru, s.state_id, st.state_name_ru, s.faculty_id, f.faculty_name_ru, s.speciality_id, sp.speciality_okpd, 
                      sp.speciality_name_ru, s.lang_division_id, ld.lang_division_name_ru, s.students_adress, s.students_contact_town_phone, u.user_temppass
FROM         dbo.univer_users AS u INNER JOIN
                      dbo.univer_students AS s LEFT OUTER JOIN
                      dbo.univer_faculty AS f ON f.faculty_id = s.faculty_id LEFT OUTER JOIN
                      dbo.univer_speciality AS sp ON s.speciality_id = sp.speciality_id LEFT OUTER JOIN
                      dbo.univer_state AS st ON st.state_id = s.state_id LEFT OUTER JOIN
                      dbo.univer_country AS c ON c.country_id = s.country_id LEFT OUTER JOIN
                      dbo.univer_lang_division AS ld ON ld.lang_division_id = s.lang_division_id ON u.user_id = s.user_id
WHERE     (s.status = 1) AND (s.student_edu_status_id = 1) AND (s.students_curce_number = 2) AND (s.education_form_id = 1) AND (s.stage_id = 2)
go

