
-- =============================================
-- Author:		Yerlan
-- Create date: 14.06.2012
-- Description: Получить общую сумму баллов сотрудников с таким же кодом показателя по определенному категории(0 - все категории, 1 - на уровне факультета, 2- на уровне кафедры, 3 - на уровне ППС)
-- =============================================
CREATE FUNCTION [dbo].[IP_ALL_getSumOfAllValuesByIndicatorCode]
(
	@facultyId int,
	@chairId int,	
	@year int,
	@semester int,
	@indPlanCodeId int,
	@categoryId int
)
RETURNS real
AS
BEGIN
DECLARE @Result real

-- ==================================== если СУММА по всем категориям
IF (@categoryId = 0)
BEGIN
	SELECT @Result = SUM(ipp.ind_plan_personal_f_value)
		FROM 
			univer_ind_plan_indicator ipi, univer_ind_plan_personal ipp
		WHERE 
		ipi.ind_plan_indicator_id = ipp.ind_plan_indicator_id 
		-- по всем категориям если 0 или конкретная категория (1 - Фак, 2 - Каф, 3 - ППС)
		AND (ipi.ind_plan_category_id=@categoryId OR @categoryId=0) 
		-- по ИД кода показателя
		AND ipi.ind_plan_code_id=@indPlanCodeId
		-- только активные показатели
		AND ipi.status = 1 AND EXISTS(SELECT * FROM univer_ind_plan_code c WHERE c.ind_plan_code_id = ipi.ind_plan_code_id AND c.status=1)
		-- за академ. год и за тек. семестр
		AND ipp.year = @year AND ipp.semester = @semester
END

-- ==================================== если СУММА по всем сотрудникам кафедры
IF (@categoryId = 3)
BEGIN
	SELECT @Result = SUM(ipp.ind_plan_personal_f_value)
		FROM 
			univer_ind_plan_indicator ipi, univer_ind_plan_personal ipp, (select distinct p.personal_id,ppl.structure_division_id from univer_personal p, univer_personal_struct_pos_link_1c ppl where ppl.personal_id =p.personal_id and ppl.status=1 and p.status=1) p, univer_chair c
        WHERE 
            p.personal_id = ipp.personal_id --AND p.status=1
            --ZDES PROVERAEM (wtatniy pps na etoi kafedre ili wtatniy no s adm. doljnostiu)            
AND EXISTS(SELECT * FROM univer_personal_struct_pos_link_1c spl1 where spl1.status=1 and spl1.type_id=1 and (spl1.personal_position_id not in(6,123,124,308,309,322,325,348,350,351,352,359,360,361,446,447,448,449,506) OR spl1.structure_division_id=p.structure_division_id) and spl1.personal_id = p.personal_id)
            AND ipi.ind_plan_indicator_id = ipp.ind_plan_indicator_id        
            --AND spl.personal_id = ipp.personal_id AND spl.status=1 
            AND p.structure_division_id = c.structure_division_id 
		-- по кафедре
		AND c.structure_division_id = @chairId
		-- по всем категориям если 0 или конкретная категория (1 - Фак, 2 - Каф, 3 - ППС)
		AND ipi.ind_plan_category_id=@categoryId 
		-- по ИД кода показателя
		AND ipi.ind_plan_code_id=@indPlanCodeId
		-- только активные показатели
		AND ipi.status = 1 AND EXISTS(SELECT * FROM univer_ind_plan_code c WHERE c.ind_plan_code_id = ipi.ind_plan_code_id AND c.status=1)
		-- за академ. год и за тек. семестр
		AND ipp.year = @year AND ipp.semester = @semester
END
-- ==================================== если СУММА по всем кафедрам факультета
IF (@categoryId = 2)
BEGIN
	SELECT @Result = SUM(ipp.ind_plan_personal_f_value)
		FROM 
			univer_ind_plan_indicator ipi, (SELECT DISTINCT p.personal_id, hc.chair_id FROM univer_personal p, univer_head_chair hc WHERE p.personal_id=hc.personal_id AND p.status=1 AND hc.status=1) p
			,univer_ind_plan_personal ipp
			, univer_faculty f, univer_chair c
		WHERE 
		ipi.ind_plan_indicator_id = ipp.ind_plan_indicator_id 
		-- по факультету
		AND f.structure_division_id = @facultyId AND f.faculty_id=c.faculty_id AND f.status=1		
		AND f.faculty_id=c.faculty_id		
		-- по кафедре
		AND c.chair_id = p.chair_id AND c.status=1 
		-- сравнение зав.каф с персоналом
		AND p.personal_id=ipp.personal_id
		-- по всем категориям если 0 или конкретная категория (1 - Фак, 2 - Каф, 3 - ППС)
		AND ipi.ind_plan_category_id=@categoryId 
		-- по ИД кода показателя
		AND ipi.ind_plan_code_id=@indPlanCodeId
		-- только активные показатели
		AND ipi.status = 1 AND EXISTS(SELECT * FROM univer_ind_plan_code c WHERE c.ind_plan_code_id = ipi.ind_plan_code_id AND c.status=1)
		-- за академ. год и за тек. семестр
		AND ipp.year = @year AND ipp.semester = @semester
END
-- ==================================== если СУММА по всем факультетам
IF (@categoryId = 1)
BEGIN
	SELECT @Result = SUM(ipp.ind_plan_personal_f_value)
		FROM 
			univer_ind_plan_indicator ipi, univer_ind_plan_personal ipp
			, univer_personal_struct_pos_link_1c spl, univer_faculty f
		WHERE 
		ipi.ind_plan_indicator_id = ipp.ind_plan_indicator_id 
		AND spl.personal_id = ipp.personal_id AND spl.status=1 
		AND spl.structure_division_id = f.structure_division_id 
		-- по всем категориям если 0 или конкретная категория (1 - Фак, 2 - Каф, 3 - ППС)
		AND ipi.ind_plan_category_id=@categoryId 
		-- по ИД кода показателя
		AND ipi.ind_plan_code_id=@indPlanCodeId
		-- только активные показатели
		AND ipi.status = 1 AND EXISTS(SELECT * FROM univer_ind_plan_code c WHERE c.ind_plan_code_id = ipi.ind_plan_code_id AND c.status=1)
		-- за академ. год и за тек. семестр
		AND ipp.year = @year AND ipp.semester = @semester
END
RETURN ISNULL(@Result,0)
END

go

