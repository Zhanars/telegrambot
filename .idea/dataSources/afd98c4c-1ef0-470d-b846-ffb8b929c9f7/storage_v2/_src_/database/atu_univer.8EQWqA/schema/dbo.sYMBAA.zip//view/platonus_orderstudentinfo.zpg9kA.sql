CREATE VIEW dbo.platonus_orderstudentinfo
AS
SELECT DISTINCT 
                         t.studentID, t.orderID, t.course, t.deduct_to, t.enter_from, t.old_group_id, t.old_specialization_id, t.oldprofessionid, t.oldstudyformid, t.oldstudylanguageid, t.old_payment_form, t.oldcourse, t.payment_form, t.professionid, 
                         t.studyformid, t.studylanguageid, t.operation, ISNULL(os.orderstudentinfoid, 0) AS orderstudentinfoid
FROM            (SELECT        osl.student_id AS studentID, ISNULL(o.orderID, o.order_id) AS orderID, 0 AS course, 1 AS deduct_to, NULL AS enter_from, 0 AS old_group_id, 0 AS old_specialization_id, 0 AS oldprofessionid, 0 AS oldstudyformid, 
                                                    0 AS oldstudylanguageid, 0 AS old_payment_form, st.students_curce_number AS oldcourse,
                                                        (SELECT        TOP (1) ID
                                                          FROM            atu_platonus_univer.dbo.paymentforms AS pf
                                                          WHERE        (univer_value = st.payment_forms_id)) AS payment_form, st.speciality_id AS professionid, ISNULL
                                                        ((SELECT        TOP (1) sf.Id
                                                            FROM            atu_platonus_univer.dbo.studyforms AS sf INNER JOIN
                                                                                     atu_platonus_univer.dbo.degree_types AS dt ON sf.degreeID = dt.degreeID INNER JOIN
                                                                                     atu_platonus_univer.dbo.departments AS dp ON sf.departmentID = dp.id INNER JOIN
                                                                                     dbo.univer_educ_plan AS ep ON sf.courseCount = ep.educ_plan_number_of_semestr / 2
                                                            WHERE        (dt.univer_value = st.stage_id) AND (dp.univer_value = st.education_form_id) AND (ep.speciality_id = st.speciality_id) AND (ep.education_form_id = st.education_form_id) AND 
                                                                                     (ep.edu_level_id = st.edu_levels_id) AND (ep.educ_plan_adm_year = st.educ_plan_adm_year) AND (ep.status = 1) AND (sf.univer_edu_level_id = st.edu_levels_id)), 0) AS studyformid,
                                                        (SELECT        TOP (1) Id
                                                          FROM            atu_platonus_univer.dbo.studylanguages AS pf
                                                          WHERE        (univer_value = st.lang_division_id)) AS studylanguageid, posl.operation
                          FROM            dbo.univer_order AS o INNER JOIN
                                                    dbo.univer_order_student_link AS osl ON o.order_id = osl.order_id INNER JOIN
                                                    dbo.univer_students AS st ON osl.student_id = st.students_id INNER JOIN
                                                    dbo.platonus_univer_order_student_link AS posl ON osl.order_id = posl.order_id AND osl.student_id = posl.student_id
                          WHERE        (o.order_type_id IN (71, 80)) AND (o.status IN (20, 21))
                          UNION
                          SELECT        osl.student_id AS studentID, ISNULL(o.orderID, o.order_id) AS orderID, st.students_curce_number AS course, NULL AS deduct_to, 1 AS enter_from, 0 AS old_group_id, 0 AS old_specialization_id, 0 AS oldprofessionid,
                                                    0 AS oldstudyformid, 0 AS oldstudylanguageid, 0 AS old_payment_form, 1 AS oldcourse,
                                                       (SELECT        TOP (1) ID
                                                         FROM            atu_platonus_univer.dbo.paymentforms AS pf
                                                         WHERE        (univer_value = st.payment_forms_id)) AS payment_form, st.speciality_id AS professionid, ISNULL
                                                       ((SELECT        TOP (1) sf.Id
                                                           FROM            atu_platonus_univer.dbo.studyforms AS sf INNER JOIN
                                                                                    atu_platonus_univer.dbo.degree_types AS dt ON sf.degreeID = dt.degreeID INNER JOIN
                                                                                    atu_platonus_univer.dbo.departments AS dp ON sf.departmentID = dp.id INNER JOIN
                                                                                    dbo.univer_educ_plan AS ep ON sf.courseCount = ep.educ_plan_number_of_semestr / 2
                                                           WHERE        (dt.univer_value = st.stage_id) AND (dp.univer_value = st.education_form_id) AND (ep.speciality_id = st.speciality_id) AND (ep.education_form_id = st.education_form_id) AND 
                                                                                    (ep.edu_level_id = st.edu_levels_id) AND (ep.educ_plan_adm_year = st.educ_plan_adm_year) AND (ep.status = 1) AND (sf.univer_edu_level_id = st.edu_levels_id)), 0) AS studyformid,
                                                       (SELECT        TOP (1) Id
                                                         FROM            atu_platonus_univer.dbo.studylanguages AS pf
                                                         WHERE        (univer_value = st.lang_division_id)) AS studylanguageid, posl.operation
                          FROM            dbo.univer_order AS o INNER JOIN
                                                   dbo.univer_order_student_link AS osl ON o.order_id = osl.order_id INNER JOIN
                                                   dbo.univer_students AS st ON osl.student_id = st.students_id INNER JOIN
                                                   dbo.platonus_univer_order_student_link AS posl ON osl.order_id = posl.order_id AND osl.student_id = posl.student_id
                          WHERE        (o.order_type_id = 1) AND (o.status IN (20, 21))
                          UNION
                          SELECT        osl.student_id AS studentID, ISNULL(o.orderID, o.order_id) AS orderID, st.students_curce_number AS course, (CASE WHEN student_edu_status_id IN (98, 102) THEN 1 WHEN student_edu_status_id IN (13) 
                                                   THEN 2 WHEN student_edu_status_id IN (9) THEN 3 WHEN student_edu_status_id IN (14) THEN 4 WHEN student_edu_status_id IN (16) THEN 5 WHEN student_edu_status_id IN (8) 
                                                   THEN 6 WHEN student_edu_status_id IN (108, 97) THEN 7 WHEN student_edu_status_id IN (11, 12) THEN 8 ELSE 9 END) AS deduct_to, NULL AS enter_from, 0 AS old_group_id, 0 AS old_specialization_id, 
                                                   0 AS oldprofessionid, 0 AS oldstudyformid, 0 AS oldstudylanguageid, 0 AS old_payment_form, st.students_curce_number AS oldcourse,
                                                       (SELECT        TOP (1) ID
                                                         FROM            atu_platonus_univer.dbo.paymentforms AS pf
                                                         WHERE        (univer_value = st.payment_forms_id)) AS payment_form, st.speciality_id AS professionid, ISNULL
                                                       ((SELECT        TOP (1) sf.Id
                                                           FROM            atu_platonus_univer.dbo.studyforms AS sf INNER JOIN
                                                                                    atu_platonus_univer.dbo.degree_types AS dt ON sf.degreeID = dt.degreeID INNER JOIN
                                                                                    atu_platonus_univer.dbo.departments AS dp ON sf.departmentID = dp.id INNER JOIN
                                                                                    dbo.univer_educ_plan AS ep ON sf.courseCount = ep.educ_plan_number_of_semestr / 2
                                                           WHERE        (dt.univer_value = st.stage_id) AND (dp.univer_value = st.education_form_id) AND (ep.speciality_id = st.speciality_id) AND (ep.education_form_id = st.education_form_id) AND 
                                                                                    (ep.edu_level_id = st.edu_levels_id) AND (ep.educ_plan_adm_year = st.educ_plan_adm_year) AND (ep.status = 1) AND (sf.univer_edu_level_id = st.edu_levels_id)), 0) AS studyformid,
                                                       (SELECT        TOP (1) Id
                                                         FROM            atu_platonus_univer.dbo.studylanguages AS pf
                                                         WHERE        (univer_value = st.lang_division_id)) AS studylanguageid, posl.operation
                          FROM            dbo.univer_order AS o INNER JOIN
                                                   dbo.univer_order_student_link AS osl ON o.order_id = osl.order_id INNER JOIN
                                                   dbo.univer_students AS st ON osl.student_id = st.students_id INNER JOIN
                                                   dbo.platonus_univer_order_student_link AS posl ON osl.order_id = posl.order_id AND osl.student_id = posl.student_id
                          WHERE        (o.order_type_id = 70) AND (o.status IN (20, 21))
                          UNION
                          SELECT        osl.student_id AS studentID, ISNULL(o.orderID, o.order_id) AS orderID, st.students_curce_number AS course, NULL AS deduct_to, 2 AS enter_from, 0 AS old_group_id, 0 AS old_specialization_id, 
                                                   ISNULL(osl.osl_data.value('(/MoveOutsideStudentModel/specialityIdOld)[1]', 'int'), 0) AS oldprofessionid, 0 AS oldstudyformid, ISNULL
                                                       ((SELECT        TOP (1) Id
                                                           FROM            atu_platonus_univer.dbo.studylanguages AS pf
                                                           WHERE        (univer_value = ISNULL(osl.osl_data.value('(/MoveOutsideStudentModel/langDivisionIdOld)[1]', 'int'), 0))), 0) AS oldstudylanguageid, ISNULL
                                                       ((SELECT        TOP (1) ID
                                                           FROM            atu_platonus_univer.dbo.paymentforms AS pf
                                                           WHERE        (univer_value = ISNULL(osl.osl_data.value('(/MoveOutsideStudentModel/paymentFormIdOld)[1]', 'int'), 0))), 0) AS old_payment_form, 
                                                   ISNULL(osl.osl_data.value('(/MoveOutsideStudentModel/curceNumberOld)[1]', 'int'), 0) AS oldcourse,
                                                       (SELECT        TOP (1) ID
                                                         FROM            atu_platonus_univer.dbo.paymentforms AS pf
                                                         WHERE        (univer_value = st.payment_forms_id)) AS payment_form, st.speciality_id AS professionid, ISNULL
                                                       ((SELECT        TOP (1) sf.Id
                                                           FROM            atu_platonus_univer.dbo.studyforms AS sf INNER JOIN
                                                                                    atu_platonus_univer.dbo.degree_types AS dt ON sf.degreeID = dt.degreeID INNER JOIN
                                                                                    atu_platonus_univer.dbo.departments AS dp ON sf.departmentID = dp.id INNER JOIN
                                                                                    dbo.univer_educ_plan AS ep ON dp.univer_value = ep.education_form_id AND sf.courseCount = ep.educ_plan_number_of_semestr / 2
                                                           WHERE        (dt.univer_value = st.stage_id) AND (ep.speciality_id = st.speciality_id) AND (ep.education_form_id = st.education_form_id) AND (ep.edu_level_id = st.edu_levels_id) AND 
                                                                                    (ep.educ_plan_adm_year = st.educ_plan_adm_year) AND (ep.status = 1) AND (sf.univer_edu_level_id = st.edu_levels_id)), 0) AS studyformid,
                                                       (SELECT        TOP (1) Id
                                                         FROM            atu_platonus_univer.dbo.studylanguages AS pf
                                                         WHERE        (univer_value = st.lang_division_id)) AS studylanguageid, posl.operation
                          FROM            dbo.univer_order AS o INNER JOIN
                                                   dbo.univer_order_student_link AS osl ON o.order_id = osl.order_id INNER JOIN
                                                   dbo.univer_students AS st ON osl.student_id = st.students_id INNER JOIN
                                                   dbo.platonus_univer_order_student_link AS posl ON osl.order_id = posl.order_id AND osl.student_id = posl.student_id
                          WHERE        (o.order_type_id = 8) AND (o.status IN (20, 21))
                          UNION
                          SELECT        osl.student_id AS studentID, ISNULL(o.orderID, o.order_id) AS orderID, st.students_curce_number AS course, NULL AS deduct_to, 4 AS enter_from, 0 AS old_group_id, 0 AS old_specialization_id, 
                                                   ISNULL(osl.osl_data.value('(/RestoreStudentModel/specialityIdWas)[1]', 'int'), 0) AS oldprofessionid, 0 AS oldstudyformid, ISNULL
                                                       ((SELECT        TOP (1) Id
                                                           FROM            atu_platonus_univer.dbo.studylanguages AS pf
                                                           WHERE        (univer_value = ISNULL(osl.osl_data.value('(/RestoreStudentModel/langDivisionIdWas)[1]', 'int'), 0))), 0) AS oldstudylanguageid, ISNULL
                                                       ((SELECT        TOP (1) ID
                                                           FROM            atu_platonus_univer.dbo.paymentforms AS pf
                                                           WHERE        (univer_value = ISNULL(osl.osl_data.value('(/RestoreStudentModel/paymentFormIdWas)[1]', 'int'), 0))), 0) AS old_payment_form, 
                                                   ISNULL(osl.osl_data.value('(/RestoreStudentModel/curceNumberWas)[1]', 'int'), 0) AS oldcourse,
                                                       (SELECT        TOP (1) ID
                                                         FROM            atu_platonus_univer.dbo.paymentforms AS pf
                                                         WHERE        (univer_value = st.payment_forms_id)) AS payment_form, st.speciality_id AS professionid, ISNULL
                                                       ((SELECT        TOP (1) sf.Id
                                                           FROM            atu_platonus_univer.dbo.studyforms AS sf INNER JOIN
                                                                                    atu_platonus_univer.dbo.degree_types AS dt ON sf.degreeID = dt.degreeID INNER JOIN
                                                                                    atu_platonus_univer.dbo.departments AS dp ON sf.departmentID = dp.id INNER JOIN
                                                                                    dbo.univer_educ_plan AS ep ON dp.univer_value = ep.education_form_id AND sf.courseCount = ep.educ_plan_number_of_semestr / 2
                                                           WHERE        (dt.univer_value = st.stage_id) AND (ep.speciality_id = st.speciality_id) AND (ep.education_form_id = st.education_form_id) AND (ep.edu_level_id = st.edu_levels_id) AND 
                                                                                    (ep.educ_plan_adm_year = st.educ_plan_adm_year) AND (ep.status = 1) AND (sf.univer_edu_level_id = st.edu_levels_id)), 0) AS studyformid,
                                                       (SELECT        TOP (1) Id
                                                         FROM            atu_platonus_univer.dbo.studylanguages AS pf
                                                         WHERE        (univer_value = st.lang_division_id)) AS studylanguageid, posl.operation
                          FROM            dbo.univer_order AS o INNER JOIN
                                                   dbo.univer_order_student_link AS osl ON o.order_id = osl.order_id INNER JOIN
                                                   dbo.univer_students AS st ON osl.student_id = st.students_id INNER JOIN
                                                   dbo.platonus_univer_order_student_link AS posl ON osl.order_id = posl.order_id AND osl.student_id = posl.student_id
                          WHERE        (o.order_type_id = 10) AND (o.status IN (20, 21))
                          UNION
                          SELECT        osl.student_id AS studentID, ISNULL(o.orderID, o.order_id) AS orderID, st.students_curce_number AS course, NULL AS deduct_to, 5 AS enter_from, 0 AS old_group_id, 0 AS old_specialization_id, 
                                                   ISNULL(osl.osl_data.value('(/MoveInsideStudentModel/specialityIdWas)[1]', 'int'), 0) AS oldprofessionid, 0 AS oldstudyformid, ISNULL
                                                       ((SELECT        TOP (1) Id
                                                           FROM            atu_platonus_univer.dbo.studylanguages AS pf
                                                           WHERE        (univer_value = ISNULL(osl.osl_data.value('(/MoveInsideStudentModel/langDivisionIdWas)[1]', 'int'), 0))), 0) AS oldstudylanguageid, ISNULL
                                                       ((SELECT        TOP (1) ID
                                                           FROM            atu_platonus_univer.dbo.paymentforms AS pf
                                                           WHERE        (univer_value = ISNULL(osl.osl_data.value('(/MoveInsideStudentModel/paymentFormIdWas)[1]', 'int'), 0))), 0) AS old_payment_form, 
                                                   ISNULL(osl.osl_data.value('(/MoveInsideStudentModel/curceNumberWas)[1]', 'int'), 0) AS oldcourse,
                                                       (SELECT        TOP (1) ID
                                                         FROM            atu_platonus_univer.dbo.paymentforms AS pf
                                                         WHERE        (univer_value = st.payment_forms_id)) AS payment_form, st.speciality_id AS professionid, ISNULL
                                                       ((SELECT        TOP (1) sf.Id
                                                           FROM            atu_platonus_univer.dbo.studyforms AS sf INNER JOIN
                                                                                    atu_platonus_univer.dbo.degree_types AS dt ON sf.degreeID = dt.degreeID INNER JOIN
                                                                                    atu_platonus_univer.dbo.departments AS dp ON sf.departmentID = dp.id INNER JOIN
                                                                                    dbo.univer_educ_plan AS ep ON dp.univer_value = ep.education_form_id AND sf.courseCount = ep.educ_plan_number_of_semestr / 2
                                                           WHERE        (dt.univer_value = st.stage_id) AND (ep.speciality_id = st.speciality_id) AND (ep.education_form_id = st.education_form_id) AND (ep.edu_level_id = st.edu_levels_id) AND 
                                                                                    (ep.educ_plan_adm_year = st.educ_plan_adm_year) AND (ep.status = 1) AND (sf.univer_edu_level_id = st.edu_levels_id)), 0) AS studyformid,
                                                       (SELECT        TOP (1) Id
                                                         FROM            atu_platonus_univer.dbo.studylanguages AS pf
                                                         WHERE        (univer_value = st.lang_division_id)) AS studylanguageid, posl.operation
                          FROM            dbo.univer_order AS o INNER JOIN
                                                   dbo.univer_order_student_link AS osl ON o.order_id = osl.order_id INNER JOIN
                                                   dbo.univer_students AS st ON osl.student_id = st.students_id INNER JOIN
                                                   dbo.platonus_univer_order_student_link AS posl ON osl.order_id = posl.order_id AND osl.student_id = posl.student_id
                          WHERE        (o.order_type_id = 20) AND (o.status IN (20, 21))) AS t LEFT OUTER JOIN
                         atu_platonus_univer.dbo.orderstudentinfo AS os ON t.orderID = os.orderID AND t.studentID = os.studentID
go

