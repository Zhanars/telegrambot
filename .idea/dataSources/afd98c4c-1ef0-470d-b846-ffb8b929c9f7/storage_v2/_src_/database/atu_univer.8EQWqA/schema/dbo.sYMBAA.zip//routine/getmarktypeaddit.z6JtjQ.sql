

-- =============================================
-- Author:		Sasha
-- Create date: 07.05.2012
-- Update date: 06.09.2013 /*Yerlan*/
-- Update date: 06.10.2014 /*Sasha*/
-- Description:	Функция определения буквенной оценки (mark_type_id)
-- =============================================
CREATE FUNCTION [dbo].[getMarkTypeAddit]
(
	 @progressId int
)
RETURNS int
AS
BEGIN
    declare @ball int; declare @controllTypeId int; declare @mt int;
      select @controllTypeId=pp.controll_type_id,@ball=cast(round(sum(ctl.control_portion * case c.control_title when N'' then p.additsem_progress_result when N'_rk1' then p.additsem_progress_result_rk1 when N'_rk2' then p.additsem_progress_result_rk2 when N'_mt' then p.additsem_progress_result_mt end),0) as int) from univer_additsem_progress p, univer_additsem_position pp, univer_controll_type ct, univer_controll_type_control_link ctl, univer_control c where pp.additsem_position_id=p.additsem_position_id and pp.controll_type_id=ct.controll_type_id and ct.controll_type_id=ctl.controll_type_id and ctl.control_id=c.control_id and p.additsem_progress_id=@progressId group by p.additsem_progress_id,pp.controll_type_id;
	
    declare @wrong int;
    set @wrong=(select count(*) from univer_additsem_progress p, univer_additsem_position pp, univer_controll_type ct, univer_controll_type_control_link ctl, univer_control c where pp.additsem_position_id=p.additsem_position_id and pp.controll_type_id=ct.controll_type_id and ct.controll_type_id=ctl.controll_type_id and ctl.control_id=c.control_id and p.additsem_progress_result_rk1+additsem_progress_result_rk2<ctl.control_min_ball and ctl.control_min_ball>0 and p.additsem_progress_id=@progressId);
      
    set @wrong=@wrong+(select count(*) from univer_additsem_progress p, univer_additsem_position pp, univer_controll_type ct, univer_controll_type_control_link ctl, univer_control c where pp.additsem_position_id=p.additsem_position_id and pp.controll_type_id=ct.controll_type_id and ct.controll_type_id=ctl.controll_type_id and ctl.control_id=c.control_id  and case c.control_title when N'' then p.additsem_progress_result when N'_rk1' then p.additsem_progress_result_rk1 when N'_rk2' then p.additsem_progress_result_rk2 when N'_mt' then p.additsem_progress_result_mt end<ctl.control_min_ball and ctl.control_min_ball>0 and p.additsem_progress_id=@progressId);
	declare @r int; set @r=case when @wrong<=0 then @ball else 0 end;
	set @mt=(select top 1 mt.mark_type_id from univer_controll_type ct,univer_controll_type_mark_type_link mtl, univer_mark_type mt where ct.controll_type_id=mtl.controll_type_id and mt.mark_type_id=mtl.mark_type_id and mt.mark_type_minval<=@r and mt.mark_type_maxval>=@r and ct.controll_type_id=@controllTypeId)
	
	RETURN @mt
END

go

