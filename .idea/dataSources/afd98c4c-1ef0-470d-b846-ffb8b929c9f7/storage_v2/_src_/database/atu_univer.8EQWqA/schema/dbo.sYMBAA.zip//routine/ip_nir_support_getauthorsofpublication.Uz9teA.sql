-- =============================================
-- Author:		Twice
-- Create date: 14.06.2012
-- Description:	Получить список авторов публикаций в виде строки (только сотрудники КазНУ)
-- =============================================
CREATE FUNCTION [dbo].[IP_NIR_SUPPORT_getAuthorsOfPublication] 
(
	-- Add the parameters for the function here
	@publicationId int,
	@publicationType int
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result NVARCHAR(MAX) = N''

	-- если книги
	IF (@publicationType = 1) 
	BEGIN
		SELECT @Result = COALESCE(@Result, '') + 
		ISNULL(p.personal_sname + ' ' + p.personal_name + ' ' + p.personal_father_name + ', ', '')
		--COALESCE(@Result,	p.personal_sname, p.personal_name, p.personal_father_name + N'\n', '')
		FROM 
			univer_personal p
		WHERE 
			p.personal_id in
			(SELECT person_id FROM DBScience.dbo.L_Person_Treatise_Authors a 
			WHERE a.treatise_id = @publicationId and personType = 1)
	END
	
	-- если статьи
	IF (@publicationType = 2) 
	BEGIN
		SELECT @Result = COALESCE(@Result, '') + 
		ISNULL(p.personal_sname + ' ' + p.personal_name + ' ' + p.personal_father_name + ', ', '')
		--COALESCE(@Result,	p.personal_sname, p.personal_name, p.personal_father_name + N'\n', '')
		FROM 
			univer_personal p
		WHERE 
			p.personal_id in
			(SELECT person_id FROM DBScience.dbo.L_Person_Paper_Authors a 
			WHERE a.paper_id = @publicationId and personType = 1)
	END
	
	-- если тезисы
	IF (@publicationType = 3) 
	BEGIN
		SELECT @Result = COALESCE(@Result, '') + 
		ISNULL(p.personal_sname + ' ' + p.personal_name + ' ' + p.personal_father_name + ', ', '')
		--COALESCE(@Result,	p.personal_sname, p.personal_name, p.personal_father_name + N'\n', '')
		FROM 
			univer_personal p
		WHERE 
			p.personal_id in
			(SELECT person_id FROM DBScience.dbo.L_Person_Thesis_Authors a 
			WHERE a.thesis_id = @publicationId and personType = 1)
	END
	
	-- если имиджевые статьи
	IF (@publicationType = 4) 
	BEGIN
		SELECT @Result = COALESCE(@Result, '') + 
		ISNULL(p.personal_sname + ' ' + p.personal_name + ' ' + p.personal_father_name + ', ', '')
		--COALESCE(@Result,	p.personal_sname, p.personal_name, p.personal_father_name + N'\n', '')
		FROM 
			univer_personal p
		WHERE 
			p.personal_id in
			(SELECT person_id FROM DBScience.dbo.L_Person_ImagePaper_Authors a 
			WHERE a.imagePaper_id = @publicationId and personType = 1)
	END
	
	
	-- Return the result of the function
	RETURN @Result
END
go

