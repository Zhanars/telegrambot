
-- =============================================
-- Author:		Yerlan
-- Create date: 2013-11-06 17:44:33.680
-- Description:	Добавление записи о том что данные группы были изменены 
-- =============================================
create TRIGGER [dbo].[groupStUpdateTriggerForPlatonus]
   ON  [dbo].[univer_group_student] 
   AFTER UPDATE,INSERT,DELETE
AS 
BEGIN
	
	IF @@ROWCOUNT =0
    RETURN
	
	SET NOCOUNT ON;
	
	--Insert block, all new inserted teacher_id will be writed as update
	IF EXISTS(SELECT * FROM inserted)
	BEGIN
		INSERT INTO platonus_univer_group_student(group_student_id, operation)
		SELECT DISTINCT group_student_id, 1 FROM inserted i 
		WHERE i.group_student_id NOT IN (SELECT group_student_id FROM platonus_univer_group_student)
	END
		
	--DELETE block. 
	IF EXISTS(SELECT * FROM deleted d) and not EXISTS(SELECT * FROM inserted)
	BEGIN
		delete from platonus_univer_group_student where group_student_id in (select d.group_student_id from deleted d);

		INSERT INTO platonus_univer_group_student(group_student_id, operation)
		SELECT DISTINCT i.group_student_id,2 FROM deleted i 
		WHERE i.group_student_id NOT IN (SELECT group_student_id FROM platonus_univer_group_student)
	END
END
go

