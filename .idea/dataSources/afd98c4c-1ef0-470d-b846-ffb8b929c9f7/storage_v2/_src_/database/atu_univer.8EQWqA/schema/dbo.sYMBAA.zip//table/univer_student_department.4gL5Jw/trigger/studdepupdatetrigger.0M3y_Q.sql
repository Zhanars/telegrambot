-- =============================================
-- Author:		@LFER
-- Create date: 2009-07-09 16:15:58.780
-- Description:	Триггер на изменение статуса сотрудника студенческого отдела
-- =============================================
CREATE TRIGGER [dbo].[studDepUpdateTrigger]
   ON  [dbo].[univer_student_department] 
   AFTER UPDATE
AS 
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @pi int
	DECLARE @st int
	
	DECLARE insCursor cursor 
		FOR SELECT personal_id, status FROM inserted
	
	IF UPDATE(status)
	BEGIN
		OPEN insCursor
		FETCH NEXT FROM insCursor INTO @pi, @st
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF(@st=1)
				EXEC dbo.personalSetAccess @pi, 'STUD_DEPART'
			ELSE
				EXEC dbo.personalDeleteAccess @pi, 'STUD_DEPART'
				
			FETCH NEXT FROM insCursor INTO @pi, @st
		END
		CLOSE insCursor
	END
END
go

