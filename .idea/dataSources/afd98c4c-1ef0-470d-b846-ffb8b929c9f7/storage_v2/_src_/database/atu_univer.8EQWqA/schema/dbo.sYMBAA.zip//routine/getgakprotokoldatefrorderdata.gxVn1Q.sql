-- =============================================
-- Author:		Yerlan
-- Create date: 12.04.2016
-- Description:	
-- =============================================
create FUNCTION [dbo].[GetGakProtokolDateFrOrderData] 
(
	
	@orderData xml,
	@specialityId int
)
RETURNS datetime
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result datetime
	
	DECLARE @table TABLE (ID INT, XmlCOntent XML)
	
	INSERT INTO @Table VALUES(1, @orderData);
	
	set @Result = (select top 1 a.dateGak from (
		SELECT
			ID,
			specialityId = XACE.value('(specialityId)[1]', 'varchar(50)'),
			dateGak = XACE.value('(dateGAK)[1]', 'datetime')
		FROM
			@table
		CROSS APPLY
			XmlContent.nodes('/GraduationOrder/specialities/specialityAdditioalData') AS XTbl(XACE)
	) a where a.specialityId=@specialityId);
	
	RETURN @Result
END
go

