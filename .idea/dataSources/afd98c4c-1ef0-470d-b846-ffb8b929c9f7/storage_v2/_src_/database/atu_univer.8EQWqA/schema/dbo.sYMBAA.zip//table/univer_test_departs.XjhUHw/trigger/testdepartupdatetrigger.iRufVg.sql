-- =============================================
-- Author:		ulugbek
-- Create date: 2011-11-14
-- Description:	Удаление или добавлении права доступа при изменении статуса сотрудника
-- =============================================
create TRIGGER [dbo].[testDepartUpdateTrigger]
   ON  [dbo].[univer_test_departs]
   FOR UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @pi int
	DECLARE @st int
	
	DECLARE insCursor cursor 
		FOR SELECT personal_id, status FROM inserted
	
	IF UPDATE(status)
	BEGIN
		OPEN insCursor
		FETCH NEXT FROM insCursor INTO @pi, @st
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF(@st=1)
				EXEC dbo.personalSetAccess @pi, 'TEST_DEPART'
			ELSE
				EXEC dbo.personalDeleteAccess @pi, 'TEST_DEPART'
				
			FETCH NEXT FROM insCursor INTO @pi, @st
		END
		CLOSE insCursor
	END

END
go

