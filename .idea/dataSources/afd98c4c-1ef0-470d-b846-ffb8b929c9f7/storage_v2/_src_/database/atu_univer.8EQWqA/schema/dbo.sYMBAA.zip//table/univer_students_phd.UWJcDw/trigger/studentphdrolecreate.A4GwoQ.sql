-- =============================================
-- Author:		<Baton>
-- Create date: <2009-09-22>
-- Description:	<Тригер на присвоения "права" магистра при создании записи>
-- =============================================
CREATE TRIGGER [dbo].[studentPhdRoleCreate] ON  [dbo].[univer_students_phd] AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	
	-- Insert statements for trigger here
	-- Цифра доступа для данной сущности
	DECLARE @userId int
	DECLARE @studId int
	DECLARE @status int
	
	DECLARE insCursor cursor 
		FOR SELECT students_id FROM inserted		
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @studId
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SELECT @userId = user_id FROM univer_students WHERE students_id = @studId
		SELECT @status = status FROM univer_students WHERE students_id = @studId
		
		IF(@status != 11)
			BEGIN
			exec dbo.usersSetAccess @userId, 'STUDENT_PHD'
			END
		
		FETCH NEXT FROM insCursor INTO @studId
	END
	CLOSE insCursor
END
go

