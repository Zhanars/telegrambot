CREATE VIEW dbo.site_univer_supervisor_info
AS
SELECT     TOP (100) PERCENT p_1.personal_id, p_1.personal_sname, p_1.personal_name, p_1.personal_father_name, p_1.personal_photo, p_1.personal_site_photo, 
                      p_1.chair_id, ad.academic_degree_name_kz, ad.academic_degree_name_ru, ad.academic_degree_name_en, sd.scientific_degree_name_kz, 
                      sd.scientific_degree_name_ru, sd.scientific_degree_name_en, sr.scientific_rank_name_kz, sr.scientific_rank_name_ru, sr.scientific_rank_name_en, 
                      sd.scientific_degree_short_name_kz, sd.scientific_degree_short_name_ru, sd.scientific_degree_short_name_en,
                          (SELECT     TOP (1) pp.personal_position_id
                            FROM          dbo.univer_personal_position_1c AS pp INNER JOIN
                                                   dbo.univer_personal_struct_pos_link_1c AS spl ON pp.personal_position_id = spl.personal_position_id
                            WHERE      (spl.personal_id = p_1.personal_id) AND (spl.status = 1) AND (pp.personal_position_is_teacher = 1)) AS personal_position_id
FROM         (SELECT DISTINCT 
                                              p.personal_id, p.personal_sname, p.personal_name, p.personal_father_name, p.personal_photo, p.personal_site_photo, 
                                              spl.structure_division_id AS chair_id
                       FROM          dbo.univer_personal AS p INNER JOIN
                                              dbo.univer_personal_struct_pos_link_1c AS spl ON p.personal_id = spl.personal_id INNER JOIN
                                              dbo.univer_personal_position_1c AS pp ON spl.personal_position_id = pp.personal_position_id INNER JOIN
                                              dbo.univer_teacher AS t ON p.personal_id = t.personal_id AND t.status = 1 AND p.personal_id = t.personal_id INNER JOIN
                                              dbo.univer_student_supervisor AS ss ON ss.teacher_id = t.teacher_id AND t.teacher_id = ss.teacher_id INNER JOIN
                                              dbo.univer_students AS st ON st.students_id = ss.student_id AND st.status = 1 AND st.stage_id = 3 AND ss.student_id = st.students_id
                       WHERE      (spl.structure_division_id > 0) AND (spl.personal_position_id > 0) AND (spl.status = 1) AND (p.status = 1) AND (pp.personal_position_is_teacher = 1) AND 
                                              (pp.status = 1) AND (st.status = 1) AND (st.stage_id = 3) AND (t.status = 1)) AS p_1 LEFT OUTER JOIN
                      dbo.univer_personal_academic_degree_1c AS pad ON p_1.personal_id = pad.personal_id AND pad.personal_academic_degree_id =
                          (SELECT     TOP (1) personal_academic_degree_id
                            FROM          dbo.univer_personal_academic_degree_1c AS ad
                            WHERE      (personal_id = p_1.personal_id)
                            ORDER BY personal_academic_degree_date DESC) LEFT OUTER JOIN
                      dbo.univer_personal_scientific_rank_1c AS psr ON p_1.personal_id = psr.personal_id AND psr.personal_scientific_rank_id =
                          (SELECT     TOP (1) personal_scientific_rank_id
                            FROM          dbo.univer_personal_scientific_rank_1c AS sd
                            WHERE      (personal_id = p_1.personal_id)
                            ORDER BY personal_scientific_rank_date DESC) LEFT OUTER JOIN
                      dbo.univer_personal_scientific_degree_1c AS psd ON p_1.personal_id = psd.personal_id AND psd.personal_scientific_degree_id =
                          (SELECT     TOP (1) personal_scientific_degree_id
                            FROM          dbo.univer_personal_scientific_degree_1c AS sd
                            WHERE      (personal_id = p_1.personal_id) AND (scientific_degree_id NOT IN (2, 4))
                            ORDER BY personal_scientific_degree_date DESC) LEFT OUTER JOIN
                      dbo.univer_academic_degree_1c AS ad ON pad.academic_degree_id = ad.academic_degree_id LEFT OUTER JOIN
                      dbo.univer_scientific_degree_1c AS sd ON psd.scientific_degree_id = sd.scientific_degree_id LEFT OUTER JOIN
                      dbo.univer_scientific_rank_1c AS sr ON psr.scientific_rank_id = sr.scientific_rank_id
WHERE     (p_1.personal_id > 0)
ORDER BY p_1.personal_sname, p_1.personal_name, p_1.personal_father_name
go

