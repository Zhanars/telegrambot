-- =============================================
-- Author:		Twice
-- Create date: 31.01.2012
-- Description: Получить количество научных монографий (1 - в казахстанских издательствах, 2 - зарубежных издательствах) - в разрезе сотрудника
-- =============================================
CREATE FUNCTION [dbo].[IP_NIR_getSciTreatises_Count_ByPersonalId_DESC]
(
	@personalId int,
	@year int,
	@publisherTypeId int
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @Result NVARCHAR(MAX)

IF @publisherTypeId = 1 
BEGIN 
	IF (SELECT COUNT(*)
		FROM 
			DBScience.dbo.Treatises t,
			DBScience.dbo.L_Person_Treatise_Authors a,
			DBScience.dbo.Publishers p,
			DBScience.dbo.Countries c
		WHERE
		-- не архивированная
		t.status != 2 AND
		-- издательство этой страны
		p.publisher_id = t.publisher_id AND
		c.country_id = p.country_id AND
		c.countryCurrent = 1 AND
		-- книга должна быть монографией
		t.treatiseType_id = 1 AND
		-- книга этого года
		t.yearPublication in (@year, @year+1) AND
		-- книга этого автора (ППС, потому personType = 1)
		t.treatise_id = a.treatise_id AND
		a.personType = 1 AND 
		a.person_id = @personalId
		)>0
	BEGIN
		SELECT @Result = COALESCE(@Result + ';\n\n', '') + 
			ISNULL(N'Книга\nKZ: ' + t.name_kz + N'\nRU: ' + t.name_ru + N'\nEN: ' + t.name_en +
			N'\nИздательство:' + p.name + N'\nСтрана издательства:' + c.name_ru, '')
			--AS [description]	
		FROM 
			DBScience.dbo.Treatises t,
			DBScience.dbo.L_Person_Treatise_Authors a,
			DBScience.dbo.Publishers p,
			DBScience.dbo.Countries c
		WHERE
		-- не архивированная
		t.status != 2 AND
		-- издательство этой страны
		p.publisher_id = t.publisher_id AND
		c.country_id = p.country_id AND
		c.countryCurrent = 1 AND
		-- книга этого года
		t.yearPublication in (@year, @year+1) AND
		-- книга должна быть монографией
		t.treatiseType_id = 1 AND
		-- книга этого автора (ППС, потому personType = 1)
		t.treatise_id = a.treatise_id AND
		a.personType = 1 AND 
		a.person_id = @personalId
	END
END
IF @publisherTypeId = 2 
BEGIN 
	IF (SELECT COUNT(*)
		FROM 
			DBScience.dbo.Treatises t,
			DBScience.dbo.L_Person_Treatise_Authors a,
			DBScience.dbo.Publishers p,
			DBScience.dbo.Countries c
		WHERE
		-- не архивированная
		t.status != 2 AND
		-- издательство этой страны
		p.publisher_id = t.publisher_id AND
		c.country_id = p.country_id AND
		c.countryCurrent <> 1 AND
		-- книга должна быть монографией
		t.treatiseType_id = 1 AND
		-- книга этого года
		t.yearPublication in (@year, @year+1) AND
		-- книга этого автора (ППС, потому personType = 1)
		t.treatise_id = a.treatise_id AND
		a.personType = 1 AND 
		a.person_id = @personalId
		)>0
	BEGIN
		SELECT @Result = COALESCE(@Result + ';\n\n', '') + 
			ISNULL(N'Книга\nKZ: ' + t.name_kz + N'\nRU: ' + t.name_ru + N'\nEN: ' + t.name_en +
			N'\nИздательство:' + p.name + N'\nСтрана издательства:' + c.name_ru, '')
			--AS [description]	
		FROM 
			DBScience.dbo.Treatises t,
			DBScience.dbo.L_Person_Treatise_Authors a,
			DBScience.dbo.Publishers p,
			DBScience.dbo.Countries c
		WHERE
		-- не архивированная
		t.status != 2 AND
		-- издательство этой страны
		p.publisher_id = t.publisher_id AND
		c.country_id = p.country_id AND
		c.countryCurrent <> 1 AND
		-- книга должна быть монографией
		t.treatiseType_id = 1 AND
		-- книга этого года
		t.yearPublication in (@year, @year+1) AND
		-- книга этого автора (ППС, потому personType = 1)
		t.treatise_id = a.treatise_id AND
		a.personType = 1 AND 
		a.person_id = @personalId
	END
END
-- Return the result of the function
RETURN @Result

END
go

