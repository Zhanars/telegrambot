-- =============================================
-- Author:		Yerlan
-- Create date: 23.09.2016
-- Description:	for perco
-- =============================================
CREATE TRIGGER [dbo].[StrucPosLinkUpdateForPerco]
   ON  [dbo].[univer_personal_struct_pos_link_1c]
   AFTER UPDATE,INSERT
AS 
BEGIN
	
	IF @@ROWCOUNT =0
    RETURN
	
	SET NOCOUNT ON;
	
	--Insert block, all new inserted progress_id will be writed as update
	IF EXISTS(SELECT * FROM inserted i WHERE i.status=1 AND i.structure_division_id>0) 
		AND NOT EXISTS(SELECT * FROM deleted)
	BEGIN
		INSERT INTO perco_univer_personal(personal_id, operation)
		SELECT DISTINCT tbl.personal_id, 1 FROM (
			select spl.personal_id, spl.structure_division_id, spl.personal_position_id, spl.type_id, spl.personal_rate, ROW_NUMBER() OVER(PARTITION BY spl.personal_id ORDER BY spl.type_id, spl.personal_rate DESC) row_num
	            from univer_personal_struct_pos_link_1c spl INNER JOIN inserted i ON spl.personal_id=i.personal_id
	            where spl.status=1 AND spl.structure_division_id>0
	    ) AS tbl WHERE tbl.row_num<=1 
			/*NEOBHODIMO CHTOBY PERVIY PO PRIORITETNOSTI PODRAZDELENIE ILI DOLZHNOST PO SOTRUDNIKU IZMENILSIA, INACHE NET SMYSLA MENIAT EGO V PERCO*/
			AND NOT EXISTS(SELECT * FROM inserted ii WHERE ii.personal_id=tbl.personal_id AND (ii.structure_division_id<>tbl.structure_division_id OR ii.personal_position_id<>tbl.personal_position_id))
			AND NOT EXISTS(SELECT * FROM perco_univer_personal p WHERE p.personal_id=tbl.personal_id)
	END
	
	
	--Update block.
	IF EXISTS(SELECT * FROM inserted i WHERE i.status=1 AND i.structure_division_id>0)
		AND EXISTS(SELECT * FROM deleted)
	BEGIN
		
		INSERT INTO perco_univer_personal(personal_id, operation)
		SELECT DISTINCT tbl.personal_id, 1 FROM (
			select spl.personal_id, spl.structure_division_id, spl.personal_position_id, spl.type_id, spl.personal_rate, ROW_NUMBER() OVER(PARTITION BY spl.personal_id ORDER BY spl.type_id, spl.personal_rate DESC) row_num
	            from univer_personal_struct_pos_link_1c spl INNER JOIN inserted i ON spl.personal_id=i.personal_id
	            where spl.status=1 AND spl.structure_division_id>0
	    ) AS tbl WHERE tbl.row_num<=1 
			/*NEOBHODIMO CHTOBY PERVIY PO PRIORITETNOSTI PODRAZDELENIE ILI DOLZHNOST PO SOTRUDNIKU IZMENILSIA, INACHE NET SMYSLA MENIAT EGO V PERCO*/
			AND NOT EXISTS(SELECT * FROM inserted ii WHERE ii.personal_id=tbl.personal_id AND (ii.structure_division_id<>tbl.structure_division_id OR ii.personal_position_id<>tbl.personal_position_id))
			AND NOT EXISTS(SELECT * FROM perco_univer_personal p WHERE p.personal_id=tbl.personal_id)
	END
END
go

