-- =============================================
-- Author:		@LFER
-- Create date: 2009-05-06 11:59:28.353
-- Description:	При добавлении связи с формой обучения обновляется количество связей в таблице с новостями
-- =============================================
CREATE TRIGGER [dbo].[newsEducFormLinkInsertTrigger]
   ON  [dbo].[univer_news_educationform_link]
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
	DECLARE @ni int
	DECLARE @c int
	
	DECLARE insCursor cursor 
		FOR SELECT news_id, COUNT(*) as count FROM inserted GROUP BY news_id
	
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @ni, @c
	WHILE @@FETCH_STATUS = 0
	BEGIN
		UPDATE univer_news SET news_educforms_count=news_educforms_count+@c WHERE news_id=@ni;
			
		FETCH NEXT FROM insCursor INTO @ni, @c
	END
	CLOSE insCursor
END
go

