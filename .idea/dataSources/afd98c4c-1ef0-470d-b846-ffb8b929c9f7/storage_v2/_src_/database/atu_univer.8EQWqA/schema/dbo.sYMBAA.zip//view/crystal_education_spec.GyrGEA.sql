CREATE VIEW dbo.crystal_education_spec
AS
SELECT     CAST(speciality_okpd AS NVARCHAR(10)) AS num_spec, speciality_name_kz AS spec_kaz, speciality_name_ru AS spec_rus, speciality_name_en AS spec_eng
FROM         dbo.univer_speciality
WHERE     (status = 1)
go

