
CREATE VIEW [dbo].[powerBI_univer_stazhirovka]
AS
SELECT     TOP (100) PERCENT o.order_id AS ид_приказа, osl.student_id AS ид_студента, o.order_date AS дата_приказа, o.order_year AS учебный_год, 
                      CASE o.order_type_id WHEN 41 THEN N'начало стажировки' WHEN 42 THEN N'окончание стажировки' WHEN 43 THEN N'продление стажировки' END AS тип_приказа
FROM         univer.dbo.univer_order AS o INNER JOIN
                      univer.dbo.univer_order_student_link AS osl ON o.order_id = osl.order_id
WHERE     (osl.student_id IN
                          (SELECT     st.students_id 
FROM         univer.dbo.univer_students AS st INNER JOIN
                      univer.dbo.univer_educ_plan AS p ON st.edu_levels_id = p.edu_level_id AND st.educ_plan_adm_year = p.educ_plan_adm_year AND st.education_form_id = p.education_form_id AND 
                      st.speciality_id = p.speciality_id
WHERE     (p.status = 1) AND (st.status = 1))) AND (o.order_type_id IN (41, 42, 43)) AND (o.status IN (21, 22))
ORDER BY ид_студента, дата_приказа

go

