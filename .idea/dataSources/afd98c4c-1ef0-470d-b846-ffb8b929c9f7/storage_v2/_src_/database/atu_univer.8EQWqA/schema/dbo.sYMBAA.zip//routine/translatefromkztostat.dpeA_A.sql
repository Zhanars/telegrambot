
-- =============================================
-- Author:		Саша
-- Create date: 
-- Description:	Преобразование казахских символов в символы для агенства по статистике
-- =============================================
CREATE FUNCTION [dbo].[translateFromKZToStat]
(
	@str NVARCHAR(4000)
)
RETURNS NVARCHAR(4000)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ret NVARCHAR(4000)

	-- Add the T-SQL statements to compute the return value here
	SELECT @ret = REPLACE(@str, N'қ' collate KAZAKH_100_CS_AS, N'ќ')--
	SELECT @ret = REPLACE(@ret, N'Қ' collate KAZAKH_100_CS_AS, N'Ќ')--
									
	SELECT @ret = REPLACE(@ret, N'ң' collate KAZAKH_100_CS_AS, N'ѕ')--
	SELECT @ret = REPLACE(@ret, N'Ң' collate KAZAKH_100_CS_AS, N'Ѕ')--
									
	SELECT @ret = REPLACE(@ret, N'ә' collate KAZAKH_100_CS_AS, N'ј')--
	SELECT @ret = REPLACE(@ret, N'Ә' collate KAZAKH_100_CS_AS, N'Ј')--
									
	SELECT @ret = REPLACE(@ret, N'ғ' collate KAZAKH_100_CS_AS, N'є')--
	SELECT @ret = REPLACE(@ret, N'Ғ' collate KAZAKH_100_CS_AS, N'Є')--
									
	SELECT @ret = REPLACE(@ret, N'ұ' collate KAZAKH_100_CS_AS, N'ў')--
	SELECT @ret = REPLACE(@ret, N'Ұ' collate KAZAKH_100_CS_AS, N'Ў')--
									
	SELECT @ret = REPLACE(@ret, N'ө' collate KAZAKH_100_CS_AS, N'ґ')--
	SELECT @ret = REPLACE(@ret, N'Ө' collate KAZAKH_100_CS_AS, N'Ґ')--
									
	SELECT @ret = REPLACE(@ret, N'ү' collate KAZAKH_100_CS_AS, N'ї')--
	SELECT @ret = REPLACE(@ret, N'Ү' collate KAZAKH_100_CS_AS, N'Ї')--
	
	SELECT @ret = REPLACE(@ret, N'һ' collate KAZAKH_100_CS_AS, N'ћ')--	
	SELECT @ret = REPLACE(@ret, N'Һ' collate KAZAKH_100_CS_AS, N'Ћ')--
		
	SELECT @ret = REPLACE(@ret, N'І' collate KAZAKH_100_CS_AS, N'І')--	
	SELECT @ret = REPLACE(@ret, N'Һ' collate KAZAKH_100_CS_AS, N'і')--	
	
	RETURN @ret

END

go

