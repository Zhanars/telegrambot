
-- =============================================
-- Author:		Yerlan
-- Create date: 21.01.2013
-- Description:	Триггер, который обновляет Индикативный план кафедры или факультета в зависимости от категории.
-- =============================================
CREATE TRIGGER [dbo].[updateSUMorAVGofCHAIRorFACULTY]
   ON  [dbo].[univer_ind_plan_personal]
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	--PRINT 'upd trigger called';

    -- UPDATE statements for trigger here
    DECLARE @indPlanId int, @personalId int, @year int, /*@semester int,*/ @categoryId int, @calcType int, @strucDivId int, @dependId int;
    DECLARE @fUpdate bit, @pUpdate bit;
	
	SELECT @indPlanId = i.ind_plan_indicator_id, @personalId = i.personal_id, @year = i.year/*, @semester = i.semester*/
			,@categoryId = ipi.ind_plan_category_id, @calcType = ipi.ind_plan_indicator_calc_type, @dependId = ipi.ind_plan_indicator_depend_id
		FROM inserted i INNER JOIN univer_ind_plan_indicator ipi ON i.ind_plan_indicator_id=ipi.ind_plan_indicator_id AND ipi.status=1 
		WHERE ind_plan_personal_f_value is not null OR ind_plan_personal_f_approve_value is not null
		
	IF UPDATE(ind_plan_personal_f_value) OR UPDATE(ind_plan_personal_p_value)
		OR UPDATE(ind_plan_personal_f_approve_value) OR UPDATE(ind_plan_personal_p_approve_value)
	BEGIN
		IF UPDATE(ind_plan_personal_f_value) OR UPDATE(ind_plan_personal_f_approve_value)
		BEGIN
			SET @fUpdate = 1;
			--PRINT 'YES, F UPDATED';
		END
		IF UPDATE(ind_plan_personal_p_value) OR UPDATE(ind_plan_personal_p_approve_value)
		BEGIN
			SET @pUpdate = 1;
			--PRINT 'YES, P UPDATED';
		END

		set @dependId = isnull(@dependId,0);
			
		--PRINT ' PERSONALiD='+Convert(nvarchar(max),@personalId);
		--PRINT ' categoryId='+Convert(nvarchar(max),@categoryId);
		IF (@categoryId IN (2,3) AND @calcType>0 AND @dependId>0)
		BEGIN
			DECLARE @indPlanIndId INT, @newPersonalId INT; 
			DECLARE @fValue real, @pValue real, @fValueDesc nvarchar(max), @pValueDesc nvarchar(max);
			IF (@categoryId=3) --pps
			BEGIN
				SET @strucDivId = ISNULL((SELECT TOP 1 spl.structure_division_id FROM univer_personal_struct_pos_link_1c spl, univer_personal_position_1c pp
						WHERE spl.status=1 AND spl.personal_id = @personalId and pp.personal_position_id=spl.personal_position_id and pp.personal_position_is_teacher=1
					--ZDES PROVERAEM (wtatniy pps na etoi kafedre ili wtatniy no s adm. doljnostiu)
					AND dbo.IsPersonalInStrucDivisionByIndPlan(@personalId,spl.structure_division_id,1)=1
					ORDER BY spl.type_id),0);
				--PRINT 'strucDivId='+Convert(nvarchar(max),@strucDivId);
				--PRINT 'indPlanId='+Convert(nvarchar(max),@indPlanId);
				IF (@strucDivId>0)
				BEGIN
					SELECT @newPersonalId = hc.personal_id FROM univer_head_chair hc, univer_chair c 
						WHERE hc.status=1 AND c.status=1 AND hc.chair_id = c.chair_id AND c.structure_division_id = @strucDivId;
					IF (@fUpdate=1)
					BEGIN
						SET @fValue=dbo.IP_CalcSumOrAVGForIndicator(@indPlanId, @calcType, 2, @strucDivId, @year, /*@semester,*/ 2);
						--PRINT @fValue;
						SET @fValueDesc = dbo.IP_CalcSumOrAVGForIndicatorDESC(@indPlanId, 2, @strucDivId, @year, /*@semester,*/ 2);
						--PRINT @fValueDesc;
					END
					IF (@pUpdate=1)
					BEGIN
						SET @pValue=dbo.IP_CalcSumOrAVGForIndicator(@indPlanId, @calcType, 2, @strucDivId, @year, /*@semester,*/ 1);
						--PRINT @fValue;
						SET @pValueDesc = dbo.IP_CalcSumOrAVGForIndicatorDESC(@indPlanId, 2, @strucDivId, @year, /*@semester,*/ 1);
						--PRINT @fValueDesc;
					END
				END
				SET @indPlanIndId = @dependId;
				--(SELECT TOP 1 ind_plan_indicator_id FROM univer_ind_plan_indicator i 
				--	WHERE i.status=1 AND i.ind_plan_code_id IN (SELECT ind_plan_code_id FROM univer_ind_plan_indicator i2 
				--											WHERE i2.ind_plan_indicator_id = @indPlanId)
				--											AND i.ind_plan_category_id = 2
				--);
				--PRINT 'newPId='+Convert(nvarchar(max),@newPersonalId);
				--PRINT 'newIndicatorId='+Convert(nvarchar(max),@indPlanIndId);
			END
			ELSE IF (@categoryId=2) -- CHAIR
			BEGIN
				SELECT @strucDivId =  f.structure_division_id 
					FROM univer_faculty f , univer_head_chair hc, univer_chair c
					WHERE f.faculty_id = c.faculty_id AND f.status=1 AND c.chair_id = hc.chair_id AND hc.status=1 AND c.status=1
						AND hc.personal_id = @personalId ;
				SET @strucDivId = ISNULL(@strucDivId,0);
				--PRINT 'strucDivId='+Convert(nvarchar(max),@strucDivId);
				--PRINT 'indPlanId='+Convert(nvarchar(max),@indPlanId);
				IF (@strucDivId>0)
				BEGIN
					SELECT @newPersonalId = d.personal_id FROM univer_dekan d, univer_faculty f 
						WHERE d.status=1 AND f.status=1 AND d.faculty_id = f.faculty_id AND f.structure_division_id = @strucDivId;
					IF (@fUpdate=1)
					BEGIN
						SET @fValue=dbo.IP_CalcSumOrAVGForIndicator(@indPlanId, @calcType, 1, @strucDivId, @year, /*@semester,*/ 2);
						--PRINT @fValue;
						SET @fValueDesc = dbo.IP_CalcSumOrAVGForIndicatorDESC(@indPlanId, 1, @strucDivId, @year, /*@semester,*/ 2);
						--PRINT @fValueDesc;
					END
					IF (@pUpdate=1)
					BEGIN
						SET @pValue=dbo.IP_CalcSumOrAVGForIndicator(@indPlanId, @calcType, 1, @strucDivId, @year, /*@semester,*/ 1);
						--PRINT @fValue;
						SET @pValueDesc = dbo.IP_CalcSumOrAVGForIndicatorDESC(@indPlanId, 1, @strucDivId, @year, /*@semester,*/ 1);
						--PRINT @fValueDesc;
					END
				END
				SET @indPlanIndId = @dependId;
				--SET @indPlanIndId = (SELECT TOP 1 ind_plan_indicator_id FROM univer_ind_plan_indicator i 
				--	WHERE i.status=1 AND i.ind_plan_code_id IN (SELECT ind_plan_code_id FROM univer_ind_plan_indicator i2 
				--											WHERE i2.ind_plan_indicator_id = @indPlanId)
				--											AND i.ind_plan_category_id = 1
				--	);
				--PRINT 'newPId='+Convert(nvarchar(max),@newPersonalId);
				--PRINT 'newIndicatorId='+Convert(nvarchar(max),@indPlanIndId);
			END
			--Здесь проверяем все параметры, если хотя бы один из них не удовлетворит условие, обновление или добавление не будет
			IF (@indPlanIndId IS NOT NULL AND ((@fValue IS NOT NULL AND @fUpdate=1) OR (@pValue IS NOT NULL AND @pUpdate=1)) AND @newPersonalId>0)
			BEGIN
				IF EXISTS(
					SELECT * FROM univer_ind_plan_personal p 
					WHERE p.personal_id = @newPersonalId AND p.ind_plan_indicator_id=@indPlanIndId AND p.year=@year /*AND semester=@semester*/
				)
				BEGIN
					--PRINT 'UPDATE';
					IF (@fUpdate=1)
					BEGIN
						UPDATE univer_ind_plan_personal SET 
							--ind_plan_personal_p_value_desc=(CASE WHEN @pUpdate=1 THEN @fValueDesc ELSE ind_plan_personal_p_value_desc END), 
							--ind_plan_personal_p_value = (CASE WHEN @pUpdate=1 THEN @pValue ELSE ind_plan_personal_p_value END),
							--ind_plan_personal_p_create=(CASE WHEN @pUpdate=1 THEN GETDATE() ELSE ind_plan_personal_p_create END), 					
							ind_plan_personal_f_value=@fValue, 
							ind_plan_personal_f_value_desc = @fValueDesc,
							ind_plan_personal_f_create=GETDATE() 
						WHERE personal_id=@newPersonalId AND ind_plan_indicator_id=@indPlanIndId AND year=@year /*AND semester = @semester*/;
					END
					IF (@pUpdate=1)
					BEGIN
						UPDATE univer_ind_plan_personal SET 
							--ind_plan_personal_p_value_desc=(CASE WHEN @pUpdate=1 THEN @fValueDesc ELSE ind_plan_personal_p_value_desc END), 
							--ind_plan_personal_p_value = (CASE WHEN @pUpdate=1 THEN @pValue ELSE ind_plan_personal_p_value END),
							--ind_plan_personal_p_create=(CASE WHEN @pUpdate=1 THEN GETDATE() ELSE ind_plan_personal_p_create END), 					
							ind_plan_personal_p_value=@pValue, 
							ind_plan_personal_p_value_desc = @pValueDesc,
							ind_plan_personal_p_create=GETDATE() 
						WHERE personal_id=@newPersonalId AND ind_plan_indicator_id=@indPlanIndId AND year=@year /*AND semester = @semester*/;
					END
					--UPDATE univer_ind_plan_personal SET 
					--			ind_plan_personal_p_value_desc=(CASE WHEN @pUpdate=1 THEN @pValueDesc ELSE ind_plan_personal_p_value_desc END), 
					--			ind_plan_personal_p_value = (CASE WHEN @pUpdate=1 THEN @pValue ELSE ind_plan_personal_p_value END),
					--			ind_plan_personal_p_create=(CASE WHEN @pUpdate=1 THEN GETDATE() ELSE ind_plan_personal_p_create END), 					
					--			ind_plan_personal_f_value_desc=(CASE WHEN @fUpdate=1 THEN @fValueDesc ELSE ind_plan_personal_f_value_desc END), 
					--			ind_plan_personal_f_value = (CASE WHEN @fUpdate=1 THEN @fValue ELSE ind_plan_personal_f_value END),
					--			ind_plan_personal_f_create=(CASE WHEN @fUpdate=1 THEN GETDATE() ELSE ind_plan_personal_f_create END) 		
					--		WHERE personal_id=@newPersonalId AND ind_plan_indicator_id=@indPlanIndId AND year=@year AND semester = @semester;
				END	
				ELSE
				BEGIN
					--PRINT 'INSERT';
					INSERT INTO univer_ind_plan_personal
					(ind_plan_indicator_id,personal_id,year/*,semester*/
					   ,ind_plan_personal_p_value
					   ,ind_plan_personal_p_value_desc
					   ,ind_plan_personal_p_approve_value
					   ,ind_plan_personal_p_approve
					   ,ind_plan_personal_p_approve_desc
					   ,ind_plan_personal_p_create
					   ,ind_plan_personal_p_update
					   ,ind_plan_personal_f_value
					   ,ind_plan_personal_f_value_desc
					   ,ind_plan_personal_f_approve_value
					   ,ind_plan_personal_f_approve
					   ,ind_plan_personal_f_approve_desc
					   ,ind_plan_personal_f_create
					   ,ind_plan_personal_f_update)
					VALUES (
							@indPlanIndId, @newPersonalId, @year/*, @semester*/
							,(CASE WHEN @pUpdate=1 THEN @pValue ELSE 0 END)
							,(CASE WHEN @pUpdate=1 THEN @pValueDesc ELSE NULL END)
							,NULL
							,0
							,NULL
							,GETDATE()
							,NULL
							,(CASE WHEN @fUpdate=1 THEN @fValue ELSE 0 END)
							,(CASE WHEN @fUpdate=1 THEN @fValueDesc ELSE NULL END)
							,NULL
							,0
							,NULL
							,GETDATE()
							,NULL
						)
				END	
			END
		END
	END
END
go

