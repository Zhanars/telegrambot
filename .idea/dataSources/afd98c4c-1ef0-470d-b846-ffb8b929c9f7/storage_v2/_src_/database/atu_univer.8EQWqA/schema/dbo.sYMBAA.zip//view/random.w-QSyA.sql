CREATE VIEW RANDOM   

AS  

SELECT RAND() as random


go

