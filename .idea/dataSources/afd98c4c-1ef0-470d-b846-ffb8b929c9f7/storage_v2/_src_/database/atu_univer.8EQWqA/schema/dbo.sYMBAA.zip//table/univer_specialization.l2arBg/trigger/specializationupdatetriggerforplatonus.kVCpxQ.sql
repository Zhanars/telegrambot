create TRIGGER [dbo].[specializationUpdateTriggerForPlatonus]
   ON  [dbo].[univer_specialization] 
   AFTER UPDATE,INSERT,DELETE
AS 
BEGIN
	
	IF @@ROWCOUNT =0
    RETURN
	
	SET NOCOUNT ON;
	
	--Insert block, all new inserted subject_id will be writed as update
	IF EXISTS(SELECT * FROM inserted) AND NOT EXISTS(SELECT * FROM deleted)
	BEGIN
		INSERT INTO platonus_univer_specialization(specialization_id, operation)
		SELECT specialization_id,1 FROM inserted i 
		WHERE i.status=1 AND i.specialization_id NOT IN (SELECT specialization_id FROM platonus_univer_specialization)
	END
	
	
	--Update block, all new updated subject_id will be writed as update, and old subject_id from deleted will be writed as delete.
	--This block usually triggers when programmer updates subject_id in educ_plan_pos table to zips catalog of subject.
	--Delete will trigger only for subject_id changing
	IF (UPDATE(specialization_name_ru) OR UPDATE(specialization_name_kz) or update(specialization_name_en) or update(status)) 
	AND EXISTS(SELECT * FROM inserted) AND EXISTS(SELECT * FROM deleted)
	BEGIN
		delete from platonus_univer_specialization where specialization_id in (select specialization_id from deleted)
		
		insert into platonus_univer_specialization(specialization_id, operation)
		select i.specialization_id, 1 from inserted i where i.status=1
		
		insert into platonus_univer_specialization(specialization_id, operation)
		select i.specialization_id, 2 from inserted i, deleted d where i.specialization_id=d.specialization_id and i.status=2 and d.status=1
		
	END
	
	--DELETE block, in univer there are only 2 ways: insert and delete. 
	IF EXISTS(SELECT * FROM deleted d WHERE d.status=1) AND NOT EXISTS(SELECT * FROM inserted i)
	BEGIN
		delete from platonus_univer_specialization where specialization_id in (select specialization_id from deleted where status=1)
		
		INSERT INTO platonus_univer_specialization(specialization_id,operation)
		SELECT specialization_id,2 FROM deleted d 
		WHERE d.status=1
	END
END
go

