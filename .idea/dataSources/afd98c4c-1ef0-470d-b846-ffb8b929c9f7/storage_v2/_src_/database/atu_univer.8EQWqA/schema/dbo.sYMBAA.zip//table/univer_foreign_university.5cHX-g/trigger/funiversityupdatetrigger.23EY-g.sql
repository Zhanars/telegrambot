-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[FUniversityUpdateTrigger] 
   ON  [dbo].[univer_foreign_university]
   AFTER INSERT,DELETE,UPDATE
AS 
BEGIN
	IF @@ROWCOUNT =0
    RETURN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
    if exists(select * from inserted) and not exists(select * from deleted)
    begin 
		insert into platonus_univer_foreignuniversities(universities_id, operation)
		select i.foreign_university_id,1 from inserted i, univer_country c 
		where i.status=1 and i.country_id=c.country_id and c.country_foreign_type in (1,2)
		and i.foreign_university_id not in (select universities_id from platonus_univer_foreignuniversities)
    end
    
    if exists(select * from inserted) and exists(select * from deleted)
    begin
		delete from platonus_univer_foreignuniversities where universities_id in (select foreign_university_id from deleted)
		
		insert into platonus_univer_foreignuniversities(universities_id, operation)
		select i.foreign_university_id, 1 from inserted i, univer_country c 
		where i.status=1 and i.country_id=c.country_id and c.country_foreign_type in (1,2)
		
		insert into platonus_univer_foreignuniversities(universities_id, operation)
		select i.foreign_university_id, 2 from inserted i, deleted d, univer_country c 
		where i.status=2 and d.status=1 and i.foreign_university_id=d.foreign_university_id
		and i.country_id=c.country_id and c.country_foreign_type in (1,2)
		
    end
    
    if not exists(select * from inserted) and exists(select * from deleted where status=1)
    begin
		delete from platonus_univer_foreignuniversities 
		where universities_id in (select foreign_university_id from deleted where status=1)
		
		insert into platonus_univer_foreignuniversities(universities_id, operation)
		select foreign_university_id, 2 from deleted d, univer_country c where d.status=1
		and d.country_id=c.country_id and c.country_foreign_type in (1,2)
    end
    

END
go

