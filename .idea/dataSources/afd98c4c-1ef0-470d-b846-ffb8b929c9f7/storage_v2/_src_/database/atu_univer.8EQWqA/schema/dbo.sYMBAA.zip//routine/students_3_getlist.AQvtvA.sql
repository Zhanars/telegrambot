-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[students_3_getList]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	select 
	st.students_sname,st.students_name,st.students_father_name as fio,
	f.faculty_name_ru,
	sp.speciality_name_ru,
	st.students_mobile_phone,
	st.students_contact_town_phone,
	st.students_email
from dbo.univer_students st
	left join dbo.univer_faculty f
		on f.faculty_id=st.faculty_id
	left join dbo.univer_speciality sp
		on sp.speciality_id=st.speciality_id
where st.status=1 and st.stage_id=11
	and st.students_curce_number=3
	order by f.faculty_id
END
go

