CREATE VIEW dbo.site_personal_premium_1c
AS
SELECT     dbo.univer_personal.personal_id, dbo.univer_personal_premium_1c.premium_id, dbo.univer_premium_1c.premium_name_kz, 
                      dbo.univer_premium_1c.premium_name_ru, dbo.univer_premium_1c.premium_name_en, 
                      CASE WHEN dbo.univer_personal_premium_1c.personal_premium_date < '3086-10-21 00:00:00.000' THEN NULL ELSE DATEADD(YYYY, - 2000, 
                      dbo.univer_personal_premium_1c.personal_premium_date) END AS personal_premium_date
FROM         dbo.univer_personal_premium_1c INNER JOIN
                      dbo.univer_premium_1c ON dbo.univer_personal_premium_1c.premium_id = dbo.univer_premium_1c.premium_id INNER JOIN
                      dbo.univer_personal ON dbo.univer_personal_premium_1c.personal_id = dbo.univer_personal.personal_id
go

