
CREATE TRIGGER [dbo].[countryUpdateTriggerForPlatonus]
   ON  [dbo].[univer_country] 
   AFTER UPDATE,INSERT,DELETE
AS 
BEGIN
	
	IF @@ROWCOUNT =0
    RETURN
	
	SET NOCOUNT ON;
	
	--Insert block, all new inserted subject_id will be writed as update
	IF EXISTS(SELECT * FROM inserted) AND NOT EXISTS(SELECT * FROM deleted)
	BEGIN
		INSERT INTO platonus_univer_country(country_id, operation)
		SELECT country_id, 1 FROM inserted i 
		WHERE i.status=1 and i.country_id not in (select country_id from platonus_univer_country)
	END
	
	
	IF (UPDATE(country_name_ru) OR UPDATE(country_name_kz) or update(country_name_en) or update(status)
	or update(country_code) or update(country_foreign_type)) 
	and EXISTS(SELECT * FROM inserted) AND EXISTS(SELECT * FROM deleted)
	BEGIN
		
		
		delete from platonus_univer_country where country_id in (select d.country_id from deleted d)
		
		insert into platonus_univer_country(country_id, operation)
		select i.country_id, case when i.status=1 then 1 else 2 end 
		from inserted i, deleted d where i.country_id=d.country_id and i.status=2 and d.status=1
		
	END
	
	--DELETE block, in univer there are only 2 ways: insert and delete. 
	IF EXISTS(SELECT * FROM deleted d WHERE d.status=1) AND NOT EXISTS(SELECT * FROM inserted i)
	BEGIN
		delete from platonus_univer_country where country_id in (select country_id from deleted where status=1)
		
		INSERT INTO platonus_univer_country(country_id,operation)
		SELECT country_id, 2 FROM deleted d 
		WHERE d.status=1
	END
END

go

