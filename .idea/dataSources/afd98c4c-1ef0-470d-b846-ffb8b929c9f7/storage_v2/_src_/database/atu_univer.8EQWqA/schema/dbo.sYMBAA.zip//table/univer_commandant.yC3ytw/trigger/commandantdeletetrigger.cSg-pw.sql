-- =============================================
-- Author:		Ruslan
-- Create date: 15.07.2016
-- Description:	Триггер на удаление коменданта
-- =============================================
CREATE TRIGGER [dbo].[commandantDeleteTrigger]
   ON  [dbo].[univer_commandant]
   FOR DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @pi int
	DECLARE @st int
	
	DECLARE insCursor cursor 
		FOR SELECT personal_id FROM deleted
	
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @pi
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC dbo.personalDeleteAccess @pi, 'COMMANDANT'
			
		FETCH NEXT FROM insCursor INTO @pi
	END
	CLOSE insCursor
END
go

