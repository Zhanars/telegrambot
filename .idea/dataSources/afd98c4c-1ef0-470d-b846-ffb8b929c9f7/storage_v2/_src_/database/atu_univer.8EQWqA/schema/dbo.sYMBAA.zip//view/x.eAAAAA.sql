CREATE VIEW dbo.x
AS
SELECT     s.students_id
FROM         dbo.univer_students AS s INNER JOIN
                      dbo.univer_educ_plan AS ep ON s.education_form_id = ep.education_form_id AND s.speciality_id = ep.speciality_id AND s.edu_levels_id = ep.edu_level_id AND 
                      s.educ_plan_adm_year = ep.educ_plan_adm_year
WHERE     (ep.status = 1) AND (s.status = 1) AND (ep.educ_plan_adm_year + (ep.educ_plan_number_of_semestr - 1) / 2 > 2009) AND (s.education_form_id = 1) AND 
                      (s.stage_id = 2) AND (s.payment_forms_id = 2) AND (s.faculty_id = 14) AND (s.citizenship_id = 1) AND (s.student_edu_status_id = 1) AND
                          ((SELECT     COUNT(*) AS Expr1
                              FROM         dbo.univer_progress AS p
                              WHERE     (student_id = s.students_id) AND (status = 1) AND (academ_year BETWEEN ep.educ_plan_adm_year AND 2009) AND (mark_type_id IN (16, 12, 18, 21)) 
                                                    AND (subject_type NOT IN (2)) AND (progress_credit > 0)) = 0) AND (dbo.getGPAForStudentRound(s.students_id, 0, 0, 1) >= 1.5) OR
                      (ep.status = 1) AND (s.status = 1) AND (s.education_form_id = 1) AND (s.stage_id = 2) AND (s.payment_forms_id = 2) AND (s.faculty_id = 14) AND (s.citizenship_id = 1) 
                      AND (s.student_edu_status_id > 1) AND (dbo.getGPAForStudentRound(s.students_id, 0, 0, 1) >= 1.5) AND (s.student_edu_status_id = 1) AND
                          ((SELECT     COUNT(*) AS Expr1
                              FROM         dbo.univer_progress AS p
                              WHERE     (student_id = s.students_id) AND (status = 1) AND (academ_year BETWEEN ep.educ_plan_adm_year AND 2009) AND (mark_type_id IN (16, 12, 18, 21)) 
                                                    AND (subject_type NOT IN (2)) AND (progress_credit > 0)) = 0)
go

