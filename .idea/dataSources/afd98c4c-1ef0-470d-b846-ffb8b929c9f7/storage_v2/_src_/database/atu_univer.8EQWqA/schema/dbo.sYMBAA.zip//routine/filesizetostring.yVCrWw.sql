-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION test
(
	@size bigint
)
RETURNS nvarchar(10)
AS
BEGIN
DECLARE @x real, @i int
    set @i=1; set @x=convert(real,@size)
    while @x >= 1024
		begin
		declare @l real; set @l= @x/convert(real,1024);
			set @x = @l;
			set @i=@i+1;
		end
	return convert(nvarchar, @x, 5)+' '+ case @i when 1 then N'б'
											when 2 then N'Кб'
											when 3 then N'Мб'
											when 4 then N'Гб'
											when 5 then N'Тб'
											else '' end

END
go

