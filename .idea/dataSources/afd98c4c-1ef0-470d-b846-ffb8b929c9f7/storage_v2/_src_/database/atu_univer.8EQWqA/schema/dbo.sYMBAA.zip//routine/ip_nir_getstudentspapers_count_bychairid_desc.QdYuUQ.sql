-- =============================================
-- Author:		Twice
-- Create date: 31.01.2012
-- Description: Получить количество публикаций студентов, магистрантов, докторантов (1 - в казахстанских изданиях по МОН РК, 2 - ближнее зарубежье, 3 - дальнее зарубежье) - в разрезе кафедр
-- =============================================
CREATE FUNCTION IP_NIR_getStudentsPapers_Count_ByChairId_DESC
(
	@chairId int,
	@year int,
	@publisherTypeId int
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @Result NVARCHAR(MAX)

SELECT @Result = N''

-- Return the result of the function
RETURN @Result

END
go

