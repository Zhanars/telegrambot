



-- =============================================
-- Author:		Ruslan
-- Create date: 06.09.2017
-- Description:	Определить находится ли студент в неутвержденном представлении
-- =============================================
CREATE FUNCTION [dbo].[IsStudentInNotApprovedDormitoryApplicant]
(
 @studentId int,
 @year int
)
RETURNS int
AS
BEGIN
	DECLARE @ret int=0;

	if EXISTS(SELECT student_id 
	  FROM univer_dormitory_applicant_students das, univer_dormitory_applicant da
	  WHERE das.dormitory_applicant_id = da.dormitory_applicant_id and das.student_id = @studentId and das.status = 1 
	  and da.status = 1 and da.year = @year and da.dormitory_applicant_status != 4
	  )
	begin
		set @ret = 1;
	end;

	RETURN isnull(@ret,0);
END


go

