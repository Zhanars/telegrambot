-- =============================================
-- Author:		Nurzhan	
-- Create date: 17.10.2011
-- Description:	Получаем список кафедр по факультетам
-- =============================================
CREATE PROCEDURE [dbo].[getChairsForSite]
AS
BEGIN
	SELECT fac.faculty_id,ch.chair_id, fac.faculty_full_name_en, fac.faculty_full_name_kz, fac.faculty_full_name_ru, ch.chair_name_en, ch.chair_name_kz, ch.chair_name_ru from univer_faculty fac left JOIN univer_chair ch ON fac.faculty_id = ch.faculty_id
where fac.status = 1 and ch.status = 1
END
go

