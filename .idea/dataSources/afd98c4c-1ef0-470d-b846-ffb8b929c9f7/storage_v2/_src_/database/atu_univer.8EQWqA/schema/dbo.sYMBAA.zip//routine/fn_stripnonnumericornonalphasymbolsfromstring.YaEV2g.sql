-- =============================================
-- Author:		Daniyar Aitmukash	
-- Create date: 13.01.2017
-- Description:	Функция для удаления из строки не алфабитных,не числовых символов, кроме точки и нижней черточки
-- =============================================
CREATE FUNCTION [dbo].[fn_StripNonNumericOrNonAlphaSymbolsFromString]
(
    @String NVARCHAR(MAX)
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
    declare @MatchExpression nvarchar(100)= '%[' + '^a-z0-9._' + ']%';
	set @String=REPLACE(REPLACE(@String, '-','_'), ' ', '');

    WHILE PatIndex(@MatchExpression, @String) > 0
        SET @String = Stuff(@String, PatIndex(@MatchExpression, @String), 1, '') 
    RETURN @String 
END
go

