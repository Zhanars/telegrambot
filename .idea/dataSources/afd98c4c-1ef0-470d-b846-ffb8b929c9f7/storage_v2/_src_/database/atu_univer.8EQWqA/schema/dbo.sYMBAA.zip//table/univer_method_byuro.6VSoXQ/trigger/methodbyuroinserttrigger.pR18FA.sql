-- =============================================
-- Author:		ulugbek
-- Create date: 2011-11-14
-- Description:	Добавление права доступа сотруднику при добавлении строки
-- =============================================
create TRIGGER [dbo].[methodByuroInsertTrigger] ON  [dbo].[univer_method_byuro] FOR INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	-- Insert statements for trigger here
	-- Цифра доступа для данной сущности
	DECLARE @pi int
	
	DECLARE insCursor cursor 
		FOR SELECT personal_id FROM inserted WHERE status=1
		
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @pi
	WHILE @@FETCH_STATUS = 0
	BEGIN
		exec dbo.personalSetAccess @pi, 'METHOD_BYURO'
		FETCH NEXT FROM insCursor INTO @pi;
	END
	CLOSE insCursor
END
go

