
-- =============================================
-- Author:		Twice
-- Create date: 30.05.2012
-- Description:	Добавление в пользователи Науки созданного преподавателя
-- =============================================
CREATE PROCEDURE [dbo].[SCI_PPS_newAccount] 
	@personal_id int = 0
AS
BEGIN
	SET NOCOUNT ON;	
	--DECLARE @user_id int 
	--SELECT @user_id = p.user_id
	--FROM univer_personal p
	--WHERE p.personal_id = @personal_id	
	---- если такого пользователя нет ещё в таблице пользователей Науки
	--IF ((SELECT COUNT(*) FROM DBScience.dbo.univer_userAccounts ua WHERE ua.univer_user_id = @user_id) = 0)
	--BEGIN
	--	-- Добавить в таблицу пользователей Науки нового препода с ролью ППС (id=8)
	--	INSERT INTO DBScience.dbo.univer_userAccounts 
	--	(univer_user_id, status, person_id, personType, role_id)
	--	VALUES 
	--	(@user_id, 1, @personal_id, 1, 8)
 --   END
END
go

