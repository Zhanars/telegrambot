CREATE FUNCTION [dbo].[getNumberFromString]
(
@Src nvarchar(16)
)
RETURNS nvarchar(16)
AS 
BEGIN
DECLARE @Ret nvarchar(255);
declare @Res nvarchar(255);
declare @substr nvarchar(10);
declare @i int, @l int, @c char, @prevCPos int;
select @i=1, @l=len(@Src)
SET @Res = '';
SET @Ret = '';
while @i<=@l
begin
   set @c=upper(substring(@Src,@i,1))
    IF  isnumeric(@c)=1
        SET @Res = @Res + @c
   set @i=@i+1
end
-------------------------------
set @Res = REPLACE(@Res,'.','|');
set @Res = REPLACE(@Res,',','|');
set @Res = @Res+'|';
-------------------------------
set @i=1;
set @prevCPos=charindex('|',@Res,@i);
while @prevCPos<>0
begin
	set @substr = substring(@Res,@i,@prevCPos-@i);
	if (len(@substr)>1)
	begin
	SET @Ret = @Ret + @substr;
	end
	else
	begin
	SET @Ret = @Ret+'0'+@substr;
	end
	set @i=@prevCPos+1;
	set @prevCPos=charindex('|',@Res,@i);
end
return(@Ret)
END


go

