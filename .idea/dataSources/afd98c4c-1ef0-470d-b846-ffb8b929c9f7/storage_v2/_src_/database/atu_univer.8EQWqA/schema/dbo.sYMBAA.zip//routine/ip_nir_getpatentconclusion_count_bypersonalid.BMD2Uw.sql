-- =============================================
-- Author:		Twice
-- Create date: 31.01.2012
-- Description: Получить количество заключений о выдаче охранных документов - в разрезе сотрудника
-- =============================================
CREATE FUNCTION IP_NIR_getPatentConclusion_Count_ByPersonalId
(
	@personalId int,
	@year int
)
RETURNS real
AS
BEGIN
DECLARE @Result real

SELECT @Result = 0

-- Return the result of the function
RETURN @Result

END
go

