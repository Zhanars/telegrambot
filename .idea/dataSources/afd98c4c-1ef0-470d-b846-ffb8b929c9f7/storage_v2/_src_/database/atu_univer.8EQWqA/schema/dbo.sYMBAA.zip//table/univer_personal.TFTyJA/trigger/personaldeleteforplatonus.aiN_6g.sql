-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[personalDeleteForPlatonus]
   ON  [dbo].[univer_personal]
   AFTER delete
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    delete from platonus_univer_personals where personal_id in (select d.personal_id from deleted d);
    insert into platonus_univer_personals(personal_id, operation)
    select d.personal_id, 2 from deleted d
    
END
go

