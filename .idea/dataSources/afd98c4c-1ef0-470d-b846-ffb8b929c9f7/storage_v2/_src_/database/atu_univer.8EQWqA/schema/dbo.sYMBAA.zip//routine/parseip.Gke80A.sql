CREATE FUNCTION [dbo].[parseIP]
(
       @ui uniqueidentifier
)
RETURNS varchar(128)
AS
BEGIN
declare @hex varchar(8),  @t varchar (8), @number int = 1, @n INT = 0, @IP varchar(128) = '', @i int = 1

SET    @hex = SUBSTRING(CONVERT(VARCHAR(128), @ui), 1, 8)

WHILE @i <8
BEGIN
       set @t =  REVERSE(SUBSTRING(@hex, @i, 2))
       --SELECT @t

       WHILE @number < = LEN(@t)
       BEGIN
             SET @n = @n +
             case lower(SUBSTRING(@t, @number, 1))
                    when '0' then 0
                    when '1' then 1
                    when '2' then 2
                    when '3' then 3
                    when '4' then 4
                    when '5' then 5
                    when '6' then 6
                    when '7' then 7
                    when '8' then 8
                    when '9' then 9
                    when 'a' then 10
                    when 'b' then 11
                    when 'c' then 12
                    when 'd' then 13
                    when 'e' then 14
                    when 'f' then 15
             end * convert( decimal( 28 , 0 ) , power( 16 , @number - 1 ) )
             SET @number = @number + 1
       END
--     SELECT @n

       SET @IP = @IP + CASE WHEN LEN(@IP) >0 THEN '.' ELSE '' END + CONVERT(VARCHAR(3), @n)
       SELECT @n = 0, @number = 1
       SET @i = @i +2
END
--SELECT @IP

       -- Return the result of the function
       RETURN @IP

END
go

