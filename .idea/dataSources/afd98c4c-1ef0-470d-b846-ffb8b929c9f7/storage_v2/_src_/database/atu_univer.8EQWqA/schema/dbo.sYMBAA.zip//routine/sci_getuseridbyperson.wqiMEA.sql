-- =============================================
-- Author:		Twice
-- Create date: 21.02.2012
-- Description:	Получить univer_userId по персоне
-- =============================================
CREATE FUNCTION SCI_getUserIdByPerson 
(
	-- Add the parameters for the function here
	@personId int,
	@personType int
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result int

	
	SELECT @Result = 
	univer_user_id
	FROM DbScience.dbo.univer_userAccounts u
	WHERE u.person_id = @personId AND u.personType = @personType
	
	RETURN @Result
END
go

