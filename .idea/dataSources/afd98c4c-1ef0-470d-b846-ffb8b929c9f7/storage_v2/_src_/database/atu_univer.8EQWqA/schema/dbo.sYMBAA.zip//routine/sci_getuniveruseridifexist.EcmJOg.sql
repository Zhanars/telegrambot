-- =============================================
-- Author:		Twice
-- Create date: 21.02.2012
-- Description:	Получить user_id, если такой человек уже имеет профайл пользователя
-- =============================================
CREATE FUNCTION sci_getUniverUserIdIfExist 
(
	-- Add the parameters for the function here
	@personId int,
	@personType int
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result int

	SELECT @Result = u.user_id
		FROM 
			univer_users u
		WHERE
			(
				@personType = 1 AND 
				u.user_id = 
				(SELECT p.user_id 
				FROM univer_personal p 
				WHERE p.personal_id = @personId)
			) OR
			(
				@personType = 2 AND
				u.user_id = 
				(SELECT st.user_id
				FROM univer_students st
				WHERE st.students_id = @personId)
			)

	-- Return the result of the function
	RETURN @Result

END
go

