-- =============================================
-- Author:		Sasha
-- Create date: <20.04.2011>
-- Description:	<Тригер на присвоения "права" студента летнего семестра при создании записи>
-- =============================================
CREATE TRIGGER [dbo].[studentSummerRoleCreate] ON  [dbo].[univer_additsem_student] AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	-- Insert statements for trigger here
	-- Цифра доступа для данной сущности
	DECLARE @userId int
	DECLARE @st int
	
	DECLARE insCursor cursor
		FOR SELECT user_id, status FROM inserted
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @userId, @st
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF(@st=1)
			exec dbo.usersSetAccess @userId, 'ADDIT_STUDENT'
		FETCH NEXT FROM insCursor INTO @userId, @st;
	END
	CLOSE insCursor
END
go

