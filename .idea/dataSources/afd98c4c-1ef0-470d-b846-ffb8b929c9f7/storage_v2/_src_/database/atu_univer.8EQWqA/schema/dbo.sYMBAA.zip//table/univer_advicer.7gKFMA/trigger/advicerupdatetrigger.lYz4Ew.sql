-- =============================================
-- Author:		@LFER
-- Create date: 2009-05-22 17:44:33.680
-- Description:	Удаление или добавлении права доступа при изменении статуса сотрудника
-- =============================================
CREATE TRIGGER [dbo].[advicerUpdateTrigger]
   ON  [dbo].[univer_advicer]
   FOR UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @pi int
	DECLARE @st int
	DECLARE @ad int
	
	DECLARE insCursor cursor 
		FOR SELECT personal_id, status, advicer_id FROM inserted
	
	IF UPDATE(status)
	BEGIN
		OPEN insCursor
		FETCH NEXT FROM insCursor INTO @pi, @st,@ad
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF(@st=1)
				EXEC dbo.personalSetAccess @pi, 'ADVICER'
			ELSE
				begin 
				EXEC dbo.personalDeleteAccess @pi, 'ADVICER'
				delete from univer_advicer_student_link where advicer_id=@ad
				end
				
			FETCH NEXT FROM insCursor INTO @pi, @st,@ad
		END
		CLOSE insCursor
	END

END
go

