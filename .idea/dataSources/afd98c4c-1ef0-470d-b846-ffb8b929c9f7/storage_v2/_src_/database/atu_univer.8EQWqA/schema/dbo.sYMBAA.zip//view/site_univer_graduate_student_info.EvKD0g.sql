CREATE VIEW dbo.site_univer_graduate_student_info
AS
SELECT     TOP (100) PERCENT st.students_id, st.user_id, st.students_sname, st.students_name, st.students_father_name, st.speciality_id, st.students_thesis_en, 
                      st.students_thesis_kz, st.students_thesis_ru, sp.speciality_okpd, sp.speciality_name_en, sp.speciality_name_kz, sp.speciality_name_ru, ss.teacher_id, 
                      t.personal_id, st.stage_id, st.education_form_id, st.edu_levels_id, aw.work_name, aw.work_title, aw.work_id, aw.work_ext
FROM         dbo.univer_students AS st INNER JOIN
                      dbo.univer_student_supervisor AS ss ON st.students_id = ss.student_id INNER JOIN
                      dbo.univer_speciality AS sp ON st.speciality_id = sp.speciality_id INNER JOIN
                      dbo.univer_teacher AS t ON ss.teacher_id = t.teacher_id LEFT OUTER JOIN
                      dbo.univer_antipl_work AS aw ON aw.user_id = st.user_id AND aw.report_use_index = 0 AND aw.report_indexed IS NOT NULL
WHERE     (st.status = 1) AND (sp.status = 1)
ORDER BY t.personal_id, st.students_sname, st.students_name, st.students_father_name
go

