-- =============================================
-- Author:		@LFER
-- Create date: 2009-07-09 16:14:06.200
-- Description:	Триггер на удаление сотрудника студенческого отдела
-- =============================================
CREATE TRIGGER [dbo].[studDepDeleteTrigger]
   ON  [dbo].[univer_student_department] 
   AFTER DELETE
AS 
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    DECLARE @pi int
	DECLARE @st int
    DECLARE insCursor cursor 
		FOR SELECT personal_id FROM deleted
	
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @pi
	WHILE @@FETCH_STATUS = 0
	BEGIN
		EXEC dbo.personalDeleteAccess @pi, 'STUD_DEPART'
			
		FETCH NEXT FROM insCursor INTO @pi
	END
	CLOSE insCursor
END
go

