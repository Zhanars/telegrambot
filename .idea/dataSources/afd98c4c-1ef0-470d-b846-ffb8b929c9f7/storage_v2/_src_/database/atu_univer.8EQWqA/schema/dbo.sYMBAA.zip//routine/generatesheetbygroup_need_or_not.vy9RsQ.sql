-- =============================================
-- Author:		sasha
-- Create date: 13.10.2014
-- Description:	Генерация ведомостей по группе
-- =============================================
CREATE PROCEDURE [dbo].[generateSheetByGroup_need_or_not]  	
		@needAccess bit,
		@planId int, 
        @semestr int,
        @sheetType int,
	    @groupId int,	
		@ppId int,	
		@apm int,
		@ldId int,
		@sheetPriority int,
		@credit int,
		@ctId int,
		@subId int,
		@acY int,
		@acS int,
		@teacherId int
		
	
AS
BEGIN
	
	SET NOCOUNT ON;
    
    declare @baseMT int set @baseMT=case when @ctId in (3,4) then 16 else 12 end;
          
		
		print (N'ID Группы '+cast(@groupId as nvarchar));
		if (@teacherId=0 or exists(select * from univer_group g1, univer_educ_type et1 where g1.educ_type_id=et1.educ_type_id and g1.educ_plan_pos_id=@ppId and g1.group_id<>@groupId and g1.acpos_module=@apm  and g1.lang_division_id=@ldId and et1.educ_type_sheet_priority<@sheetPriority) or @credit<=0 or (select COUNT(*) from univer_group_student gs where gs.group_id=@groupId)<=0) 
	    begin
	    print (N'Группа '+cast(@groupId as nvarchar)+N' не подходит для создания ведомости');
	    end	else
	    begin 
	    print (N'Начинаем создавать ведомость');
	    declare @sheetId int;
	    print (N'определяем дату котроля');
	    declare @dateControl datetime;
	    select @dateControl=isnull(app.acpos_date_end, cast(GETDATE() as date)) from univer_academ_calendar_pos app where app.educ_plan_id=@planId and app.acpos_module=@apm and app.acpos_semester=@semestr and app.control_id=(select top 1 control_id from univer_controll_type_control_link ccl where sheet_type_id=@sheetType and controll_type_id=@ctId order by ccl.control_number);  
         if (@sheetType in (5,7)) begin
		select @dateControl=isnull(max(exam_time),@dateControl) from univer_exam_schedule where group_id in (select distinct g.group_id from univer_group g, univer_group_student gs, univer_group g2, univer_group_student gs2 where g.group_id=gs.group_id and g2.group_id=gs2.group_id and g.educ_plan_pos_id=g2.educ_plan_pos_id and g.acpos_module=g2.acpos_module and g.educ_lang_id=g2.educ_lang_id and g.group_retake_semestr=g2.group_retake_semestr and g.lang_division_id=g2.lang_division_id and g.group_year=g2.group_year and g.group_semestr=g2.group_semestr and gs2.student_id=gs.student_id and gs2.group_id=@groupId) and type=2;
		select @teacherId=isnull(min(teacher_id),@teacherId) from univer_exam_schedule_alternate_teacher where group_id in (select distinct g.group_id from univer_group g, univer_group_student gs, univer_group g2, univer_group_student gs2 where g.group_id=gs.group_id and g2.group_id=gs2.group_id and g.educ_plan_pos_id=g2.educ_plan_pos_id and g.acpos_module=g2.acpos_module and g.educ_lang_id=g2.educ_lang_id and g.group_retake_semestr=g2.group_retake_semestr and g.lang_division_id=g2.lang_division_id and g.group_year=g2.group_year and g.group_semestr=g2.group_semestr and gs2.student_id=gs.student_id and gs2.group_id=@groupId) and type=1;	
		
		end

	    print @dateControl	 
	    print (N'определяем допуск котроля @needAccess='+cast(@needAccess as nvarchar));
	    declare @minForRk int;
	    if (@needAccess=1)
	    select @minForRk= case when @sheetType=25 then 20 else ct.controll_type_min_rk end from univer_controll_type ct where ct.controll_type_id=@ctId; 
	    else 
	    set @minForRk=0 ;
		
	    print @minForRk 
	    
	    print (N'создаем пустую ведомость');
	    insert into univer_sheet(sheet_type_id,sheet_kind_id ,group_id,acpos_module,date_create,date_control,status)
	    values (@sheetType,1,@groupId,@apm,GETDATE(),@dateControl,1)
	    set @sheetId=@@IDENTITY;
	    print @sheetId 
	    print (N'определяем список студентов');
	    
		insert into univer_sheet_result (student_id,subject_id,n_seme,academ_year,semestr,control,sheet_id,teacher_id)
	    select distinct st.students_id, @subId,@semestr,@acY,@acS,ccl.control_id,@sheetId,@teacherId  from univer_group g, univer_group_student gs, univer_students st, univer_educ_plan_pos pp,univer_controll_type_control_link ccl where ccl.controll_type_id=@ctId and sheet_type_id=@sheetType  and g.group_id=gs.group_id and gs.student_id=st.students_id and pp.educ_plan_pos_id=g.educ_plan_pos_id and g.group_id=@groupId and st.status=1 
and ((st.student_edu_status_id=1 AND g.group_isdo IS NULL) OR (st.student_edu_status_id<>1 AND g.group_isdo IS NOT NULL))
and (select count(*) from univer_sheet_result sr, univer_sheet s where s.sheet_id=sr.sheet_id and sr.semestr=g.group_semestr and sr.academ_year=g.group_year and sr.n_seme=pp.educ_plan_pos_semestr and sr.subject_id=pp.subject_id and sr.student_id=st.students_id and s.acpos_module=g.acpos_module and s.sheet_kind_id=1 and s.sheet_type_id=@sheetType)=0 and (@minForRk=0 or (select (pr.progress_result_rk1+progress_result_rk2) from univer_progress pr where pr.subject_id=@subId and pr.n_seme=@semestr and pr.status=1 and pr.student_id=st.students_id)>=@minForRk) and (@sheetType<>5 or case when (select count(*) from univer_educ_plan_pos_self_link pk, univer_educ_plan_pos pp2 left join univer_progress pr on pr.student_id=st.students_id and pr.status=1 and pr.n_seme=pp2.educ_plan_pos_semestr and pr.subject_id=pp2.subject_id left join univer_mark_type mt on mt.mark_type_id=pr.mark_type_id where pk.educ_plan_pos_id=pp.educ_plan_pos_id and pp2.educ_plan_pos_id=pk.educ_plan_pos_id_link and ISNULL(mt.mark_type_arg,-1) in (-1,2,7,6))=0 then 1 else 0 end=1);
        
        if (@sheetType in (5,7,8,18,19)) begin
	    print (N'удаляем студентов, которые имеют долги по оплате');
	    delete from univer_sheet_result where sheet_id=@sheetId and result is null and 
	    dbo.get1cDebtForStudent(univer_sheet_result.student_id)<-10000
	    ;  
	    if ((select g.group_retake_semestr from univer_group g where g.group_id=@groupId)>0) begin
	    print (N'удаляем студентов, которые не оплатили повторное обучение');
	     delete from univer_sheet_result where sheet_id=@sheetId and result is null and student_id in (select sr.student_id from univer_sheet s, univer_sheet_result sr, univer_students st, univer_mark_type mt, univer_progress p left join univer_fail_order_progress_link fpl on fpl.progress_id=p.progress_id left join univer_fail_order fo on fo.fail_order_id=fpl.fail_order_id where s.sheet_id=sr.sheet_id and sr.subject_id=p.subject_id and sr.n_seme=p.n_seme and sr.student_id=p.student_id and p.status=4 and st.students_id=sr.student_id and mt.mark_type_id=p.mark_type_id and s.sheet_id=@sheetId and mt.mark_type_arg in (2, 6) and isnull(fo.status, case when st.payment_forms_id=5 and mt.mark_type_arg=6 then 7 else 1 end) not in (6,7));
        end
        end    
       /*
        if (@sheetType in (8,18,19)) begin
	    print (N'удаляем студентов, которые не загрузили дипломку');
	    delete from univer_sheet_result where sheet_id=@sheetId and result is null 
			--and (select COUNT(*) from univer_student_diplom_file df where df.student_id=univer_sheet_result.student_id)=0;
			and not EXISTS(select * from univer_antipl_work aw, univer_students st where aw.user_id=st.user_id AND st.students_id=univer_sheet_result.student_id
				AND aw.student_diplom_file_type_id=1/*Tip raboty - diplomnaia*/ 
				AND aw.report_indexed IS NOT NULL/*Rabota dobavlena v bazu istochnikov rukovoditelem*/ 
				AND aw.work_check_for_index=1/*Otpravlen studentom na proverku rukovoditeliu*/ 
				AND aw.report_check_status=2/*Status uspewno proveren*/)
        end
        */
		insert into univer_progress(student_id,subject_id,n_seme,academ_year,semestr,acpos_module,controll_type_id,cycle_id,educ_lang_id,mark_type_id,progress_credit,progress_result,progress_result_rk1,progress_result_rk2,progress_rup_kz,progress_rup_ru,progress_rup_en,status,subject_name_en,subject_name_kz,subject_name_ru,subject_type,teacher_id, educ_plan_pos_addit)
		select distinct sr.student_id,pp.subject_id,pp.educ_plan_pos_semestr,g.group_year,g.group_semestr,g.acpos_module,pp.controll_type_id,pp.cycle_id,g.educ_lang_id,@baseMT,pp.educ_plan_pos_credit,0,0,0,pp.rup_kz, pp.rup_ru,pp.rup_en,1,subject_name_en,subject_name_kz,subject_name_ru,subject_type,g.teacher_id, pp.educ_plan_pos_addit from univer_educ_plan_pos pp, univer_subject s, univer_group g, univer_sheet_result sr where sr.sheet_id=@sheetId and g.educ_plan_pos_id=pp.educ_plan_pos_id and pp.subject_id=s.subject_id and pp.status=1 and g.group_id=@groupId and (not exists(select * from univer_progress p1 where p1.student_id=sr.student_id and p1.subject_id=sr.subject_id and p1.status=1 and p1.n_seme=sr.n_seme))

		insert into univer_progress(student_id,subject_id,n_seme,academ_year,semestr,acpos_module,controll_type_id,cycle_id,educ_lang_id,mark_type_id,progress_credit,progress_result,progress_result_rk1,progress_result_rk2,progress_rup_kz,progress_rup_ru,progress_rup_en,status,subject_name_en,subject_name_kz,subject_name_ru,subject_type,teacher_id,educ_plan_pos_addit)
		select distinct sr.student_id,pp.subject_id,pp.educ_plan_pos_semestr,g.group_year,g.group_semestr,g.acpos_module,pp.controll_type_id,pp.cycle_id,g.educ_lang_id,@baseMT,pp.educ_plan_pos_credit,0,0,0,pp.rup_kz, pp.rup_ru,pp.rup_en,1,subject_name_en,subject_name_kz,subject_name_ru,subject_type,g.teacher_id, pp.educ_plan_pos_addit from univer_educ_plan_pos pp, univer_subject s, univer_group g, univer_sheet_result sr where sr.sheet_id=@sheetId and g.educ_plan_pos_id=pp.educ_plan_pos_id and pp.subject_id=s.subject_id and pp.status=1 and g.group_id=@groupId and (not exists(select * from univer_progress p1 where p1.student_id=sr.student_id and subject_id=@subId and status=1 and n_seme=@semestr))
        
        update univer_progress set academ_year=@acY, semestr=@acS where progress_id in 
        (select p.progress_id from univer_progress p, univer_sheet_result sr where sr.subject_id=p.subject_id and sr.student_id=p.student_id and sr.n_seme=p.n_seme
        and sr.sheet_id=@sheetId) and status=1


       
		if ((select COUNT(*) from univer_sheet_result where sheet_id=@sheetId)<=0)
	    delete from univer_sheet where sheet_id=@sheetId 	
        end
	
END
go

