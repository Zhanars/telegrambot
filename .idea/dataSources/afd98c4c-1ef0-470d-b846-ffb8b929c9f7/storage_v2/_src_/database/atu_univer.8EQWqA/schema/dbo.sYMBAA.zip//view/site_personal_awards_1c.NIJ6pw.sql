CREATE VIEW dbo.site_personal_awards_1c
AS
SELECT     dbo.univer_personal.personal_id, dbo.univer_awards_1c.awards_name_kz, dbo.univer_awards_1c.awards_name_ru, dbo.univer_awards_1c.awards_name_en, 
                      dbo.univer_awards_1c.status, 
                      CASE WHEN dbo.univer_personal_awards_1c.personal_awards_date < '3086-10-21 00:00:00.000' THEN dbo.univer_personal_awards_1c.personal_awards_date ELSE
                       DATEADD(YYYY, - 2000, dbo.univer_personal_awards_1c.personal_awards_date) END AS personal_awards_date
FROM         dbo.univer_personal_awards_1c INNER JOIN
                      dbo.univer_awards_1c ON dbo.univer_personal_awards_1c.awards_id = dbo.univer_awards_1c.awards_id INNER JOIN
                      dbo.univer_personal ON dbo.univer_personal_awards_1c.personal_id = dbo.univer_personal.personal_id
go

