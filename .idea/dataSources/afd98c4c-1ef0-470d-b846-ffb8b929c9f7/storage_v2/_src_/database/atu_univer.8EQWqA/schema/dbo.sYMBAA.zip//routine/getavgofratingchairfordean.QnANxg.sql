

-- =============================================
-- Author:		YERLAN
-- Create date: Подсчет ср. арифм. рейтинга Кафедры
-- Description:	Считает ср. арифм. рейтинга Кафедры для декана
-- =============================================
CREATE FUNCTION [dbo].[getAVGOfRatingChairForDean] 
(
 @facultyId int,
 @yearId int,
 @categoryId int,
 @approve bit,
 @stavka int
)
RETURNS real
AS
BEGIN
	DECLARE @ret real;
	DECLARE @status int;
	SET @status = 1;

	SELECT @ret=CONVERT(decimal(10,3), tab.scores/tab.counts) FROM (
		select COUNT(tab.counts) as counts, SUM(tab.scores) as scores from (	
				SELECT c.chair_id,COUNT(distinct p.personal_id) as counts, (CONVERT(decimal(10,3), SUM(ISNULL(irp.indicator_rating_personal_value,0)))+dbo.getAVGOfRatingPPSForChair(c.chair_id,@yearId,1,@stavka,@approve))as scores
				FROM univer_personal p LEFT JOIN univer_indicators i ON i.status=@status AND i.indicator_category_id=@categoryId
				LEFT JOIN univer_indicator_rating_personal irp ON p.personal_id=irp.personal_id AND irp.year=@yearId AND i.indicator_id=irp.indicator_id AND (irp.indicator_rating_personal_approve=@approve OR @approve=0)
				, univer_head_chair hc,  univer_chair c
				WHERE p.personal_id = hc.personal_id AND hc.chair_id=c.chair_id AND c.faculty_id=@facultyId AND p.status=@status AND p.status=hc.status 
				AND c.status=@status 
				group by c.chair_id
		) as tab
	) tab 
	RETURN isnull(ROUND(@ret, 0),0)
END

go

