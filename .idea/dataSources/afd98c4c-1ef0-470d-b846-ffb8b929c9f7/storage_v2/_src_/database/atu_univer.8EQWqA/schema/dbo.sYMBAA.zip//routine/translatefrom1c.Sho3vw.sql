
CREATE FUNCTION [dbo].[translateFrom1C]
(
	@str NVARCHAR(4000)
)
RETURNS NVARCHAR(4000)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @ret NVARCHAR(4000)

	-- Add the T-SQL statements to compute the return value here
	SELECT @ret = REPLACE(@str, N'ќ', N'қ' collate Cyrillic_General_CS_AS) 
	SELECT @ret = REPLACE(@ret, N'Ќ', N'Қ' collate Cyrillic_General_CS_AS) 
	
	SELECT @ret = REPLACE(@ret, N'ѕ', N'ң' collate Cyrillic_General_CS_AS) 
	SELECT @ret = REPLACE(@ret, N'Ѕ', N'Ң' collate Cyrillic_General_CS_AS)
	
	SELECT @ret = REPLACE(@ret, N'ј', N'ә' collate Cyrillic_General_CS_AS)
	SELECT @ret = REPLACE(@ret, N'Ј', N'Ә' collate Cyrillic_General_CS_AS)
	
	SELECT @ret = REPLACE(@ret, N'є', N'ғ' collate Cyrillic_General_CS_AS)
	SELECT @ret = REPLACE(@ret, N'Є', N'Ғ' collate Cyrillic_General_CS_AS)
	
	SELECT @ret = REPLACE(@ret, N'ў', N'ұ' collate Cyrillic_General_CS_AS)
	SELECT @ret = REPLACE(@ret, N'Ў', N'Ұ' collate Cyrillic_General_CS_AS)
	
	SELECT @ret = REPLACE(@ret, N'ґ', N'ө' collate Cyrillic_General_CS_AS)
	SELECT @ret = REPLACE(@ret, N'Ґ', N'Ө' collate Cyrillic_General_CS_AS)
	
	SELECT @ret = REPLACE(@ret, N'ї', N'ү' collate Cyrillic_General_CS_AS)
	SELECT @ret = REPLACE(@ret, N'Ї', N'Ү' collate Cyrillic_General_CS_AS)
	
	SELECT @ret = REPLACE(@ret, N'і', N'і' collate Cyrillic_General_CS_AS)
	SELECT @ret = REPLACE(@ret, N'І', N'І' collate Cyrillic_General_CS_AS)
	
	SELECT @ret = REPLACE(@ret, N'ћ', N'һ' collate Cyrillic_General_CS_AS)
	SELECT @ret = REPLACE(@ret, N'Ћ', N'Һ' collate Cyrillic_General_CS_AS)
	
	RETURN @ret
END

go

