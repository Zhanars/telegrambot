
-- =============================================
-- Author:		Yerlan
-- Create date: 02.02.2013
-- Description:	Триггер, который обновляет рейтинговую таблицу по тем показателям, у которых формула ОБЫЧНАЯ и поле=ЧИСЛО. Автоматически умножает количество с Инд. плана на стоимость показателя в рейтинге. Все это работает если оба показателя сопоставлены.
-- =============================================
CREATE TRIGGER [dbo].[updateToRatingAnketWithCursor]
   ON  [dbo].[univer_ind_plan_personal]
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
    DECLARE @indPlanId int, @personalId int, @year int, @fValue real, @fValueDesc nvarchar(max), @fValueApprove bit, @pValue real;
    
	DECLARE @cost real, @formulaId int, @costType int, @indexGoal real;
	DECLARE @categoryId int;
		
	DECLARE insCursor cursor /*LOCAL FAST_FORWARD*/ LOCAL FOR
		SELECT i.ind_plan_indicator_id, i.personal_id, i.year,(CASE when ind_plan_personal_f_approve_value is not null then ind_plan_personal_f_approve_value else ind_plan_personal_f_value end), ind_plan_personal_f_value_desc, ind_plan_personal_f_approve
				,(CASE when ind_plan_personal_p_approve_value is not null then ind_plan_personal_p_approve_value else ind_plan_personal_p_value end)
		FROM inserted i 
		WHERE i.ind_plan_personal_f_value is not null OR ind_plan_personal_f_approve_value IS NOT NULL;
		
	IF UPDATE(ind_plan_personal_f_value) OR UPDATE(ind_plan_personal_f_approve_value)
	BEGIN
		OPEN insCursor
		FETCH NEXT FROM insCursor INTO @indPlanId, @personalId, @year, @fValue,@fValueDesc,@fValueApprove,@pValue;
		WHILE @@FETCH_STATUS = 0
		BEGIN
			
			SET @categoryId = (select top 1 i.ind_plan_category_id from univer_ind_plan_indicator i where i.ind_plan_indicator_id=@indPlanId);
			set @categoryId = isnull(@categoryId,3);
			if (@categoryId=2/*CHAIR*/)
			begin
				set @indexGoal = round(((cast(@fValue as real)/(case when @pValue=0 then cast(1 as real) else cast(@pValue as real) end))),5);
			end;
			else
			begin
				set @indexGoal = round(cast(@fValue as real),5);
			end

			select TOP 1 @cost = ic.indicator_cost, @formulaId = ic.indicator_formula_id , @costType = ic.indicator_cost_type
			from univer_indicator_cost ic 
			where ic.status=1 and ic.ind_plan_indicator_id=@indPlanId AND ic.year <= @year 
			order by ic.year desc;
			IF (ISNULL(@formulaId,0)=1)
			BEGIN
				
				IF (exists(select * from univer_indicator_rating_personal where personal_id = @personalId AND ind_plan_indicator_id=@indPlanId AND year = @year))
				BEGIN
					UPDATE univer_indicator_rating_personal SET 
					indicator_rating_personal_value = Convert(real,case when @costType=1 then @indexGoal else (CASE WHEN @indexGoal=0 THEN 0 ELSE 1 END) end)*Convert(real,@cost)
					, indicator_rating_personal_value_desc = @fValueDesc
					, indicator_rating_personal_incoming_data = Convert(nvarchar(max),case when @costType=1 then @indexGoal else (CASE WHEN @indexGoal=0 THEN 0 ELSE 1 END) end)+'*'+Convert(nvarchar(max),@cost)
					, indicator_rating_personal_approve = @fValueApprove
					WHERE ind_plan_indicator_id = @indPlanId AND year = @year AND personal_id = @personalId
				END
				ELSE
				BEGIN
					INSERT INTO  univer_indicator_rating_personal 
				   ( ind_plan_indicator_id , personal_id , year 
				   , indicator_rating_personal_value , indicator_rating_personal_value_desc
				   , indicator_rating_personal_approve , indicator_rating_personal_approve_desc
				   , indicator_rating_personal_update , indicator_rating_personal_create 
				   , indicator_rating_personal_incoming_data, indicator_id )
					VALUES
					(@indPlanId, @personalId, @year, Convert(real,case when @costType=1 then @indexGoal else (CASE WHEN @indexGoal=0 THEN 0 ELSE 1 END) end)*Convert(real,@cost), @fValueDesc, @fValueApprove, NULL, NULL, GETDATE(), Convert(nvarchar(max),case when @costType=1 then @indexGoal else (CASE WHEN @indexGoal=0 THEN 0 ELSE 1 END) end)+'*'+Convert(nvarchar(max),@cost),0)
				END
			END
			ELSE IF (ISNULL(@formulaId,0)=11)/*Impact factor*/
			BEGIN
				IF (exists(select * from univer_indicator_rating_personal where personal_id = @personalId AND ind_plan_indicator_id=@indPlanId AND year = @year))
				BEGIN
					UPDATE univer_indicator_rating_personal SET 
					indicator_rating_personal_value = dbo.[IP_GetRatingIFBall](@fValue)
					, indicator_rating_personal_value_desc = @fValueDesc
					, indicator_rating_personal_incoming_data = Convert(nvarchar(max),dbo.[IP_GetRatingIFBall](@fValue))
					, indicator_rating_personal_approve = @fValueApprove
					WHERE ind_plan_indicator_id = @indPlanId AND year = @year AND personal_id = @personalId			
				END
				ELSE
				BEGIN
					INSERT INTO  univer_indicator_rating_personal 
				   ( ind_plan_indicator_id , personal_id , year 
				   , indicator_rating_personal_value , indicator_rating_personal_value_desc
				   , indicator_rating_personal_approve , indicator_rating_personal_approve_desc
				   , indicator_rating_personal_update , indicator_rating_personal_create 
				   , indicator_rating_personal_incoming_data, indicator_id)
					VALUES
					(@indPlanId, @personalId, @year, dbo.[IP_GetRatingIFBall](@fValue), @fValueDesc, @fValueApprove, NULL, NULL, GETDATE(), Convert(nvarchar(max),dbo.[IP_GetRatingIFBall](@fValue)),0)
				END
			END
			ELSE IF (ISNULL(@formulaId,0)=12)/*Index Hirwa*/
			BEGIN
				IF (exists(select * from univer_indicator_rating_personal where personal_id = @personalId AND ind_plan_indicator_id=@indPlanId AND year = @year))
				BEGIN
					UPDATE univer_indicator_rating_personal SET 
					indicator_rating_personal_value = dbo.[IP_GetRatingIHBall](@fValue)
					, indicator_rating_personal_value_desc = @fValueDesc
					, indicator_rating_personal_incoming_data = Convert(nvarchar(max),dbo.[IP_GetRatingIHBall](@fValue))
					, indicator_rating_personal_approve = @fValueApprove
					WHERE ind_plan_indicator_id = @indPlanId AND year = @year AND personal_id = @personalId			
				END
				ELSE
				BEGIN
					INSERT INTO  univer_indicator_rating_personal 
				   ( ind_plan_indicator_id , personal_id , year 
				   , indicator_rating_personal_value , indicator_rating_personal_value_desc
				   , indicator_rating_personal_approve , indicator_rating_personal_approve_desc
				   , indicator_rating_personal_update , indicator_rating_personal_create 
				   , indicator_rating_personal_incoming_data, indicator_id)
					VALUES
					(@indPlanId, @personalId, @year, dbo.[IP_GetRatingIHBall](@fValue), @fValueDesc, @fValueApprove, NULL, NULL, GETDATE(), Convert(nvarchar(max),dbo.[IP_GetRatingIHBall](@fValue)),0)
				END
			END
			ELSE IF (ISNULL(@formulaId,0)=13)/*ГЦВП */
			BEGIN
				IF (exists(select * from univer_indicator_rating_personal where personal_id = @personalId AND ind_plan_indicator_id=@indPlanId AND year = @year))
				BEGIN
					UPDATE univer_indicator_rating_personal SET 
					indicator_rating_personal_value = dbo.[IP_GetRatingGTSVPBall](@fValue)
					, indicator_rating_personal_value_desc = @fValueDesc
					, indicator_rating_personal_incoming_data = Convert(nvarchar(max),dbo.[IP_GetRatingGTSVPBall](@fValue))
					, indicator_rating_personal_approve = @fValueApprove
					WHERE ind_plan_indicator_id = @indPlanId AND year = @year AND personal_id = @personalId			
				END
				ELSE
				BEGIN
					INSERT INTO  univer_indicator_rating_personal 
				   ( ind_plan_indicator_id , personal_id , year 
				   , indicator_rating_personal_value , indicator_rating_personal_value_desc
				   , indicator_rating_personal_approve , indicator_rating_personal_approve_desc
				   , indicator_rating_personal_update , indicator_rating_personal_create 
				   , indicator_rating_personal_incoming_data, indicator_id)
					VALUES
					(@indPlanId, @personalId, @year, dbo.[IP_GetRatingGTSVPBall](@fValue), @fValueDesc, @fValueApprove, NULL, NULL, GETDATE()
						, Convert(nvarchar(max),dbo.[IP_GetRatingGTSVPBall](@fValue)),0)
				END
			END
			ELSE IF (ISNULL(@formulaId,0)=14)/*English Education Programm stud procent */
			BEGIN
				IF (exists(select * from univer_indicator_rating_personal where personal_id = @personalId AND ind_plan_indicator_id=@indPlanId AND year = @year))
				BEGIN
					UPDATE univer_indicator_rating_personal SET 
					indicator_rating_personal_value = dbo.[IP_GetRatingEnglishEducProgrammBall](@indexGoal*100)*@cost
					, indicator_rating_personal_value_desc = @fValueDesc
					, indicator_rating_personal_incoming_data = Convert(nvarchar(max),(dbo.[IP_GetRatingEnglishEducProgrammBall](@indexGoal*100)))+'*'+convert(nvarchar,@cost)
					, indicator_rating_personal_approve = @fValueApprove
					WHERE ind_plan_indicator_id = @indPlanId AND year = @year AND personal_id = @personalId			
				END
				ELSE
				BEGIN
					INSERT INTO  univer_indicator_rating_personal 
				   ( ind_plan_indicator_id , personal_id , year 
				   , indicator_rating_personal_value , indicator_rating_personal_value_desc
				   , indicator_rating_personal_approve , indicator_rating_personal_approve_desc
				   , indicator_rating_personal_update , indicator_rating_personal_create 
				   , indicator_rating_personal_incoming_data, indicator_id)
					VALUES
					(@indPlanId, @personalId, @year, dbo.[IP_GetRatingEnglishEducProgrammBall](@indexGoal*100)*@cost, @fValueDesc, @fValueApprove, NULL, NULL, GETDATE()
						, Convert(nvarchar(max),(dbo.[IP_GetRatingEnglishEducProgrammBall](@indexGoal*100)))+'*'+convert(nvarchar,@cost),0)
				END
			END
			ELSE IF (ISNULL(@formulaId,0)=15)/*VOUD */
			BEGIN
				IF (exists(select * from univer_indicator_rating_personal where personal_id = @personalId AND ind_plan_indicator_id=@indPlanId AND year = @year))
				BEGIN
					UPDATE univer_indicator_rating_personal SET 
					indicator_rating_personal_value = (case when @categoryId=2 then @fValue else @indexGoal end)*@cost
					, indicator_rating_personal_value_desc = @fValueDesc
					, indicator_rating_personal_incoming_data = Convert(nvarchar(max),(case when @categoryId=2 then @fValue else @indexGoal end))+'*'+convert(nvarchar,@cost)
					, indicator_rating_personal_approve = @fValueApprove
					WHERE ind_plan_indicator_id = @indPlanId AND year = @year AND personal_id = @personalId			
				END
				ELSE
				BEGIN
					INSERT INTO  univer_indicator_rating_personal 
				   ( ind_plan_indicator_id , personal_id , year 
				   , indicator_rating_personal_value , indicator_rating_personal_value_desc
				   , indicator_rating_personal_approve , indicator_rating_personal_approve_desc
				   , indicator_rating_personal_update , indicator_rating_personal_create 
				   , indicator_rating_personal_incoming_data, indicator_id)
					VALUES
					(@indPlanId, @personalId, @year, (case when @categoryId=2 then @fValue else @indexGoal end)*@cost, @fValueDesc, @fValueApprove, NULL, NULL, GETDATE()
						, Convert(nvarchar(max),(case when @categoryId=2 then @fValue else @indexGoal end))+'*'+convert(nvarchar,@cost),0)
				END
			END
			ELSE IF (ISNULL(@formulaId,0)=16)/*SJR*/
			BEGIN
				IF (@categoryId=3)
				begin
					set @indexGoal = case when @indexGoal=0 then -1 else @indexGoal end;
				end;
				IF (exists(select * from univer_indicator_rating_personal where personal_id = @personalId AND ind_plan_indicator_id=@indPlanId AND year = @year))
				BEGIN
					UPDATE univer_indicator_rating_personal SET 
					indicator_rating_personal_value = (case when @categoryId=2 then dbo.[IP_GetRatingSJRBall](@indexGoal*100) else @indexGoal end)*@cost
					, indicator_rating_personal_value_desc = @fValueDesc
					, indicator_rating_personal_incoming_data = Convert(nvarchar(max),(case when @categoryId=2 then dbo.[IP_GetRatingSJRBall](@indexGoal*100) else @indexGoal end))+'*'+convert(nvarchar,@cost)
					, indicator_rating_personal_approve = @fValueApprove
					WHERE ind_plan_indicator_id = @indPlanId AND year = @year AND personal_id = @personalId			
				END
				ELSE
				BEGIN
					INSERT INTO  univer_indicator_rating_personal 
				   ( ind_plan_indicator_id , personal_id , year 
				   , indicator_rating_personal_value , indicator_rating_personal_value_desc
				   , indicator_rating_personal_approve , indicator_rating_personal_approve_desc
				   , indicator_rating_personal_update , indicator_rating_personal_create 
				   , indicator_rating_personal_incoming_data, indicator_id)
					VALUES
					(@indPlanId, @personalId, @year, (case when @categoryId=2 then dbo.[IP_GetRatingSJRBall](@indexGoal*100) else @indexGoal end)*@cost, @fValueDesc, @fValueApprove, NULL, NULL, GETDATE()
						, Convert(nvarchar(max),(case when @categoryId=2 then dbo.[IP_GetRatingSJRBall](@indexGoal*100) else @indexGoal end))+'*'+convert(nvarchar,@cost),0)
				END
			END
			FETCH NEXT FROM insCursor INTO @indPlanId, @personalId, @year, @fValue,@fValueDesc,@fValueApprove,@pValue;
		END
		CLOSE insCursor
	END
END
go

disable trigger updateToRatingAnketWithCursor on univer_ind_plan_personal
go

