-- =============================================
-- Author:		Yerlan
-- Create date: 2013-11-03 17:44:33.680
-- Description:	Добавление записи о том что данные транскрипта были изменены 
-- =============================================
CREATE TRIGGER [dbo].[progressUpdateTriggerForPlatonus]
   ON  [dbo].[univer_progress]
   AFTER UPDATE,INSERT
AS 
BEGIN
	
	IF @@ROWCOUNT =0
    RETURN
	
	SET NOCOUNT ON;
	
	--Insert block, all new inserted progress_id will be writed as update
	IF EXISTS(SELECT * FROM inserted i WHERE i.status=1 AND (i.progress_result_rk1+i.progress_result_rk2+i.progress_result)>0) 
		AND NOT EXISTS(SELECT * FROM deleted)
	BEGIN
		INSERT INTO platonus_univer_progress(progress_id, command,type)
		SELECT DISTINCT progress_id,'update',(CASE WHEN ct.controll_type_section NOT IN (1,3,4) THEN 1 ELSE 2 end) 
		FROM inserted i INNER JOIN univer_controll_type ct ON ct.status=1 
		AND ct.controll_type_id = i.controll_type_id
		WHERE i.status=1 AND (i.progress_result_rk1+i.progress_result_rk2+i.progress_result)>0
		AND i.progress_id NOT IN (SELECT progress_id FROM platonus_univer_progress)
	END
	
	
	--Update block.
	IF EXISTS(SELECT * FROM inserted i WHERE i.status=1 AND (i.progress_result_rk1+i.progress_result_rk2+i.progress_result)>0)
		AND EXISTS(SELECT * FROM deleted)
	BEGIN
		INSERT INTO platonus_univer_progress(progress_id, command,type)
		SELECT DISTINCT d.progress_id,'delete',(CASE WHEN ct.controll_type_section NOT IN (1,3,4) THEN 1 ELSE 2 end) 
		FROM deleted d JOIN inserted i ON d.progress_id=i.progress_id AND d.status=1 AND i.status<>1 
		AND d.progress_id NOT IN (SELECT progress_id FROM platonus_univer_progress)
		INNER JOIN univer_controll_type ct ON ct.status=1 AND ct.controll_type_id = d.controll_type_id
		
		INSERT INTO platonus_univer_progress(progress_id, command,type)
		SELECT DISTINCT i.progress_id,'update',(CASE WHEN ct.controll_type_section NOT IN (1,3,4) THEN 1 ELSE 2 end) 
		FROM inserted i JOIN deleted d ON d.progress_id=i.progress_id AND i.status=d.status AND i.status=1
		 AND (i.progress_result_rk1+i.progress_result_rk2+i.progress_result)>0 AND NOT(i.progress_credit_ects<>d.progress_credit_ects AND i.progress_credit=d.progress_credit)
		AND i.progress_id NOT IN (SELECT progress_id FROM platonus_univer_progress)
		INNER JOIN univer_controll_type ct ON ct.status=1 AND ct.controll_type_id = i.controll_type_id
	END
	
	--DELETE block, in univer there are only 2 ways: insert and delete. 
	--IF EXISTS(SELECT * FROM deleted d WHERE d.status=1) AND NOT EXISTS(SELECT * FROM inserted i)
	--BEGIN
	--	INSERT INTO platonus_univer_progress(progress_id,command)
	--	SELECT DISTINCT progress_id,'delete' FROM deleted i 
	--	WHERE i.status=1 AND i.progress_id NOT IN (SELECT subject_id FROM platonus_univer_progress)
	--END
END
go

