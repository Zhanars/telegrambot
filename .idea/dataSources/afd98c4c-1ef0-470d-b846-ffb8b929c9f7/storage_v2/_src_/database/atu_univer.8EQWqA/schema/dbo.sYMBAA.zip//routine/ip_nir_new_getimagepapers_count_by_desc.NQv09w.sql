-- =============================================
-- Author:		Yerlan
-- Create date: 26.12.2016
-- Description: Получить описания имиджевых публикации
-- (@indicatorCode=4.2.1 - Количество имиджевых публикации достижениях КазНУ - в СМИ страны
-- @indicatorCode=4.2.2 - Количество имиджевых публикации достижениях КазНУ - в зарубежных СМИ
-- @indicatorCode=4.2.3 - Количество имиджевых публикации достижениях КазНУ - в газете "Қазақ университеті"
-- =============================================
CREATE FUNCTION [dbo].[IP_NIR_NEW_getImagePapers_Count_By_DESC]
(
	@categoryId int,
	@personalId int=0,
	@chairId int=0,
	@facultyId int=0,
	@year int=0,
	@indicatorCode varchar(10)
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @Result NVARCHAR(MAX)
-- ====================================Количество имиджевых публикации достижениях КазНУ - в СМИ страны
IF (@indicatorCode = '4.2.1')
BEGIN
	SELECT @Result = COALESCE(@Result + ';\n\n', '') + 
			CASE WHEN @categoryId=3 THEN
				ISNULL(N'Имиджевая статья\nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en +
				N'\nИздание:' + op.name + N'\nИздательство:' + pb.name + N'\nСтрана издательства:' + c.name_ru, '')
			ELSE ISNULL(
				CONVERT(NVARCHAR(MAX), ROW_NUMBER() OVER (ORDER BY dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.imagePaper_id, 4))) +N') '
				+ N'Автор(ы): ' + dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.imagePaper_id, 4) 
				+ N'Имиджевая статья:\nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en
				+ N'\nИздание:' + op.name + N'\nИздательство:' + pb.name + N'\nСтрана издательства:' + c.name_ru, '')
			END
		FROM 
			DBScience.dbo.ImagePapers p,
			DBScience.dbo.L_Person_ImagePaper_Authors a,
			DBScience.dbo.OtherPeriodicEditions op,
			DBScience.dbo.Countries c,
			DBScience.dbo.Publishers pb
		WHERE
		-- статья не архивирована
		p.status != 2 AND
		op.otherPeriodicEdition_id = p.periodicEdition_id AND
		op.publisher_id = pb.publisher_id AND
		pb.country_id = c.country_id AND
		EXISTS(select * from DBScience.dbo.IndPlanIndicator ind WHERE ind.code=@indicatorCode AND ind.ipIndicator_id=p.ipIndicator_id) AND
		-- статья этого года
		p.yearPublication in (@year, @year + 1) AND
		-- не дублированная и подтвержденная
		p.is_overlap IS NULL AND
		p.is_approve=1 AND
		-- статья этого автора (ППС, потому personType = 1)
		p.imagePaper_id = a.imagePaper_id AND
		a.personType = 1 AND 
		(
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		)
END

-- ==================================== Количество имиджевых публикации достижениях КазНУ - в зарубежных СМИ
IF (@indicatorCode = '4.2.2')
BEGIN
	SELECT @Result = COALESCE(@Result + ';\n\n', '') + 
			CASE WHEN @categoryId=3 THEN
				ISNULL(N'Имиджевая статья\nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en +
				N'\nИздание:' + op.name + N'\nИздательство:' + pb.name + N'\nСтрана издательства:' + c.name_ru, '')
			ELSE ISNULL(
				CONVERT(NVARCHAR(MAX), ROW_NUMBER() OVER (ORDER BY dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.imagePaper_id, 4))) +N') '
				+ N'Автор(ы): ' + dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.imagePaper_id, 4) 
				+ N'Имиджевая статья:\nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en
				+ N'\nИздание:' + op.name + N'\nИздательство:' + pb.name + N'\nСтрана издательства:' + c.name_ru, '')
			END
		FROM 
			DBScience.dbo.ImagePapers p,
			DBScience.dbo.L_Person_ImagePaper_Authors a,
			DBScience.dbo.OtherPeriodicEditions op,
			DBScience.dbo.Countries c,
			DBScience.dbo.Publishers pb
		WHERE
		-- статья не архивирована
		p.status != 2 AND
		op.otherPeriodicEdition_id = p.periodicEdition_id AND
		op.publisher_id = pb.publisher_id AND
		pb.country_id = c.country_id AND
		EXISTS(select * from DBScience.dbo.IndPlanIndicator ind WHERE ind.code=@indicatorCode AND ind.ipIndicator_id=p.ipIndicator_id) AND
		-- статья этого года
		p.yearPublication in (@year, @year + 1) AND
		-- не дублированная и подтвержденная
		p.is_overlap IS NULL AND
		p.is_approve=1 AND
		-- статья этого автора (ППС, потому personType = 1)
		p.imagePaper_id = a.imagePaper_id AND
		a.personType = 1 AND 
		(
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		)
END

-- ==================================== Количество имиджевых публикации достижениях КазНУ - в газете "Қазақ университеті", журнал Аль-Фараби и др.
IF (@indicatorCode = '4.2.3')
BEGIN
	SELECT @Result = COALESCE(@Result + ';\n\n', '') + 
			CASE WHEN @categoryId=3 THEN
				ISNULL(N'Имиджевая статья\nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en +
				N'\nИздание:' + op.name + N'\nИздательство:' + pb.name + N'\nСтрана издательства:' + c.name_ru, '')
			ELSE ISNULL(
				CONVERT(NVARCHAR(MAX), ROW_NUMBER() OVER (ORDER BY dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.imagePaper_id, 4))) +N') '
				+ N'Автор(ы): ' + dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.imagePaper_id, 4) 
				+ N'Имиджевая статья:\nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en
				+ N'\nИздание:' + op.name + N'\nИздательство:' + pb.name + N'\nСтрана издательства:' + c.name_ru, '')
			END
		FROM 
			DBScience.dbo.ImagePapers p,
			DBScience.dbo.L_Person_ImagePaper_Authors a,
			DBScience.dbo.OtherPeriodicEditions op,
			DBScience.dbo.Publishers pb,
			DBScience.dbo.Countries c
		WHERE
		-- статья не архивирована
		p.status != 2 AND
		op.otherPeriodicEdition_id = p.periodicEdition_id AND
		pb.publisher_id = op.publisher_id AND
		c.country_id = pb.country_id AND
		EXISTS(select * from DBScience.dbo.IndPlanIndicator ind WHERE ind.code=@indicatorCode AND ind.ipIndicator_id=p.ipIndicator_id) AND
		-- статья этого года
		p.yearPublication in (@year, @year + 1) AND
		-- не дублированная и подтвержденная
		p.is_overlap IS NULL AND
		p.is_approve=1 AND
		-- статья этого автора (ППС, потому personType = 1)
		p.imagePaper_id = a.imagePaper_id AND
		a.personType = 1 AND 
		(
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		)
END

-- Return the result of the function
RETURN ISNULL(@Result, '')

END
go

