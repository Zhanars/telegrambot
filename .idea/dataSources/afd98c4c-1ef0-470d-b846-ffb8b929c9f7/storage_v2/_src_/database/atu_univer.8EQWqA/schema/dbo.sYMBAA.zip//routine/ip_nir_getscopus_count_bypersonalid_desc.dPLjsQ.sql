-- =============================================
-- Author:		Twice
-- Create date: 01.06.2012
-- Description:	Получить количество научных трудов, опубликованных в международных научных изданиях, входящих в базу данных Scopus - по сотруднику
-- =============================================
CREATE FUNCTION [dbo].[IP_NIR_getScopus_Count_ByPersonalId_DESC]
(
	@personalId int,
	@year int
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @Result NVARCHAR(MAX)

DECLARE @count FLOAT 
SELECT @count  =COUNT(*)
	FROM 
		DBScience.dbo.Papers p,
		DBScience.dbo.L_Person_Paper_Authors a,
		DBScience.dbo.SciJournals sj
	WHERE
	-- статья не архивирована
	p.status != 2 AND
	-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
	sj.sciJournal_id = p.periodicEdition_id AND
	p.periodicEditionType_id = 1 AND
	-- журнал должен иметь галочку "относится к scopus"
	sj.indexedByScopus = 1 AND
	-- статья этого года
	p.yearPublication in (@year, @year+1) AND
	-- статья этого автора (ППС, потому personType = 1)
	p.paper_id = a.paper_id AND
	a.personType = 1 AND 
	a.person_id = @personalId
	
IF (@count > 0)
	BEGIN 
	SELECT @Result = COALESCE(@Result + ';\n\n', '') + 
		ISNULL(N'Статья\nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en +
		N'\nЖурнал:' + sj.name, '')
		--AS [description]
	FROM 
		DBScience.dbo.Papers p,
		DBScience.dbo.L_Person_Paper_Authors a,
		DBScience.dbo.SciJournals sj
	WHERE
	-- статья не архивирована
	p.status != 2 AND
	-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
	sj.sciJournal_id = p.periodicEdition_id AND
	p.periodicEditionType_id = 1 AND
	-- журнал должен иметь галочку "относится к scopus"
	sj.indexedByScopus = 1 AND
	-- статья этого года
	p.yearPublication in (@year, @year+1)  AND
	-- статья этого автора (ППС, потому personType = 1)
	p.paper_id = a.paper_id AND
	a.personType = 1 AND 
	a.person_id = @personalId		
END
ELSE
BEGIN
	SELECT @Result = N''
END

RETURN @Result

END
go

