CREATE FUNCTION [dbo].[Ad_sortGroups](@groups nvarchar(512))
RETURNS NVARCHAR(63)
as
BEGIN
	declare @ind int
	declare @token nvarchar(30) = null
	declare @tempTable table(g nvarchar(30))

	WHILE LEN(@groups) > 0
	begin
		set @ind = CHARINDEX(';', @groups)
		if(@ind > 0)
		begin
			SET @token = SUBSTRING(@groups, 1, @ind - 1)
			insert into @tempTable select LOWER(ltrim(rtrim(@token)))
			SET @groups = SUBSTRING(@groups, @ind + 1, LEN(@groups))
		END
		ELSE
		BEGIN
			SET @token = @groups
			SET @groups = NULL
			insert into @tempTable select LOWER(ltrim(rtrim(@token)))
		END
	end
	
	return substring((Select ';' + g
        From @tempTable
        Where g != N''
        group by g
        ORDER BY g
        For XML PATH ('')),2, 63)
END
go

