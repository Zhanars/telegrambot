
-- =============================================
-- Author:		Sasha
-- Create date: 13.05.2010
-- Description:	Подсчет Среднего балла традиционного для студента (@maxSem-семестр, до которого нужно считать ср.балл, если 0, то считается за все семестры; @course-курс, за который считать ср.балл, если 0 - то считается общий балл)
-- =============================================
CREATE FUNCTION [dbo].[getMarkTradForStudentRound]
(
 @studentId int,
 @maxSem int,
 @course int,
 @roundDigitCount int
)
RETURNS float
AS
BEGIN
	DECLARE @ret float

if exists (select * from univer_students where students_id=@studentId)
select @ret=round(SUM(mt.mark_trad_value)/COUNT(*),@roundDigitCount) from univer_progress p, univer_mark_type m, univer_mark_traditional mt where m.mark_type_id=p.mark_type_id and mt.mark_trad_max_ball>=dbo.getTotalForProgress(p.progress_id) and mt.mark_trad_min_ball<=dbo.getTotalForProgress(p.progress_id) and student_id=@studentId and m.mark_type_arg in (2,3,4,5) and p.status=1 and ((@course>0 and p.n_seme in (@course*2,@course*2-1) ) or @course=0) and ((@maxSem>0 and p.n_seme<@maxSem) or @maxSem=0)
else
select @ret=round(SUM(mt.mark_trad_value)/COUNT(*),@roundDigitCount) from _arc_univer_progress p, univer_mark_type m, univer_mark_traditional mt where m.mark_type_id=p.mark_type_id and mt.mark_trad_max_ball>=dbo.getTotalForProgress(p.progress_id) and mt.mark_trad_min_ball<=dbo.getTotalForProgress(p.progress_id) and student_id=@studentId and m.mark_type_arg in (2,3,4,5) and p.status=1 and ((@course>0 and p.n_seme in (@course*2,@course*2-1) ) or @course=0) and ((@maxSem>0 and p.n_seme<@maxSem) or @maxSem=0)
	
	RETURN isnull(@ret,0)

END

go

