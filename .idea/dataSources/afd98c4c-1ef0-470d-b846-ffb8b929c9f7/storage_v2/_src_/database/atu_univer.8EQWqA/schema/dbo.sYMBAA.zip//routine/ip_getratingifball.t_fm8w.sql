-- =============================================
-- Author:		
-- Create date: 
-- Description:	
-- =============================================
CREATE FUNCTION [dbo].[IP_GetRatingIFBall]
(
 @value float
)
RETURNS float
AS
BEGIN
	DECLARE @ret float;
	set @value = Round(@value,0);
    if (@value <= 0) begin set @ret = 0; end
	else if (@value > 0 and @value <= 0.5) begin set @ret = 160; end
	else if (@value > 0.5 and @value <= 1) begin set @ret = 240; end
	else if (@value > 1 and @value <= 3) begin set @ret = 500; end
	else if (@value > 3 and @value <= 5) begin set @ret = 700; end
	else if (@value > 5 and @value <= 10) begin set @ret = 1000; end
	else if (@value > 10 and @value <= 20) begin set @ret = 1500; end
	else if (@value > 20 and @value <= 30) begin set @ret = 2000; end
	else if (@value > 30 and @value <= 40) begin set @ret = 2500; end
	else if (@value > 40 and @value <= 50) begin set @ret = 3000; end
	else if (@value > 50 and @value <= 60) begin set @ret = 3500; end
	else if (@value > 60 and @value <= 70) begin set @ret = 4000; end
	else if (@value > 70 and @value <= 80) begin set @ret = 4500; end
	else if (@value > 80 and @value <= 90) begin set @ret = 5000; end
	else if (@value > 90 and @value <= 100) begin set @ret = 6000; end
	else if (@value > 100 and @value <= 110) begin set @ret = 7000; end
	else if (@value > 110 and @value <= 120) begin set @ret = 8000; end
	else if (@value > 120 and @value <= 130) begin set @ret = 9000; end
	else if (@value > 130 and @value <= 140) begin set @ret = 10000; end
	else if (@value > 140 and @value <= 150) begin set @ret = 11000; end
	else if (@value > 150) begin set @ret = 12000; end
	RETURN isnull(@ret,0);

END
go

