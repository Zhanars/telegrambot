-- =============================================
-- Author:		@LFER&Baton
-- Create date: 2009-04-24
-- Description: Установка права доступа любому поьлзователю
-- =============================================
CREATE PROCEDURE [dbo].[usersSetAccess] @user_id int, @role nvarchar(50)
AS
BEGIN	
IF @user_id>0
	BEGIN		
		UPDATE 
			univer_users 
		SET 
			user_access = user_access | CONVERT(bigint, dbo.accessGetByRole(@role)) 
		WHERE user_id=@user_id
		
		-- Добавление записи о том, что пользователю необходимо перелогиниться
		INSERT INTO univer_alert 
			(alert_code, user_id, alert_date) 
		VALUES 
			(2, @user_id, getdate())
	END
END
go

