-- =============================================
-- Author:		Twice
-- Create date: 31.01.2012
-- Description: Получить уровень обеспеченности современным оборудованием научно-технических и научно-исследовательских лабораторий/центров - в разрезе кафедр
-- =============================================
CREATE FUNCTION IP_NIR_getModernEquipment_Count_ByChairId
(
	@chairId int,
	@year int
)
RETURNS real
AS
BEGIN
DECLARE @Result real

SELECT @Result = 0

-- Return the result of the function
RETURN @Result

END
go

