

-- =============================================
-- Author:		Sasha
-- Create date: 06.10.2014
-- Description:	Суммарная оценка по прогрессу
-- =============================================
CREATE FUNCTION [dbo].[getTotalRKForProgress] 
(
 @progressId int
)
RETURNS float
AS
BEGIN
	DECLARE @ret float


declare @ct int;
declare @rk1_r real;set @rk1_r=1;
declare @rk2_r real;set @rk2_r=1;
select @ct=controll_type_id from univer_progress where progress_id=@progressId;
select @rk1_r=isnull(ctl.control_portion,1) from univer_controll_type_control_link ctl, univer_control c where ctl.controll_type_id=@ct and c.control_id=ctl.control_id and c.control_title=N'_rk1';
select @rk2_r=isnull(ctl.control_portion,1) from univer_controll_type_control_link ctl, univer_control c where ctl.controll_type_id=@ct and c.control_id=ctl.control_id and c.control_title=N'_rk2';

select @ret=round(p.progress_result_rk1*@rk1_r + p.progress_result_rk2*@rk2_r,0) from univer_progress p where p.progress_id=@progressId;


	RETURN isnull(@ret,0)

END


go

