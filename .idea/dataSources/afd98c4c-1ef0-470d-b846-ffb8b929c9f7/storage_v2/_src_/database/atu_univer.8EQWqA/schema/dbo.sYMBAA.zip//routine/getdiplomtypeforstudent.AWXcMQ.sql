-- =============================================
-- Author:		Sasha
-- Create date: 23.05.2011
-- Description:	Определение красный диплом, или нет должен получить студент @vypusk - параметр для приказа о выпуске, если=0, то не учитывается
-- =============================================
CREATE FUNCTION [dbo].[getDiplomTypeForStudent]
(
 @studentId int,
 @vypusk int
)
RETURNS int
AS
BEGIN
	DECLARE @ret int
	DECLARE @gpa float;
	DECLARE @antiplCnt int=0;
	DECLARE @diplomCnt int =0;
	declare @eduLevelId int=0;
	set @eduLevelId = (select top 1 edu_levels_id from univer_students s where s.students_id=@studentId);
	
		set @gpa=round(dbo.getGPAForStudent(@studentId,0,0),2);
	set @antiplCnt = 1;
	--if (@eduLevelId not in (6,7,8))
	--begin
	--	set @antiplCnt = (
	--					select COUNT(*)
	--					from univer_antipl_work aw , univer_students st
	--					where aw.user_id=st.user_id AND st.students_id=@studentId
	--						AND aw.student_diplom_file_type_id=1/*Tip raboty - diplomnaia*/ 
	--						AND aw.report_indexed IS NOT NULL/*Rabota dobavlena v bazu istochnikov rukovoditelem*/ 
	--						AND aw.work_check_for_index=1/*Otpravlen studentom na proverku rukovoditeliu*/ 
	--						AND aw.report_check_status=2/*Status uspewno proveren*/);
	--end;
	DECLARE @gakCnt int=0;
	/*Proverka dlia teh studentov kotorye vmesto zawwity dvajdy sdaiut GAK, takie studenty dolzhny uspewno vypuskatsia. Esli kolichestvo bolwe 1, to budem schitat chto on dvajdy sdal gos*/
	SET @gakCnt = (SELECT COUNT(*) 
					FROM univer_progress p with (nolock), univer_mark_type mt  
					WHERE p.student_id=@studentId AND p.status=1 AND p.controll_type_id IN (select ct.controll_type_id from univer_controll_type ct where ct.controll_type_section=1 and status=1 and ct.controll_type_id not in (select cl.controll_type_id from univer_control_educ_type_link el, univer_controll_type_control_link cl where cl.controll_type_id=ct.controll_type_id and cl.control_id=el.control_id and el.attendance_prop<>0)) AND mt.mark_type_id=p.mark_type_id and mt.mark_type_arg not in (2,6,7)
				);
		
	set @diplomCnt = (select COUNT(*) from univer_progress p  with (nolock) where p.student_id=@studentId and p.status=1 and p.controll_type_id IN (select ct.controll_type_id from univer_controll_type ct where ct.controll_type_section=4 and status=1));
	
		declare @gak nvarchar(max)='';
		select @gak=@gak+'('+cast(ct.controll_type_id as nvarchar)+')' from univer_controll_type ct where ct.controll_type_section in (1,4) 
		and status=1		
	    declare @att nvarchar(max)=N'';
		select @att=@att+N'('+cast(ct.controll_type_id as nvarchar)+N')' from univer_controll_type ct, univer_controll_type_mark_type_link mtl, univer_mark_type mt where 
		ct.status=1 and ct.controll_type_id=mtl.controll_type_id and mtl.mark_type_id=mt.mark_type_id and mt.mark_type_arg in (1)	
			
				
							
	DECLARE @stageId int; set @stageId=(select stage_id from univer_students where students_id=@studentId)	
	Declare @countRetake int; set @countRetake=(select COUNT(*) from univer_progress p with (nolock), univer_mark_type mt  where student_id=@studentId and status=4 and (select count(*) from univer_sheet_result sr, univer_sheet s where s.sheet_id=sr.sheet_id and sr.student_id=p.student_id and sr.subject_id=p.subject_id and sr.n_seme=p.n_seme and s.sheet_type_id=15)=0 and mt.mark_type_id=p.mark_type_id and mt.mark_type_arg in (2,3))
	select @ret=CASE 
		WHEN @countRetake<=0 and t.gak_all=t.gak_otl and t.vsego=t.otl+t.hor and @gpa>=3.5 and t.ud = 0 and t.neud = 0 and t.neudVipusk=0 and @stageId=2 and ((@antiplCnt>0 and @diplomCnt>0) OR @gakCnt>1) then 1--с отл. 	    
		WHEN @countRetake<=0 and t.gak_all=t.gak_otl and t.vsego=t.otl+t.hor and t.hor<=t.vsego/4 and t.ud = 0 and t.neud = 0 and t.neudVipusk=0 and @stageId=5 then 1--с отл. для колледжа	
		when (t.neudVipusk>0 OR (@diplomCnt<=0 AND @antiplCnt<=0 AND @gakCnt<=1) OR (@gakCnt<=1 AND @antiplCnt<=0)) and @vypusk>0 then 2 --с правом пересдачи
		when t.neud>0 and @vypusk>0 then 3 --есть задолжности (не выпускается)
		--when (/*@antiplCnt<=0 AND*/ @gakCnt<=1) then 2 --с правом пересдачи
	else 0 end from --обычный
	(select 
	
		sum(case when mt.mark_type_arg in (2,3,4,5,6,7) then 1 else 0 end)as vsego,--всего качественных оценок
		sum(case when mt.mark_type_arg in (5) then 1 else 0 end)as otl,--всего отлично
		sum(case when mt.mark_type_arg in (4) then 1 else 0 end)as hor,--всего хорошо
		sum(case when mt.mark_type_arg in (3) then 1 else 0 end)as ud,--всего удовлетворительно
		sum(case when mt.mark_type_arg in (2,7,6) then 1 else 0 end)as neud,--всего неудовлетворительно
		sum(case when mt.mark_type_arg in (2,7,6) and  @gak like N'%('+cast(controll_type_id as nvarchar)+')%' then 1 else 0 end) as neudVipusk,--неуд. по дип. и ГЭК
		sum(case when @att like N'%('+cast(controll_type_id as nvarchar)+')%' and  mt.mark_type_arg in (1) then 1 else 0 end) as attest,--всего аттестаций и зачетов
		sum(case when @gak like N'%('+cast(controll_type_id as nvarchar)+')%' then 1 else 0 end) as gak_all,--всего ГОСов и пр.
		sum(case when @gak like N'%('+cast(controll_type_id as nvarchar)+')%' and mt.mark_type_arg in (5) then 1 else 0 end) as gak_otl--ГОСов и пр. на отлично

	from univer_progress p with (nolock), univer_mark_type mt  where mt.mark_type_id=p.mark_type_id and p.status=1 and p.student_id=@studentId /*and p.subject_id not in (835)*//*военка не влияет на тип диплома*/) t
	RETURN isnull(@ret,0);--[dbo].[getDiplomTypeForStudentGak](@studentId,@vypusk,1)

END


go

