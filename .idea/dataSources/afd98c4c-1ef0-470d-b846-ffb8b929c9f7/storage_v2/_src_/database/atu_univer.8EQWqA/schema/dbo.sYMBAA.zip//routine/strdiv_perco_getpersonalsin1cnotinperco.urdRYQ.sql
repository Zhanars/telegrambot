-- =============================================
-- Author:		yerlan
-- Create date: 31.01.2017
-- Description:	Получить список соавторов публикаций в виде строки (только сотрудники КазНУ)
-- =============================================
CREATE FUNCTION [dbo].[strDiv_perco_GetPersonalsIn1CNotInPerco] 
(
	-- Add the parameters for the function here
	@structureDivisionID int
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result NVARCHAR(MAX) = N''
		
	SELECT @Result = COALESCE(@Result, '') + 
	ISNULL(p.personal_sname + ' ' + left(p.personal_name,1) + '.' + left(p.personal_father_name,1) + '., ', '')
	--COALESCE(@Result,	p.personal_sname, p.personal_name, p.personal_father_name + N'\n', '')
	FROM 
	dbo.univer_personal p , dbo.univer_personal_struct_pos_link_1c spl
	WHERE 
		p.personal_id = spl.personal_id
		and spl.structure_division_id = @structureDivisionID
		and p.status=1 and spl.status=1
		and not exists(select * from dbo.perco_univer_staff sf, dbo.perco_univer_subdiv sd 
						where sf.id_subdiv_internal = sd.subdiv_id_internal and sd.structure_division_id = @structureDivisionID and sf.staff_tabel_id='p_'+CAST(p.personal_id as varchar))
		and not exists(select * from dbo.perco_univer_staff sf, univer.dbo.perco_univer_subdiv sd 
						where sf.id_subdiv_internal = sd.subdiv_id_internal and sd.structure_division_id <> @structureDivisionID and sf.staff_tabel_id='p_'+CAST(p.personal_id as varchar) and sd.structure_division_id>0)
	ORDER BY p.personal_sname, p.personal_name, p.personal_father_name;
	
	IF LEN(@Result) > 1 
	BEGIN 
		SELECT @Result = LEFT(@Result, LEN(@Result) - 1)
	END
	-- Return the result of the function
	RETURN @Result
END
go

