-- =============================================
-- Author:		@LFER
-- Create date: 2009-02-27 17:07:47.207
-- Description:	Получаем список действий по массе фильтров
-- =============================================
CREATE PROCEDURE [dbo].[historyGetList] @from_date datetime, @to_date datetime, @user_id int, 
						@history_model nvarchar(50), @history_action nvarchar(50), @from int, @to int,
						@order_by nvarchar(30), @order_type nvarchar(4)
AS
BEGIN
	DECLARE @cmd nvarchar(1024), @param nvarchar(1024), @orderT nvarchar(100) ;
	
	IF(@order_by='id' OR @order_by='date' OR @order_by='model' OR @order_by='action' OR @order_by='object_id' OR @order_by='ip')
		SET @orderT='history_' + @order_by;
	ELSE IF(@order_by='user_login')
		SET @orderT='user_login';
	ELSE
		SET @orderT='history_date';

	IF(lower(@order_type)='desc' OR lower(@order_type)='inc')
		SET @orderT = @orderT + ' ' + @order_type;

	SET @cmd='WITH NUMBERS AS (SELECT history_id, history_date, hi.user_id, user_login, history_model, history_action, history_object_id, history_info, history_description, history_ip, history_link, cheater_user_id, ROW_NUMBER() OVER(ORDER BY ' + @orderT + ', history_id DESC) AS COUNT FROM univer_history hi LEFT JOIN univer_users ui ON hi.user_id=ui.user_id WHERE 1=1';
	SET @param = N'@from_date datetime, @to_date datetime, @user_id int, @history_model nvarchar(50), @history_action nvarchar(50), @from int, @to int, @order_by nvarchar(30), @order_type nvarchar(4)'
	
	IF(ISNULL(@from_date, 0)!=0)
		SET @cmd = @cmd + ' AND history_date>=@from_date';
	
	IF(ISNULL(@to_date, 0)!=0)
		SET @cmd = @cmd + ' AND history_date<=@to_date';

	IF(ISNULL(@user_id, 0)!=0 AND @user_id>0)
		SET @cmd = @cmd + ' AND hi.admin_id=@admin_id';

	IF(ISNULL(@history_model, '')!='' AND @history_model!='')
		SET @cmd  = @cmd + ' AND history_model LIKE ''%''+@history_model+''%''';

	IF(ISNULL(@history_action, '')!='' AND @history_action!='')
		SET @cmd  = @cmd + ' AND history_action LIKE ''%''+@history_action+''%''';

	SET @cmd = @cmd + ') SELECT * FROM NUMBERS WHERE 1=1';
	
	IF(ISNULL(@from, 0)!=0 AND @from>0)
		SET @cmd = @cmd + ' AND COUNT>=@from';
	
	IF(ISNULL(@to, 0)!=0 AND @to>0)	
		SET @cmd = @cmd + ' AND COUNT<=@to';

	EXECUTE sp_executesql @cmd, @param, @from_date, @to_date, @user_id, @history_model, @history_action, @from, @to, @order_by, @order_type
END
go

