
-- =============================================
-- Author:		sasha
-- Create date: 11.01.2018
-- Description:	Обновление ECTS в univer_progress
-- =============================================
CREATE PROCEDURE [dbo].[updECTS_ALL]
AS
BEGIN
	
	SET NOCOUNT ON;
begin transaction
--таблица для выборки норм из xml
declare @ects_norm table(educFormId int,stageId int, eduLevelId int, academYear int, subjType int, specId int, subjectId int, practiceType int, credit int, val real, controllTypeId int);
--все возможные кредиты
declare @credits table(credit int)
declare @min int=0, @max int=0;
 select @max=max(ects_case_value.query('/ArrayOfEntry/Entry').value('max(Entry/Key)', 'int')), @min=min(ects_case_value.query('/ArrayOfEntry/Entry').value('min(Entry/Key)', 'int')) from univer_ects_ratio r where status=1
  /*select @max=max(progress_credit), @min=min(progress_credit) from univer_progress where status=1 and student_id in (select s.students_id from univer_students s where s.status=1)*/
--заполняем кредиты
 while @min<=@max
 begin
 insert into @credits (credit)
 values (@min)
 set @min=@min+1
 end
 --заполняем нормы
 insert into @ects_norm (educFormId,stageId, eduLevelId, academYear, subjType, specId, subjectId, practiceType, 
 credit, val, controllTypeId)
select distinct  isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="educFormId"]/Value)[1]', 'int'),0) educFormId,
 isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="stageId"]/Value)[1]', 'int'),0) stageId,
 isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="eduLevelId"]/Value)[1]', 'int'),0) eduLevelId,
 isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="academYear"]/Value)[1]', 'int'),0) academYear,
 isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="subjType"]/Value)[1]', 'int'),0) subjType,
 isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="specId"]/Value)[1]', 'int'),0) specId,
 isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="subjectId"]/Value)[1]', 'int'),0) subjectId,
 isnull(ects_compare_filter.value('(/ArrayOfEntry/Entry[Key="practiceType"]/Value)[1]', 'int'),0)  practiceType, 
 c.credit,
 case when ects_const_value>0 then 
	ects_const_value 
else 
	case when ects_calc_type=1 then
		case when ects_max_value>0 and credit*ects_ratio>ects_max_value then ects_max_value else credit*ects_ratio end
	else
		 cast(isnull(ects_case_value.value('(/ArrayOfEntry/Entry[Key=sql:column("credit")]/Value)[1]', 'float'),0) as real)
	end
end, controll_type_id  from univer_ects_ratio r, @credits c where status=1;
--прогресс, в котором нужно обновить ects
declare @upd_ects table (p_id bigint, ects real)
insert into @upd_ects(p_id, ects)
select progress_id,s from (
select progress_id, p.controll_type_id, progress_credit_ects, 
isnull((select top 1 val from @ects_norm t, univer_students st where t.controllTypeId=p.controll_type_id and t.credit=p.progress_credit
and st.students_id=p.student_id 
and  t.academYear in (0,st.educ_plan_adm_year) and
 t.eduLevelId in (0,st.edu_levels_id) and
 t.educFormId in (0,st.education_form_id) and 
 t.practiceType in (0,isnull(p.educ_plan_pos_addit,0) ) and
 t.specId in (0,st.speciality_id) and
 t.stageId in (0, st.stage_id) and 
 t.subjType in (0,p.subject_type) and 
 t.subjectId in (0,p.subject_id) 
  order by credit desc, subjectId desc, practiceType desc, subjType desc,specId desc, academYear desc, eduLevelId desc, educFormId desc, stageId ),isnull(progress_credit_ects,0)) s
 from univer_progress p where status=1 and student_id in (select s.students_id from univer_students s where s.status=1)
 ) t where t.progress_credit_ects<>t.s

 --обновляем
 update univer_progress set progress_credit_ects=(select ects from @upd_ects where p_id=progress_id) where progress_id in (select p_id from @upd_ects)

 commit

 
END
go

