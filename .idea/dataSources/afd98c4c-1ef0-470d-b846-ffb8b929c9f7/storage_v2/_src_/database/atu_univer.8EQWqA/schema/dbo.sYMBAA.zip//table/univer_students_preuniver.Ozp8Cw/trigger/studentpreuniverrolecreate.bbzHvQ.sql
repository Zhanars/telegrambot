-- =============================================
-- Author:		Sasha
-- Create date: 2016-09-15
-- Description:	Триггер на присвоения "права" студента довузовского при создании записи
-- =============================================
CREATE TRIGGER [dbo].[studentPreUniverRoleCreate] ON  [dbo].[univer_students_preuniver] FOR INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	-- Insert statements for trigger here
	-- Цифра доступа для данной сущности
	DECLARE @userId int
	DECLARE @studId int
	DECLARE @status int
		DECLARE insCursor cursor 
		FOR SELECT students_id FROM inserted		
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @studId
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SELECT @userId = user_id FROM univer_students WHERE students_id = @studId
		SELECT @status = status  FROM univer_students WHERE students_id = @studId
		IF (@status != 11)
			BEGIN
				exec dbo.usersSetAccess @userId, 'STUDENT_PREUNIVER'
			END
		
		FETCH NEXT FROM insCursor INTO @studId
	END
	CLOSE insCursor
END
go

