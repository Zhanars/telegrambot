-- =============================================
-- Author:		Twice
-- Create date: 31.01.2012
-- Description: Получить долю ученых вуза, участвующих в работе советов PhD-докторантуры - в разрезе кафедр
-- =============================================
CREATE FUNCTION IP_NIR_getPhdCouncil_Share_ByChairId_DESC
(
	@chairId int,
	@year int
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @Result NVARCHAR(MAX)

SELECT @Result = N''

-- Return the result of the function
RETURN @Result

END
go

