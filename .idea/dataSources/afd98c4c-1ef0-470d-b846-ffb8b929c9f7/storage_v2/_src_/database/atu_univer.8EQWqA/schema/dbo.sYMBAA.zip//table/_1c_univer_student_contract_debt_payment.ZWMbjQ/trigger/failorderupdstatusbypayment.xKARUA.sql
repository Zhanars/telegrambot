-- =============================================
-- Author:		yerlan
-- Create date: 01.07.2016
-- Description:	Для автоматического обновления статуса заявок по доп. семестру
-- =============================================
CREATE TRIGGER [dbo].[FailOrderUpdStatusByPayment]
   ON  [dbo].[_1c_univer_student_contract_debt_payment]
   AFTER INSERT,DELETE,UPDATE
AS 
BEGIN
	
	SET NOCOUNT ON;
    begin transaction
    
    /**************************************************************************************/
    DECLARE @table table (inp nvarchar(MAX), num nvarchar(MAX), dt DateTime, sum real);
	
	declare @cId nvarchar(max);
    declare @cmt nvarchar(max);
    declare @sum real;
	-- создаем переменную, хранящую разделитель
	declare @delimeter nvarchar(1) = ';'
    -- создаем таблицу в которую будем
	-- записывать наши данные
	
	DECLARE cr cursor 
		FOR SELECT d._1c_student_contract_id/*, d._1c_student_contract_payment*/, d._1c_student_contract_payment_sum, rtrim(ltrim(d._1c_student_contract_datenumber))+';' FROM _1c_univer_student_contract_debt_payment d 
				INNER JOIN inserted i ON d._1c_student_contract_id=i._1c_student_contract_id;
				--INNER JOIN inserted i ON i._1c_student_contract_id=d._1c_student_contract_id AND i._1c_student_contract_payment=d._1c_student_contract_payment;
		
	OPEN cr
	FETCH NEXT FROM cr INTO @cId, @sum, @cmt;
	WHILE @@FETCH_STATUS = 0
	BEGIN
		-- определяем позицию первого разделителя
		declare @pos int = charindex(@delimeter,@cmt)
		 
		-- создаем переменную для хранения одной строки
		declare @one nvarchar(MAX)
		
		while (@pos != 0)
		begin
			-- получаем строку
			set @one = rtrim(ltrim(SUBSTRING(@cmt, 1, @pos-1)))
			declare @n nvarchar(20);
			set @n=substring(@one,1,charindex(' ',@one))
			declare @d nvarchar(10);
			declare @d1 datetime;
			set @d=substring(@one,len(@n)+5,charindex(' ',@one,len(@n)+5))			
			declare @s nvarchar(20);	
			--declare @s1 real;
			set @s=replace(substring(@one,len(@n)+18,charindex(' ',@one,len(@n)+18)),' ','');
			BEGIN TRY 
			--set @s1=cast(@s as real); 			
			set @d1=CONVERT(datetime,@d,104);
			END TRY  
			BEGIN CATCH 
			
			END CATCH  
			-- записываем в таблицу
			if (len(@n)>2 and year(@d1)>=2016 /*and @s1>0*/)
			begin
			
			insert into @table (inp,num,dt,sum) values(@one,ltrim(rtrim(@n)),@d1,@sum);
			
			end;
			-- сокращаем исходную строку на размер полученной и разделителя
			set @cmt = SUBSTRING(@cmt, @pos+1, LEN(@cmt))
			-- определяем позицию след. разделителя
			set @pos = CHARINDEX(@delimeter,@cmt)
		end
	FETCH NEXT FROM cr INTO @cId, @sum, @cmt;
	END
	CLOSE cr
	deallocate cr;
    /**************************************************************************************/
    DECLARE @finalTable table (fail_order_id int, fail_order_number nvarchar(30), status int, sum real);
    
    INSERT INTO @finalTable(fail_order_id, fail_order_number,status, sum)
	SELECT fo.fail_order_id, t.num, fo.status,SUM(t.sum) 
    FROM @table t, univer_fail_order fo WHERE t.num=fo.fail_order_number AND CONVERT(varchar, fo.fail_order_date, 104)=CONVERT(varchar, t.dt, 104)
    GROUP BY fo.fail_order_id, t.num, fo.status
    
    insert into univer_fail_order_history(fail_order_id,date_change,status,user_id,comments)
    select fo.fail_order_id, GETDATE(),7,0,N'Изменен статус на оплаченный через синхронизацию с 1С' from @finalTable fo, univer_fail_order_progress_link fl 
    WHERE fo.fail_order_id=fl.fail_order_id AND fo.status=6 AND fo.sum>=fl.cost
        
    update univer_fail_order set status=7 where fail_order_id in (
		select fo.fail_order_id from @finalTable fo, univer_fail_order_progress_link fl WHERE fo.fail_order_id=fl.fail_order_id AND fo.status=6 AND fo.sum>=fl.cost
    )
    commit

END
go

