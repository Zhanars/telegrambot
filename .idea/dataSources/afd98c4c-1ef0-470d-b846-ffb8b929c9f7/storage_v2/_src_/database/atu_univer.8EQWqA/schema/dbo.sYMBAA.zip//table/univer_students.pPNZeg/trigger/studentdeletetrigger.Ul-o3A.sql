-- =============================================
-- Author:		@LFER
-- Create date: 2009-03-31 13:33:35.650
-- Description:	Удаление соответствующего права у сотрудника при удалении строки
-- =============================================
CREATE TRIGGER [dbo].[studentDeleteTrigger]
   ON  dbo.univer_students
   AFTER DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @userId int
	DECLARE @st int
	
	DECLARE insCursor cursor 
		FOR SELECT user_id, status FROM deleted
	
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @userId, @st
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF(@st=10)
			EXEC dbo.usersDeleteAccess @userId, 'ABITURIENT'
		ELSE IF(@st=11)
			EXEC dbo.usersDeleteAccess @userId, 'ABITURIENT'		
		ELSE 
		    BEGIN
			EXEC dbo.usersDeleteAccess @userId, 'STUDENT'
			EXEC dbo.usersDeleteAccess @userId, 'STUDENT_BAKALAVR'				
			EXEC dbo.usersDeleteAccess @userId, 'STUDENT_MAGISTRANT'
			EXEC dbo.usersDeleteAccess @userId, 'STUDENT_PHD'				
			EXEC dbo.usersDeleteAccess @userId, 'STUDENT_PREUNIVER'
			END
		FETCH NEXT FROM insCursor INTO @userId, @st
	END
	CLOSE insCursor
END
go

