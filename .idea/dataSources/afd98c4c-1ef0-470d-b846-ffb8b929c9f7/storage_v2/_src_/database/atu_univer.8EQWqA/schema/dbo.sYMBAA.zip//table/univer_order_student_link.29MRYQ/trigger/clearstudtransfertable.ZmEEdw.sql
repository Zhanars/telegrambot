-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER ClearStudTransferTable
   ON  univer_order_student_link
   AFTER delete
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	if exists(select *  from univer_students_transfer st, deleted d where st.order_id=d.order_id and st.student_id=d.student_id)
	begin
		update st
		set st.status=2, st.operation=2
		from univer_students_transfer st inner join deleted d on st.order_id=d.order_id and st.student_id=d.student_id;
	end;
END
go

