-- =============================================
-- Author:		Sasha
-- Create date: 2016-09-15
-- Description:	Удаление соответствующего права у студента
-- =============================================
CREATE TRIGGER [dbo].[studentPreUniverDeleteTrigger]
   ON  [dbo].[univer_students_preuniver]
   AFTER DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @userId int
	DECLARE @studId int
	
	DECLARE insCursor cursor 
		FOR SELECT students_id FROM deleted
	
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @studId
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SELECT @userId = user_id FROM univer_students WHERE students_id = @studId
		EXEC dbo.usersDeleteAccess @userId, 'STUDENT_PREUNIVER'			
		FETCH NEXT FROM insCursor INTO @userId
	END
	CLOSE insCursor
END
go

