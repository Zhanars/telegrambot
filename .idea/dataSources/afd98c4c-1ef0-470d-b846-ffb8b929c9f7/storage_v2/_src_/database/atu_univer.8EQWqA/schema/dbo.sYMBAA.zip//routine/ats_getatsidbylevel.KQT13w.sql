-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[ats_getAtsIdByLevel]
(
	-- Add the parameters for the function here
	@parents varchar(200), -- в формате: ':1:parent1Id:parent2Id:parent3Id:parent4Id:'
	@need_level int
)
RETURNS bigint
AS
BEGIN
	
	if (@parents is null) return null

	declare @ind1 int = 3;
	declare @ind2 int;
	declare @cur_level int = 1;

	while 1 = 1
	begin
		set @ind2 = charindex(':', @parents, @ind1 + 1)
		if (@ind2 <= 0) return null
		if (@ind1 > 0 and @ind2 > 0 and @cur_level = @need_level)
			return CONVERT(bigint, substring(@parents, @ind1 + 1, @ind2 - @ind1 - 1))
		set @cur_level = @cur_level + 1;
		set @ind1 = @ind2
	end
	
	return NULL;

END
go

