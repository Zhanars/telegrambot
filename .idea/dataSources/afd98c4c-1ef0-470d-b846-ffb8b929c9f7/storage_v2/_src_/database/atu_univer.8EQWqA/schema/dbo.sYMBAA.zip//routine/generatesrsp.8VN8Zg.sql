-- =============================================
-- Author:		Sasha
-- Create date: 18.10.2017
-- Description:	Генерация групп СРСП по учебному плану и семестру
-- =============================================
CREATE PROCEDURE generateSRSP
(
	 @planId int,
     @sem int
)
AS
BEGIN
	-- Declare the return variable here
DECLARE @ret int=0;
  	  begin transaction

------------------------------------------------------Генерация СРСП по семестру-------------------------------------------------


--1. Находим все группы по которым надо создать группу СРСП
----выберем для каждой позиции тип занятий, по которому нужно создать группу. Приоритет лек.-сем.-лаб.
declare @pos table(educ_plan_pos_id int, educ_type_id int, controll_type_id int)
insert into @pos (educ_plan_pos_id, controll_type_id, educ_type_id)
select distinct pp.educ_plan_pos_id, pp.controll_type_id, min(ppc.educ_type_id)  from univer_educ_plan_pos pp, univer_educ_plan_pos_credit ppc, univer_controll_type_control_link ccl, univer_control_educ_type_link c where ccl.controll_type_id=pp.controll_type_id and c.control_id=ccl.control_id and c.attendance_prop>0 and ppc.educ_plan_pos_id=pp.educ_plan_pos_id and pp.educ_plan_id=@planId and pp.status=1 and pp.educ_plan_pos_semestr=@sem and ppc.credit>0
group by pp.educ_plan_pos_id, pp.controll_type_id
----выберем все группы по таким позициям с таким типом занятий
declare @group table(group_id int,educ_plan_pos_id int, educ_lang_id int, educ_type_id int, group_isdo int, teacher_id int, group_retake_semestr int, group_semestr int, group_year int, lang_division_id int, acpos_module int)
insert into @group (group_id,educ_plan_pos_id, educ_lang_id, educ_type_id, group_isdo, teacher_id, group_retake_semestr, group_semestr, group_year, lang_division_id, acpos_module)
select g.group_id, g.educ_plan_pos_id, g.educ_lang_id, g.educ_type_id, g.group_isdo, g.teacher_id, g.group_retake_semestr, g.group_semestr, g.group_year, g.lang_division_id, g.acpos_module from univer_group g, @pos p where g.educ_plan_pos_id=p.educ_plan_pos_id and g.educ_type_id=p.educ_type_id
----выберем уже существующие группы СРСП
declare @groupSRSP table(group_id int,educ_plan_pos_id int, educ_lang_id int, educ_type_id int, group_isdo int, teacher_id int, group_retake_semestr int, group_semestr int, group_year int, lang_division_id int, acpos_module int)
insert into @groupSRSP(group_id,educ_plan_pos_id, educ_lang_id, educ_type_id, group_isdo, teacher_id, group_retake_semestr, group_semestr, group_year, lang_division_id, acpos_module)
select g.group_id, g.educ_plan_pos_id, g.educ_lang_id, g.educ_type_id, g.group_isdo, g.teacher_id, g.group_retake_semestr, g.group_semestr, g.group_year, g.lang_division_id, g.acpos_module from univer_group g, @pos p where g.educ_plan_pos_id=p.educ_plan_pos_id and g.educ_type_id=4

----найдем те группы, по которым нет группы СРСП
delete from @group where group_id in (
select g.group_id from @group g left join @groupSRSP g2 on
g.acpos_module=g2.acpos_module and g.educ_lang_id =g2.educ_lang_id and g.educ_plan_pos_id=g2.educ_plan_pos_id and isnull(g.group_isdo,0)=isnull(g2.group_isdo,0) and g.group_retake_semestr=g2.group_retake_semestr and g.group_semestr=g2.group_semestr and g2.group_year =g.group_year and g.lang_division_id=g2.lang_division_id and g.teacher_id=g2.teacher_id
where g2.group_id is not null)
--2. Создаем группы
----Для каждой группы создадим группу СРСП и запомним, какая к какой относится
if (exists (select * from @group))
begin
    declare @groupId int=0;
    declare @g_g1 table (group_old int, group_new int);
    DECLARE addSRS cursor 
		FOR SELECT group_id FROM @group		
	OPEN addSRS
	FETCH NEXT FROM addSRS INTO @groupId
	WHILE @@FETCH_STATUS = 0
	BEGIN
	    insert into univer_group(educ_plan_pos_id, group_students_max,group_students_min, educ_lang_id, educ_type_id, group_isdo, teacher_id, group_retake_semestr, group_semestr, group_year, lang_division_id, acpos_module)
	  select educ_plan_pos_id, group_students_max,group_students_min, educ_lang_id, 4, group_isdo, teacher_id, group_retake_semestr, group_semestr, group_year, lang_division_id, acpos_module from univer_group g where g.group_id=@groupId;  
	    insert into @g_g1(group_old, group_new)
	    values (@groupId, @@identity);
		FETCH NEXT FROM addSRS INTO @groupId;
	END
	CLOSE addSRS
	select @ret=count(*) from @g_g1;

----Добавим в созданные группы студентов
    insert into univer_group_student (group_id, student_id, student_choice_date, student_reg)
    select g.group_new, gs.student_id, getdate() student_choice_date, 0 student_reg from univer_group_student gs,@g_g1 g where g.group_old=gs.group_id    end;
    commit
	select @ret as res

END
go

