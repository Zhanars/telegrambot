


CREATE function [dbo].[sscStatementCurStepId](@statementId int, @successStepStatusses int)
returns int
as 
begin
	declare @ret int
	
	select @ret=MAX(step_id)+1 from ssc_step_user su where su.statement_id=@statementId and (su.application_status&@successStepStatusses)>0
	
	return ISNULL(@ret, 1)
end


go

