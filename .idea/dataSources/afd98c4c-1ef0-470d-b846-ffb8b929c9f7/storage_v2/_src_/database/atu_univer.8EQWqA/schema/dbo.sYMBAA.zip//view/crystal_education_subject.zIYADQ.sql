CREATE VIEW dbo.crystal_education_subject
AS
SELECT     subject_id AS id, REPLACE(subject_name_kz, ';', '') AS name_kaz, REPLACE(subject_name_ru, ';', '') AS name_rus, subject_name_en AS name_eng, N'' AS notes, 
                      N'' AS lang, N'' AS subject_type
FROM         dbo.univer_subject
WHERE     (status = 1)
go

