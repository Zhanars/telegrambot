-- =============================================
-- Author:		@LFER
-- Create date: 2009-05-22 12:58:07.427
-- Description:	Добавление права доступа сотруднику при добавлении строки
-- =============================================
CREATE TRIGGER [dbo].[teacherInsertTrigger] ON  [dbo].[univer_teacher] FOR INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	DECLARE @pi int
	DECLARE insCursor cursor 
		FOR SELECT personal_id FROM inserted WHERE status=1
		
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @pi
	WHILE @@FETCH_STATUS = 0
	BEGIN
		exec dbo.personalSetAccess @pi, 'TEACHER'
		-- Добавление ППС-ника в таблицу пользователей Науки с ролью "ППС"
		exec dbo.SCI_PPS_newAccount @pi 
		FETCH NEXT FROM insCursor INTO @pi;
	END
	CLOSE insCursor
END
go

