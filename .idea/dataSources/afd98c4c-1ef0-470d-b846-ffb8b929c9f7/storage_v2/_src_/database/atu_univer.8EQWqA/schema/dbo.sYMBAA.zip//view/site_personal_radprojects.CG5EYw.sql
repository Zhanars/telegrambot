
CREATE VIEW [dbo].[site_personal_radprojects]
AS
SELECT     TOP (100) PERCENT p.personal_id, pspl.structure_division_id AS chair_id, p.personal_sname + ' ' + LEFT(p.personal_name, 1) + '.' + LEFT(p.personal_father_name, 1)
                       + '.' AS author, 
                      DBScience.dbo.support_getParticipantsOfProject(rp.RADProject_id,1,p.personal_id) AS participants,
                      rp.RADProject_id, rp.name_kz, rp.name_ru, rp.name_en, 
                      rp.projectStart, rp.projectEnd, 
                      rps.name_kz as RADProjectStatuses_name_kz,
                      rps.name_ru as RADProjectStatuses_name_ru,
                      rps.name_en as RADProjectStatuses_name_en,
                      DBScience.dbo.support_getLeaderOfProject(rp.leaderPerson_id, rp.leaderPersonType) as leader,
                      pri.name_kz as RADPriorities_name_kz,
                      pri.name_ru as RADPriorities_name_ru,
                      pri.name_en as RADPriorities_name_en,
                      subpri.name_kz as RADSubPriorities_name_kz,
                      subpri.name_ru as RADSubPriorities_name_ru,
                      subpri.name_en as RADSubPriorities_name_en,
                      annotF.fileInfo_id as annotF_id,
                      annotF.serverFileName as annotF_serverFileName,
                      annotF.showName as annotF_showName,
                      refF.fileInfo_id as refF_id,
                      refF.serverFileName as refF_serverFileName,
                      refF.showName as refF_showName,
                      finF.fileInfo_id as finF_id,
                      finF.serverFileName as finF_serverFileName,
                      finF.showName as finF_showName
FROM dbo.univer_personal AS p LEFT OUTER JOIN
                      DBScience.dbo.L_Person_RADProject_Participants AS lrp ON lrp.person_id = p.personal_id INNER JOIN
                      DBScience.dbo.RADProjects AS rp ON rp.RADProject_id = lrp.RADProject_id AND rp.status <> 2 and rp.RADProjectStage=2 LEFT OUTER JOIN
                      DBScience.dbo.RADProjectStatuses rps ON rps.RADProjectStatus_id=rp.RADProjectStatus_id LEFT outer join
                      DBScience.dbo.RADPriorities pri ON pri.RADPriority_id=rp.RADPriority_id LEFT outer join
                      DBScience.dbo.RADSubPriorities subpri ON rp.RADSubPriority_id=subpri.RADSubPriority_id LEFT OUTER JOIN
                      DBScience.dbo.FileInfos AS annotF ON annotF.fileInfo_id=(select lrp.reportFile_id from DBScience.dbo.L_RADReport_RADProject lrp
					  where lrp.RADProject_id=rp.RADProject_id and lrp.reportFileAgree=1
					  and lrp.RADReportType_id=2) LEFT OUTER JOIN
					  DBScience.dbo.FileInfos AS refF ON refF.fileInfo_id=(select lrp.reportFile_id from DBScience.dbo.L_RADReport_RADProject lrp
					  where lrp.RADProject_id=rp.RADProject_id and lrp.reportFileAgree=1
					  and lrp.RADReportType_id=5) LEFT OUTER JOIN					  
					  DBScience.dbo.FileInfos AS finF ON finF.fileInfo_id=(select lrp.reportFile_id from DBScience.dbo.L_RADReport_RADProject lrp
					  where lrp.RADProject_id=rp.RADProject_id and lrp.reportFileAgree=1
					  and lrp.RADReportType_id=4) LEFT OUTER JOIN
                      dbo.univer_personal_struct_pos_link_1c AS pspl ON pspl.personal_id = p.personal_id AND pspl.status = 1 AND pspl.type_id IN (1, 2)
ORDER BY p.personal_id
go

