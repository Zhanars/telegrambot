
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER CertPointInsertForPlatonus
   ON  univer_certificate_points
   AFTER insert
AS 
BEGIN
	SET NOCOUNT ON;
	if (ISNULL((select COUNT(*) from inserted d),0)>0)
	begin
		insert into platonus_univer_certificate_points(point_id, operation)
		select d.point_id, 1 from inserted d
	end;
END
go

