-- =============================================
-- Author:		Twice
-- Create date: 31.01.2012
-- Description: Получить количество НИР студентов получивших дипломы за участие в республиканском конкурсе НИР - в разрезе кафедр
-- =============================================
CREATE FUNCTION IP_NIR_getNIRContestStudent_Count_ByChairId_DESC
(
	@chairId int,
	@year int
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @Result NVARCHAR(MAX)

SELECT @Result = N''

-- Return the result of the function
RETURN @Result

END
go

