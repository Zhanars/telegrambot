-- =============================================
-- Author:		@LFER
-- Create date: 2009-02-23 09:50:58.383
-- Description:	Добавление записи в таблицу истории действий
-- =============================================
CREATE PROCEDURE [dbo].[historyInsert] @user_id int, @history_model nvarchar(50), @history_action nvarchar(50), 
				@history_object_id int, @history_info ntext, @history_description ntext, @history_ip nvarchar(50), 
				@history_link nvarchar(300)
AS
BEGIN
	INSERT INTO univer_history (
		history_date,
		user_id,
		history_model,
		history_action,
		history_object_id,
		history_info,
		history_description,
		history_ip,
		history_link) VALUES (
		getdate(),
		@user_id,
		@history_model,
		@history_action,
		@history_object_id,
		@history_info,
		@history_description,
		@history_ip,
		@history_link)
END
go

