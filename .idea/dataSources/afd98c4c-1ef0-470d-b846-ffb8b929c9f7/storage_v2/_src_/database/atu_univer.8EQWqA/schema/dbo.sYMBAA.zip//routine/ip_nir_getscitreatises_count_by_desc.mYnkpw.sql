-- =============================================
-- Author:		Yerlan
-- Create date: 22.12.2015
-- Description: Получить описания учебных пособий 
-- (@indicatorConst=1 - Количество учебников с грифом МОН РК
-- @indicatorConst=2 - Количество учебников и учебных пособий рекомендованных УМО РУМС (Издательство "Қазақ Университеті")
-- @indicatorConst=3 - Количество учебников и учебных пособий рекомендованных РИСО (Издательство «Қазақ Университеті»)
-- @indicatorConst=4 - Количество научных монографий на английском языке изданных в дальнем зарубежье
-- @indicatorConst=5 - Количество научных монографий изданных в Казахстане и странах ближнего зарубежья
-- =============================================
CREATE FUNCTION [dbo].[IP_NIR_getSciTreatises_Count_By_DESC]
(
	@categoryId int,
	@personalId int=0,
	@chairId int=0,
	@facultyId int=0,
	@year int=0,
	@publisherTypeId int=null,
	@indicatorConst int=0
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @Result NVARCHAR(MAX)

-- ==================================== с грифом МОН РК
IF (@indicatorConst = 1)
BEGIN
SELECT @Result = COALESCE(@Result + ';\n\n', '') + 
			CASE WHEN @categoryId=3 THEN
				ISNULL(N'Книга\nKZ: ' + t.name_kz + N'\nRU: ' + t.name_ru + N'\nEN: ' + t.name_en +
				N'\nИздательство:' + p.name + N'\nСтрана издательства:' + c.name_ru, '')
			ELSE ISNULL(
				CONVERT(NVARCHAR(MAX), ROW_NUMBER() OVER (ORDER BY dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(t.treatise_id, 1))) +N') '
				+ N'Автор(ы): ' + dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(t.treatise_id, 1) 
				+ N'Научная монография:\nKZ: ' + t.name_kz + N'\nRU: ' + t.name_ru + N'\nEN: ' + t.name_en
				+ N'\nИздательство:' + p.name + N'\nСтрана издательства:' + c.name_ru, '')
			END
			--AS [description]
		FROM 
			DBScience.dbo.Treatises t,
			DBScience.dbo.L_Person_Treatise_Authors a,
			DBScience.dbo.Publishers p,
			DBScience.dbo.Countries c
		WHERE
		-- не архивированная
		t.status != 2 AND
		-- издательство 
		p.publisher_id = t.publisher_id AND
		c.country_id = p.country_id AND
		-- книга должна быть "Учебник с грифом МОН РК"
		t.treatiseType_id = 26 AND
		-- книга этого года или следующего
		t.yearPublication in (@year, @year+1) AND
		-- не дублированная и подтвержденная
		t.is_overlap IS NULL AND
		t.is_approve=1 AND
		-- книга этого автора (ППС, потому personType = 1)
		t.treatise_id = a.treatise_id AND
		a.personType = 1 AND 
		(
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		)
END
-- ==================================== рекомендованных УМО РУМС 
IF (@indicatorConst = 2)
BEGIN
SELECT @Result = COALESCE(@Result + ';\n\n', '') + 
			CASE WHEN @categoryId=3 THEN
				ISNULL(N'Книга\nKZ: ' + t.name_kz + N'\nRU: ' + t.name_ru + N'\nEN: ' + t.name_en +
				N'\nИздательство:' + p.name + N'\nСтрана издательства:' + c.name_ru, '')
			ELSE ISNULL(
				CONVERT(NVARCHAR(MAX), ROW_NUMBER() OVER (ORDER BY dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(t.treatise_id, 1))) +N') '
				+ N'Автор(ы): ' + dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(t.treatise_id, 1) 
				+ N'Научная монография:\nKZ: ' + t.name_kz + N'\nRU: ' + t.name_ru + N'\nEN: ' + t.name_en
				+ N'\nИздательство:' + p.name + N'\nСтрана издательства:' + c.name_ru, '')
			END
			--AS [description]
		FROM 
			DBScience.dbo.Treatises t,
			DBScience.dbo.L_Person_Treatise_Authors a,
			DBScience.dbo.Publishers p,
			DBScience.dbo.Countries c
		WHERE
		-- не архивированная
		t.status != 2 AND
		-- издательство этой страны
		p.publisher_id = t.publisher_id AND
		c.country_id = p.country_id AND
		c.countryCurrent = 1 AND
		-- книга должна быть "Учебник с УМО РУМС"
		t.treatiseType_id = 27 AND
		-- Издательство "Қазақ Университеті"
		p.name LIKE N'%Қазақ университеті%' AND
		-- книга этого года или следующего
		t.yearPublication in (@year, @year+1) AND
		-- не дублированная и подтвержденная
		t.is_overlap IS NULL AND
		t.is_approve=1 AND
		-- книга этого автора (ППС, потому personType = 1)
		t.treatise_id = a.treatise_id AND
		a.personType = 1 AND 
		(
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		)
END
-- ==================================== рекомендованных РИСО 
IF (@indicatorConst = 3)
BEGIN
SELECT @Result = COALESCE(@Result + ';\n\n', '') + 
			CASE WHEN @categoryId=3 THEN
				ISNULL(N'Книга\nKZ: ' + t.name_kz + N'\nRU: ' + t.name_ru + N'\nEN: ' + t.name_en +
				N'\nИздательство:' + p.name + N'\nСтрана издательства:' + c.name_ru, '')
			ELSE ISNULL(
				CONVERT(NVARCHAR(MAX), ROW_NUMBER() OVER (ORDER BY dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(t.treatise_id, 1))) +N') '
				+ N'Автор(ы): ' + dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(t.treatise_id, 1) 
				+ N'Научная монография:\nKZ: ' + t.name_kz + N'\nRU: ' + t.name_ru + N'\nEN: ' + t.name_en
				+ N'\nИздательство:' + p.name + N'\nСтрана издательства:' + c.name_ru, '')
			END
			--AS [description]
		FROM 
			DBScience.dbo.Treatises t,
			DBScience.dbo.L_Person_Treatise_Authors a,
			DBScience.dbo.Publishers p,
			DBScience.dbo.Countries c
		WHERE
		-- не архивированная
		t.status != 2 AND
		-- издательство этой страны
		p.publisher_id = t.publisher_id AND
		c.country_id = p.country_id AND
		c.countryCurrent = 1 AND
		-- книга должна быть "Учебник рекомендованных РИСО "
		t.treatiseType_id = 28 AND
		-- Издательство "Қазақ Университеті"
		p.name LIKE N'%Қазақ университеті%' AND
		-- книга этого года или следующего
		t.yearPublication in (@year, @year+1) AND
		-- не дублированная и подтвержденная
		t.is_overlap IS NULL AND
		t.is_approve=1 AND
		-- книга этого автора (ППС, потому personType = 1)
		t.treatise_id = a.treatise_id AND
		a.personType = 1 AND 
		(
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		)
END

-- ==================================== Количество научных монографий на английском языке изданных в дальнем зарубежье
IF (@indicatorConst = 4)
BEGIN
SELECT @Result = COALESCE(@Result + ';\n\n', '') + 
			CASE WHEN @categoryId=3 THEN
				ISNULL(N'Монография\nKZ: ' + t.name_kz + N'\nRU: ' + t.name_ru + N'\nEN: ' + t.name_en +
				N'\nИздательство:' + p.name + N'\nСтрана издательства:' + c.name_ru, '')
			ELSE ISNULL(
				CONVERT(NVARCHAR(MAX), ROW_NUMBER() OVER (ORDER BY dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(t.treatise_id, 1))) +N') '
				+ N'Автор(ы): ' + dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(t.treatise_id, 1) 
				+ N'Научная монография:\nKZ: ' + t.name_kz + N'\nRU: ' + t.name_ru + N'\nEN: ' + t.name_en
				+ N'\nИздательство:' + p.name + N'\nСтрана издательства:' + c.name_ru, '')
			END
			--AS [description]
		FROM 
			DBScience.dbo.Treatises t,
			DBScience.dbo.L_Person_Treatise_Authors a,
			DBScience.dbo.Publishers p,
			DBScience.dbo.Countries c
		WHERE
		-- не архивированная
		t.status != 2 AND
		-- на английском языке
		t.language_id=4 AND
		-- издательство дальнего зарубежья
		p.publisher_id = t.publisher_id AND
		c.country_id = p.country_id AND
		c.countryCurrent = 0 AND
		c.foreignType in (2) AND
		-- книга должна быть "Монография"
		t.treatiseType_id = 1 AND
		-- книга этого года или следующего
		t.yearPublication in (@year, @year+1) AND
		-- не дублированная и подтвержденная
		t.is_overlap IS NULL AND
		t.is_approve=1 AND
		-- книга этого автора (ППС, потому personType = 1)
		t.treatise_id = a.treatise_id AND
		a.personType = 1 AND 
		(
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		)
END

-- ==================================== Количество научных монографий изданных в Казахстане и странах ближнего зарубежья
IF (@indicatorConst = 5)
BEGIN
SELECT @Result = COALESCE(@Result + ';\n\n', '') + 
			CASE WHEN @categoryId=3 THEN
				ISNULL(N'Монография\nKZ: ' + t.name_kz + N'\nRU: ' + t.name_ru + N'\nEN: ' + t.name_en +
				N'\nИздательство:' + p.name + N'\nСтрана издательства:' + c.name_ru, '')
			ELSE ISNULL(
				CONVERT(NVARCHAR(MAX), ROW_NUMBER() OVER (ORDER BY dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(t.treatise_id, 1))) +N') '
				+ N'Автор(ы): ' + dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(t.treatise_id, 1) 
				+ N'Научная монография:\nKZ: ' + t.name_kz + N'\nRU: ' + t.name_ru + N'\nEN: ' + t.name_en
				+ N'\nИздательство:' + p.name + N'\nСтрана издательства:' + c.name_ru, '')
			END
			--AS [description]
		FROM 
			DBScience.dbo.Treatises t,
			DBScience.dbo.L_Person_Treatise_Authors a,
			DBScience.dbo.Publishers p,
			DBScience.dbo.Countries c
		WHERE
		-- не архивированная
		t.status != 2 AND
		-- издательство дальнего зарубежья
		p.publisher_id = t.publisher_id AND
		c.country_id = p.country_id AND
		--в Казахстане и странах ближнего зарубежья
		c.countryCurrent in (0,1) AND
		c.foreignType in (0) AND
		-- книга должна быть "Монография"
		t.treatiseType_id = 1 AND
		-- книга этого года или следующего
		t.yearPublication in (@year, @year+1) AND
		-- не дублированная и подтвержденная
		t.is_overlap IS NULL AND
		t.is_approve=1 AND
		-- книга этого автора (ППС, потому personType = 1)
		t.treatise_id = a.treatise_id AND
		a.personType = 1 AND 
		(
		-- на уровне ппс
		(@categoryId=3 AND a.person_id = @personalId)
		OR
		-- на уровне кафедры
		(@categoryId=2 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		OR
		-- на уровне факультета
		(@categoryId=1 AND a.person_id IN 
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_ext = @facultyId AND
				spl.status != 2  AND p.status != 2
				AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id,spl.structure_division_id,1)=1
			))
		)
END
-- Return the result of the function
RETURN ISNULL(@Result, '')

END
go

