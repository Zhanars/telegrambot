CREATE VIEW dbo.esuvo_tutor_cafedra_list
AS
SELECT DISTINCT t.tutorid, t.rate, t.cafedraid, t.position, t.type, t.hourlyFund, ISNULL(tc.id, 0) AS id
FROM            (SELECT        per.personal_id AS tutorid, ROUND(SUM(l.personal_rate), 2) AS rate, ch.chair_id AS cafedraid, l.personal_position_id AS position, ISNULL(tp.platonus_value, 0) AS type, 0 AS hourlyFund
                          FROM            dbo.univer_personal AS per INNER JOIN
                                                    dbo.univer_personal_struct_pos_link_1c AS l ON per.personal_id = l.personal_id INNER JOIN
                                                    dbo.univer_chair AS ch ON l.structure_division_id = ch.structure_division_id LEFT OUTER JOIN
                                                    dbo.univer_type_personal_1c AS tp ON l.type_id = tp.type_personal_id
                          WHERE        (per.status = 1) AND (l.status = 1) AND (ch.status = 1) AND (l.structure_division_id > 0)
                          GROUP BY per.personal_id, ch.chair_id, l.personal_position_id, tp.platonus_value) AS t LEFT OUTER JOIN
                         atu_platonus_univer.dbo.tutor_cafedra AS tc ON tc.TutorID = t.tutorid AND tc.cafedraID = t.cafedraid AND tc.type = t.type AND tc.position = t.position AND tc.operation <> 2
go

