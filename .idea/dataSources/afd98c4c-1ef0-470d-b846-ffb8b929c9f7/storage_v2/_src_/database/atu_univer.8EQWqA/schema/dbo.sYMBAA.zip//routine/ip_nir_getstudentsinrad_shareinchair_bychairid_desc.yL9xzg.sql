-- =============================================
-- Author:		Twice
-- Create date: 31.01.2012
-- Description: Получить долю студентов, магистрантов, PhD-докторантов, участвующих в выполнении проектов, от общего их количества на кафедре - в разрезе кафедр
-- =============================================
CREATE FUNCTION IP_NIR_getStudentsInRAD_ShareInChair_ByChairId_DESC
(
	@chairId int,
	@year int
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @Result NVARCHAR(MAX)

SELECT @Result = N''

-- Return the result of the function
RETURN @Result

END
go

