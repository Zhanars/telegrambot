
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[getFioBlock]
(
	-- Add the parameters for the function here
	@fio nvarchar(200),
	@block int -- 1 - Фамилия, 2 - Имя, 3 - Отчество
)
RETURNS nvarchar(200)
AS
BEGIN
	
	set @fio = rtrim(@fio)
	if (@fio is null or @fio = '' or @block < 1 or @fio = N'нет' or @fio = '-') return null
	
	declare @cur_block int = 1;
	declare @ind int
	

	while 1 = 1
	begin
		set @ind = PATINDEX('%[. ]%', @fio)
		if @ind = 1 begin
			set @fio = right(@fio, len(@fio) - 1)
			continue;
		end
		
		if @block = @cur_block begin
			if @ind <= 0 return @fio;
			return left(@fio, @ind - 1);
		end
		
		if @ind <= 0 return null;
		set @cur_block = @cur_block + 1
		set @fio = right(@fio, len(@fio) - @ind)
	end

	return NULL;
END
go

