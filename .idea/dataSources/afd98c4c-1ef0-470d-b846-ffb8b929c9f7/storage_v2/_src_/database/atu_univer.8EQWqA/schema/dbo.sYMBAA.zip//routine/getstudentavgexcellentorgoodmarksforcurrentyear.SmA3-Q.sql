-- =============================================
-- Author:		YERLAN
-- Create date: 27.06.2016
-- Description:	Определяет является ли студент отличником или ударником
-- =============================================
CREATE FUNCTION [dbo].[GetStudentAVGExcellentOrGoodMarksForCurrentYear] 
(
 @studentId int,
 @year int
)
RETURNS int
AS
BEGIN
	
	DECLARE @ret int=0;
	--Переделала, так как возникал timeout//sasha
	declare @t_acdata table (n_seme int, module int)
	declare @t_pr table (progress_id bigint)
	--declare @t_pr_all table (progress_id bigint, n_seme int,subject_id int, progress_result_rk1 int,progress_result_rk2 int, progress_result_mt int, progress_result  int, controll_type_id int, academ_year int,semestr int, status int, mark_type_id int, acpos_module int)

	--Определяем семестры и модули для студента
	insert into @t_acdata(n_seme,module)
	select ac.acpos_semester, ac.acpos_module from univer_students st, univer_educ_plan ep, univer_academ_calendar_pos ac where 
	st.students_id=@studentId and ep.edu_level_id=st.edu_levels_id and ep.educ_plan_adm_year=st.educ_plan_adm_year and ep.education_form_id=st.education_form_id 
	and ep.speciality_id=st.speciality_id and ep.status=1 and ac.educ_plan_id=ep.educ_plan_id and ac.control_id=0 and ac.acpos_date_end<GETDATE()/*МЕНЬШЕ сегодняшнего дня*/;
    --выбираем прогресс студента
    --insert into @t_pr_all(progress_id, n_seme,subject_id, progress_result_rk1,progress_result_rk2, progress_result_mt, progress_result , controll_type_id,academ_year,semestr, status, mark_type_id, acpos_module)
    --select progress_id, n_seme,subject_id, progress_result_rk1,progress_result_rk2, progress_result_mt, progress_result , controll_type_id,academ_year,semestr, status, mark_type_id, acpos_module from univer_progress where student_id=@studentId;
	--ищем записи, по которым есть незакрытые ведомости
	insert into @t_pr(progress_id)
	select distinct p.progress_id from univer_progress p inner join univer_controll_type_control_link ccl on ccl.controll_type_id=p.controll_type_id inner join univer_controll_type ct on ct.controll_type_id=p.controll_type_id inner join univer_control c on c.control_id=ccl.control_id left join univer_sheet_result sr on p.subject_id=sr.subject_id AND p.n_seme=sr.n_seme AND p.academ_year=sr.academ_year AND p.semestr=sr.semestr  and sr.student_id=p.student_id and ccl.control_id=sr.control left join univer_sheet s on s.sheet_id=sr.sheet_id and s.acpos_module=p.acpos_module where p.student_id=@studentId and p.status=1 and (sr.date_keep is null or s.date_keep is null) /*добавила это условие, чтобы включить тех студентов, кто недопущен к экзамену из-за ненабранного минимума по РК*/ and (p.progress_result_rk1+p.progress_result_rk2>=ct.controll_type_min_rk or c.control_title not in ('','_mt')) 
    	
    --ищем оценки, которые не являются оценками "хорошо" и "отлично"
	DECLARE @notExcellentAndGood int=0;
    select @notExcellentAndGood=COUNT(p.progress_id) from univer_progress p, @t_acdata ac where p.mark_type_id in (select mt.mark_type_id from univer_mark_type mt where mt.mark_type_arg in (2,3,7)) and p.n_seme=ac.n_seme and p.acpos_module=ac.module and p.academ_year=@year and p.status IN(1,4/*Retake*/) and student_id=@studentId and progress_id not in (select pp.progress_id from @t_pr pp)
	if (@notExcellentAndGood<=0)
	begin
	--находим среднюю оценку
	select @ret=ROUND(ISNULL(AVG([dbo].[getProgressMark](p.controll_type_id, p.progress_result_rk1,p.progress_result_rk2, p.progress_result_mt, p.progress_result)),0),0) from univer_progress p where p.student_id=@studentId and p.status=1 and p.academ_year=@year and progress_id not in (select pp.progress_id from @t_pr pp)
	end
	else 
	begin
	set @ret=0;
	end
	/*
	DECLARE @ret int=0;
	DECLARE @notExcellentAndGood int=0;
	set @notExcellentAndGood = (SELECT COUNT(pr.progress_id)
								FROM univer_progress pr, univer_mark_type mt,
									(
										SELECT ac.acpos_semester, ac.acpos_module
										FROM univer_educ_plan ep, univer_students st, univer_academ_calendar_pos ac
										WHERE ep.edu_level_id=st.edu_levels_id AND ep.educ_plan_adm_year=st.educ_plan_adm_year AND ep.speciality_id=st.speciality_id AND ep.education_form_id = st.education_form_id 
											AND ep.educ_plan_id=ac.educ_plan_id AND ac.control_id=0/*период*/ AND st.students_id=@studentId 
											AND ac.acpos_date_end<GETDATE()/*МЕНЬШЕ сегодняшнего дня*/
									) as acc
								WHERE pr.status IN(1,4/*Retake*/) and pr.mark_type_id=mt.mark_type_id AND pr.student_id = @studentId
									AND pr.n_seme=acc.acpos_semester AND pr.acpos_module=acc.acpos_module
									AND mt.mark_type_arg in (2,3,7) and pr.academ_year=@year);
	IF (@notExcellentAndGood<=0)
	BEGIN
		SET @ret = (
						select ROUND(ISNULL(AVG([dbo].[getProgressMark](pr.controll_type_id, pr.progress_result_rk1,pr.progress_result_rk2, pr.progress_result_mt, pr.progress_result)),0),0)
						from univer_progress pr
						WHERE pr.status=1 AND pr.student_id=@studentId and pr.academ_year=@year
						AND (SELECT COUNT(DISTINCT sr.control) 
							FROM univer_sheet_result sr 
							WHERE pr.subject_id=sr.subject_id AND pr.n_seme=sr.n_seme AND pr.academ_year=sr.academ_year AND pr.semestr=sr.semestr  and sr.student_id=pr.student_id
							AND sr.result IS NOT NULL)=(SELECT COUNT(distinct ct.control_id) FROM univer_controll_type_control_link ct WHERE ct.controll_type_id=pr.controll_type_id)

		);
	END;
	ELSE
	BEGIN
		SET @ret = 0;
	END;*/
	
	RETURN isnull(@ret, 0);
END
go

