-- =============================================
-- Author:		Nurzhan
-- Create date: 04.07.2013
-- Description:	Триггер на удаление сотрудника бухгалтерии
			--исправлен 26.10.2018 Данияр
-- =============================================
CREATE TRIGGER [dbo].[accountingDepDeleteTrigger]
   ON  [dbo].[univer_accounting_department] 
   AFTER DELETE
AS 
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    DECLARE @pi int 
	DECLARE @type int
    DECLARE insCursor cursor 
		FOR SELECT personal_id, accounting_department_id FROM deleted
	
	OPEN insCursor
	FETCH NEXT FROM insCursor INTO @pi, @type
	WHILE @@FETCH_STATUS = 0
	BEGIN 
		IF(@type=1) EXEC dbo.personalDeleteAccess @pi, 'ACCOUNTING_DEPART'
		ELSE IF(@type=2) EXEC dbo.personalDeleteAccess @pi, 'ACCOUNTING_DEPART_STUD'
		ELSE EXEC dbo.personalDeleteAccess @pi, 'ACCOUNTING_DEPART_ABROAD'
		FETCH NEXT FROM insCursor INTO @pi, @type
	END
	CLOSE insCursor
	deallocate insCursor
END
go

