
-- =============================================
-- Author:		d.aitmukash
-- Create date: 24.05.2018
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[foreignSubjectsUpdateTrigger]
   ON  [dbo].[platonus_foreignsubjects] 
    AFTER UPDATE,INSERT,DELETE
AS 
BEGIN 
	
	IF @@ROWCOUNT =0
    RETURN
	
	SET NOCOUNT ON;
	
	--Insert block, all new inserted subject_id will be writed as update
	IF EXISTS(SELECT * FROM inserted) 
	BEGIN
		declare @iden int, @stat int;
		declare cur cursor for select i.id, i.status FROM inserted i
		open cur
		FETCH NEXT FROM cur INTO @iden, @stat
		WHILE @@FETCH_STATUS=0
		BEGIN
			IF(not exists (select 1 from platonus_foreignsubjects_trigger t where t.foreign_subject_id=@iden))
			BEGIN
				INSERT INTO platonus_foreignsubjects_trigger(foreign_subject_id, operation)
				VALUES(@iden,(case when @stat=1 then 1 else 2 end));
			END
			ELSE
			BEGIN
				UPDATE platonus_foreignsubjects_trigger SET operation=(case when @stat=1 then 1 else 2 end) WHERE foreign_subject_id=@iden;
			END
			FETCH NEXT FROM cur INTO @iden, @stat
		END
		close cur;
		deallocate cur;		
	END 
	
	--DELETE block, in univer there are only 2 ways: insert and delete. 
	IF EXISTS(SELECT * FROM deleted d)  
	BEGIN
		declare @iden2 int;
		declare cur2 cursor for select d.id FROM deleted d
		open cur2
		FETCH NEXT FROM cur2 INTO @iden2
		WHILE @@FETCH_STATUS=0
		BEGIN
			IF(not exists (select 1 from platonus_foreignsubjects_trigger t where t.foreign_subject_id=@iden2))
			BEGIN
				INSERT INTO platonus_foreignsubjects_trigger(foreign_subject_id, operation)
				VALUES(@iden2,2);
			END
			ELSE
			BEGIN
				UPDATE platonus_foreignsubjects_trigger SET operation=2 WHERE foreign_subject_id=@iden2;
			END
			FETCH NEXT FROM cur2 INTO @iden2
		END
		close cur2;
		deallocate cur2;	
	END

END
go

