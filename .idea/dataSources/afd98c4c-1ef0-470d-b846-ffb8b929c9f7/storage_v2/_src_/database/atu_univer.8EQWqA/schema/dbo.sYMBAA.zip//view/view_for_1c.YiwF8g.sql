/*s(.student_id_1c IS NULL)*/
CREATE VIEW dbo.view_for_1c
AS
SELECT     s.students_id AS ID, ISNULL(s.students_sname, '') AS Фамилия, ISNULL(s.students_name, '') AS Имя, ISNULL(s.students_father_name, '') AS Отчество, ISNULL(f.faculty_name_ru, '') AS Факультет,
                       s.students_curce_number AS Курс, ISNULL(sp.speciality_okpd, '') + ' ' + ISNULL(sp.speciality_name_ru, '') AS Специальность, st.stage_name_ru AS [Ступень обучения], 
                      el.edu_level_name_ru AS [Уровень обучения], ld.lang_division_name_ru AS [Язык обучения], ef.education_form_name_ru AS [Форма обучения], pf.payment_form_name_ru AS [Форма оплаты], 
                      CASE s.students_sex WHEN 1 THEN N'М' ELSE N'Ж' END AS Пол, s.students_birth_date AS [Дата рождения], 
                      CASE s.students_document_identity_type WHEN 1 THEN N'УДОСТОВЕРЕНИЕ' WHEN 2 THEN N'ПАСПОРТ РК' WHEN 10 THEN N'ДРУГОЙ' WHEN 11 THEN N'СВИДЕТЕЛЬСТВО О РОЖДЕНИИ' ELSE
                       N'' END AS [тип документа], ISNULL(s.students_document_identity_number, '') AS [номер документа], s.students_document_identity_date AS [Дата выдачи], 
                      ISNULL(s.students_document_identity_issued, '') AS [Кем выдан], s.students_udo_validity AS [Действителен до], ISNULL(s.students_identify_code, '') AS ИИН, 
                      c.country_name_ru AS Гражданство,
                          (SELECT     MIN(YEAR(o.order_date)) AS Expr1
                            FROM          dbo.univer_order AS o INNER JOIN
                                                   dbo.univer_order_student_link AS osl ON o.order_id = osl.order_id
                            WHERE      (osl.student_id = s.students_id) AND (o.status IN (21, 22))) AS [Год поступления], ISNULL(s.student_id_1c, '') AS [ID 1с]
FROM         dbo.univer_students AS s INNER JOIN
                      dbo.univer_faculty AS f ON s.faculty_id = f.faculty_id INNER JOIN
                      dbo.univer_speciality AS sp ON s.speciality_id = sp.speciality_id INNER JOIN
                      dbo.univer_stage AS st ON s.stage_id = st.stage_id INNER JOIN
                      dbo.univer_edu_levels AS el ON s.edu_levels_id = el.edu_level_id INNER JOIN
                      dbo.univer_lang_division AS ld ON s.lang_division_id = ld.lang_division_id INNER JOIN
                      dbo.univer_education_form AS ef ON s.education_form_id = ef.education_form_id INNER JOIN
                      dbo.univer_payment_forms AS pf ON s.payment_forms_id = pf.payment_form_id INNER JOIN
                      dbo.univer_country AS c ON s.citizenship_id = c.country_id
WHERE     (s.status = 1) AND (YEAR(s.student_reg_date) = YEAR(GETDATE()) + CASE WHEN month(getdate()) >= 8 THEN 0 ELSE 1 END) AND (MONTH(s.student_reg_date) >= 8)
go

