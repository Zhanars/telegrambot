-- =============================================
-- Author:		Twice
-- Create date: 15.12.2011
-- Description:	Получить общее количество найденных сотрудников
-- =============================================
CREATE FUNCTION [dbo].[sci_univerPersonnel_GetSearchCount] 
(
	-- Add the parameters for the function here
	@fioStr NVARCHAR(80) = '',
	@stdIds integer_list_tbltype READONLY
)
RETURNS int
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result int

	-- Add the T-SQL statements to compute the return value here
	SELECT @Result = COUNT(DISTINCT p.personal_id)
			FROM 
				univer_personal p
				LEFT JOIN univer_personal_struct_pos_link_1c spl ON spl.personal_id = p.personal_id
				AND spl.status = 1 AND dbo.IsPersonalInStrucDivisionByIndPlan(p.personal_id, spl.structure_division_id, 1)=1
				LEFT JOIN univer_personal_position_1c pos ON spl.personal_position_id = pos.personal_position_id
				AND pos.status = 1
			WHERE
				(CHARINDEX(@fioStr, p.personal_sname + ' ' + 
					p.personal_name + ' ' + p.personal_father_name) > 0 
					OR LEN(@fioStr)=0) AND
				spl.structure_division_id in (SELECT n FROM @stdIds) 
				AND
				-- исключить из списка ОбП
				(pos.category_id IS NULL OR
				(pos.category_id IS NOT NULL AND pos.category_id IN (2, 3, 4, 5)))
	-- Return the result of the function
	RETURN Isnull(@Result, 0)

END
go

