CREATE VIEW dbo.univer_ad_sync_students
AS
select isnull(ad.ac_dir_login,user_login) ac_dir_login,
	   isnull(ad.ac_dir_password,'') ac_dir_password,
	   ad.card_id,
	   ad.date_change_ac_dir,
	   isnull(ad.date_change_univer,GETDATE()) date_change_univer,
	   0 drop_password,
	   0 fio_change,
	   st.status,
	   st.students_father_name student_fname,
	   st.students_id student_id,
	   st.students_name  student_name,
	   st.students_sname student_sname,
	   u.user_login collate Cyrillic_General_CI_AS  uni_login,
	   st.students_email e_mail
	   from univer.dbo.univer_students st inner join univer.dbo.univer_users u on st.user_id=u.user_id 
	   left join ac_dir_synch_student ad on ad.student_id=students_id
	   where st.status=1 
union
select isnull(ad.ac_dir_login,user_login) ac_dir_login,
	   isnull(ad.ac_dir_password,'') ac_dir_password,
	   ad.card_id,
	   ad.date_change_ac_dir,
	   isnull(ad.date_change_univer,GETDATE()) date_change_univer,
	   0 drop_password,
	   0 fio_change,
	   st.status,
	   st.additsem_student_fname,
	   0-st.additsem_student_id,
	   st.additsem_student_name,
	   st.additsem_student_sname,
	   u.user_login collate Cyrillic_General_CI_AS  uni_login,
	   '' e_mail
	   from univer.dbo.univer_additsem_student st inner join univer.dbo.univer_users u on st.user_id=u.user_id   and  u.user_last_login>=getdate()-180 
	   left join ac_dir_synch_student ad on ad.student_id=0-st.additsem_student_id
	   where st.status=1 and st.student_id=0

go

