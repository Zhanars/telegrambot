-- =============================================
-- Author:		Sasha
-- Create date: 11.05.2009
-- Description:	Триггер на изменение  офис-регистратора
-- =============================================
CREATE TRIGGER [dbo].[officeRegUpdateTrigger]
   ON  [dbo].[univer_office_registrator] 
   AFTER UPDATE
AS 
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @pi int
	DECLARE @st int
	DECLARE @type int
	
	DECLARE insCursor cursor 
		FOR SELECT personal_id, status FROM inserted
	
	IF UPDATE(status)
	BEGIN
		OPEN insCursor
		FETCH NEXT FROM insCursor INTO @pi, @st
		WHILE @@FETCH_STATUS = 0
		BEGIN
		set @type=(SELECT top 1 type FROM inserted WHERE personal_id=@pi)
		if (@type=1) begin
			IF(@st=1) begin
				EXEC dbo.personalSetAccess @pi, 'OFICE_REGISTRATOR';
				if (select count(*) from univer_office_registrator where personal_id=@pi and status=1 and type=2)=0
				EXEC dbo.personalDeleteAccess @pi, 'METODIST';
				end
			ELSE
				EXEC dbo.personalDeleteAccess @pi, 'OFICE_REGISTRATOR'
		end
		if (@type=2) begin
			IF(@st=1) begin
				EXEC dbo.personalSetAccess @pi, 'METODIST';
				if (select count(*) from univer_office_registrator where personal_id=@pi and status=1 and type=1)=0
				EXEC dbo.personalDeleteAccess @pi, 'OFICE_REGISTRATOR';
				end
			ELSE
				EXEC dbo.personalDeleteAccess @pi, 'METODIST'
		end	
				
			FETCH NEXT FROM insCursor INTO @pi, @st
		END
		CLOSE insCursor
	END
END
go

