-- =============================================
-- Author:		Twice
-- Create date: 14.06.2012
-- Description:	Получить количество научных трудов, опубликованных в международных научных изданиях, входящих в базу данных Scopus - по кафедре
-- =============================================
CREATE FUNCTION [dbo].[IP_NIR_getScopus_Count_ByChairId_DESC] 
(
	@chairId int,
	@year int
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @Result NVARCHAR(MAX) = N''

SELECT @Result = COALESCE(@Result + '\n\n', '') + 
		ISNULL(
		CONVERT(NVARCHAR(MAX), ROW_NUMBER() OVER (ORDER BY dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.paper_id, 2))) +N') '
		+ N'Автор(ы): ' + dbo.IP_NIR_SUPPORT_getAuthorsOfPublication(p.paper_id, 2) 
		+ N'Научная статья\nKZ: ' + p.name_kz + N'\nRU: ' + p.name_ru + N'\nEN: ' + p.name_en 
		+ N'\nЖурнал:' + sj.name, '')
		--AS [description]
	FROM 
		DBScience.dbo.Papers p,
		DBScience.dbo.SciJournals sj
	WHERE
	p.paper_id IN
	(
	SELECT 
		DISTINCT p.paper_id
	FROM
		DBScience.dbo.Papers p,
		DBScience.dbo.L_Person_Paper_Authors a,
		DBScience.dbo.SciJournals sj
	WHERE
		-- статья не архивирована
		p.status != 2 AND
		-- статья должна иметь научный журнал в качестве издания (periodicEditionType)
		sj.sciJournal_id = p.periodicEdition_id AND
		p.periodicEditionType_id = 1 AND
		-- журнал должен иметь галочку "относится к scopus"
		sj.indexedByScopus = 1 AND
		-- статья этого года
		p.yearPublication in (@year, @year+1) AND
		-- статья этого автора (ППС, потому personType = 1)
		p.paper_id = a.paper_id AND
		a.personType = 1 AND 
		a.person_id IN
			(SELECT
				DISTINCT p.personal_id
			FROM
				univer_personal p,
				univer_structure_division_1c sd,
				univer_personal_struct_pos_link_1c spl
			WHERE
				p.personal_id = spl.personal_id AND
				sd.structure_division_id = spl.structure_division_id AND
				sd.structure_division_id = @chairId AND
				spl.status != 2  AND p.status != 2
			)
	) AND p.periodicEdition_id = sj.sciJournal_id
	
-- Return the result of the function
RETURN @Result
END
go

