-- =============================================
-- Author:		YERLAN
-- Create date: 17.08.2017
-- Description:	Определяет является ли студент круглым отличником 
-- =============================================
create FUNCTION [dbo].[IsStudentExcellent] 
(
 @studentId int
)
RETURNS int
AS
BEGIN
	DECLARE @ret int=0;
	DECLARE @notExcellent int=0;
	
	set @notExcellent = (SELECT COUNT(pr.progress_id)
								FROM univer_progress pr, univer_mark_type mt,
									(
										SELECT ac.acpos_semester, ac.acpos_module
										FROM univer_educ_plan ep, univer_students st, univer_academ_calendar_pos ac
										WHERE ep.edu_level_id=st.edu_levels_id AND ep.educ_plan_adm_year=st.educ_plan_adm_year AND ep.speciality_id=st.speciality_id AND ep.education_form_id = st.education_form_id 
											AND ep.educ_plan_id=ac.educ_plan_id AND ac.control_id=0/*период*/ AND st.students_id=@studentId 
											AND ac.acpos_date_end<GETDATE()/*МЕНЬШЕ сегодняшнего дня*/
									) as acc
								WHERE pr.status IN(1,4/*Retake*/) and pr.mark_type_id=mt.mark_type_id AND pr.student_id = @studentId
									AND pr.n_seme=acc.acpos_semester AND pr.acpos_module=acc.acpos_module
									AND mt.mark_type_arg in (2,3,7,4));
	IF (@notExcellent<=0)
	BEGIN
		SET @ret = 1;
	END;
	ELSE
	BEGIN
		SET @ret = 0;
	END;
	
	RETURN isnull(@ret, 0);
END
go

