

-- =============================================
-- Author:		yerlan
-- Create date: 2014-09-07 
-- Description: Включение или отключение триггера в таблице univer_ind_plan_personal
-- =============================================
CREATE PROCEDURE [dbo].[IP_enOrDisIPPTrigger] @type int
AS
BEGIN
	
	IF (@type = 1)
	BEGIN
		ENABLE Trigger dbo.updateToRatingAnketWithCursor ON dbo.univer_ind_plan_personal;
		DISABLE Trigger dbo.insertSUMorAVGofCHAIRorFACULTY ON dbo.univer_ind_plan_personal;
		DISABLE Trigger dbo.updateSUMorAVGofCHAIRorFACULTY ON dbo.univer_ind_plan_personal;
	END
	ELSE
	BEGIN
		DISABLE Trigger dbo.updateToRatingAnketWithCursor ON dbo.univer_ind_plan_personal;
		ENABLE Trigger dbo.insertSUMorAVGofCHAIRorFACULTY ON dbo.univer_ind_plan_personal;
		ENABLE Trigger dbo.updateSUMorAVGofCHAIRorFACULTY ON dbo.univer_ind_plan_personal;
	END
END
go

