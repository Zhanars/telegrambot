

CREATE VIEW [dbo].[site_personal_subjects]
AS
SELECT DISTINCT 
                      TOP (100) PERCENT p.personal_id, sb.subject_id, sb.subject_name_ru, sb.subject_name_kz, f.faculty_name_kz, f.faculty_name_ru, st.stage_id, st.stage_name_kz, 
                      st.stage_name_ru, spec.speciality_id, spec.speciality_name_kz, spec.speciality_name_ru, spec.faculty_id
FROM         dbo.univer_personal AS p INNER JOIN
                      dbo.univer_teacher AS te ON p.personal_id = te.personal_id INNER JOIN
                      dbo.univer_educ_plan AS ep INNER JOIN
                      dbo.univer_educ_plan_pos AS pp ON ep.educ_plan_id = pp.educ_plan_id INNER JOIN
                      dbo.univer_speciality AS spec ON ep.speciality_id = spec.speciality_id INNER JOIN
                      dbo.univer_stage AS st ON spec.stage_id = st.stage_id INNER JOIN
                      dbo.univer_faculty AS f ON spec.faculty_id = f.faculty_id INNER JOIN
                      dbo.univer_group AS g ON pp.educ_plan_pos_id = g.educ_plan_pos_id INNER JOIN
                      dbo.univer_subject AS sb ON pp.subject_id = sb.subject_id ON te.teacher_id = g.teacher_id
WHERE     (f.status = 1) AND (pp.status = 1) AND (sb.status = 1) AND (st.status = 1) AND (spec.status = 1) AND (te.status = 1) AND (ep.status = 1) AND (sb.subject_type IN (0, 1)) 
                      AND
                          ((SELECT     COUNT(*) AS Expr1
                              FROM         dbo.univer_group_student AS gs
                              WHERE     (group_id = g.group_id)) > 0)
ORDER BY st.stage_id


go

