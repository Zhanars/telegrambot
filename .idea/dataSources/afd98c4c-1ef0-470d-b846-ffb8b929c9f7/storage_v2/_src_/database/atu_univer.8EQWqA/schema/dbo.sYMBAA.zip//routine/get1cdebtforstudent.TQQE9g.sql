
-- =============================================
-- Author:		Sasha
-- Create date: 12.05.2016
-- Description:	Подсчет суммы долга 1с по студенту
-- =============================================
CREATE FUNCTION [dbo].[get1cDebtForStudent]
(
 @studentId int
)
RETURNS float
AS
BEGIN
	DECLARE @ret float

	/*select @ret=SUM(d._1c_student_contract_debt) from 
		_1c_univer_student_contract_debt d, 
		_1c_univer_student_contract c left join _1c_univer_student_contract_delay d2 on d2._1c_student_contract_id=c._1c_student_contract_id, 
		_1c_univer_student s 
	where 
	d._1c_student_contract_id=c._1c_student_contract_id and 
	c._1c_student_id=s._1c_student_id /*and 
	c._1c_student_contract_type_id<>2*/ and 
	s._1c_univer_student_id=@studentId and 
	d._1c_student_contract_debt<0 and  
	isnull(d2._1c_student_contract_to,getdate()-1)<GETDATE()*/
	select @ret=debt  from _1c_univer_student_total_debt where student_id=@studentId;

	RETURN isnull(@ret,0);

END

go

