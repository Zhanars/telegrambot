CREATE TRIGGER [dbo].[TriggerForPlatonus]
   ON  [dbo].[univer_order_student_link]
   AFTER insert , update , delete
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	/*Delete trigger*/
	if exists(select * from deleted d) and not exists(select * from inserted d)
	begin
		delete from platonus_univer_order_student_link where order_id in (select d.order_id from deleted d) and student_id in (select d.student_id from deleted d);

		insert into platonus_univer_order_student_link (order_id, student_id, operation)
		select order_id, student_id,2 from deleted;
	end;

	/*Insert trigger*/
	else if(not exists(select * from deleted d) and exists(select * from inserted i))
	begin
		insert into platonus_univer_order_student_link (order_id, student_id, operation)
		select i.order_id, i.student_id, (case when (select top 1 status from univer_order o where o.order_id=i.order_id)=2 then 2 else 1 end) from inserted i where not exists(select * from platonus_univer_order_student_link l 
		where l.order_id=i.order_id and l.student_id=i.student_id) 
		and i.order_id in(select order_id from univer_order o where o.order_type_id 
		in(
		 1  /*Приказ на зачисление*/
		,8  /*Приказ о переводе из другого ВУЗа*/
		,10 /*Приказ о восстановлении*/
		,20 /*Перевод в пределах АТУ*/
		,70 /*Приказ на отчисление*/
		,80 /*Приказ о выпуске*/
		,71 /*Приказ о выпуске докторантов PhD*/
		));
	end;

	/*Update trigger*/
	else if(exists(select * from deleted d) and exists(select * from inserted i))
	begin 
		delete from platonus_univer_order_student_link where order_id in (select d.order_id from deleted d) and student_id in (select d.student_id from deleted d);
		delete from platonus_univer_order_student_link where order_id in (select d.order_id from inserted d) and student_id in (select d.student_id from inserted d);
		/*Delete*/
		insert into platonus_univer_order_student_link (order_id, student_id, operation)
		select order_id, student_id,2 from deleted WHERE order_id not in(select order_id from inserted);

		insert into platonus_univer_order_student_link (order_id, student_id, operation)
		select i.order_id, i.student_id, (case when (select top 1 status from univer_order o where o.order_id=i.order_id)=2 then 2 else 1 end) from inserted i 
		where not exists(select * from platonus_univer_order_student_link l where l.order_id=i.order_id and l.student_id=i.student_id) 
		and i.order_id in(select order_id from univer_order o where o.order_type_id 
		in(
		 1  /*Приказ на зачисление*/
		,8  /*Приказ о переводе из другого ВУЗа*/
		,10 /*Приказ о восстановлении*/
		,20 /*Перевод в пределах АТУ*/
		,70 /*Приказ на отчисление*/
		,80 /*Приказ о выпуске*/
		,71 /*Приказ о выпуске докторантов PhD*/
		));
	end;
END

go

