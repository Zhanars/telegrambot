-- =============================================
-- Author:		Twice
-- Create date: 31.01.2012
-- Description: Получить количество студентов, магистрантов, Phd-докторантов, привлекаемых на оплачиваемой основе к исследованиям по проектам фундаментальных,  прикладных и хоздоговорных работ (1 - бакалавры, 2 - магистранты, 3 - докторанты) - в разрезе кафедр
-- =============================================
CREATE FUNCTION IP_NIR_getStudentsInRAD_Count_ByChairId_DESC
(
	@chairId int,
	@year int,
	@studentEducStageId int
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
DECLARE @Result NVARCHAR(MAX)

SELECT @Result = N''

-- Return the result of the function
RETURN @Result

END
go

