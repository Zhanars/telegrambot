
-- =============================================
-- Author:		Yerlan
-- Create date: 2013-11-01 17:44:33.680
-- Description:	Добавление записи о том что данные дисциплины были изменены (триггер токо для UPDATE,так как при добавлении у дисциплины статус еще не StatusNormal)
-- =============================================
CREATE TRIGGER [dbo].[subjectUpdateTriggerForPlatonus]
   ON  [dbo].[univer_educ_plan_pos] 
   AFTER UPDATE,INSERT,DELETE
AS 
BEGIN
	
	IF @@ROWCOUNT =0
    RETURN
	
	SET NOCOUNT ON;
	
	--Insert block, all new inserted subject_id will be writed as update
	IF EXISTS(SELECT * FROM inserted) AND NOT EXISTS(SELECT * FROM deleted)
	BEGIN
		INSERT INTO platonus_univer_subject(subject_id, command)
		SELECT DISTINCT subject_id,'update' FROM inserted i 
		WHERE i.status=1 AND i.subject_id NOT IN (SELECT subject_id FROM platonus_univer_subject)
	END
	
	
	--Update block, all new updated subject_id will be writed as update, and old subject_id from deleted will be writed as delete.
	--This block usually triggers when programmer updates subject_id in educ_plan_pos table to zips catalog of subject.
	--Delete will trigger only for subject_id changing
	IF (UPDATE(subject_id) OR UPDATE(rup_kz) OR UPDATE(rup_ru) OR UPDATE(rup_en)) AND EXISTS(SELECT * FROM inserted) AND EXISTS(SELECT * FROM deleted)
	BEGIN
		INSERT INTO platonus_univer_subject(subject_id, command)
		SELECT DISTINCT d.subject_id,'delete' 
		FROM deleted d JOIN inserted i ON d.educ_plan_pos_id=i.educ_plan_pos_id AND d.subject_id<>i.subject_id 
		AND d.subject_id NOT IN (SELECT subject_id FROM platonus_univer_subject)
		
		INSERT INTO platonus_univer_subject(subject_id, command)
		SELECT DISTINCT i.subject_id,'update' 
		FROM inserted i JOIN deleted d ON d.educ_plan_pos_id=i.educ_plan_pos_id 
		AND (d.subject_id<>i.subject_id 
			OR ISNULL(d.rup_kz,'') <> ISNULL(i.rup_kz,'') 
			OR ISNULL(d.rup_ru,'') <> ISNULL(i.rup_ru,'') 
			OR ISNULL(d.rup_en,'') <> ISNULL(i.rup_en,''))
		AND i.subject_id NOT IN (SELECT subject_id FROM platonus_univer_subject)
	END
	
	--DELETE block, in univer there are only 2 ways: insert and delete. 
	IF EXISTS(SELECT * FROM deleted d WHERE d.status=1) AND NOT EXISTS(SELECT * FROM inserted i)
	BEGIN
		INSERT INTO platonus_univer_subject(subject_id,command)
		SELECT DISTINCT subject_id,'delete' FROM deleted i 
		WHERE i.status=1 AND i.subject_id NOT IN (SELECT subject_id FROM platonus_univer_subject)
		AND NOT EXISTS(SELECT * FROM univer_progress p WHERE p.subject_id=i.subject_id AND p.status=1)
	END
END

go

